# AWS (EC2) hosting - DEATH DEVELOPMENT

1. Launch Ubuntu 22.04/24.04 (t3.small / 2 GB RAM or more recommended; 1 GB works only with the swap the script adds).
2. Upload and unzip the bot, then run ONE command (it asks for the token once, writes `.env`, installs everything and starts the bot):
   ```bash
   cd botfast
   bash deploy/setup_aws.sh
   ```
   Or fully non-interactive: `TOKEN=your_token bash deploy/setup_aws.sh`
   Live logs: `journalctl -u deathbot -f`
3. Discord Developer Portal -> Bot: turn ON **Presence**, **Server Members**, **Message Content** intents (needed or the bot exits with a clear message).
4. Music: needs a Lavalink node (`lavalink/docker-compose.yml`, Java 17+) and `LAVALINK_URI` / `LAVALINK_PASSWORD` in `.env`. Without it the rest of the bot still runs.
5. Keep-alive web server uses port 8080 (set `PORT=` to change, `DISABLE_KEEPALIVE=1` to turn off). You do NOT need to open it in the security group.

Common errors
* `PrivilegedIntentsRequired` -> step 3.   * `externally-managed-environment` -> use the venv (the script does).
* `No module named ...` -> run with `.venv/bin/python`, not system python.
* `unable to open database file` -> fixed: the bot now always runs from its own folder.
* Killed / out of memory -> add swap (script does) or use a bigger instance.
