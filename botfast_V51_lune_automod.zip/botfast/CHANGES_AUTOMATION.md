# Automation update

## New
- Help menu category **Automation** (select menu) listing all autorole commands.
- Autorole commands rebuilt to match the reference screenshots (group pages with « ‹ <:bin:1567102784552304640> › » pager,
  Autorole Added / Removed / Permission Error / Nothing to Reset / Configuration panels).

## Removed
- Autorole listing removed from the *Server Commands* help page (it lives under Automation now).

## Speed
- Autorole data is cached in memory (`utils/autorole_store.py`): joins and `config` never hit the disk.
- Several roles on join are sent to Discord in parallel.
- Removed the bot-wide `max_concurrency` lock and the 3s cooldowns from the autorole commands.
- `eval()` removed; old `db/autorole.db` data is read as-is.

## Hosting fixes
- `discord-ext-menus` was missing from requirements (crash on a clean host) -> built-in fallback `utils/_menus_shim.py`.
- `pkg_resources` import (removed in new setuptools) replaced with `importlib.metadata`.
- Autorole DB path no longer depends on the working directory; a corrupt file is moved aside instead of crashing.

# Autoresponder category update

## New
- Help menu category **Autoresponder** (select menu) with two sections: *Autoresponder* and *Autoreact*.
- `autoresponder` / `autoreact` (alias `react`) rebuilt to match the reference screenshots:
  group page `AUTOREACT GROUP` with the « ‹ <:bin:1567102784552304640> › » pager, `✔ Trigger Added`, `✖ No Triggers Set`, pink result panels.
- Help for these commands uses the same panels (`utils/autoresponder_ui.py`).

## Removed
- Autoresponder / Auto React listing removed from the *Server Commands* help page.
- `cogs/events/autoreact.py` (a second listener, now merged into the autoreact cog).

## Fixes
- Autoresponder crashed in DMs (`message.guild` was `None`) and answered other bots (loop risk).
- Autoreact never matched uppercase triggers, ignored many emojis (e.g. ☑ ✔ <a:star_white:1567124664558297180> flags, skin tones) and could save a trigger with zero emojis.
- Unknown custom emojis are rejected when adding, instead of failing silently on every message.
- Listener could raise `KeyError` on its 5s rate-limit set and blocked while waiting; now a small per-user cooldown + background task.
- Bot no longer tries to send/react without permission.
- Removed global `max_concurrency` locks and cooldowns from these commands.

## Speed
- Both modules are cached in memory (`utils/autoresponder_store.py`): no SQL on normal messages, writes in a worker thread.
- Old `db/autoresponder.db` and `db/autoreact.db` data is read as-is.

# Leaderboard category update

## New
- Help menu category **Leaderboard** (select menu) with the sections VoiceLeaderboard, MessageLeaderboard,
  InviteLeaderboard, LiveLeaderboard and TopLeaderboard (same command list as the reference bot).
- New cog `cogs/commands/leaderboard.py` (+ `utils/leaderboard_store.py`, `utils/leaderboard_ui.py`).
- Every command has its own help panel (`?help top messages` -> Command Usage + Aliases); groups use the « ‹ <:bin:1567102784552304640> › » pager.

## Removed
- Old **Invite Tracker** help category (`cogs/axon/inviteTracker.py`) and its commands (`cogs/commands/InviteTracker.py`).
- Old `messages` cog and the unused `msgpack` cog (replaced by the message leaderboard; old counts from
  `db/messages.db` are imported automatically once into `db/leaderboard.db`).

## Speed
- Message / voice counting happens in memory and is written in ONE batched transaction every 10 s
  (boards still show real-time numbers, because every read flushes first).
- Settings, blacklists and reward roles are cached; the message listener never touches the disk.
- One shared SQLite connection in WAL mode instead of connect-per-command.

## Notes
- Voice time is counted per UTC day; "weekly" = the last 7 days. AFK channel is not counted.
- Invite tracking needs the `Manage Server` permission. Accounts younger than 7 days count as fake invites
  (`setaltthreshold <days>`, `0` = off, `unsetaltthreshold` = back to 7).
- `setmessagerole` / `setinviterole <amount> <role>` give the role automatically when the amount is reached.

# Premium category update

## New
- Help menu category **Premium** (`cogs/axon/premium.py`), built live from the real commands.
- `cogs/commands/premium.py`: activate, botavatar, botbanner, botbio, botname, botreset, customise,
  customisereset, deactivate, premium, premiumstats, servernoprefix (same names/aliases/descriptions as the reference).
- **`cmdalias`** (aliases: customalias, setalias, commandalias, calias): `add <alias> <command>`, `remove`, `list`, `reset`.
  Any server admin can give any main command their own alias (max 50 per server).
- Owner-only hidden commands: `premiumadd <user> [slots] [30d|2w|1mo|1y|lifetime]`, `premiumremove <user>`, `premiumlist`.
  Bot owners (`OWNER_IDS`) automatically have unlimited premium for testing.
- `servernoprefix add/remove/list/reset`: up to 10 members per server; works together with the global `np` system.

## Speed
- `utils/premium_store.py`: everything in memory, SQLite (db/premium.db) written in a worker thread.
- `core/axon.py`: `get_prefix` checks server no-prefix from memory; `get_context` resolves aliases only when no real command matched.

## Fixes
- `np.py`: `staff` table was never created on a fresh database (`load_staff` crashed with "no such table").
- Premium expiry loop auto-deactivates expired servers and resets the bot's per-server look.
