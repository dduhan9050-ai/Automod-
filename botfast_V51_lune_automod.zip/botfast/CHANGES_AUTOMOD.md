# Automod rebuild

## Removed
- Old automod cog (`automod enable/disable/punishment/config/logging/ignore/unignore`), its engine and the old help
  category (`__Automod__`, "Automod Commands").
- Old `blacklistword` cog (`cogs/commands/blacklist.py`: add/remove/reset/config/bypass). `blword` is now part of Automod.
- Old tables in `db/automod.db` / `db/blword.db` are no longer used (new tables are `am_*` in `db/automod.db`).

## New commands (same as the reference screenshots)
`automod`, `automod enable`, `automod logging [channel|off]`, `automod reset`, `automod manage`, `automod settings`,
`automod wlshow`, `automod whitelist`, `automod disable`,
`blword`, `blword add`, `blword remove`, `blword show`, `blword reset`, `blword guide`.
- Command replies are Components V2 containers with accent colour **#ffffff**.
- Help menu: new **Automod** category ("Automod" + "Word Blacklist" lists). That page is plain (no white bar).
- `.automod` / `.blword` group help: paginated (7 per page) with first / prev / delete / next / last buttons.
- Allowed: Administrator, Server Owner, Extraowner.

## 13 filters with a heat system
Anti spam, Anti caps, Anti link, Anti invites, Anti mass mention, Anti emoji spam, Anti NSFW link,
Anti attachment spam, Anti zalgo spam, Similar message spam, Character limit spam, New line spam, Blacklist word.
- Every filter adds heat (configurable per filter in `automod settings`, defaults as in the screenshot) to a per-user
  heat bar. Heat cools down 4/second. At 100 the punishment of the biggest contributor is applied and the bar resets.
- Anti NSFW link and Blacklist word are fixed at 100 (Max): they punish instantly.
- Punishments: `Auto Mute` (timeout 5 > 10 > 30 > 60 > 180 min for repeat offenders, resets after 1 h), `Kick`, `Ban`, `Warn`.
- `automod whitelist`: per filter roles, channels/categories and users. `automod wlshow` lists them.
- `blword`: wildcards `word`, `word*`, `*word`, `*word*`; evasion detection (spaces, dots, symbols, fullwidth,
  accents, zalgo, zero-width). Max 100 words per server.
- Edited messages are scanned too (not spam / similar / attachment counters).

## Speed
- Whole config in RAM, zero DB reads per message; one `on_message` + one `on_message_edit` listener.
- Only enabled filters run, cheap checks first, one precompiled regex per guild for the blacklist,
  invite lookups cached 10 min, delete + punish run together, notice + log are background tasks.

## Files
`utils/automod_core.py` (filters, heat constants, matcher), `utils/automod_ui.py`, `cogs/automod/store.py`,
`cogs/automod/engine.py`, `cogs/commands/automod.py`, `cogs/axon/automod.py`;
small hooks in `cogs/__init__.py` (old Blacklist cog removed) and `cogs/commands/help.py`.
Bot permissions needed: Manage Messages, Timeout Members (Kick/Ban Members for those punishments),
Manage Channels (only for the auto-created `automod-logs` channel).
