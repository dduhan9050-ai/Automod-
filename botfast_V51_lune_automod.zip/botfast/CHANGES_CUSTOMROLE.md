# CustomRole module (ZEON style)

- REMOVED help category "Server Commands" (`cogs/axon/server.py`).
- REMOVED old Death commands: `setup` (+ create/delete/list/staff/girl/friend/vip/guest/config/reset/reqrole) and
  `staff`, `girl`, `friend`, `vip`, `guest`.
- NEW `cogs/commands/customrole.py`: `customrole`, `customrole create|delete|list|reqrole|reset`.
  Custom command usage: `<prefix><name> <member>` toggles the role (Role Added / Role Removed).
  Existing data in `db/customrole.db` is kept (same tables). Per-guild in-memory cache, no DB hit per message.
- NEW help category "CustomRole" (`cogs/axon/customrole.py`); its help-menu container has NO accent colour.
- Every customrole reply / group help is a white (#ffffff) Components V2 card.
- `components_v2.NO_ACCENT` sentinel: `Container(accent_colour=NO_ACCENT)` = container without accent bar.
- Not run against Discord (static compile check only).
