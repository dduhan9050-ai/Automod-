# General module rebuild

* Removed the old **Utility Commands** and **General Commands** help categories and every command inside them
  (`cogs/commands/extra.py`, old `cogs/commands/general.py`, `cogs/axon/extra.py`, old `cogs/axon/general.py`,
  and the old `stats` command in `cogs/commands/stats.py`).
* New **General** category (`cogs/commands/general.py`, help page in `cogs/axon/general.py`):
  * Basic: afk (existing), membercount, boostcount, joinedat, serverinfo, userinfo, channelinfo, roleinfo,
    avatar, banner, servericon, serverbanner, profile, vote
  * Bot Information: invite, stats, botinfo, ping
  * List: list + users, emojis, boosters, bots, admins, mods, roles, inrole, invoice, joinedat, createdat,
    early, bans, activedeveloper, bughunters, hypesquad, pending, channels, timeouts, hasperms
* Every reply is a Components V2 container with accent colour `#ffffff` (`utils/general_ui.py`).
* Lists use one paginator (`‹ <:bin:1567102784552304640> › ↕ page`), `list` itself uses the `« ‹ <:bin:1567102784552304640> › »` help paginator.
* `badges` lost its `profile`/`pr` aliases (now owned by the new `profile` command).
* Optional env vars for extra link buttons: `WEBSITE_URL`, `DOCS_URL`, `STATUS_URL`.
