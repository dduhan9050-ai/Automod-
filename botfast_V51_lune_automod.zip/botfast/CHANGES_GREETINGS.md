# Greetings module (replaces Welcomer)

## Removed
* `cogs/commands/welcome.py` (Welcomer cog + all its `greet ...` commands)
* `cogs/axon/welcome.py` (the "Welcomer Commands" help category)
* `cogs/events/greet2.py` (old welcome listener)
* `db/welcome.db` is imported once into `db/greetings.db` on first start, then renamed to `welcome.db.migrated`.

## New: `cogs/greetings/greet.py` (cog `Greetings`)
* Help-menu category **Greetings** (`help_plain = True` -> help container has no accent colour).
* Every command reply is a white `#ffffff` Components V2 card.
* `greet` group: `setup [channel]`, `channel [channel]`, `enable`, `disable`, `autodelete [seconds]`,
  `config`, `test`, `reset`, `edit` (+ hidden `welcomesetup`).
* `greet setup` / `greet edit` open the configuration menu: dropdown (Message, Author, Title, Description,
  Thumbnail toggle, Main Image, Footer, Color, Auto Delete) + green **Save** button.
  Only one open menu per channel ("You already have an active welcome configuration menu in this channel...").
* Placeholders are the same as before: `{user} {user_name} {user_id} {user_nick} {user_avatar}
  {user_joindate} {user_createdate} {server_name} {server_id} {server_membercount} {server_icon}`.

## Speed
* Whole config table is preloaded into memory; a member join never touches SQLite.
* Welcome message is built/sent in its own task -> joins are greeted in parallel, listener returns instantly.
* DB is written only on Save / config commands.

## Not touched
* `FastGreet` (`fastgreet_add/remove/list`) is a separate module and stays as it was.
* Not run against Discord (static compile check only).

## Update: colourless containers
* `components_v2._install_white_accent` now strips missing and #ffffff accents, so no card (help menu or command replies) has a colour bar. Other explicit colours (e.g. the welcome message colour picked in the menu) are kept.
* To get white cards back, set `kwargs["accent_colour"] = WHITE` for the missing/white case in that function.
