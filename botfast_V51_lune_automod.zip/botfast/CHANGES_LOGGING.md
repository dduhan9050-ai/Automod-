# Logging rebuild

## Removed
- Old logging cog (`loggingsetup`, `removelogs`, `Axon-logging` category, 8 log types) and the old help category `Loggingdrop`.
- Old `logging.db` (root) is no longer used; new data lives in `db/logging.db`.

## New commands (same as the reference screenshots)
`logging`, `logging config`, `logging enable`, `logging disable`, `logging remove <type>`, `logging wizard`,
`logging setup` (`auto`, `channel <type|all> <#channel>`, `clear`),
`logging ignore` (`add <entity>`, `remove <entity>`, `embed`, `voice`).
- All replies are Components V2 containers with accent colour **#ffffff**.
- Help menu: new **Logging** category ("Logging Commands" page); group/command help pages are white V2 too.
- Allowed: Administrator, Server Owner, Extraowner.

## 16 log types, delivered by webhook
system, join, leave, member, message, thread, voice, stage, moderation, channel, server, event, webhook, role, application, alert.
`logging setup auto` creates the private category `<:emoji_19:1566458847613419591> | Server Logs`, one channel per type and one webhook per channel.
- Ignore Embeds: skip messages that contain embeds. Ignore Voice: skip voice/stage channel create/update/delete, their invites and chat.
- "Who did it" footers come from the audit-log gateway event (needs `View Audit Log`); webhook/application/kick logs need it too.

## Speed
- Whole config is in memory; a log event does one dict lookup and exits when logging is off.
- First embed of a burst is sent instantly; embeds queued while a request is in flight are merged (max 10/message). Per-channel queues.
- Deleted log webhook is re-created automatically.
- Executors via gateway audit entries (no REST calls). Raw message events (no cache dependency).

## Files
`utils/logging_store.py`, `utils/logging_ui.py`, `utils/logging_setup.py`, `cogs/commands/logging.py`,
`cogs/logsys/{core,engine}.py`, `cogs/axon/logging.py`; small hooks in `cogs/__init__.py`, `cogs/commands/help.py`, `components_v2.py` (`legacy_embed` opt-out so log embeds stay real embeds).
Bot permissions needed: Manage Channels, Manage Webhooks, View Audit Log.
