# Moderation rebuild

## Removed
- Old moderation cogs (`cogs/moderation/*`: ban, unban, mute, lock, hide, kick, warn, role, message, topcheck, snipe, moderation).
- `jail` / `unjail` / `jailhistory` (replaced by quarantine).
- Autorole commands + their listener + the **Automation** help category.
- Old `steal` cog (now part of Moderation) and the old "Moderation Commands" help category.

## New (`cogs/mod/`)
- Help category **Moderation**: Basic / Role / Purge / Quarantine command lists.
- 70 commands, prefix only. Every reply is a Components V2 card, accent `#ffffff`, with <:emoji_4:1566043104551768114> success / <a:cross:1567096105299214336> denied / <a:warn:1567101252712530020> error.
- Group + command help in the same layout as the reference (`« ‹ <:bin:1567102784552304640> › ` pager, aliases line).
- Quarantine: `setup [role] [channel]` auto-creates the **Quarantine** role + `#quarantine` channel and denies the role
  in every category/channel. Channels created later are locked automatically. `add` auto-runs setup if needed.
  Roles are saved and restored on `remove` / `unquarantine`; rejoining while quarantined re-applies the role.

## Speed
- Zero disk reads on the command path (caches + in-memory quarantine data, SQLite writes in a background thread).
- One API call per action (ban/kick/mute/role edit/quarantine = a single request); DMs are fire-and-forget.
- Bulk jobs (lockall, role all, unbanall, quarantine setup) run with parallel workers.
- No cooldowns / max_concurrency locks; purge never touches messages older than 14 days one-by-one.

## Notes
- `unlock`/`unhide` reset the @everyone overwrite to neutral (not "allow").
- `nuke` has no confirmation. Slash versions of the old commands are gone.
- Quarantine/deleteafter data: `db/zmod.db`.
