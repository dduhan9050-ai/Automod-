# Music module - fixes

## Bot leaving the VC right after `play`
Cause: when a track failed to load (YouTube blocked / old Lavalink / Spotify mirror failure) Lavalink
sends `track_end(loadFailed)`; the old code treated that as "queue finished" and left after 2s.
Now:
* load failures retry the same song on SoundCloud / YT Music / YouTube (skipping the failed source) and tell the channel
* if nothing can play, the bot says so and waits 30s instead of leaving instantly
* leaving is debounced (cancelled the moment any track starts) - no more race with autoplay/queue
* Discord close code 4017 (DAVE) is detected and tells you the node must be Lavalink >= 4.2.0

## Platforms
* YouTube, YouTube Music, SoundCloud, Spotify (via LavaSrc), JioSaavn
* Spotify track / album / playlist links work in `play`; `search` has a Spotify option
* `play sc: name`, `sp: name`, `yt: name`, `ytm: name` force a platform
* plain `play name` searches YouTube + SoundCloud + YT Music in parallel; best-priority hit wins,
  so a blocked YouTube no longer means "No results found"
* old code used wavelink's default `ytmsearch` for plain text - now explicit

## Speed
* join VC and search run at the same time
* parallel multi-source search, 7s timeout per search
* no more `queue.get_wait()` (could deadlock the guild lock)
* no fixed sleeps in track_end

## Glitches fixed
* double-connect when two `play` were sent quickly (connect is now locked)
* requester tracking via track.extras (no id()-keyed dict leak)
* `stop` keeps the bot in the VC when 24/7 is on
* `seek`/`replay` on streams no longer error
* node connect retries with backoff instead of giving up forever; node-ready check uses a *connected* node
* startup log shows Lavalink version + plugins (warns if YouTube/LavaSrc plugin is missing)
* playlists capped at 1000 tracks

## Lavalink server (`lavalink/` folder)
`application.yml` + `docker-compose.yml` for Lavalink 4.2+ with youtube-plugin + LavaSrc (Spotify).
Set SPOTIFY_CLIENT_ID / SPOTIFY_CLIENT_SECRET (free, developer.spotify.com/dashboard).


# V37 - every music platform + real error messages

## Platforms (play / search / links)
* Prefixes: `yt:` `ytm:` `sp:` `sc:` `am:` (Apple Music) `dz:` (Deezer) `js:` (JioSaavn) `ym:` (Yandex)
  `vk:` `td:` (Tidal) `qb:` (Qobuz). `search` dropdown lists every platform the node really has.
* Links are recognised for YouTube / YT Music, Spotify, Apple Music, Deezer, JioSaavn, Yandex, VK, Tidal,
  Qobuz, SoundCloud (incl. on.soundcloud.com / snd.sc), Bandcamp, Twitch, Vimeo and direct mp3/radio URLs.
* New command `platforms` (alias `sources`): shows what the Lavalink node supports right now + Lavalink version.
* The node's `/v4/info` is read on every (re)connect; platforms the node lacks are hidden from the dropdown,
  skipped in the fallback chain and named in the error message.

## Errors are now explained
Before: every failure said "No results found." Now it says why, e.g. YouTube bot-check (-> enable OAuth/poToken),
age-restricted / private, platform missing on the node, wrong API key, rate limit, search timeout.
A track that fails mid-queue also shows Lavalink's reason.

## Bugs fixed
* Requester on the Now-Playing card was lost (wavelink rebuilds the track and drops `extras`) -> restored
  from `payload.original`.
* Node connect retry created a new Node every attempt and never removed dead ones (leak + log spam);
  it now reuses a pooled node and ejects dead ones.
* `play` no longer leaves a dangling voice-join task if the search is cancelled.
* Spotify-missing hint wrongly appeared/vanished (used plugin names instead of real source managers).

## Lavalink server (`lavalink/application.yml`)
* Every LavaSrc platform is toggled by env (`APPLEMUSIC_ENABLED`, `DEEZER_ENABLED`, `YANDEX_ENABLED`,
  `VK_ENABLED`, `TIDAL_ENABLED`, `QOBUZ_ENABLED`, `JIOSAAVN_ENABLED`) with its key in `.env.example`.
  All default OFF (except Spotify as before) so a missing key can never stop the node from booting.
* No keys needed for: YouTube, YT Music, SoundCloud, Bandcamp, Twitch, Vimeo, direct links.
* Tidal / Qobuz / VK / JioSaavn need a LavaSrc release that includes them - bump the `lavasrc-plugin`
  version (and `youtube-plugin`) to the newest release before enabling them.


# V38 - instant Lavalink connect
* Node supervisor: retries every 3s forever (old code backed off to 60s and gave up on empty config values), so music starts working seconds after Lavalink comes up - no bot restart.
* `play` / `join` with no node yet now trigger an immediate reconnect and wait up to 8s instead of failing with "Music is not available".
* If Lavalink restarts/drops later, the bot reconnects by itself and restores 24/7 channels (stale players are dropped on a non-resumed session).
* `LAVALINK_PASSWORD` defaults to `youshallnotpass` (same as docker-compose), so only `LAVALINK_URI` is needed.
* Node uses `retries=None` (never stop reconnecting) + 15s heartbeat; each connect attempt is bounded to 12s.
