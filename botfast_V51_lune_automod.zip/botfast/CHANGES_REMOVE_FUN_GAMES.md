# Fun + Games removed

Deleted cogs (code + help entries + loader entries):
* Fun  : `cogs/commands/fun.py` (mydog, image, howgay, lesbian, chutiya, tharki, horny, cute, intelligence, gif,
         iplookup, weather, fakeban, hug, kiss, pat, cuddle, slap, tickle, spank, kill, 8ball, truth, dare, translate)
         `cogs/commands/ship.py` (ship - it was listed in the Fun help category)
         `cogs/axon/fun.py` (Fun help category)
* Games: `cogs/commands/Games.py` (chess, rps, tic-tac-toe, wordle, 2048, memory-game, number-slider, battleship,
         country-guesser, connectfour, lights-out), `cogs/commands/slots.py`, `cogs/commands/blackjack.py`,
         `cogs/axon/games.py` (Games help category)

Deleted data / assets:
* `games/` package (all game logic, button games, country flags/data, fonts, words.txt, emoji assets)
* `data/cards/`, `data/ship/`, `data/pictures/{mydog.jpg,slot-face.png,slot-reel.png,table.png}`

Cleaned references: `cogs/__init__.py` (imports + _COGS), `requirements.txt` + `preflight.py` (python-chess was
only used by chess), old changelog lines about the country game / blackjack / ship.

The SQLite databases had no fun/game tables, so nothing had to be dropped there.
Kept on purpose: `hinglish` (translate cog), `imagine.py` (already disabled), `data/pictures/{album_image,spotify,
spotify_card_output,player}.png` (used by the status/music cards).
