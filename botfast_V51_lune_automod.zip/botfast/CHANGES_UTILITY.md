# Utility module (embed / sticky / reactionrole)

## Help menu
* Giveaway removed from the help menu (`cogs/axon/giveaway.py` deleted). The giveaway commands themselves still work.
* New **Utility** category (`cogs/utility/helpcat.py`): Embed System, Sticky Message, Reaction Role.
* Duplicates deleted: old `embed` (cogs/commands/Embed.py), `createrr`, `dmrr` (cogs/commands/reactionroles.py).
  Old reaction roles from `rr.db` are imported automatically on first start (file is renamed to `rr.db.migrated`).

## Commands (all cards are Components V2, accent #ffffff)
* `embed` create / edit / show / delete / rename / save / export / import / send   (+ `/variables [module]`)
* `sticky` add / remove / bump / show / channel add / channel remove
* `reactionrole` (alias `rr`) add / addmany / remove / edit / clear / clone / format (alias `mode`) / maxroles / info / show
  * formats: `normal`, `unique`, `verify`, `reverse`

## Speed
* `utils/utility_store.py`: everything is cached in memory; reaction + sticky listeners never touch SQLite.
* Writes are queued to one background writer (batched commits to `db/utility.db`).
* Sticky re-post: new message is sent while the old one is deleted in parallel, bursts coalesced per channel (0.8 s).
* Saved embeds can be used in sticky messages with `{embed:name}`.
