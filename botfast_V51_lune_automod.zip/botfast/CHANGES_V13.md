# V13 - bug fixes, speed, duplicate cleanup

## Removed duplicates
- `cogs/commands/image.py` (never loaded, defined a second `girl` command that clashed with the Customrole `girl`).
- Old vanityroles / vanity help cogs replaced by the new single module (see V12).

## Speed (no DB work per message any more)
- `events/mention.py`: returns immediately unless the message is a bare bot mention (was 3 DB queries on EVERY message).
- `commands/afk.py`: in-memory set of AFK users; DB only touched when an AFK user speaks / is mentioned.
- `commands/Media.py`: media channel cached per guild (invalidated on setup/remove); table created on cog load.
- `commands/blacklist.py` (blacklistword): words / bypass users / bypass roles cached 60s, invalidated on every write.
- `commands/customrole.py`: custom-role lookup cached per guild (invalidated on create/delete/reset).
- `commands/owner.py`: badge icons downloaded once (with timeout) instead of per render.
- `commands/map.py`: rewritten - async geocoding (old code blocked the whole bot with `requests`, no timeout).

## Bugs fixed
- `Errors.py`: crashes inside commands were swallowed silently. Now logged with traceback + short message to the user; Forbidden gets a clear permission message.
- `customrole.py` listener crashed in DMs (`message.guild` None) and on a bare prefix (`split()[0]`).
- `blacklist.py` word filter crashed when the message was already deleted / no permission.
- `map.py` buttons used invalid emoji names (Discord rejected the message) and answered interactions twice.
- `.avatar.url` on users with default avatars raised AttributeError (Errors, owner, help, giveaway, nightmode, emergency) -> `display_avatar`.
- `mention.py`: hard-coded other bot's invite client id -> uses this bot's id.
- `app.py`: Flask keep-alive thread is now a daemon (process exits cleanly).

## V13.1 - secrets, branding, access
- Removed hard-coded API keys (RapidAPI, Giphy, Google, OpenWeather, MapQuest) - now read from `.env` (see `.env.example`);
  commands reply with a clear "not configured" message when a key is missing. ROTATE the old keys, they were public in the source.
- gif / image / weather / map requests now URL-encode the query (`params=`); weather no longer crashes on an invalid key.
- `blacklist_check` / `ignore_check` no longer crash in DMs (clean "can't use in DMs" message).
- Removed a hard-coded foreign user id that had owner-level bypass in `emergency`, `owner` and silent command-log skip -> now uses `OWNER_IDS` from `utils/config.py`.
- Branding -> Death Development (footers, config NAME/BotName, support link = `serverLink`); dead Website buttons removed.
- Remaining foreign id bypasses (nightmode / automation_ui) removed or mapped to OWNER_IDS.
