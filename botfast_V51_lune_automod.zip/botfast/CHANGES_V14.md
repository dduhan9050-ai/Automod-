# V14 - bug fixes + speed pass

> Verification: static only (every file compiles, AST scans for undefined names / blocking calls /
> duplicate commands are clean). The bot was NOT run against Discord (needs your token).
> Run `python preflight.py` then `python app.py` and watch the "Loaded N/78 cogs" line.

## Bugs fixed
- **autoblacklist.py (critical)**: the guild-flood check counted EVERY chat message, so any server with >8
  messages in 2s got the whole guild blacklisted. It now counts real command runs (`on_command`). Also fixed a
  crash from a non-existent `guild_settings` table, double "Guild Blacklisted" embeds, and new blacklist
  entries now take effect immediately (cache invalidated).
- **core/Context.py**: `ctx.error()` was called (owner purge command) but never defined -> AttributeError.
  Added `ctx.error()` / `ctx.success()`. `ctx.session` pointed to a non-existent `bot.session` -> now a shared
  aiohttp session on the bot.
- **owner.py**: `Counter` was never imported (crash in the purge command); badge icons were downloaded with
  blocking `requests.get` inside the command, freezing the whole bot -> prefetched in parallel threads.
- **notify.py**: crash when a stream has no URL; "is now live" fired on every presence tick instead of when the
  stream starts.
- **Invc.py**: crash when the VC role was deleted (`add_roles(None)`).
- **np.py**: crash if the log channel isn't cached/visible (after the no-prefix grant had already happened).
- **axon.py**: editing ANY old message re-executed its command; now only messages < 2 min old.
- **cogs/__init__.py**: one broken cog aborted loading of every cog after it; each cog now loads independently
  and failures are listed at the end.

## Speed
- `fastgreet.py`: blocking `sqlite3` in `on_member_join` and commands -> async + cached; channels greeted in parallel.
- `Invc.py`: voice listener did a DB query on every mute/deafen toggle -> ignores non join/leave/move events,
  role id cached per guild.
- `notify.py`: presence listener (busiest gateway event) returns before touching the DB; config cached 60s.
- `autoblacklist.py`: per-message hot path is now one in-memory bucket check (no list rebuilds, no DB reads).
- `app.py`: optional `uvloop`; Flask thread replaced by a tiny in-loop aiohttp health endpoint (set `PORT`,
  or `DISABLE_KEEPALIVE=1`); removed blocking `os.system("clear")`; command-log webhook goes through a bounded
  queue (never slows commands, never piles up tasks); clean shutdown.
- `requirements.txt`: `discord.py[voice,speed]` (orjson/aiodns/Brotli) + `uvloop`. Run `pip install -r requirements.txt`.
- `OWNER_IDS`: removed duplicate id.

## Noticed but NOT changed (your call)
- `notifications` table (setnotif) is global, not per guild: a second server can't configure Twitch/YouTube
  (UNIQUE on `type`) and `setnotif reset` wipes every server's config. Needs a `guild_id` column + migration.
- `Intents.all()` incl. `presences`: needed only by vanity roles + stream notifications. If you can live
  without those, turning presences off is the biggest remaining CPU/RAM saving on large bots.
- `np.py` still pings a hard-coded user id and posts to a hard-coded log channel id.
- `owner.py` keeps a module-level sync sqlite connection for badges (local + tiny, left as is).
