# V15 - image commands, antinuke recovery, command rate-limit protection

> Static checks only (compile + undefined-name scan + unit test of utils/ratelimit.py). The bot was NOT run
> against Discord (needs your token). Run `python preflight.py`, `python app.py` and test in a server.

## 1. avatar / banner / servericon / serverbanner not working  (FIXED)
Root cause: `discord.ui.MediaGalleryItem` does not exist - the class is `discord.MediaGalleryItem`.
Every image card raised `AttributeError`. New helper `components_v2.media_gallery(*urls)` is used everywhere
(general, greet images, map, emojis, utilkit, ticket_ui, embed->V2 conversion).
Also: format buttons can't crash the command any more, `banner` handles a failed fetch, new aliases
`sicon/guildicon` and `sbanner/guildbanner`.

## 2. Antinuke recovery (channels / roles)  (REWORKED)  - cogs/antinuke/engine.py
- Failures are no longer silent: retries transient Discord errors, logs the reason, and the antinuke log
  channel shows `Recovery: <a:cross:1567096105299214336> (reason)` (e.g. "Missing permissions / role hierarchy").
- Deleted channel: restored from the cached snapshot, or (fallback) rebuilt from the audit-log data; position restored.
- Deleted role: restored (perms, colour, hoist, position) AND its members get the role back
  (member list is captured right before discord.py strips the role).
- Channel update revert now also restores category + position.
- Snapshots are kept whenever antinuke is enabled (works even if autorecovery is switched on afterwards).
- `antinuke enable` on a fresh server now turns **Auto Recovery ON** by default.
- IMPORTANT for existing servers: run `>antinuke config` - if "Auto Recovery" shows <a:cross:1567096105299214336>, run `>antinuke autorecovery enable`.
- The bot needs Manage Channels + Manage Roles + Ban Members, and its top role must be ABOVE the roles it restores/bans.

## 3. Rate-limit protection with escalating temporary blacklist  (NEW)  - utils/ratelimit.py
- More than 5 commands in 3 s, or more than 10 in 20 s  ->  user is blocked for **10 min**.
- Every repeat doubles it: 10m -> 20m -> 40m -> 1h20m -> 2h40m ... (cap 7 days). Strikes reset after 7 clean days.
- Runs as a global check (`bot.add_check(..., call_once=True)`), RAM-only on the hot path, persisted in `db/ratelimit.db`.
- The blocked user gets ONE notice (with the remaining time), then at most one reminder per minute - no reply spam.
- Bot owners are exempt. Mention-spam (`@bot`) and media-channel spam now use the same temporary system instead
  of the old permanent blacklist (the permanent `blacklist` commands still work as before).
- Owner commands: `>tempblock list`, `>tempblock clear <user>`, `>tempblock add <user> [minutes]` (aliases `tbl`, `ratelimit`).
- Tunable via env: `RL_BASE_BLOCK` (seconds, default 600), `RL_MAX_BLOCK`, `RL_STRIKE_RESET`; thresholds in `WINDOWS`.

## 4. Premium help design + Bot Owner category
- New `utils/grouphelp.py`: group help card (title, `usage` / ❯ description, "Requested by | Page n/m", « ‹ <:bin:1567102784552304640> › »).
- `premium` is now a group. Bot owners running `>premium` get the card; normal users still get the premium info embed.
  Owner-only subcommands (page 1/2): `list`, `add <user> [duration=30d] [guild_limit=1] [reason]`, `activate`, `revoke`,
  `remove <user> [reason]` — page 2/2: `status [user]`.  The old hidden `premiumadd/premiumremove/premiumlist` are replaced by these.
- New help category **Bot Owner** (<a:crownn:1567121063194918967>) = premium group + tempblock group. It is invisible to everyone except bot owners.
- The **Customize** help page now uses the same style (`usage` + ❯ description).

## 5. New owner + data reset
- `utils/config.py`: `OWNER_IDS = [937212899380834314]` (old owners removed). np.py log pings now mention the new owner.
- Cleared (rows only, tables kept): db/np.db (no-prefix users), db/anti.db (old antinuke servers + whitelist/extra owners),
  db/prefix.db, db/afk.db, db/messages.db, db/media.db, db/welcome.db, db/stats.db.
- Not touched: np.py still has the OLD support-server id (699587669059174461), np role id and old log channel ids hard-coded.
