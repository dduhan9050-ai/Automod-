# V38 - Antinuke: barrier role, recovery, speed
Static checks only (py_compile). Not run against Discord - test with `>antinuke wizard` in a server.

## Barrier role (cogs/antinuke/engine.py: ensure_barrier / _watch_barrier)
- Created with **Administrator** (or exactly the bot's own permissions if the bot has no Administrator).
- Always worn by the bot and placed **directly below the bot's highest role**.
- Re-orders itself automatically (debounced, 1s) when roles move/are created/deleted, when the bot's roles change,
  when its permissions are edited, if it is deleted (re-created), and once at startup for every antinuke guild.
- Errors are no longer swallowed: wizard shows the real problem (hierarchy / Manage Roles).

## Recovery
- Root cause: `antinuke wizard` (and `enable` on an existing config) never switched **Auto Recovery** on. Both now do.
- Role-update revert uses the audit-log diff (old values) first: instant, no snapshot wait, works if the event was missed.
- Channel-update revert falls back to the audit diff when the snapshot is missing.
- Existing servers: run `>antinuke autorecovery enable` once (or re-run the wizard).

## Speed
- No up-to-2s snapshot wait for role reverts; retry back-off 0.6s -> 0.25s; role-member give-back concurrency 5 -> 10.

## Lowest-latency pass
- Ban goes straight to `bot.http.ban` (no Object/guild.ban wrapper); the DM yields first so the ban is written to the socket first.
- Keep-warm loop (8s, only when some guild has antinuke enabled): keeps the HTTPS connection to Discord alive so the first ban never pays a new TLS handshake.
