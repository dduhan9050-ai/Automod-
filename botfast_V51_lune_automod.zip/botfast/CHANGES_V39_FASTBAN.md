# V39 - Antinuke fastest ban/kick punishment
Static check only (py_compile). Test in a server with a non-whitelisted alt: delete a channel / kick someone and read the log line.

## What changed (cogs/antinuke/engine.py)
- Raw fast path: `GUILD_AUDIT_LOG_ENTRY_CREATE` parser is wrapped. If the executor is NOT whitelisted for that module
  (and not owner / bot / main-role), the ban is queued straight from the raw gateway dict - before AuditLogEntry is built
  and before any listener (logsys etc.) runs. Whitelisted users + betrayal guard + member-role-update still use the old listener.
- The listener reuses the already-running ban task (no double ban) and still does recovery + log afterwards.
- DM now starts 5 ms AFTER the ban request, so it can never compete with the ban.
- Keep-warm: 4 parallel connections every 6s (was 1 every 8s). Ban + recovery + DM each need their own warm TLS connection.
- Logs: `antinuke ban ok guild=.. rtt=..ms event_age=..ms`  (rtt = our request to Discord, event_age = how old the audit entry was on arrival).
- `event loop lag` warning if anything blocks the loop >50 ms.

## V39b - recovery fixes + more speed
- BUG FIXED (channel/role create revert): the audit entry often arrives before discord.py has cached the new channel/role, so
  `guild.get_channel()/get_role()` was None and the delete was silently skipped. Now deleted by id (raw HTTP).
- Dangerous-role removal (member role update) now removes by id in parallel, no member cache needed.
- Channel restore from audit data passes `position` in the create call (one request fewer).
- Recovery retries only 5xx/429 (4xx are our mistake, retry just wasted time); back-off 0.15s.
- Every recovery is logged: `antinuke recovery rec_xxx ok guild=.. in ..ms` or `FAILED guild=..: reason`.
- Startup warning lists protected guilds that still have Auto Recovery OFF (nothing is reverted there) -> `antinuke autorecovery enable`.
- Ban and recovery tasks use Python 3.12 eager start: they run to their first await immediately instead of queueing behind other loop callbacks (3.11 falls back automatically).

## V39c
- DM removed completely: antinuke punishment is now ban-only (no DM-channel request, no extra connection use). Log card no longer has the "Member DM" line.
- Keep-warm now 6 parallel connections.

## V39d
- Raw fast path now also covers member role update (dangerous role GRANT), so kick / ban / role & channel actions / role grant are all punished from the raw gateway data.
- Antinuke log card is sent 1s after the action as a background task, so it never competes with the ban or recovery.

## V39e
- Raw hook now makes the COMPLETE verdict (whitelist, main roles, betrayal-guard limits) and passes it to the listener by audit-entry id. Whitelisted users who exceed their limit are banned from the raw path too; nothing is judged or counted twice.

## V39f
- GC tuning 45s after startup: gc.freeze() + higher thresholds, so a full garbage collection cannot freeze the loop during a nuke.
- core/axon.py: DISCORD_PRESENCES=0 in .env turns the presence intent off (PRESENCE_UPDATE is the busiest gateway event, parsed on the same loop as antinuke). Default stays 1 because vanityroles/notify need it.

## V39g
- Direct ban: the PUT /guilds/{id}/bans/{uid} request is prebuilt at startup (URL base, auth/user-agent headers, JSON body, cached reason header) and written straight onto the warm discord.py aiohttp session - no Route / rate-limit bookkeeping / header+JSON building per ban. 204 = done, 403/404 = refused; 429 / 5xx / any surprise falls back to bot.http.ban automatically. Log shows `ban ok (direct)`.
- Logic tested with a stub harness (raw hook, whitelist, betrayal limit, owner/bot ignore, 429 fallback, listener reuse, no double ban). Not tested against real Discord / real discord.py.
