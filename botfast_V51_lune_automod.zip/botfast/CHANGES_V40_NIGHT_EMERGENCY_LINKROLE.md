# V40 - Nightmode, Emergency, Anti Link Role
Static checks only (py_compile + matcher/parser unit tests). Not run against Discord - test in a server.
No automod files were touched.

## Anti Linked Role (new antinuke module)
- Blocks Discord **Linked Roles** (roles with connection / app requirements). The moment a role becomes a linked role
  (created as one, or requirements added) it is deleted, and whoever did it is found in the audit log and judged like every
  other module (not whitelisted = ban, whitelisted + betrayal guard = limit). Server owner and the bot are exempt.
- The delete does not wait for the audit lookup. Works even with Auto Recovery off.
- Command: `antinuke linkrole enable|disable` (alias `lr`); also in `antinuke manage`, `whitelist`, `limit linkrole <n>`.
- Not testable offline: relies on Discord marking such roles with the "guild connection" role tag. If a role cannot be
  deleted (missing permission) it is logged in the console.

## Nightmode (cogs/commands/nightmode.py, rewritten)
- Parallel role edits (6 at once), no 50-member rule, strips Administrator, Manage Roles/Channels/Server/Webhooks/Expressions,
  Ban, Kick, Timeout, Mention Everyone - also from @everyone. Restore gives back exactly the stripped bits.
- `nightmode enable [30m|8h|1d]` (auto-disable timer), `disable`, `status`, `exempt add/remove/list`,
  `schedule set <start> <end> [utc offset]` / `off` / `view` (daily automatic night mode, e.g. `23:00 07:00 +5:30`).
- While ON, a role that gets or is created with a dangerous permission is stripped again immediately.
- Old-nightmode servers (old table) are still restored correctly.

## Emergency (cogs/commands/emergency.py)
- `emgs` now runs in parallel, also strips @everyone, deletes every invite and pauses new invites, saves the moved
  role's old position. Running it twice no longer loses the restore data. No antinuke pause any more (bot actions are ignored).
- `emgrestore` restores permissions in parallel, puts the moved role back, re-opens invites.
- New: `emergency lockdown` / `unlock` (exact restore of channel overwrites), `emergency auto enable|disable`
  (antinuke bans a nuker -> emergency runs by itself), `emergency status`.
- Per-guild lock + max_concurrency per guild (was global).

## Help
- Security category now lists Antinuke, Mainrole, Nightmode and Emergency commands.
