# V42 - antinuke faster + lag-free pass over the other modules
Static checks only (compileall + a stub harness for the antinuke raw-recovery logic). NOT run against Discord.
Test in a server: `>antinuke wizard`, then nuke-test with a non-whitelisted alt.

## Antinuke (cogs/antinuke/engine.py)
- Raw-path recovery: for id-only reverts (created channel / role / webhook deleted, ban / unban undone, added bot kicked)
  the recovery now starts from the raw gateway dict next to the ban, instead of waiting for the listener task to be
  scheduled behind every other cog's listener. Under a mass nuke this removes the queueing delay.
  The listener finds the already-running task by audit-entry id and reuses it (nothing runs twice). Needs Auto Recovery ON.
- Deleted role restore: members get the role back in parallel with the position fix (used to wait for it).
- Already-punished attacker: recovery of their remaining actions starts from the raw hook too.

## Other modules (everything that could block or slow the event loop - antinuke shares that loop)
- Help (`?help`): banners/logo were 1.3 MB + 1 MB PNG uploaded on EVERY category click (24 MB of assets).
  Now JPEG 1400px / 512px logo (assets 24.2 MB -> 0.9 MB) and the bytes are cached in RAM (no disk read per click).
  Files renamed: help_banner*.png -> .jpg, help_logo.png -> help_logo.jpg (utils/help.py updated; .png still accepted for new banners).
- `hinglish` (translate): deep-translator is blocking HTTP; it froze the whole bot for the request time. Now in a worker thread.
- `status`: Spotify card used a new aiohttp session per call, wrote a shared temp file and ran PIL on the loop.
  Now shared session + PIL in a thread + in-memory PNG (also fixes two users clashing on the same temp file).
- Media channel: 2 SQLite queries per message -> one cached lookup (10 s), only for messages without attachments.
- Giveaway: `on_message_delete` ran a DB query for EVERY deleted message in EVERY server (and crashed on DMs); cheap checks first now.
- `blacklist list` / `staff_list`: fetch_user one-by-one -> cache first + parallel.
- Owner-mention reaction listener: skips every message that has no mention.

## Already fine (checked, left as is)
AFK, autoresponder, autoreact, automod, logging (gateway audit buffer, no REST), leaderboard, sticky, customrole, greetings,
fastgreet, vanity roles, voice roles, nightmode, emergency (parallel edits), tickets, stores (RAM + worker threads).

## Not changed
- Owner-only bulk commands (global ban/kick/nick) still go one guild at a time on purpose (rate limits).
- Music is still loaded; remove `Music`/`_music` from cogs/__init__.py `_COGS` if you no longer want it.

## V42b - less gateway noise on the antinuke loop
- `intents.typing = False` (core/axon.py): TYPING_START is no longer received/parsed (no cog uses on_typing).
- Presence filter (antinuke engine): PRESENCE_UPDATE (busiest event, parsed on the same loop as the raw ban hook) is dropped
  for servers where nobody uses it. It is still parsed for servers with Vanity Roles, and for ALL servers while stream-notify
  (`notify` command) is configured (checked every 30 s). Side effect: `status` shows stale online/offline in other servers.
  Set `PRESENCE_FILTER=0` in .env to turn the filter off.
