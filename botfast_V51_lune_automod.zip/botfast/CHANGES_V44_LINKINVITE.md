# V44 - Linked Role protection, invite attribution, X/Y verification, selective lockdown

Status: **tested with doubles only** (60 unit/integration tests, all passing). It has NOT been run against real
Discord. Do the post-deploy checks at the bottom before trusting it.

## What changed (4 files touched, 1 new)
| File | Change |
|---|---|
| `cogs/antinuke/linkinvite.py` | **NEW** cog `LinkInvite` (all new logic) |
| `cogs/antinuke/engine.py` | +11 lines: 3 hook calls (`on_guild_role_create`, `on_member_update`, `on_audit_log_entry_create`). No listener added or removed (10 before, 10 after). |
| `cogs/__init__.py` | import + register `LinkInvite` after `AntinukeEngine` |
| `tests/`, `reports/`, `deploy/*_linkinvite.sh` | tests, benchmark, reports, upgrade + rollback |

Nothing existing was removed. The engine still deletes a Linked Role and punishes its creator exactly as in V43
(`antinuke linkrole`); the new code runs **first, in the same tick**, so dangerous bits are stripped even when the delete
fails (e.g. hierarchy), and the forensic record exists either way.

## Behaviour
1. **Linked role created** (engine hook, sync) -> if it holds Administrator / Manage Server / Manage Roles, only those bits are
   removed with one direct `PATCH` (hierarchy pre-checked, transient errors retried, 403 never retried). Original bitfield is
   kept in RAM first and written to `db/linkinvite.db` concurrently (never awaited before the PATCH). First original is never
   overwritten (`INSERT OR IGNORE`).
2. **X** = account that created the role. Taken from the gateway audit entry the engine already receives (no REST); falls back
   to two audit-log REST attempts; `None` if audit logs are unavailable. Kept 1 hour (RAM + DB), then expires and is purged.
3. **Receiver monitoring**: a member gaining a monitored role is recorded (member, role, time). Owner, this bot, linked-role
   whitelist, main-roles and whitelisted bots are exempt (the existing antinuke lists). Nobody is banned for receiving a role.
4. **Y** = inviter of the receiver, recorded at join time by invite use-count diff (one `guild.invites()` call per join, joins
   serialised per guild, nothing fetched for untracked guilds). Vanity joins -> `VANITY` with no inviter. Missing Manage Server,
   simultaneous joins, restart gaps -> `UNAVAILABLE` / `AMBIGUOUS` / `UNKNOWN`. An inviter is never invented.
5. **Cross-verification**
   | X | Y | Result |
   |---|---|---|
   | known | same as X | `CONFIRMED` -> ban only if every evidence check passes (role was dangerous, X still alive, attribution was a normal invite, neither side trusted, inviter below the bot) |
   | known | different | `MISMATCH` -> alert + evidence, no action |
   | missing | known | `X_MISSING` -> alert only |
   | known | missing | `Y_MISSING` -> alert; lockdown if threshold met |
   | missing | missing | `UNKNOWN` -> alert; lockdown if threshold met |
6. **Selective lockdown** only on `UNKNOWN` / `Y_MISSING` **and** score >= threshold (default 2 = distinct flagged roles +
   distinct receivers inside 600 s; per-guild `?linkinvite threshold <n> [seconds]`). Removes exactly the three bits from roles
   strictly below the bot's top role, excluding the bot's own roles, `mainroles`, the barrier role, whitelisted bots' roles.
   `@everyone` is eligible. Snapshot is committed (bounded 0.5 s wait) before the first PATCH; edits run 8 at a time.
   Per-guild state machine `idle -> applying -> locked -> restoring -> idle`, claimed synchronously, so duplicates are refused.
7. **Recovery** `?linkinvite unlock [force]` (owner): a role still equal to what lockdown set gets its original back; a role
   someone edited since is **not overwritten** (reported, original kept in the event log); `force` re-adds only the stripped
   bits. Failed roles keep their snapshot row and can be retried. After a crash `applying`/`restoring` resume at startup.
   `?linkinvite restore <role_id>` undoes a strip on a wrongly flagged role.

## Owner commands (`?linkinvite`, alias `?lrp`)
`status` (default) | `threshold <events> [seconds]` | `unlock [force]` | `restore <role_id>` | `evidence [n]`

## Database (additive, automatic)
New file `db/linkinvite.db` (WAL, one writer thread). Tables: `li_events` (append-only forensic log, 90 d), `li_roles`,
`li_candidates`, `li_invites`, `li_joins` (30 d), `li_lockdown`, `li_snapshots`, `li_config`. No existing database or table is
modified, so no migration step is needed and rollback leaves it harmlessly in place.

## Requirements / limits you should know
- Bot needs **Manage Server** (to read invites) and **View Audit Log**; without them attribution is honestly `UNAVAILABLE`.
- Discord does not report which invite was used; Y is inference. Several joins at the same instant become `AMBIGUOUS`.
- Joins that happen while the bot is offline are detected as a gap (`offline_gap` event) but cannot be attributed.
- Role edits are rate limited by Discord; a large lockdown (hundreds of roles) will take as long as Discord allows.
- X is the role **creator**; the spec's "invite creator candidate" is ambiguous, so this is the interpretation used.
  If you meant something else, only `_handle_linked_role` / `_resolve_x` change.
- Timings in `reports/BENCHMARK_REPORT.md` are bot-side only. No claim is made about Discord's response time.

## Deploy (AWS Ubuntu, existing systemd unit untouched)
```bash
# on the VPS: unpack the new zip NEXT TO production, never over it
unzip DEATH_DEVELOPMENT_FAST_V44_linkinvite.zip -d ~/botfast_new
cd ~/botfast_new/botfast
bash deploy/upgrade_linkinvite.sh /path/to/production/botfast
```
The script: checks Python/discord.py -> compiles + runs the tests **in staging** -> tar backup (`~/deathbot_backups`) -> copies
only the changed files (deletes nothing, leaves `.env`, `deathbot.service`, databases alone) -> restarts -> greps the journal
for `Loaded N/N cogs`, `Failed to load cog`, tracebacks -> **rolls back automatically** if verification fails.
Manual run of the tests: `python -m unittest discover -s tests -v`.

## Rollback
```bash
bash deploy/rollback_linkinvite.sh /path/to/production/botfast     # uses ~/deathbot_backups/LAST_BACKUP
```
Restores `engine.py` + `cogs/__init__.py` from the backup, removes `linkinvite.py`, restarts, checks the service is active.
If a lockdown was active, run `?linkinvite unlock` BEFORE rolling back (the old code does not know the snapshots; they stay
in `db/linkinvite.db` and the original bitfields are in `li_snapshots`).

## Verify after deploy (real Discord, test server)
1. `journalctl -u deathbot -n 80 | grep -E "Loaded|Failed|linkinvite"` -> no failed cog.
2. `?linkinvite` -> `invite cache: ready`, state `idle`.
3. Create a Linked Role with Administrator in a throw-away server -> permissions drop to the non-dangerous remainder;
   `?linkinvite evidence` shows `linked_role_stripped` and `candidate_x`.
4. Join with an alt via a normal invite, give it the (stripped) role from a second account -> `cross_verify` event.
5. `?linkinvite unlock` after a test lockdown -> originals restored; check `li_event` lines in the journal.
