# V46 - Anti Bot Nuker + Bot Add Authorization

Status: **tested with doubles only** (44 new tests, all passing). Not run against real Discord and discord.py was not
installable in the build sandbox. Do the post-deploy checks at the bottom first.

## Files
| File | Change |
|---|---|
| `cogs/antinuke/botguard.py` | **NEW** cog `BotGuard` (all logic) |
| `cogs/commands/antinuke.py` | + `integration`, `botadd`, `extraowner add/remove/list`; help pages; hooks in enable / wizard / disable / config |
| `utils/antinuke_ui.py` | `group_help_view(..., extra_pages=None)` - new optional arg, default behaviour unchanged |
| `cogs/axon/antinuke.py`, `cogs/__init__.py` | help text lines, cog registration |
| `utils/config.py`, `.env.example` | `EXTRA_OWNER_IDS = []` (+ env `EXTRA_OWNER_IDS=1,2`) |
| `tests/test_botguard.py`, `tests/_compat.py` | tests; stub enum gained a few members |

Engine, linkinvite, `antinuke_store` and its DB are **not modified**. New DB: `db/botguard.db` (flags, extra owners,
bot-role snapshot, append-only `bg_events`).

## Behaviour
**Bot Add** - `on_member_join` (bot) -> audit log `bot_add` (<= 5 polls, <= 5.8 s) -> only Server Owner / Extra Owners are
authorized. Else: kick bot -> ban executor -> log -> DM owner. Executor not identifiable = **nothing is punished**, owner is told.
**Bot role** - snapshot of my managed role (perms + rank). Reconciled on role update / delete / integration update. Harmful =
lost perms, moved down, deleted. Sequence: verify executor -> strip attacker's dangerous *roles* (only the attacker; shared roles
are never edited) -> restore my role (re-read via `fetch_roles` before claiming success) -> ban -> log.
Owner / Extra Owner / me = change accepted, snapshot updated. Whitelisted for Anti Integration or mainrole = alert only.
Unidentified executor = my role is restored (if possible) but nobody is punished.
**Removal** - guild-remove / integration-delete: owner is DM'd; the card says plainly I cannot re-add myself.

## Decisions you may want to change
1. Both modules are **OFF until enabled**; `antinuke enable` and the wizard switch them on for new setups. Existing servers
   are not silently changed.
2. Bot Add policy follows your spec strictly: antinuke-**whitelisted** users are *not* authorized to add bots (the old engine allowed them).
3. `on/off/snapshot` and extra-owner changes: Server Owner + Extra Owners only. `status` / `list`: also whitelisted users.
4. "Owner log channel" = the existing per-server antinuke log channel (`antinuke logging`), plus a DM to the Server Owner.
5. `EXTRA_OWNER_IDS` in config applies to every server; per-server extras are added with the command.
6. Restore respects the existing Auto Recovery flag.

## Limits (Discord, not bugs)
- Discord cannot block a bot add beforehand; reaction is after the join.
- **A bot cannot edit its own highest role.** Restore works only if I wear an extra role above my integration role that also grants
  Manage Roles. `antinuke integration status` shows "Can restore now" and why not.
- A deleted/removed integration cannot be self-recovered; a managed role cannot be recreated.
- Position-only changes are usually not audit-logged -> alert + restore, no punishment.
- Changes made while the bot is offline are reported, never auto-reverted.

## Post-deploy checks
Run `python -m unittest discover -s tests`. NOTE: 7 tests in `test_linkinvite.py` fail in the sandbox *with or without* these
changes (pre-existing; they ran against stub discord) - confirm on the real install. Then on a test server: add a bot as an admin,
as owner, as extra owner; strip my role perms with a lower admin; check `?antinuke` pages show both modules.

## Speed update
- Executor now comes from the **gateway audit entry** (`on_audit_log_entry_create`, no REST, no polling). If the entry arrives
  just after the join/role event it is awaited event-driven (max 0.6 s) before falling back to the bounded REST polling.
  Entries are single-use and expire after 60 s.
- Bot add: kick and ban are sent **at the same time** (steps still logged in order).
- Role events settle 50 ms (was 300 ms). Strip -> restore -> ban order is unchanged (spec).
- Every security log card now shows `handled in N ms` (bot-side, handler start to log) and whether it used the gateway or REST.
  Use those numbers for your real timings. 48 tests pass (doubles only).

## Max-speed update
- **Raw gateway hook** (chained in front of discord.py's audit parser, like the engine's): an unauthorized bot add is decided from the
  raw audit dict in RAM and kick + ban are sent from an eager task - no member_join, no member cache, no REST lookup, no listeners.
  Authorized adds, garbage payloads and disabled guilds are ignored in the hook. `member_join` stays as fallback (shared claim -> no double punishment).
- Bans use the engine's pre-warmed direct PUT (`_direct_ban`) when present, else discord.py.
- Role flow: executor hint seeded from the raw dict; API confirmations (member / roles re-read) run **after** the ban, in parallel.
  Action order strip -> restore -> ban is unchanged; the "ok" claims are still only made after the re-read.
- Log cards show `punishment sent in N ms` and `handled in N ms (raw gateway | gateway audit entry | audit-log REST)`.
- 55 botguard tests (doubles only). Bug fixed on the way: eager tasks are now referenced (no GC).

## Command Permission Protection (Integrations page)
- Raw audit action **121** (application command permissions updated) for MY application -> executor checked: Owner / Extra Owner = recorded only;
  whitelisted = alert only; anyone else = strip + ban (parallel) + log + owner DM. Burst of edits = one incident.
- Restore is NOT possible (Discord: command permissions need a user OAuth token); the card says `impossible` and the owner must reset them.
- Works through the raw gateway hook only (needs it to read the application id). Action id 121 and the `options.application_id`
  field are from memory of Discord's docs - verify on a real server (edit /play permissions as a test admin).
- 58 botguard tests (doubles only).
