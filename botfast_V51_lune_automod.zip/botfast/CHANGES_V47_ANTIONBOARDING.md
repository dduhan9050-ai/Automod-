# V47 - Anti-Onboarding (inside AntiNuke)

Status: **tested with doubles only** (62 new tests, all passing; 5 safety mutations were each caught). Not run against real Discord;
discord.py could not be installed in the build sandbox. Do the post-deploy checks at the bottom first.

## Files
| File | Change |
|---|---|
| `cogs/antinuke/onboardguard.py` | **NEW** cog `OnboardGuard` (all logic, inside the antinuke package like BotGuard / LinkInvite) |
| `cogs/commands/antinuke.py` | + `antinuke onboarding on/off/status/scan/clean`, `antinuke onboarding trust add/remove/list`; help page; hooks in enable / wizard / disable / config |
| `cogs/axon/antinuke.py` | Anti-Onboarding line in the Security help body |
| `cogs/__init__.py` | cog registration |
| `tests/test_onboardguard.py` | tests |

Engine, linkinvite, botguard, `antinuke_store` and `utils/antinuke_ui.py` are **not modified**. No new help category: the page
is appended to the existing `antinuke` help menu (same Components V2 pager as Anti Bot Nuker). New DB: `db/onboardguard.db`
(flag, trusted list, append-only `ob_events`).

## What Discord gives us (nothing is assumed beyond this)
- Onboarding config changes: audit actions 163-167. They say WHO touched onboarding, not WHICH role was added, so the added role is found by diffing `GET /guilds/{id}/onboarding` against the last confirmed read.
- Roles handed out by onboarding: only a `GUILD_MEMBER_UPDATE`. No dedicated event. The person responsible is therefore the person who **configured** the role.
- A role already in onboarding that later gains Administrator: role-update audit (action 31).
Detection layers: raw gateway hook (RAM only, no REST) -> normal listeners (same events, claimed so nothing runs twice) -> periodic poll (every 10 min, spread over guilds) -> startup baseline.

## Policy (the executor must be VERIFIED; Owner, Extra Owners and the trusted list are exempt)
| Situation | verified unauthorized | executor unverified |
|---|---|---|
| Admin role added to onboarding | clean config, delete role (if safe), **ban** | clean config, alert |
| Admin role handed to a member | remove from member, clean config, delete role (if safe), **ban** configurer | remove from member, clean config, alert |
| Onboarding role gains Administrator | revert permission, clean config, **ban** | clean config, alert (role not edited) |
| Other dangerous perms (Manage Roles/Guild/Channels/Webhooks, Ban, Kick, Moderate) | clean / remove / revert, **no ban** | alert only |
"Verified" = exactly ONE distinct person touched onboarding in the 20 s window (gateway entry, else one REST read). Two people, none, or an
unreadable audit log = unverified = nobody is banned or has a role deleted. Every audit entry is consumed once. For roles handed out later, the configurer is
taken from the remembered config change, or one audit entry from the last 10 min that names the role id; older = unverified.
- The **affected member** is never banned, kicked, timed out or stripped of other roles; only the one dangerous role is removed. Exempt members keep it.
- **Deletion guards**: never deleted if managed, mainrole/barrier, @everyone, if the member cache is incomplete, or if any non-affected member already holds it (it would demote them). In that case it is cleaned from onboarding and the log says why.
- Bans go through BotGuard's `_ban` (shares the engine's `flagged` claim: no double ban) and are confirmed with `fetch_ban`.

## Honesty
Each step is `ok` only after a re-read: member (`fetch_member`), role (`fetch_roles`), config (`GET` after `PUT`), ban (`fetch_ban`). Otherwise `failed` / `blocked` / `unverified`.

## Emergency lockdown
If removing, deleting, reverting or cleaning ends `failed`/`blocked` **and** a re-read shows the role still exists with dangerous permissions (or cannot be re-read): `Emergency._lockdown` runs (120 s cooldown; plus `auto_trigger` if `emergency auto` is on), the owner is DM'd and the log channel gets the card, then failed steps are retried at +1.5 s and +4 s (hierarchy-blocked steps are not retried). `emergency unlock` undoes the lockdown. If the role is gone the lockdown is skipped.

## Config cleaning
Reads fresh, edits only `role_ids`, writes, reads again. Options left with no role and no channel (Discord rejects them) and empty prompts are dropped and listed in `ob_events`. Writes are serialised per guild. The config is re-checked after every incident.

## Decisions you may want to change
1. Opt-in for existing servers (`antinuke onboarding on`); `antinuke enable` and the wizard switch it on for new setups only.
2. Trust = Owner + Extra Owners (from BotGuard) + `antinuke onboarding trust`. Antinuke-whitelisted users are NOT auto-trusted.
3. A first look at a server only reports dangerous roles already configured (history unknown); `antinuke onboarding clean` removes them.
4. `DELETE_MAX_OTHER_HOLDERS = 0` in the module.

## Limits (Discord, not bugs)
- Needs Manage Server + Manage Roles to read/edit onboarding, View Audit Log, Ban Members, and the `guild_moderation` + members intents.
- Discord cannot block an assignment beforehand; the role is removed right after it lands (RAM-only detection, parallel actions).
- Members not in the cache are not seen by the member hooks.

## Post-deploy checks (unverified from memory of Discord's docs)
1. Audit action ids 163-167 and the `GET/PUT /guilds/{id}/onboarding` shape (emoji_* fields on PUT) - add a harmless role to a test onboarding, then an Administrator role as a non-owner admin.
2. Whether a PUT with the edited config is accepted (prompt/option minimums); if not the log says `failed` and the owner removes the role by hand.
3. Complete onboarding as a test member and confirm the role is removed; confirm the owner is exempt.
4. Run `python -m unittest discover -s tests`: the 7 `test_linkinvite` failures are pre-existing in the stub environment.

## Speed update
- **Role handed out via onboarding**: the Administrator role is removed from the member immediately, in parallel with the audit-log lookup of the configurer (no more waiting for a REST round trip first). If the lookup then shows an exempt configurer, the role is given back (`assign_role_restored` in the ledger).
- **Gateway audit entry wait is event driven** (futures woken by the entry itself) instead of 50 ms polling.
- **Config check starts as an eager task**: the onboarding GET is sent before the event loop yields.
- A fixed **20 ms settle** runs only when an incident is already certain, so two people editing onboarding at the same instant still count as ambiguous (nobody banned). 64 tests.
- Unchanged: kick/ban/delete/clean run in parallel; the ban uses the engine's pre-warmed direct request via BotGuard.
- Real timings: read `punishment sent in N ms | handled in N ms` on each log card on your test server.

## Max-speed update
- The clean step reuses the onboarding config the check just read (one GET less, used once, only if < 1 s old; a stale copy can never re-add a removed role - tested).
- `punishment sent in N ms` is now taken when Discord ACCEPTS the ban; the `fetch_ban` confirmation runs after and no longer inflates it.
- Owner DM and log-channel card are sent in parallel.
- What cannot be made faster: one Discord round trip to learn which role was added (the audit entry does not name it), and Discord cannot block an assignment beforehand.

## Linked role command merge
`antinuke linkinvite` was merged into `antinuke linkedrole` (one command): `enable|disable` toggle Anti Linked Role; `status|threshold|unlock|restore|evidence` are forwarded to the LinkInvite cog. Old names `linkrole`, `linkroles`, `lr`, `linkinvite`, `lrp` stay as aliases. The standalone `linkinvite` command is unchanged.
