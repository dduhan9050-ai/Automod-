# V48 - Anti Invite Role (inside AntiNuke)

Status: **tested with doubles only** (68 new tests, all passing; 8 safety mutations were each caught). Not run against real Discord; discord.py could not be installed in the build sandbox. Do the post-deploy checks at the
bottom first.

## Files
| File | Change |
|---|---|
| `cogs/antinuke/inviteguard.py` | **NEW** cog `InviteGuard` (all logic, inside the antinuke package like BotGuard / OnboardGuard) |
| `cogs/commands/antinuke.py` | + `antinuke inviterole on/off/status/scan/restore <role_id>`; help page; hooks in enable / wizard / disable / config |
| `cogs/axon/antinuke.py` | Anti Invite Role line in the Security help body |
| `cogs/__init__.py` | cog registration |
| `tests/test_inviteguard.py` | tests |

Engine, linkinvite, botguard, onboardguard, `antinuke_store` and `utils/antinuke_ui.py` are **not modified**. No new help category: the page
is appended to the existing `antinuke` help menu. New DB: `db/inviteguard.db` (flag, first-original role permissions, append-only `ig_events`).
Aliases of the command: `inviteroles`, `invrole`, `invroles`, `roleinvite`, `antiinviterole`.

## What Discord gives us (documented, checked against the Discord docs)
- Invites can carry roles (`role_ids` on create, needs Manage Roles). The **INVITE_CREATE gateway event contains `code`, `channel_id`, `inviter` and `role_ids`**,
  so detection needs no REST call and no member cache.
- Audit action **40** (INVITE_CREATE) names the creator; it is used to **confirm** the creator before a ban.
- `DELETE /invites/{code}` needs Manage Channels (on that channel) or Manage Server. `GET /invites/{code}` returns `roles`.
- Roles a member already received **stay** after the invite is deleted: that is why the role itself is defanged.

## Behaviour
Exempt (nothing happens): the bot, Server Owner, Extra Owners (BotGuard / `EXTRA_OWNER_IDS`) and everyone on the **antinuke whitelist** (`antinuke whitelist`).
Anyone else who creates an invite with an attached role:

1. **Verify (RAM, before any request):** invite code is well-formed, creator id is a valid snowflake, linked role ids exist in the server (unknown ids are re-read, never invented).
2. **In parallel, in the same event-loop tick:** delete the invite | strip every privileged bit from every linked role | wait for the audit entry.
   Privileged = Administrator, Manage Server, Manage Roles, Manage Channels, Ban, Kick, Manage Webhooks, Moderate Members, Manage Expressions,
   Manage Nicknames, View Audit Log, Manage Messages, Manage Threads, Manage Events, Mention Everyone. Everything else on the role is untouched.
   **The role is never deleted.**
3. **Ban the creator only if the audit log names the same user for the same invite code.** Mismatch, ambiguous, no entry or an unreadable audit log =
   nobody is banned (the invite is still removed and the role still stripped). The ban goes through BotGuard's `_ban` (shares the engine's claim: no double ban).
4. **Honest statuses:** invite = re-read returns 404, role = `fetch_roles` shows no privileged bit, ban = `fetch_ban`. Otherwise `failed` / `unverified`.
5. **Failure handling:** failed steps are retried at +1.5 s and +4 s (hierarchy-blocked steps are not). If the invite could not be removed (or its state could
   not be read) the **Emergency lockdown** starts (120 s cooldown; undo with `emergency unlock`). If the invite is verified gone but a role could not be
   stripped, no lockdown: the card says the role is still privileged.
6. **Creator missing in the payload:** the audit log must name them first. If it cannot: a privileged role is still defanged and the invite deleted, but nobody is banned; a harmless role = alert only.
7. **Logging:** every incident is a card in the antinuke log channel, a DM to the Server Owner (once per creator per minute), a row in `ig_events`, and a journal line.
   The card shows `invite removal sent in N ms | handled in N ms (raw gateway | gateway event)`.

## Race conditions
- Raw gateway hook **and** the normal listener report the same invite: first one claims `(guild, code)`; the other is ignored.
- A burst of invites by one creator: each invite is deleted and logged, **one** ban, one DM; a role shared by several invites is edited once (per-role lock) and the rest see it already clean.
- Audit entries are single-use; the gateway entry is awaited event-driven (max 0.6 s), then one REST read.
- Role edits are serialised per role; verification re-reads after the edit, so a concurrent re-escalation shows up as `failed` and is retried from a fresh read.

## Recovery
The **first** original permission bitfield of every stripped role is stored (never overwritten). `antinuke inviterole restore <role_id>` (Server Owner / Extra Owners)
re-adds only the bits that were stripped; any other edit made since is kept. Use it when a legitimate staff role was linked by mistake.

## Decisions you may want to change
1. Opt-in for existing servers (`antinuke inviterole on`); `antinuke enable` and the wizard switch it on for new setups only.
2. Exempt = Owner + Extra Owners + antinuke whitelist (your spec's "trusted whitelist"). There is no separate trust list.
3. **Any** role-attached invite by a non-exempt user triggers the full response, even when the role is harmless (spec). If you want "only when a linked role is privileged", change the condition in `_handle_inner`.
4. A linked **mainrole / barrier** role is stripped too (spec says all linked roles). Use `restore` if that was a legitimate staff role.
5. `on/off/restore`: Server Owner + Extra Owners only. `status` / `scan`: also whitelisted users.

## Limits (Discord, not bugs)
- Discord cannot block an invite beforehand; the reaction is right after `INVITE_CREATE` (RAM-only detection, parallel requests).
- Members who accepted the invite in the milliseconds before it was deleted keep the (now stripped) role.
- Invites created while the bot was offline are not acted on; `antinuke inviterole scan` lists role-attached invites (read only).
- Needs: View Audit Log, Manage Roles, Ban Members, Manage Server (or Manage Channels) and the guild invites + moderation intents (you use `Intents.all()`).

## Post-deploy checks (not verifiable here)
1. `antinuke inviterole status` shows `Raw gateway hook` yes. Create a role invite with a **test admin** (not owner, not whitelisted) on a test server and check:
   invite gone, role stripped, admin banned, card in the log channel. `Invite events seen / with roles` must count up; if it stays 0 the gateway is not sending `role_ids`.
2. Create one as Owner and as a whitelisted user: nothing may happen.
3. Confirm the audit `changes` of action 40 contain `code` (the module also accepts entries without it, but only when the event already named the creator).
4. REST calls use `discord.http.Route` (`DELETE/GET /invites/{code}`, `PATCH /guilds/{id}/roles/{id}`, `GET /guilds/{id}/invites`) and `http.get_audit_logs(..., action_type=40)` with a fallback; these signatures are from memory of discord.py 2.x.
5. `python -m unittest discover -s tests`: the 7 `test_linkinvite` failures are pre-existing in the stub environment.
