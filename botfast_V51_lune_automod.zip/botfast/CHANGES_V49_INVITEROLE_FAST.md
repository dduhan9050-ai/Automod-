# V49 - Anti Invite Role: fastest + complete

Tested with doubles only (78 inviteguard tests pass; the 7 `test_linkinvite` failures are the old stub-environment ones). Not run on real Discord.

## Faster
- The creator ban now leaves in the SAME tick as invite delete + role strip. Before, it waited for the audit log (up to 0.6 s + a REST call).
  The creator comes from Discord's own INVITE_CREATE event. The audit entry is still read in parallel and shown on the card.
  Want the old behaviour back? Set `BAN_NEEDS_AUDIT = True` in `cogs/antinuke/inviteguard.py` (one line).
- Creator missing from the event: still audit-confirmed before any ban (unchanged).

## More complete
- **Joiner role removal:** members who joined since the invite was created and hold its role lose it. The roles of a neutralised invite are also watched
  for 15 min (raw GUILD_MEMBER_ADD / UPDATE): anyone who gets one loses it at once. Owner / extra owners / whitelist / bot are never touched.
  A failed removal never starts a lockdown.
- **Startup sweep:** on ready, role-attached invites of untrusted creators that were made while the bot was offline are deleted and their roles defanged.
  A sweep never bans (nothing proves the invite is fresh). Manual run: `antinuke inviterole sweep` (owner / extra owners).
- Help page + `antinuke` help body list the new `sweep` command.

## Files
`cogs/antinuke/inviteguard.py`, `cogs/commands/antinuke.py`, `cogs/axon/antinuke.py`, `tests/test_inviteguard.py`.

## Not done
- "Protected roles" list: the antinuke store has no such list, so nothing is exempt by role (only by user: owner, extra owners, whitelist).
