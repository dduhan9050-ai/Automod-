# V50 - Anti Vanity (inside AntiNuke)

Status: **tested with doubles only** (40 new tests, all passing; 4 of 5 safety mutations caught, the 5th is a second guard behind an earlier one). Not run on real Discord.
Do the post-deploy checks at the bottom first.

## Files
| File | Change |
|---|---|
| `cogs/antinuke/vanityguard.py` | **NEW** cog `VanityGuard` (all logic) |
| `cogs/commands/antinuke.py` | + `antinuke vanity on/off/status/restore/sync`; help page; hooks in enable / wizard / disable / config |
| `cogs/axon/antinuke.py` | Anti Vanity line in the Security help body |
| `cogs/__init__.py` | cog registration |
| `tests/test_vanityguard.py` | tests |

Engine, linkinvite, botguard, onboardguard, inviteguard are **not modified**. No new help category. New DB: `db/vanityguard.db` (flag, protected code, append-only `vg_events`).
Aliases of the command: `vanityurl`, `antivanity`, `vanityguard`.

## Behaviour
Exempt: the bot, Server Owner, Extra Owners, antinuke whitelist.
1. The raw GUILD_UPDATE payload is compared (RAM only) with the protected code. Same code = nothing.
2. The actor is read from the audit log (gateway GUILD_AUDIT_LOG_ENTRY_CREATE first, then REST, REST twice because the log can lag).
3. Exempt actor = their new code becomes the protected one.
4. Untrusted actor = **restore + ban run in parallel** (both leave in the same tick). The restore is re-read with GET before it is called ok, the ban with fetch_ban. Log card + owner DM.
5. Actor not provable (no entry / several users / audit log unavailable) = **alert only**, nothing restored, nobody banned (it could be the owner). `antinuke vanity restore` puts the old code back, `antinuke vanity sync` accepts the new one.
6. Change while the bot was offline = alert only, never acted on.
7. Removal of the vanity is treated like a change.

Why restore and ban both wait for the audit log: without it the bot cannot tell the owner from an attacker. The restore would undo the owner's own change.

## Discord limits (cannot be fixed in code)
- A code that is released can be claimed by another server before the bot restores it. Then the restore fails and the card says so.
- `PATCH /guilds/{id}/vanity-url` is **not in Discord's official docs** (the client uses it). Test it first.
- Needs Manage Server (restore), View Audit Log (actor), Ban Members. The server needs its vanity feature (boost level 3 / partnered).

## Post-deploy checks (test server first)
1. `?antinuke vanity status` shows the protected code and all three permissions green.
2. With an alt in the whitelist: change the vanity. Protected code must follow, no ban.
3. With an alt NOT in the whitelist (Manage Server): change the vanity. Code must come back, alt must be banned, card + DM must arrive.
4. Bot without View Audit Log: change the vanity. Expect alert only, no ban.
5. Stop the bot, change the vanity, start the bot: expect the "differs from the protected code" alert.

## V50b - speed (fast mode)
Fast mode is **ON by default** (`antinuke vanity fast on|off`).
- **Immediate restore:** the PATCH leaves in the same tick the change is seen, in parallel with the audit lookup. Untrusted actor = already restored, the ban follows as soon as the audit names them.
- **Direct request:** the restore is written straight onto the warm connection (same idea as the engine's direct ban). 429 / 5xx / anything odd falls back to `bot.http` with retries.
- **No extra round trip:** the restore is confirmed from Discord's own PATCH response (the code it returns). If the response has no code, a GET re-reads it.
- **Owner changes:** an Owner / Extra Owner / whitelisted change is reverted by the immediate restore and applied again right after (about a second); the protected code follows. In that moment the code is free. If the re-apply fails, the owner gets a card + DM.
- **Never blind:** without View Audit Log the immediate restore is skipped (the owner could not be recognised).
- **Unproven actor:** the code stays restored, nobody is banned, the owner is alerted.
- Turn fast mode off for the slower audit-gated behaviour (the owner's change is then never reverted).
Tests: 56 in `tests/test_vanityguard.py`.
