# V51 - Lune AutoMod port

Lune's automod (native Discord AutoMod rules + Components V2 dashboard) replaces the old heat-based automod.
Lune is discord.js, botfast is discord.py, so everything was rewritten in Python with the same behaviour.

## Commands (prefix and slash)
`automod` (= `automod overview`), `automod modules`, `automod rules`, `automod stats`, `automod logs`.
Allowed: Administrator, Server Owner, Extraowner (bot owner).

## What it does (same as Lune)
* 4 native Discord AutoMod rules: Keyword, Spam, Mention Spam, Profanity (preset).
* Dashboard pages: Overview, Modules, Configure, Rules ("Sync Rules to Discord"), Exclusions, Stats, Settings, Logs.
* Per module action: Block message / Timeout / Alert only (+ Enable/Disable, Advanced modal).
* Server settings: log channel, notifications, DM offenders, escalation (5 hits in 10 min = 1 h timeout).
* Violations + daily stats are stored (SQLite), driven by Discord's `AUTO_MODERATION_ACTION_EXECUTION` event.

## Fixed / improved while porting (Lune bugs)
* Lune inserted a duplicate rule row on every save (`ON CONFLICT(id)` never matched) -> unique (guild, type) now.
* Keywords could never be set in Lune (only the `discord.gg/*` default) -> Advanced modal has keywords, allow list, regex.
* Exclusions were hard-wired to Keyword -> module picker; roles/channels are selected directly on the page.
* Timeout action is not allowed by Discord on Spam/Profanity rules -> falls back to Block (shown on the page).
* Alert-only without a log channel (Discord rejects "no action") -> shown as a clear error on the Rules page.
* Alert + Block of one message counted as 2 violations (escalation fired too early) -> counted once; stats still per action.
* Changing the log channel re-syncs the already created rules (alert channel lives inside the Discord rule).
* External edit/delete of a rule in Discord keeps the local state in sync.

## Files (only these are replaced)
`cogs/commands/automod.py`, `cogs/automod/store.py`, `cogs/automod/engine.py`, `cogs/axon/automod.py`,
`utils/automod_ui.py`, `utils/automod_core.py`.  `cogs/__init__.py`, `help.py` and the DB layer are untouched.

## Not carried over
The previous heat-based automod (13 filters, `blword` word blacklist, `automod whitelist/wlshow/manage/...`) is gone;
its tables (`am_*` in `db/automod.db`) are left in place but unused. New tables: guild_automod, automod_rules,
automod_violations, automod_stats.

Bot permissions: Manage Server (create/edit AutoMod rules + receive execution events), Timeout Members (escalation).
