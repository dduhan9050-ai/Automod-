# Voice module (ZEON style)

- REMOVED old `cogs/commands/voice.py`, `cogs/commands/Invc.py` (vcrole add/remove/config) and the old help category.
- NEW `cogs/commands/voice.py`: `voice` (alias `vc`) with 18 subcommands: kick, kickall, mute, muteall, unmute,
  unmuteall, deafen, deafenall, undeafen, undeafenall, move, moveall, pull, pullall, lock, unlock, private, unprivate.
  Bulk commands run with 8 parallel workers. Replies are a single white (#ffffff) `<:emoji_4:1566043104551768114> | text` / `<a:cross:1567096105299214336> | text` card.
- NEW `vcrole`: enable, disable, set, show, reset. Roles with dangerous permissions are refused.
  Data stays in `db/invc.db` (an `enabled` column is added automatically). In-memory cache, no DB hit per voice event.
- NEW help category "Voice Commands" (sections "Voice Commands" + "VC Roles"), container without accent colour.
- Legacy `roles` columns (staff/girl/vip/guest/frnd) dropped from db/customrole.db and auto-dropped on load.
- Static compile check only; not run against Discord.
