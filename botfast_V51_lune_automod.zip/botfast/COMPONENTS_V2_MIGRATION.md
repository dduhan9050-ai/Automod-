# Rich Black Components V2 migration

This build adds a shared Components V2 response layer for the bot.

## What it does

- Routes normal text responses and legacy `discord.Embed` responses through native `discord.ui.LayoutView` messages.
- Uses white (#ffffff accent) `Container` cards and `TextDisplay` blocks.
- Handles `Context.send/reply`, channel/messageable sends, webhook sends, interaction response sends/edits, message edits, and interaction original-response edits.
- Converts supported classic `discord.ui.View` buttons and select menus into V2 `ActionRow` components when a message is converted.
- Keeps command implementations in their existing cogs; the shared renderer avoids hand-editing hundreds of individual embed call sites.
- Preflight now checks that the installed discord.py exposes the Components V2 API and loads `.env` before checking TOKEN.

## Important compatibility notes

- Requires discord.py 2.6 or newer (the requirements file already declares `>=2.6.0`).
- Existing custom view callbacks are copied with their items. Test every interactive workflow (tickets, pagination, role menus, moderation confirmations) in a private test server because custom `View.interaction_check`, `on_timeout`, and custom view-level error handlers are not guaranteed to transfer to a new LayoutView.
- Image and thumbnail URLs from old embeds are rendered as clickable links in the rich-black card; they are not recreated as embedded image previews.
- Raw low-level calls made directly through `bot.http` bypass the shared response renderer. The source's `send_raw` helper is the only such helper found during this migration audit; ordinary cog sends are routed through the patched Discord.py APIs.
- This is a broad compatibility migration, not a claim that every command's business logic has been runtime-tested. Test commands and interactions in a staging Discord server before relying on them in production.

## Install/update

Keep a backup of the current working directory and databases before replacing source files. Install requirements, run `python preflight.py`, then restart the service. See `FIXES_AND_DEPLOYMENT.md` for the deployment notes.
