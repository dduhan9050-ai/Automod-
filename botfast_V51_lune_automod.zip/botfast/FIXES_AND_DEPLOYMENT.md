# Source fixes and deployment notes

## Applied fixes
- Removed automatic `pip install` execution from `app.py`; install dependencies before starting the bot.
- Replaced the hardcoded Discord webhook with optional `COMMAND_LOG_WEBHOOK_URL`.
- Removed the hardcoded Discord bot-token-like string from `utils/config.py`.
- Added a clear startup error when `TOKEN` is missing.
- Ensured the `db/` directory exists before startup.
- Replaced invalid/duplicate dependency entries with a cleaned requirements file based on imports in this source.
- Added Components V2 conversion for embed-only messages sent through the project's custom `Context.send()` and `Context.reply()`.
- Removed Python cache files from the packaged source.
- Kept SQLite because this codebase actively uses `sqlite3` and `aiosqlite`; it does not implement MongoDB.

## Critical security action
A bot token and webhook URL were present in the uploaded source. Treat both as compromised:
1. Reset the bot token in Discord Developer Portal.
2. Delete/regenerate the exposed webhook in Discord.
3. Put only the newly generated token in `.env` or hosting environment variables.
4. Never upload `.env` to GitHub.

## Install / run
```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
# Edit .env and set TOKEN to your NEW token
python app.py
```

Use Python 3.11 or 3.12. Enable the Server Members Intent and Message Content Intent in the Discord Developer Portal.

## Important limitations
- This is a static source/dependency repair and compilation check, not a live Discord login test.
- Components V2 conversion covers embed-only sends routed through `core.Context.send/reply`. Messages that combine legacy `discord.ui.View` with embeds, and direct `interaction.response.send_message`, webhook, or raw channel sends need their own V2 layouts.
- Existing database remains SQLite. No MongoDB Atlas migration or data conversion was performed.
- Music playback also requires a reachable Lavalink node configured for the Wavelink version used by the project.

## Additional compatibility repairs
- Removed Pycord-only `sync_commands` constructor arguments; the project now uses the `discord.py` command tree and its existing `tree.sync()` call.
- Removed import-time `asyncio.run()` from the SQLite setup helper and initialize the prefix table from the async startup function instead.
- Music no longer relies on a hardcoded public Lavalink node. Configure `LAVALINK_URI` and `LAVALINK_PASSWORD`; without these, the rest of the bot can start and music reports that it is disabled.
- Added `preflight.py` to check installed modules, token configuration, Lavalink configuration, and SQLite file integrity.

Run `python preflight.py` before `python app.py`.
