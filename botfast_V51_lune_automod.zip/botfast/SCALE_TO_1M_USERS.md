# DEATH DEVELOPMENT — scale planning for 1,000,000 users

## Important distinction
A bot serving one million *total* users across many guilds is not the same as one million concurrent users. This release makes Gateway sharding configurable and lets a single process discover Discord's recommended shard count. It is a foundation, not a guarantee of one-million-user capacity. Actual capacity depends on guild count, event rate, enabled intents, command mix, hosting, and Discord's Gateway/API limits.

## Included in this build
- `SHARD_COUNT=0` (default): let discord.py discover the recommended shard count for a single process.
- `SHARD_COUNT=N` plus `SHARD_IDS=...`: configure a worker for an explicitly partitioned multi-process shard deployment.
- `DISCORD_MAX_MESSAGES=1000`: bound the in-memory message cache (set lower if message-history features do not need it).
- Existing prefix/no-prefix TTL caches remain enabled.

## Single-process starting point
1. Install requirements and configure `.env` as usual.
2. Keep `SHARD_COUNT=0` and leave `SHARD_IDS` empty.
3. Start one bot process. Check startup logs for connected shard count and Gateway errors.
4. Enable only the privileged Discord intents that the bot's actual features require in the Developer Portal. This source currently requests all intents, including members and presences; do not disable them blindly because some features may depend on them.

## Multi-process deployment
Do not run multiple copies with `SHARD_COUNT=0`: they may all request overlapping automatic shard assignments. Instead:
1. Obtain the current recommended shard count and session-start limits from Discord's Gateway Bot endpoint / Developer Portal.
2. Choose a total `SHARD_COUNT=N` and split shard IDs into non-overlapping groups across workers. Every worker uses the same `SHARD_COUNT`; each worker gets its own `SHARD_IDS` list.
3. Keep exactly one owner for each shard ID. Never launch duplicate workers for the same shard IDs.
4. Coordinate deployments and restarts with Discord's session-start / identify concurrency limits.

Example only (if Discord recommends 4 shards):
- Worker A: `SHARD_COUNT=4`, `SHARD_IDS=0,1`
- Worker B: `SHARD_COUNT=4`, `SHARD_IDS=2,3`

## Required engineering before claiming production readiness at 1M users
This codebase currently contains hundreds of direct SQLite access sites and local in-process caches. SQLite on one local disk is not a suitable shared database for a horizontally scaled multi-worker service. Before multi-worker production use:
- Migrate guild/user/configuration data to PostgreSQL (managed PostgreSQL with backups, connection pooling, indexes, and migrations).
- Replace process-local prefix/no-prefix caches with Redis or another shared cache; publish invalidation events when settings change.
- Audit and migrate the direct SQLite call sites; adding PostgreSQL/Redis packages alone does not migrate application queries.
- Move expensive image, AI, and logging work to bounded background queues where appropriate.
- Reuse long-lived HTTP sessions; apply timeouts, retry/backoff, and per-feature concurrency limits.
- Add structured logs, error reporting, latency/event-loop metrics, health checks, and alerts.
- Load-test realistic guild counts and event rates; test shard reconnects, database failover, cache loss, and rate limits.

## Safety notes
- Never commit `.env` or bot tokens. Rotate any token that has been pasted into chat, screenshots, shell history, or a repository.
- Do not promise a fixed response latency: Discord API/network conditions and hosting capacity affect it.
- Scale based on measured CPU, RAM, event-loop lag, database latency, queue depth, and Gateway events—not the headline user count alone.
