# Ticket system (rewritten)

Replaced: `cogs/commands/ticket.py` (old `/ticketsetup`), `cogs/axon/ticket.py` (old empty help menu).
New files: `utils/ticket_store.py`, `utils/ticket_ui.py`, `utils/ticket_setup.py`, `utils/ticket_vars.py`.
Edited: `cogs/commands/help.py` (routes `?ticket` to the new group help). `cogs/__init__.py` needs no change.

## Commands (same order / pages as the reference: 5 / 5 / 2)
Page 1: `ticket delete`, `ticket transcript <channel>`, `ticket staff <role>`, `ticket adduser <member>`, `ticket reset`
Page 2: `ticket close`, `ticket edit`, `ticket setcategory <category>`, `ticket removeuser <member>`, `ticket config`
Page 3: `ticket panel [channel]`, `ticket setup`
Extra: `ticketvariables` (aliases: ticketvars, ticketvariable, tvars)

## Quick start
1. `?ticket staff @Role`   2. `?ticket setcategory <category>`   3. `?ticket transcript #logs`
4. `?ticket setup` -> customise everything (panel, ticket message, subcategories + questions, toggles)
5. `?ticket panel #channel`

## Subcategories
`?ticket setup` -> Subcategories -> Add. Each has: name, emoji, description, extra staff roles,
own category (optional) and up to 5 questions (asked in a form before the channel is created).
No subcategory = one "Create Ticket" button. 1+ subcategories = select menu (or buttons, Panel Style).

## Data
`db/ticket.db` is created automatically (tables `ticket_guild`, `tickets`).
Buttons use fixed `zticket:*` custom ids, so old panels keep working after restarts.

## Notes
* Needs discord.py >= 2.6 (Components V2), same as the rest of the bot.
* Bot needs Manage Channels, Manage Roles/permissions overwrites, Send Messages, Attach Files, Embed Links in the ticket category.
* `ticket edit` / `ticket setup` open the in-Discord dashboard (there is no web dashboard in this source).
