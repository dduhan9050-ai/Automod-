import os
from pathlib import Path

# Always run from the bot's own folder: db/, .env, config.yml and lang/ are all relative paths,
# so starting the bot from another directory (systemd, pm2, cron, `python /path/app.py`) used to crash.
os.chdir(Path(__file__).resolve().parent)

from dotenv import load_dotenv

# Load secrets before initializing the bot. Install dependencies before startup.
load_dotenv()
import utils.fastsqlite as _fastsqlite
_fastsqlite.install()  # pooled + WAL sqlite for every aiosqlite.connect(...) block
Path("db").mkdir(parents=True, exist_ok=True)
import asyncio
import traceback
from datetime import datetime

try:  # optional speed-up: libuv event loop (not available on Windows)
    import uvloop
    uvloop.install()
except Exception:
    pass

import aiohttp
import discord
from discord.ext import commands
from components_v2 import install_v2_send_patch

# Route legacy text/embed command responses through white (#ffffff) V2 containers.
install_v2_send_patch()

from core import Context
from core.Cog import Cog
from core.axon import axon
from utils.Tools import *
from utils.config import *

import jishaku
import cogs

os.environ["JISHAKU_NO_DM_TRACEBACK"] = "False"
os.environ["JISHAKU_HIDE"] = "True"
os.environ["JISHAKU_NO_UNDERSCORE"] = "True"
os.environ["JISHAKU_FORCE_PAGINATOR"] = "True"

TOKEN = os.getenv("TOKEN")

client = axon()
tree = client.tree
_commands_synced = False

@client.event
async def on_ready():
    global _commands_synced
    await client.wait_until_ready()
    
    print("""
           \033[1;31m

 ▄████▄   ▒█████  ▓█████▄ ▓█████ ▒██   ██▒
▒██▀ ▀█  ▒██▒  ██▒▒██▀ ██▌▓█   ▀ ▒▒ █ █ ▒░
▒▓█    ▄ ▒██░  ██▒░██   █▌▒███   ░░  █   ░
▒▓▓▄ ▄██▒▒██   ██░░▓█▄   ▌▒▓█  ▄  ░ █ █ ▒ 
▒ ▓███▀ ░░ ████▓▒░░▒████▓ ░▒████▒▒██▒ ▒██▒
░ ░▒ ▒  ░░ ▒░▒░▒░  ▒▒▓  ▒ ░░ ▒░ ░▒▒ ░ ░▓ ░
  ░  ▒     ░ ▒ ▒░  ░ ▒  ▒  ░ ░  ░░░   ░▒ ░
░        ░ ░ ░ ▒   ░ ░  ░    ░    ░    ░  
░ ░          ░ ░     ░       ░  ░ ░    ░  
░                  ░                      

           \033[0m
           """)
    print("Loaded & Online!")
    print(f"Logged in as: {client.user}")
    print(f"Connected to: {len(client.guilds)} guilds")
    print(f"Connected to: {len(client.users)} users")
    # Sync slash commands once per process, not on every reconnect.
    if not _commands_synced:
        try:
            synced = await client.tree.sync()
            all_commands = list(client.commands)
            print(f"Synced Total {len(all_commands)} Client Commands and {len(synced)} Slash Commands")
            _commands_synced = True
        except Exception as e:
            print(f"Slash command sync failed: {e}")

_log_session = None
_log_queue: "asyncio.Queue | None" = None
_log_worker_task = None


def _get_log_session():
    """One shared HTTP session for the command-log webhook (no new session per command)."""
    global _log_session
    if _log_session is None or _log_session.closed:
        _log_session = aiohttp.ClientSession()
    return _log_session


async def _log_worker(webhook_url: str):
    webhook = discord.Webhook.from_url(webhook_url, session=_get_log_session())
    while True:
        embed = await _log_queue.get()
        try:
            await webhook.send(embed=embed)
        except Exception as e:
            print(f"Command log failed: {e}")
        # stay under the webhook rate limit (5 req / 2s) without ever blocking commands
        await asyncio.sleep(0.5)


@client.event
async def on_command_completion(context: commands.Context) -> None:
    global _log_queue, _log_worker_task
    webhook_url = os.getenv("COMMAND_LOG_WEBHOOK_URL")
    if not webhook_url:
        return
    if _log_queue is None:
        _log_queue = asyncio.Queue(maxsize=200)
    if _log_worker_task is None or _log_worker_task.done():
        _log_worker_task = asyncio.create_task(_log_worker(webhook_url))

    executed_command = context.command.qualified_name
    avatar_url = context.author.display_avatar.url
    embed = discord.Embed(color=0x000000)
    embed.set_author(name=f"Executed {executed_command} Command By : {context.author}", icon_url=avatar_url)
    embed.set_thumbnail(url=avatar_url)
    embed.add_field(name=" Command Name :", value=f"{executed_command}", inline=False)
    embed.add_field(
        name=" Command Executed By :",
        value=f"{context.author} | ID: [{context.author.id}](https://discord.com/users/{context.author.id})",
        inline=False)
    if context.guild is not None:
        embed.add_field(
            name=" Command Executed In :",
            value=f"{context.guild.name} | ID: [{context.guild.id}](https://discord.com/guilds/{context.guild.id})",
            inline=False)
        embed.add_field(
            name=" Command Executed In Channel :",
            value=f"{context.channel.name} | ID: [{context.channel.id}](https://discord.com/channels/{context.guild.id}/{context.channel.id})",
            inline=False)
        embed.timestamp = discord.utils.utcnow()
        embed.set_footer(text="Death Development™ ❤️", icon_url=client.user.display_avatar.url)
    else:
        embed.set_footer(text="Powered by Death Development™", icon_url=client.user.display_avatar.url)
    try:
        _log_queue.put_nowait(embed)   # full queue -> drop the log line, never slow a command
    except asyncio.QueueFull:
        pass

async def _start_keep_alive():
    """Tiny health endpoint on the bot's own event loop (replaces the Flask dev-server thread:
    less memory, no extra thread, faster startup).  Set PORT / DISABLE_KEEPALIVE=1 to change."""
    if os.getenv("DISABLE_KEEPALIVE") == "1":
        return None
    from aiohttp import web

    async def home(_request):
        return web.Response(text="Death Development™")

    web_app = web.Application()
    web_app.router.add_get("/", home)
    runner = web.AppRunner(web_app, access_log=None)
    await runner.setup()
    try:
        await web.TCPSite(runner, "0.0.0.0", int(os.getenv("PORT", "8080"))).start()
    except OSError as e:
        print(f"Keep-alive server not started: {e}")
        await runner.cleanup()
        return None
    return runner

async def main():
    if not TOKEN:
        raise RuntimeError("TOKEN is missing. Add TOKEN to your .env file or hosting environment variables.")
    await setup_db()
    runner = await _start_keep_alive()
    try:
        async with client:
            await client.load_extension("jishaku")
            await client.start(TOKEN)
    except discord.PrivilegedIntentsRequired:
        raise SystemExit("Privileged intents are OFF. Discord Developer Portal -> your bot -> Bot -> "
                         "turn ON Presence Intent, Server Members Intent and Message Content Intent, then restart.")
    except discord.LoginFailure:
        raise SystemExit("Discord rejected the token. Reset it in the Developer Portal and update TOKEN in .env.")
    finally:
        if _log_worker_task is not None:
            _log_worker_task.cancel()
        if _log_session is not None and not _log_session.closed:
            await _log_session.close()
        if runner is not None:
            await runner.cleanup()
        await _fastsqlite.close_all()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
