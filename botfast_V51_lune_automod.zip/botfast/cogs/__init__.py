from __future__ import annotations
from core import axon
from colorama import Fore, Style, init


#----------Commands---------#
from .commands.help import Help
from .commands.general import General
from .commands.music import Music
from .commands.automod import Automod
from .commands.owner import Owner
from .commands.voice import Voice, VcRole
from .commands.afk import afk
from .commands.permit import Permit
from .commands.Media import Media
from .commands.giveaway import Giveaway
from .commands.timer import Timer
from .commands.block import Block
from .commands.nightmode import Nightmode
#from .commands.imagine import AiStuffCog
from .commands.owner import Badges
from .commands.map import Map
from .commands.autoresponder import AutoResponder
from .commands.customrole import CustomRole
from .commands.ticket import TicketSystem
from .commands.logging import Logging
from .logsys.engine import LoggingEngine   # fast webhook logging engine (16 log types)
from .commands.translate import TranslateCog

from .commands.antinuke import Antinuke
from .antinuke.engine import AntinukeEngine
from .antinuke.linkinvite import LinkInvite
from .antinuke.botguard import BotGuard
from .antinuke.onboardguard import OnboardGuard
from .antinuke.inviteguard import InviteGuard
from .antinuke.vanityguard import VanityGuard
from .commands.autoreact import AutoReaction
from .commands.stats import Stats
from .commands.emergency import Emergency
from .commands.notify import NotifCommands
from .commands.status import Status
from .commands.np import NoPrefix
from .commands.owner2 import Global
from .commands.qr import QR
from .commands.vanityroles import VanityRoles
from .commands.leaderboard import Leaderboard
from .commands.fastgreet import FastGreet
from .greetings.greet import Greetings
from .commands.premium import Premium
from .commands.botinfo import BotInfo

#from .commands.activity import Activity
#____________ Events _____________

from .events.autoblacklist import AutoBlacklist
from .events.Errors import Errors
from .events.on_guild import Guild
from .events.auto import Autorole
from .events.mention import Mention
from .events.react import React
#from .events.topgg import TopGG

########-------HELP-------########
from .axon.antinuke import _antinuke
from .axon.general import _general
from .axon.automod import _automod 
from .axon.music import _music
from .axon.permit import _permit
from .axon.customrole import _customrole
from .axon.voice import _voice 
from .axon.ticket import _ticket
#from .axon.vanityroles import Vanityroles69999
from .axon.logging import _logging
from .axon.vanity import _vanity
from .axon.leaderboard import _leaderboard
from .axon.autoresponder import _autoresponder
from .axon.premium import _premium
from .axon.botowner import _botowner


########--- MODERATION (rebuilt) ---########
from .mod.basic import ModBasic
from .mod.channels import ModChannels
from .mod.roles import ModRoles
from .mod.purge import ModPurge
from .mod.emojis import ModEmoji
from .mod.quarantine import Quarantine
from .mod.helpcat import ModerationHelp


########--- UTILITY (embed / sticky / reactionrole) ---########
from .utility.helpcat import UtilityHelp
from .utility.embed import UtilEmbed
from .utility.sticky import UtilSticky
from .utility.reactionrole import UtilReactionRole


#########ANTINUKE#########


#Extra Optional Events 

#from .antinuke.antiemocr import AntiEmojiCreate
#from .antinuke.antiemodl import AntiEmojiDelete
#from .antinuke.antiemoup import AntiEmojiUpdate
#from .antinuke.antisticker import AntiSticker
#from .antinuke.antiunban import AntiUnban

############ AUTOMOD ############
from .automod.engine import AutomodEngine   # one fast listener for ALL automod events




_COGS = [
    Help, General, Music, Automod, Greetings,
    Voice, Owner, CustomRole, afk, Media,
    Permit, VcRole, Giveaway, Timer,
    Block, Nightmode, Badges, Antinuke, AntinukeEngine, LinkInvite, BotGuard, OnboardGuard, InviteGuard, VanityGuard,
    Stats, Emergency, Status, NoPrefix, Global,
    Map, TicketSystem, Logging, LoggingEngine, QR, VanityRoles,
    Leaderboard, TranslateCog, FastGreet, Premium, _antinuke, _general,
    _automod, _music, _permit, _customrole,
    _voice, _ticket, _logging, _vanity, _leaderboard,
    _autoresponder, _premium, ModerationHelp, ModBasic, ModChannels, ModRoles,
    ModPurge, ModEmoji, Quarantine, UtilityHelp, UtilEmbed, UtilSticky,
    UtilReactionRole, AutoBlacklist, Guild, Errors, Autorole,
    AutoResponder, Mention, React, AutoReaction, NotifCommands, AutomodEngine, _botowner, BotInfo,
]


async def setup(bot: axon):
  """Load every cog independently: one broken cog no longer prevents the rest from loading."""
  loaded, failed = 0, []
  for cog_cls in _COGS:
    try:
      await bot.add_cog(cog_cls(bot))
      loaded += 1
    except Exception as e:
      failed.append((cog_cls.__name__, e))
      print(Fore.RED + Style.BRIGHT + f"Failed to load cog {cog_cls.__name__}: {type(e).__name__}: {e}")
  print(Fore.BLUE + Style.BRIGHT + f"Loaded {loaded}/{len(_COGS)} cogs.")
  if failed:
    print(Fore.RED + Style.BRIGHT + "Failed cogs: " + ", ".join(n for n, _ in failed))
