"""Anti Bot Nuker (bot role / integration protection) + Bot Add Authorization.

Design rules (see CHANGES_V46_BOTGUARD.md):
  * Additive.  The engine, linkinvite and the existing `antinuke_store` are untouched in behaviour.  This cog owns only
    the listeners nothing else in the antinuke package uses (member_join, integration_*, guild_remove) plus the two
    role events, and it reuses the store's whitelist / mainroles / barrier / log channel / autorec flag.
  * Honest.  Every step of an incident is recorded as ok / failed / blocked / skipped / unverified.  A step is "ok"
    only when Discord accepted the call AND (for recovery) a re-read confirms the new state.
  * Never punish on a guess.  No identified executor = alert only.  Authorization is Server Owner + Extra Owners.
  * Idempotent + serialised per guild.  Role incidents are *reconciled* against a snapshot, so ten gateway events
    for one attack produce one punishment; bans are claimed synchronously (and shared with the engine's `flagged`).
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sqlite3
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Callable, Optional

import discord
from discord.ext import commands

from utils import antinuke_store as store

log = logging.getLogger("deathbot.botguard")
AL = discord.AuditLogAction
BIT = store.BIT

DB_PATH = os.getenv("BG_DB_PATH", "db/botguard.db")
AUDIT_DELAYS = (0.0, 0.4, 0.8, 1.6, 3.0)      # bounded retries: at most 5 polls, <= 5.8 s of waiting
AUDIT_DELAYS_SHORT = (0.0, 0.5)               # position-only changes are rarely audit-logged: do not wait long
AUDIT_LIMIT = 10
AUDIT_MAX_AGE = 60.0                          # an audit entry older than this cannot belong to the event
SETTLE = 0.05                                 # coalesce a burst of role events into one reconcile
PUNISH_TTL = 120.0
CMDPERM_ACTION = 121                           # audit: application command permissions updated (Integrations page)
HINT_WAIT = 0.6                               # wait for the gateway audit entry (event driven, no polling) before REST
HINT_TTL = 120.0
MAX_EXTRA_OWNERS = 25

# permission bits (documented Discord values) - pure ints so the logic is testable without discord.py
DANGER_BITS = {
    "Administrator": 1 << 3, "Manage Guild": 1 << 5, "Manage Roles": 1 << 28, "Manage Channels": 1 << 4,
    "Manage Webhooks": 1 << 29, "Ban Members": 1 << 2, "Kick Members": 1 << 1, "Manage Messages": 1 << 13,
    "Mention Everyone": 1 << 17, "Moderate Members": 1 << 40,
}
DANGER_MASK = 0
for _b in DANGER_BITS.values():
    DANGER_MASK |= _b
PERM_NAMES = {**DANGER_BITS, "Create Invite": 1 << 0, "View Channel": 1 << 10, "Send Messages": 1 << 11,
              "Embed Links": 1 << 14, "Attach Files": 1 << 15, "Read Message History": 1 << 16,
              "Add Reactions": 1 << 6, "View Audit Log": 1 << 7, "Connect": 1 << 20, "Speak": 1 << 21,
              "Manage Nicknames": 1 << 27, "Manage Emojis": 1 << 30, "Use Application Commands": 1 << 31,
              "Manage Threads": 1 << 34}
BAN_BIT, KICK_BIT, ADMIN_BIT, MANAGE_ROLES_BIT = 1 << 2, 1 << 1, 1 << 3, 1 << 28
AUDIT_BIT = 1 << 7


# --------------------------------------------------------------------------- pure helpers (unit-tested)
def _spawn_eager(coro):
    """Run the coroutine up to its first real await RIGHT NOW (3.12 eager tasks) instead of queueing behind the loop."""
    loop = asyncio.get_running_loop()
    try:
        return asyncio.Task(coro, loop=loop, eager_start=True)
    except TypeError:
        return loop.create_task(coro)


def valid_id(value) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and 0 < value < (1 << 63)


def parse_ids(raw) -> tuple[list, list]:
    """Config validation: -> (valid unique ids, problems).  Accepts a list or a comma/space separated string."""
    problems, out = [], []
    if raw is None or raw == "":
        return out, problems
    if isinstance(raw, str):
        items = [p for p in raw.replace(",", " ").split() if p]
    elif isinstance(raw, (list, tuple, set, frozenset)):
        items = list(raw)
    else:
        return out, [f"EXTRA_OWNER_IDS must be a list or comma separated string, got {type(raw).__name__}"]
    for item in items:
        try:
            if isinstance(item, bool):
                raise ValueError
            uid = int(str(item).strip())
        except (TypeError, ValueError):
            problems.append(f"ignored non-numeric id {item!r}")
            continue
        if not valid_id(uid):
            problems.append(f"ignored out-of-range id {uid}")
        elif uid in out:
            problems.append(f"ignored duplicate id {uid}")
        else:
            out.append(uid)
    return out, problems


def global_extra_owner_ids() -> frozenset:
    """EXTRA_OWNER_IDS from utils/config.py plus the EXTRA_OWNER_IDS environment variable (comma separated)."""
    raw: list = []
    try:
        import importlib
        raw += list(getattr(importlib.import_module("utils.config"), "EXTRA_OWNER_IDS", []) or [])
    except Exception:
        pass
    ids, problems = parse_ids(raw)
    env_ids, env_problems = parse_ids(os.getenv("EXTRA_OWNER_IDS", ""))
    for p in problems + env_problems:
        log.warning("botguard config: %s", p)
    return frozenset(ids) | frozenset(env_ids)


def is_authorized(owner_id: Optional[int], extra_ids, uid) -> bool:
    """Bot Add policy: ONLY the Server Owner and Extra Owners.  Admins, moderators, whitelisted users: never."""
    if not valid_id(uid):
        return False
    return uid == owner_id or uid in extra_ids


def dangerous_in(perms: int) -> list:
    return [name for name, bit in DANGER_BITS.items() if perms & bit]


def perm_names(bits: int) -> list:
    names = [n for n, b in PERM_NAMES.items() if bits & b]
    rest = bits & ~sum(PERM_NAMES.values())
    if rest:
        names.append(f"+{bin(rest).count('1')} other")
    return names


@dataclass(frozen=True)
class RoleSnap:
    role_id: int
    name: str
    perms: int
    position: int
    rank_above: int          # how many roles sit above it (position-shift proof measure of its rank)
    taken_at: float = 0.0


@dataclass(frozen=True)
class RoleDiff:
    lost: int = 0
    gained: int = 0
    rank_worse: bool = False
    deleted: bool = False

    @property
    def harmful(self) -> bool:
        return bool(self.lost or self.rank_worse or self.deleted)

    @property
    def any(self) -> bool:
        return self.harmful or bool(self.gained)

    def describe(self) -> str:
        if self.deleted:
            return "bot role DELETED"
        parts = []
        if self.lost:
            parts.append("lost permissions: " + ", ".join(perm_names(self.lost)))
        if self.gained:
            parts.append("gained permissions: " + ", ".join(perm_names(self.gained)))
        if self.rank_worse:
            parts.append("bot role moved down the hierarchy")
        return "; ".join(parts) or "no change"


def count_above(roles, role) -> int:
    return sum(1 for r in roles if r.position > role.position)


def diff_role(snap: RoleSnap, role, roles) -> RoleDiff:
    """Compare the live bot role with the snapshot.  Position is judged by RANK (roles above), because absolute
    positions shift whenever any role is created / deleted below it."""
    if role is None:
        return RoleDiff(deleted=True)
    cur = role.permissions.value
    return RoleDiff(lost=snap.perms & ~cur, gained=cur & ~snap.perms,
                    rank_worse=count_above(roles, role) > snap.rank_above)


# --------------------------------------------------------------------------- incident record
ICON_KEYS = {"ok": "ok", "failed": "no", "blocked": "no", "impossible": "no"}


@dataclass
class Step:
    name: str
    status: str          # ok | failed | blocked | impossible | skipped | unverified | partial | duplicate
    detail: str = ""


@dataclass
class Incident:
    kind: str                                   # role | integration | botadd | removed
    guild_id: int
    title: str = ""
    executor_id: Optional[int] = None
    executor_class: str = ""
    target_id: Optional[int] = None
    steps: list = field(default_factory=list)
    started: float = 0.0
    t0: float = field(default_factory=time.perf_counter)
    ms: Optional[float] = None
    ms_action: Optional[float] = None            # until kick+ban were accepted
    via: str = ""                               # how the executor was found: gateway | rest

    def add(self, name: str, status: str, detail: str = "") -> Step:
        s = Step(name, status, detail)
        self.steps.append(s)
        return s

    def status_of(self, name: str) -> str:
        for s in self.steps:
            if s.name == name:
                return s.status
        return ""

    def as_dict(self) -> dict:
        return {"kind": self.kind, "title": self.title, "executor": self.executor_id, "class": self.executor_class,
                "target": self.target_id, "steps": [[s.name, s.status, s.detail] for s in self.steps]}


def render_incident(inc: Incident, header: str, ok="[OK]", no="[X]", warn="[!]", now: Optional[float] = None) -> str:
    icon = lambda st: ok if st == "ok" else no if st in ("failed", "blocked", "impossible") else warn  # noqa: E731
    who = "unidentified" if inc.executor_id is None else f"<@{inc.executor_id}> (`{inc.executor_id}`)"
    if inc.executor_class:
        who += f" - {inc.executor_class}"
    lines = [f"## {header}", f"> **Incident :** {inc.title}", f"> **Executor :** {who}"]
    if inc.target_id:
        lines.append(f"> **Target :** `{inc.target_id}`")
    lines.append("")
    for i, s in enumerate(inc.steps, 1):
        lines.append(f"{icon(s.status)} **{i}. {s.name}** - `{s.status}`" + ("\n\u2003" + s.detail if s.detail else ""))
    speed = ((f" | punishment sent in {inc.ms_action:.0f} ms" if inc.ms_action is not None else "")
             + f" | handled in {inc.ms:.0f} ms" + (f" ({inc.via})" if inc.via else "")) if inc.ms is not None else ""
    lines.append(f"-# <t:{int(now if now is not None else time.time())}:T>{speed} | confirmed = Discord API accepted it and the state was re-read")
    return "\n".join(lines)


def help_text(prefix: str, st: dict, ok="ON", no="OFF") -> list:
    """Pages for the existing Antinuke help menu (pure text; the command cog wraps it in the Components V2 view).
    st: {integration, botadd, autorec, extra_count}"""
    sw = lambda b: ok if b else no  # noqa: E731
    bot_nuker = (
        f"### ANTI BOT NUKER {sw(st['integration'])}\n"
        f"**Integration Protection** {sw(st['integration'])}\n"
        f"**Bot Role Permission Protection** {sw(st['integration'])}\n"
        f"**Bot Role Position Protection** {sw(st['integration'])}\n"
        f"**Command Permission Protection** {sw(st['integration'])}\n"
        f"**Automatic Permission Recovery** {sw(st['integration'] and st['autorec'])}\n\n"
        f"> `{prefix}antinuke integration on`\n> `{prefix}antinuke integration off`\n"
        f"> `{prefix}antinuke integration status`\n> `{prefix}antinuke integration snapshot`\n"
        "\u276f Detects tampering with my bot role (permissions, position, deletion) and integration changes, "
        "identifies the executor in the audit log, strips their dangerous roles, restores my role "
        "(only when hierarchy allows, re-checked via API), then bans them.")
    bot_add = (
        f"### BOT ADD PROTECTION {sw(st['botadd'])}\n"
        f"**Authorized Bot Addition** {sw(st['botadd'])}\n"
        f"**Extra Owner Authorization** {sw(True)} ({st['extra_count']} extra owner(s))\n"
        f"**Unauthorized Bot Removal** {sw(st['botadd'])}\n"
        f"**Unauthorized Executor Punishment** {sw(st['botadd'])}\n\n"
        f"> `{prefix}antinuke botadd on`\n> `{prefix}antinuke botadd off`\n> `{prefix}antinuke botadd status`\n"
        f"> `{prefix}antinuke extraowner add <user>`\n> `{prefix}antinuke extraowner remove <user>`\n"
        f"> `{prefix}antinuke extraowner list`\n"
        "\u276f Only the **Server Owner** and **Extra Owners** may add bots. Anyone else: the bot is removed and the "
        "person who added it is banned (Discord cannot block an add beforehand, so this reacts right after).")
    return [bot_nuker, bot_add]


# --------------------------------------------------------------------------- persistence (own SQLite, one worker thread)
class Ledger:
    def __init__(self, path: str):
        self.path = path
        self._pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="botguard-db")
        self._conn: Optional[sqlite3.Connection] = None

    async def _run(self, fn, *a):
        return await asyncio.get_running_loop().run_in_executor(self._pool, fn, *a)

    async def open(self) -> None:
        def _open():
            d = os.path.dirname(self.path)
            if d:
                os.makedirs(d, exist_ok=True)
            c = sqlite3.connect(self.path, check_same_thread=False)
            c.execute("PRAGMA journal_mode=WAL")
            c.executescript("""
                CREATE TABLE IF NOT EXISTS bg_config (guild_id INTEGER PRIMARY KEY, integration INTEGER DEFAULT 0, botadd INTEGER DEFAULT 0);
                CREATE TABLE IF NOT EXISTS bg_extra (guild_id INTEGER, user_id INTEGER, added_by INTEGER, added_at REAL,
                                                     PRIMARY KEY (guild_id, user_id));
                CREATE TABLE IF NOT EXISTS bg_snapshot (guild_id INTEGER PRIMARY KEY, role_id INTEGER, name TEXT, perms INTEGER,
                                                        position INTEGER, rank_above INTEGER, taken_at REAL);
                CREATE TABLE IF NOT EXISTS bg_events (id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, guild_id INTEGER,
                                                      kind TEXT, executor_id INTEGER, target_id INTEGER, details TEXT);
                CREATE INDEX IF NOT EXISTS bg_events_g ON bg_events (guild_id, ts);
            """)
            c.commit()
            self._conn = c
        await self._run(_open)

    async def close(self) -> None:
        def _close():
            if self._conn is not None:
                self._conn.close()
                self._conn = None
        await self._run(_close)
        self._pool.shutdown(wait=False)

    async def exec(self, sql: str, args: tuple = ()) -> None:
        def _x():
            self._conn.execute(sql, args)
            self._conn.commit()
        await self._run(_x)

    async def query(self, sql: str, args: tuple = ()) -> list:
        return await self._run(lambda: self._conn.execute(sql, args).fetchall())

    async def wipe_guild(self, gid: int) -> None:
        def _w():
            for t in ("bg_config", "bg_extra", "bg_snapshot"):
                self._conn.execute(f"DELETE FROM {t} WHERE guild_id = ?", (gid,))
            self._conn.commit()
        await self._run(_w)


@dataclass
class Found:
    executor_id: Optional[int]
    entry_id: Optional[int]
    reason: str          # found | no_audit_permission | not_found | api_error
    attempts: int = 0

    @property
    def via(self) -> str:
        return "gateway audit entry" if self.reason == "found" and self.attempts == 0 else "audit-log REST"


def _target_id(entry) -> Optional[int]:
    tid = getattr(entry, "target_id", None)
    if tid is None:
        tid = getattr(getattr(entry, "target", None), "id", None)
    return int(tid) if tid is not None else None


def _ts(created) -> float:
    return created.timestamp() if hasattr(created, "timestamp") else float(created)


# --------------------------------------------------------------------------- the cog
class BotGuard(commands.Cog):
    def __init__(self, bot, db_path: str = DB_PATH, clock: Callable = time.time, sleep=None,
                 global_extra=None, audit_delays=AUDIT_DELAYS, settle: float = SETTLE):
        self.bot = bot
        self._now = clock
        self._sleep = sleep or asyncio.sleep
        self.audit_delays = tuple(audit_delays)
        self.settle = settle
        self.ledger = Ledger(db_path)
        self.flags: dict = {}            # gid -> {"integration": bool, "botadd": bool}
        self.extra: dict = {}            # gid -> set(user ids)
        self.snaps: dict = {}            # gid -> RoleSnap
        self._global_extra = frozenset(global_extra) if global_extra is not None else None
        self._glock: dict = {}           # per-guild lock for role / snapshot work
        self._alock: dict = {}           # per-guild lock for bot-add work
        self._rc_running: set = set()
        self._rc_dirty: set = set()
        self._punished: dict = {}        # (gid, uid) -> ts   punishment claims
        self._add_seen: dict = {}        # (gid, bot id) -> ts
        self._alerted: dict = {}         # (gid, fingerprint) -> ts   dedupe for alert-only incidents
        self._used: OrderedDict = OrderedDict()   # audit entry ids already consumed
        self._hints: OrderedDict = OrderedDict()  # (gid, action, target) -> (entry id, user id, ts) from the gateway
        self._hint_waiters: dict = {}
        self._raw_orig = self._raw_parse = None
        self._bg: set = set()
        self._tasks: list = []
        self.stats = {"incidents": 0, "bans": 0, "bots_removed": 0, "restores": 0}

    # ------------------------------------------------------------------ lifecycle
    async def cog_load(self) -> None:
        await store.load()
        await self.ledger.open()
        await self._load_state()
        if self._global_extra is None:
            self._global_extra = global_extra_owner_ids()
        self._hook_raw()
        self._tasks.append(asyncio.create_task(self._startup()))

    async def cog_unload(self) -> None:
        self._unhook_raw()
        for t in (*self._tasks, *self._bg):
            t.cancel()
        await self.ledger.close()

    async def _load_state(self) -> None:
        for gid, integ, badd in await self.ledger.query("SELECT guild_id, integration, botadd FROM bg_config"):
            self.flags[gid] = {"integration": bool(integ), "botadd": bool(badd)}
        for gid, uid in await self.ledger.query("SELECT guild_id, user_id FROM bg_extra"):
            self.extra.setdefault(gid, set()).add(uid)
        for gid, rid, name, perms, pos, rank, ts in await self.ledger.query(
                "SELECT guild_id, role_id, name, perms, position, rank_above, taken_at FROM bg_snapshot"):
            self.snaps[gid] = RoleSnap(rid, name or "", int(perms), int(pos), int(rank), ts or 0.0)

    def _spawn(self, coro) -> asyncio.Task:
        t = asyncio.get_running_loop().create_task(coro)
        self._bg.add(t)
        t.add_done_callback(self._bg.discard)
        return t

    def _lock(self, table: dict, gid: int) -> asyncio.Lock:
        lk = table.get(gid)
        if lk is None:
            lk = table[gid] = asyncio.Lock()
        return lk

    # ------------------------------------------------------------------ config / authorization (sync, RAM)
    def _enabled(self, gid: int, which: str) -> bool:
        cfg = store.peek(gid)
        return bool(cfg is not None and cfg.enabled and self.flags.get(gid, {}).get(which))

    def flag(self, gid: int, which: str) -> bool:
        return bool(self.flags.get(gid, {}).get(which))

    def global_extra(self) -> frozenset:
        return self._global_extra or frozenset()

    def extra_ids(self, gid: int) -> frozenset:
        return frozenset(self.extra.get(gid, ())) | self.global_extra()

    def is_extra_owner(self, gid: int, uid: int) -> bool:
        return uid in self.extra_ids(gid)

    def is_manager(self, guild, uid: int) -> bool:
        return is_authorized(guild.owner_id, self.extra_ids(guild.id), uid)

    def classify(self, guild, uid: Optional[int]) -> str:
        """self | owner | extra_owner | trusted | untrusted.  'trusted' = existing antinuke whitelist (Anti Integration)
        or mainrole: never punished for touching the bot role, but NOT authorised to add bots."""
        if uid is not None and uid == self.bot.user.id:
            return "self"
        if uid == guild.owner_id:
            return "owner"
        if uid in self.extra_ids(guild.id):
            return "extra_owner"
        cfg = store.peek(guild.id)
        if cfg is not None and uid is not None:
            mask = cfg.wl.get(uid, 0)
            if cfg.mainroles:
                m = guild.get_member(uid)
                if m is not None and any(r.id in cfg.mainroles for r in m.roles):
                    mask = store.ALL_MASK
            if mask & BIT["integration"]:
                return "trusted"
        return "untrusted"

    # ------------------------------------------------------------------ writes used by the commands
    async def set_flag(self, gid: int, which: str, value: bool) -> None:
        if which not in ("integration", "botadd"):
            raise ValueError(which)
        cur = self.flags.setdefault(gid, {"integration": False, "botadd": False})
        cur[which] = bool(value)
        await self.ledger.exec(
            "INSERT INTO bg_config (guild_id, integration, botadd) VALUES (?, ?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET integration=excluded.integration, botadd=excluded.botadd",
            (gid, int(cur["integration"]), int(cur["botadd"])))

    async def enable_defaults(self, gid: int) -> None:
        """`antinuke enable` / wizard: switch both modules on if the server never configured them."""
        if gid not in self.flags:
            await self.set_flag(gid, "integration", True)
            await self.set_flag(gid, "botadd", True)

    async def add_extra(self, guild, uid: int, by: int, is_bot: bool = False) -> str:
        gid = guild.id
        if not valid_id(uid) or is_bot:
            return "invalid"
        if uid == guild.owner_id or uid in self.global_extra():
            return "implicit"
        s = self.extra.setdefault(gid, set())
        if uid in s:
            return "exists"
        if len(s) >= MAX_EXTRA_OWNERS:
            return "limit"
        s.add(uid)
        await self.ledger.exec("INSERT OR IGNORE INTO bg_extra (guild_id, user_id, added_by, added_at) VALUES (?, ?, ?, ?)",
                               (gid, uid, by, self._now()))
        await self._event(gid, "extraowner_add", by, uid, {})
        return "added"

    async def remove_extra(self, gid: int, uid: int, by: int) -> str:
        if uid in self.global_extra() and uid not in self.extra.get(gid, ()):
            return "config"
        s = self.extra.get(gid, set())
        if uid not in s:
            return "absent"
        s.discard(uid)
        await self.ledger.exec("DELETE FROM bg_extra WHERE guild_id = ? AND user_id = ?", (gid, uid))
        await self._event(gid, "extraowner_remove", by, uid, {})
        return "removed"

    async def wipe(self, gid: int) -> None:
        self.flags.pop(gid, None)
        self.extra.pop(gid, None)
        self.snaps.pop(gid, None)
        await self.ledger.wipe_guild(gid)

    async def _event(self, gid, kind, executor, target, details: dict) -> None:
        try:
            await self.ledger.exec(
                "INSERT INTO bg_events (ts, guild_id, kind, executor_id, target_id, details) VALUES (?, ?, ?, ?, ?, ?)",
                (self._now(), gid, kind, executor, target, json.dumps(details)[:8000]))
        except Exception:
            log.exception("botguard: could not write audit event")

    async def recent_events(self, gid: int, n: int = 5) -> list:
        return await self.ledger.query(
            "SELECT ts, kind, executor_id, target_id FROM bg_events WHERE guild_id = ? ORDER BY id DESC LIMIT ?", (gid, n))

    # ------------------------------------------------------------------ bot role + snapshot
    def bot_role(self, guild):
        me = guild.me
        for r in getattr(me, "roles", ()):
            if getattr(getattr(r, "tags", None), "bot_id", None) == self.bot.user.id:
                return r
        return None

    def _is_bot_role(self, guild, role) -> bool:
        snap = self.snaps.get(guild.id)
        if snap is not None and role.id == snap.role_id:
            return True
        return getattr(getattr(role, "tags", None), "bot_id", None) == self.bot.user.id

    def _take(self, guild, role) -> RoleSnap:
        return RoleSnap(role.id, role.name, role.permissions.value, role.position, count_above(guild.roles, role), self._now())

    async def _save_snap(self, guild_id: int, s: RoleSnap) -> None:
        self.snaps[guild_id] = s
        await self.ledger.exec(
            "INSERT OR REPLACE INTO bg_snapshot (guild_id, role_id, name, perms, position, rank_above, taken_at) VALUES (?,?,?,?,?,?,?)",
            (guild_id, s.role_id, s.name, s.perms, s.position, s.rank_above, s.taken_at))

    async def resnapshot(self, guild) -> Optional[RoleSnap]:
        """Owner command / enabling the module: accept the CURRENT bot role as the expected state."""
        async with self._lock(self._glock, guild.id):
            role = self.bot_role(guild)
            if role is None:
                return None
            s = self._take(guild, role)
            await self._save_snap(guild.id, s)
            await self._event(guild.id, "snapshot", None, role.id, {"perms": s.perms, "position": s.position})
            return s

    def restore_possible(self, guild, role=None) -> tuple:
        """-> (bool, reason).  Pure pre-flight; never a promise."""
        role = role or (guild.get_role(self.snaps[guild.id].role_id) if guild.id in self.snaps else self.bot_role(guild))
        if role is None:
            return False, "the bot role no longer exists (a managed role can only be recreated by re-inviting me)"
        me = guild.me
        gp = me.guild_permissions
        if not (gp.administrator or gp.manage_roles):
            return False, "I no longer have Manage Roles"
        if not me.top_role > role:
            return False, ("Role hierarchy: my highest role is my own integration role and Discord does not let a bot edit its "
                           "highest role. Give me an additional role ABOVE my integration role.")
        return True, "ok"

    async def _startup(self) -> None:
        await self.bot.wait_until_ready()
        for guild in list(self.bot.guilds):
            try:
                if self._enabled(guild.id, "integration"):
                    await self._baseline(guild)
            except Exception:
                log.exception("botguard startup baseline failed for %s", guild.id)
            await self._sleep(0.2)

    async def _baseline(self, guild) -> None:
        """Start-up: create the snapshot if missing.  Drift that happened while we were OFFLINE has no executor,
        so it is reported but never auto-reverted or punished."""
        async with self._lock(self._glock, guild.id):
            role = self.bot_role(guild)
            if role is None:
                return
            snap = self.snaps.get(guild.id)
            if snap is None or snap.role_id != role.id:
                await self._save_snap(guild.id, self._take(guild, role))
                return
            d = diff_role(snap, role, guild.roles)
            if not d.any:
                return
            if not d.harmful:
                await self._save_snap(guild.id, self._take(guild, role))
                return
            fp = (guild.id, "offline", role.permissions.value, count_above(guild.roles, role))
            if fp in self._alerted:
                return
            self._alerted[fp] = self._now()
            inc = Incident("role", guild.id, title="Bot role differs from the last snapshot (changed while I was offline)")
            inc.add("Detect", "ok", d.describe())
            inc.add("Verify executor", "unverified", "no gateway event / audit entry exists for changes made while offline")
            inc.add("Recovery", "skipped", "not auto-reverted: it may be a legitimate owner change. "
                    "Fix my permissions or run `antinuke integration snapshot` to accept the current state.")
            await self._publish(guild, inc, "Security Log - Anti Bot Nuker", dm_owner=True)

    # ------------------------------------------------------------------ gateway audit hints (no REST, no polling)
    def _put_hint(self, gid, action, tid, eid, uid) -> None:
        key = (gid, action, tid)
        val = (eid, uid, self._now())
        self._hints[key] = val
        while len(self._hints) > 500:
            self._hints.popitem(last=False)
        for fut in self._hint_waiters.pop(key, ()):
            if not fut.done():
                fut.set_result(val)

    @commands.Cog.listener()
    async def on_audit_log_entry_create(self, entry):
        if entry.action not in (AL.bot_add, AL.role_update, AL.role_delete, AL.integration_delete):
            return
        tid, guild = _target_id(entry), getattr(entry, "guild", None)
        if tid is not None and guild is not None:
            self._put_hint(guild.id, entry.action, tid, entry.id, entry.user_id)

    # ------------------------------------------------------------------ raw gateway fast path
    def _hook_raw(self) -> None:
        """Chain in front of discord.py's GUILD_AUDIT_LOG_ENTRY_CREATE parser (the engine does the same).  The decision
        for an unauthorized bot add is made from the raw dict in RAM and kick + ban are sent before any discord.py
        object is built or any listener runs."""
        try:
            parsers = self.bot._connection.parsers
            orig = parsers["GUILD_AUDIT_LOG_ENTRY_CREATE"]
        except Exception:
            log.warning("botguard: raw audit hook unavailable - using the normal listeners")
            return
        if self._raw_orig is not None:
            return
        self._raw_orig, me = orig, self

        def parse(data):
            try:
                me._raw_audit(data)
            except Exception:
                log.exception("botguard raw audit hook failed")
            return orig(data)

        self._raw_parse = parse
        parsers["GUILD_AUDIT_LOG_ENTRY_CREATE"] = parse

    def _unhook_raw(self) -> None:
        try:
            parsers = self.bot._connection.parsers
            if self._raw_parse is not None and parsers.get("GUILD_AUDIT_LOG_ENTRY_CREATE") is self._raw_parse:
                parsers["GUILD_AUDIT_LOG_ENTRY_CREATE"] = self._raw_orig     # only if nobody chained after us
        except Exception:
            pass
        self._raw_orig = self._raw_parse = None

    def _raw_audit(self, data: dict) -> None:
        """Pure CPU, no awaits until the punishment task starts."""
        at = data.get("action_type")
        if at == CMDPERM_ACTION:
            return self._raw_cmdperm(data)
        if at not in (28, 31, 32, 82):
            return
        try:
            gid, eid = int(data["guild_id"]), int(data["id"])
            uid, tid = int(data["user_id"]), int(data["target_id"])
            action = AL(at)
        except (KeyError, TypeError, ValueError):
            return
        guild = self.bot.get_guild(gid)
        if guild is None:
            return
        self._put_hint(gid, action, tid, eid, uid)               # earliest possible executor hint for every flow
        if at != 28 or tid == self.bot.user.id or not self._enabled(gid, "botadd"):
            return
        if is_authorized(guild.owner_id, self.extra_ids(gid), uid):
            return                                               # authorized: the normal path records it
        key, now = (gid, tid), self._now()
        if now - self._add_seen.get(key, -1e9) < 120:
            return
        self._add_seen[key] = now                                # claim BEFORE any await
        self._mark_used(eid)
        t = _spawn_eager(self._bot_add_fast(guild, tid, uid, eid))
        self._bg.add(t)                                          # keep a reference (tasks can be garbage collected)
        t.add_done_callback(self._bg.discard)

    def _raw_cmdperm(self, data: dict) -> None:
        """Someone edited the Command Permissions of an application.  Only MY application matters."""
        try:
            gid, eid, uid = int(data["guild_id"]), int(data["id"]), int(data["user_id"])
            app = int((data.get("options") or {}).get("application_id") or 0)
        except (KeyError, TypeError, ValueError):
            return
        if app != self.bot.user.id or not self._enabled(gid, "integration"):
            return
        guild = self.bot.get_guild(gid)
        if guild is None or eid in self._used:
            return
        self._mark_used(eid)
        t = _spawn_eager(self._cmdperm_changed(guild, uid, eid, data.get("changes") or []))
        self._bg.add(t)
        t.add_done_callback(self._bg.discard)

    async def _cmdperm_changed(self, guild, uid: int, eid: int, changes) -> None:
        gid, now = guild.id, self._now()
        cls = self.classify(guild, uid)
        if cls in ("self", "owner", "extra_owner"):
            await self._event(gid, "cmdperm_change_authorized", uid, eid, {})
            return
        key = (gid, "cmdperm", uid)
        if now - self._alerted.get(key, -1e9) < PUNISH_TTL:
            return                                               # same person, burst of edits: one incident
        self._alerted[key] = now
        inc = Incident("integration", gid, target_id=eid, started=now, executor_id=uid, executor_class=cls,
                       title="Command Permissions of MY integration were changed (Server Settings > Integrations)")
        inc.via = "raw gateway"
        inc.add("Detect", "ok", "application command permissions update (audit action 121) for my application")
        if cls == "trusted":
            inc.add("Verify executor", "ok", "whitelisted for Anti Integration / mainrole: not punished, not modified")
        else:
            inc.add("Verify executor", "ok", "not the Server Owner / Extra Owner / whitelisted")
            res = await asyncio.gather(self._strip(guild, uid), self._ban(guild, uid, "Antinuke | Bot command permissions changed"))
            inc.ms_action = (time.perf_counter() - inc.t0) * 1000
            inc.add("Strip attacker", *res[0])
            inc.add("Ban attacker", *res[1])
        inc.add("Restore command permissions", "impossible",
                "Discord only lets a user's OAuth token edit command permissions, not a bot token: an owner must reset them "
                "in Server Settings > Integrations")
        await self._publish(guild, inc, "Security Log - Anti Bot Nuker", dm_owner=True)

    async def _bot_add_fast(self, guild, bot_id: int, uid: int, eid: int) -> None:
        try:
            async with self._lock(self._alock, guild.id):
                await self._handle_bot_add(guild, bot_id, Found(uid, eid, "found", 0), raw=True)
        except Exception:
            log.exception("botguard fast bot-add failed guild=%s", guild.id)

    def _take_hint(self, key):
        val = self._hints.get(key)
        if val is None or val[0] in self._used or self._now() - val[2] > AUDIT_MAX_AGE:
            return None
        self._mark_used(val[0])
        return val

    async def _gateway_hint(self, guild, action, target_id):
        """Executor straight from the gateway audit entry: already cached, or wait (event driven) up to HINT_WAIT."""
        key = (guild.id, action, target_id)
        val = self._take_hint(key)
        if val is not None:
            return val
        fut = asyncio.get_running_loop().create_future()
        self._hint_waiters.setdefault(key, []).append(fut)
        try:
            await asyncio.wait_for(fut, HINT_WAIT)
        except asyncio.TimeoutError:
            pass
        finally:
            lst = self._hint_waiters.get(key)
            if lst is not None:
                if fut in lst:
                    lst.remove(fut)
                if not lst:
                    self._hint_waiters.pop(key, None)
        return self._take_hint(key)

    # ------------------------------------------------------------------ audit-log lookup (bounded retries)
    def _mark_used(self, entry_id) -> None:
        self._used[entry_id] = True
        while len(self._used) > 500:
            self._used.popitem(last=False)

    async def _find_executor(self, guild, actions, target_id: int, delays=None, matcher=None) -> Found:
        attempts, saw_error = 0, False
        if matcher is None and len(actions) == 1:                  # fast path: gateway entry, ~0 ms when already cached
            hint = await self._gateway_hint(guild, actions[0], target_id)
            if hint is not None:
                return Found(hint[1], hint[0], "found", 0)
        for delay in (self.audit_delays if delays is None else delays):
            if delay:
                await self._sleep(delay)
            attempts += 1
            for action in actions:
                try:
                    async for entry in guild.audit_logs(limit=AUDIT_LIMIT, action=action):
                        if _target_id(entry) != target_id or entry.id in self._used:
                            continue
                        if self._now() - _ts(entry.created_at) > AUDIT_MAX_AGE:
                            continue
                        if matcher is not None and not matcher(entry):
                            continue
                        self._mark_used(entry.id)
                        return Found(entry.user_id, entry.id, "found", attempts)
                except discord.Forbidden:
                    return Found(None, None, "no_audit_permission", attempts)     # retrying cannot help
                except discord.HTTPException:
                    saw_error = True
        return Found(None, None, "api_error" if saw_error else "not_found", attempts)

    async def _retry(self, factory):
        """Retry only transient Discord failures (5xx); 429 is already handled inside discord.py."""
        for i in range(3):
            try:
                return await factory()
            except discord.HTTPException as exc:
                if isinstance(exc, (discord.Forbidden, discord.NotFound)) or getattr(exc, "status", 0) < 500 or i == 2:
                    raise
                await self._sleep(0.3 * (i + 1))

    # ------------------------------------------------------------------ punishment primitives
    async def _strip(self, guild, uid: int, defer: bool = False) -> tuple:
        """Remove the executor's dangerous ROLES from the executor only (shared roles are never edited)."""
        member = guild.get_member(uid)
        if member is None:
            try:
                member = await guild.fetch_member(uid)
            except discord.NotFound:
                return "skipped", "executor is no longer in the server"
            except discord.HTTPException:
                return "unverified", "could not load the executor to strip their roles"
        cfg = store.peek(guild.id)
        protected = set(cfg.mainroles) if cfg else set()
        if cfg and cfg.barrier:
            protected.add(cfg.barrier)
        top = guild.me.top_role
        removable, blocked = [], []
        for r in member.roles:
            if r.is_default() or not dangerous_in(r.permissions.value):
                continue
            if r.managed:
                blocked.append(f"{r.name} (managed/integration role)")
            elif r.id in protected:
                blocked.append(f"{r.name} (protected role)")
            elif not r < top:
                blocked.append(f"{r.name} (above my highest role)")
            else:
                removable.append(r)
        if not removable and not blocked:
            return "skipped", "executor holds no dangerous roles I can see"
        if removable:
            try:
                await self._retry(lambda: member.remove_roles(*removable, reason="Antinuke | Bot nuker: dangerous roles stripped", atomic=False))
            except discord.Forbidden:
                return "failed", "Discord refused (Manage Roles / hierarchy)"
            except discord.NotFound:
                return "skipped", "executor left the server"
            except discord.HTTPException as exc:
                return "failed", f"Discord error {getattr(exc, 'status', '?')}"
        async def finish():
            try:                                                # confirm by re-reading the member
                fresh = await guild.fetch_member(uid)
            except discord.HTTPException:
                return "unverified", f"removed {', '.join(r.name for r in removable) or 'nothing'}, but could not re-read the member to confirm"
            left = [r.name for r in fresh.roles if not r.is_default() and dangerous_in(r.permissions.value)]
            done = ", ".join(r.name for r in removable) or "none"
            if left:
                return "partial", f"removed: {done}. STILL dangerous: {', '.join(left)}" + (f" ({'; '.join(blocked)})" if blocked else "")
            return "ok", f"removed: {done} (re-read confirmed)"

        if defer:                                               # ban must not wait for a confirmation round trip
            return "unverified", "removal accepted by Discord; confirming after the ban", finish
        return await finish()

    async def _restore(self, guild, snap: RoleSnap, diff: RoleDiff, defer: bool = False) -> tuple:
        cfg = store.peek(guild.id)
        if cfg is not None and not cfg.autorec:
            return "skipped", "Auto Recovery is OFF (`antinuke autorecovery enable`)"
        role = guild.get_role(snap.role_id)
        if role is None:
            return "impossible", ("the bot role was deleted. A managed role is recreated only when I am re-invited; "
                                  "I cannot restore it myself")
        ok, why = self.restore_possible(guild, role)
        if not ok:
            return "blocked", why
        try:
            if role.permissions.value != snap.perms:
                await self._retry(lambda: role.edit(permissions=discord.Permissions(snap.perms), reason="Antinuke | Bot role permissions restored"))
            if diff.rank_worse:
                await self._retry(lambda: role.edit(position=snap.position, reason="Antinuke | Bot role position restored"))
        except discord.Forbidden:
            return "failed", "Discord refused the edit (403: permissions / hierarchy)"
        except discord.NotFound:
            return "failed", "the role no longer exists (404)"
        except discord.HTTPException as exc:
            return "failed", f"Discord error {getattr(exc, 'status', '?')}"
        async def finish():
            try:                                                # never claim success without re-reading
                roles = await guild.fetch_roles()
            except discord.HTTPException:
                return "unverified", "edit requests were accepted but I could not re-read roles to confirm"
            cur = next((r for r in roles if r.id == snap.role_id), None)
            if cur is None:
                return "failed", "role vanished while restoring"
            perms_ok = cur.permissions.value == snap.perms
            rank_ok = count_above(roles, cur) <= snap.rank_above
            if perms_ok and rank_ok:
                self.stats["restores"] += 1
                return "ok", "permissions + position re-read from Discord and match the snapshot"
            bits = []
            if not perms_ok:
                bits.append(f"permissions differ ({', '.join(perm_names(snap.perms ^ cur.permissions.value))})")
            if not rank_ok:
                bits.append("position still lower than expected")
            return "failed", "Discord accepted the request but the role still differs: " + "; ".join(bits)

        if defer:
            return "unverified", "edit accepted by Discord; confirming after the ban", finish
        return await finish()

    async def _ban(self, guild, uid: int, reason: str) -> tuple:
        cls = self.classify(guild, uid)
        if cls in ("self", "owner", "extra_owner"):
            return "skipped", f"protected ({cls})"
        key = (guild.id, uid)
        now = self._now()
        for k in [k for k, t in self._punished.items() if now - t > PUNISH_TTL]:
            self._punished.pop(k, None)
        eng = self.bot.get_cog("AntinukeEngine")
        flagged = getattr(eng, "flagged", None)
        engine_claim = flagged is not None and time.monotonic() - flagged.get(key, -1e9) < PUNISH_TTL
        if key in self._punished or engine_claim:
            return await self._confirm_banned(guild, uid)       # someone else is already punishing: only VERIFY
        self._punished[key] = now                               # claim BEFORE any await
        if flagged is not None:
            flagged[key] = time.monotonic()                      # the engine will not punish the same user again
        direct = getattr(eng, "_direct_ban", None)
        if direct is not None:                                   # engine's pre-warmed PUT, no discord.py overhead
            try:
                res = await direct(guild.id, uid, reason)
            except Exception:
                res = None
            if res is True:
                self.stats["bans"] += 1
                return "ok", "ban accepted by Discord (direct request)"
            if res is False:
                return "failed", "Discord refused the ban (403/404: Ban Members missing, hierarchy, or user unknown)"
        try:
            await self._retry(lambda: guild.ban(discord.Object(id=uid), reason=reason, delete_message_seconds=0))
        except discord.Forbidden:
            return "failed", "Discord refused the ban (Ban Members missing or executor's role is above mine)"
        except discord.HTTPException as exc:
            return "failed", f"Discord error {getattr(exc, 'status', '?')}"
        self.stats["bans"] += 1
        return "ok", "ban accepted by Discord"

    async def _confirm_banned(self, guild, uid: int) -> tuple:
        for i in range(2):
            try:
                await guild.fetch_ban(discord.Object(id=uid))
                return "ok", "already banned by a parallel action (confirmed with fetch_ban); no second ban sent"
            except discord.NotFound:
                if i == 0:
                    await self._sleep(1.0)
            except discord.HTTPException:
                break
        return "unverified", "another action claimed this punishment but I could not confirm a ban"

    # ------------------------------------------------------------------ reporting
    def _channel(self, guild):
        cfg = store.peek(guild.id)
        return guild.get_channel(cfg.log) if cfg is not None and cfg.log else None

    async def _publish(self, guild, inc: Incident, header: str, dm_owner: bool = False) -> None:
        """Detailed log -> configured antinuke log channel; optional DM to the Server Owner.  Both best effort and
        reported (a failed DM is logged in the card, never claimed)."""
        self.stats["incidents"] += 1
        inc.ms = (time.perf_counter() - inc.t0) * 1000
        await self._event(guild.id, f"incident_{inc.kind}", inc.executor_id, inc.target_id, inc.as_dict())
        sent = False
        channel = self._channel(guild)
        if dm_owner:
            dm_ok = await self._dm_owner(guild, render_incident(inc, header + f" ({guild.name})", now=self._now()))
            inc.add("Notify Server Owner", "ok" if dm_ok else "failed",
                    "DM delivered" if dm_ok else "could not DM the owner (DMs closed)" + ("; see log channel" if channel else ""))
        if channel is not None:
            try:
                from utils import antinuke_ui as ui
            except Exception:
                ui = None
            try:
                if ui is not None:
                    body = render_incident(inc, header, ok=ui.OK, no=ui.NO, now=self._now())
                    await channel.send(view=ui.view_of(ui.text(body)), allowed_mentions=ui.NO_PING)
                else:
                    await channel.send(content=render_incident(inc, header, now=self._now())[:1990],
                                       allowed_mentions=discord.AllowedMentions.none())
                sent = True
            except (discord.Forbidden, discord.HTTPException):
                sent = False
        log.info("botguard incident guild=%s kind=%s executor=%s log_channel=%s steps=%s", guild.id, inc.kind,
                 inc.executor_id, "sent" if sent else "unavailable", [(s.name, s.status) for s in inc.steps])

    async def _dm_owner(self, guild, text: str) -> bool:
        uid = guild.owner_id
        try:
            user = self.bot.get_user(uid) or await self.bot.fetch_user(uid)
            await user.send(content=text[:1990], allowed_mentions=discord.AllowedMentions.none())
            return True
        except (discord.Forbidden, discord.HTTPException):
            return False

    # ------------------------------------------------------------------ Bot Add Authorization
    @commands.Cog.listener()
    async def on_member_join(self, member):
        if getattr(member, "bot", False) and member.id != self.bot.user.id and self._enabled(member.guild.id, "botadd"):
            self._spawn(self._bot_added(member))

    async def _bot_added(self, member) -> None:
        guild = member.guild
        gid = guild.id
        key, now = (gid, member.id), self._now()
        if now - self._add_seen.get(key, -1e9) < 120:
            return                                               # the raw fast path (or a duplicate event) owns it
        self._add_seen[key] = now                                # claim before any await
        async with self._lock(self._alock, gid):
            found = await self._find_executor(guild, [AL.bot_add], member.id)
            await self._handle_bot_add(guild, member.id, found, name=getattr(member, "name", None))

    async def _handle_bot_add(self, guild, bot_id: int, found: Found, name=None, raw: bool = False) -> None:
        gid, now = guild.id, self._now()
        if name is None:
            m = guild.get_member(bot_id)
            name = getattr(m, "name", None) or str(bot_id)
        inc = Incident("botadd", gid, target_id=bot_id, started=now, title=f"Bot added: {name} (`{bot_id}`)")
        inc.via = "raw gateway" if raw else found.via
        inc.add("Detect", "ok", "bot add detected from the audit entry" if raw else "bot account joined the server (member-join event)")
        if found.executor_id is None:
            why = {"no_audit_permission": "I lack View Audit Log", "api_error": "audit-log requests kept failing",
                   "not_found": f"no matching entry after {found.attempts} polls"}[found.reason]
            inc.add("Verify executor", "unverified", f"executor could not be identified ({why})")
            inc.add("Remove bot", "skipped", "not removed: without a verified executor I cannot prove it was unauthorized")
            inc.add("Ban executor", "skipped", "nobody is punished on a guess")
            await self._publish(guild, inc, "Security Log - Bot Add Protection", dm_owner=True)
            return
        uid = found.executor_id
        inc.executor_id, inc.executor_class = uid, self.classify(guild, uid)
        if is_authorized(guild.owner_id, self.extra_ids(gid), uid):
            inc.title = "Authorized bot addition: " + inc.title
            inc.add("Verify executor", "ok", f"{inc.executor_class.replace('_', ' ')} is authorized")
            await self._event(gid, "botadd_authorized", uid, bot_id, {})
            log.info("botguard: authorized bot add guild=%s bot=%s by=%s (%s)", gid, bot_id, uid, inc.executor_class)
            return
        inc.title = "UNAUTHORIZED bot addition: " + inc.title
        inc.add("Verify executor", "ok", "not the Server Owner or an Extra Owner")

        async def remove_bot():
            try:                                                 # by id: needs no cached member object
                await self._retry(lambda: guild.kick(discord.Object(id=bot_id), reason="Antinuke | Unauthorized bot removed"))
                self.stats["bots_removed"] += 1
                return "ok", "kick accepted by Discord"
            except discord.NotFound:
                return "ok", "bot was already gone (404), e.g. removed by the main antinuke engine"
            except discord.Forbidden:
                return "failed", "Discord refused (Kick Members missing or that bot's role is above mine)"
            except discord.HTTPException as exc:
                return "failed", f"Discord error {getattr(exc, 'status', '?')}"

        # speed: removal and ban are independent, so both go out at the same moment (steps are still logged in order)
        (st1, d1), (st2, d2) = await asyncio.gather(remove_bot(), self._ban(guild, uid, "Antinuke | Unauthorized bot addition"))
        inc.ms_action = (time.perf_counter() - inc.t0) * 1000
        inc.add("Remove bot", st1, d1)
        inc.add("Ban executor", st2, d2)
        await self._publish(guild, inc, "Security Log - Bot Add Protection", dm_owner=True)

    # ------------------------------------------------------------------ Anti Bot Nuker: role events
    @commands.Cog.listener()
    async def on_guild_role_update(self, before, after):
        if self._enabled(after.guild.id, "integration") and self._is_bot_role(after.guild, after):
            if before.permissions != after.permissions or before.position != after.position:
                self._kick_role_check(after.guild)

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        if self._enabled(role.guild.id, "integration") and self._is_bot_role(role.guild, role):
            self._kick_role_check(role.guild)

    def _kick_role_check(self, guild) -> None:
        gid = guild.id
        if gid in self._rc_running:
            self._rc_dirty.add(gid)                              # the running reconcile re-checks once more
            return
        self._rc_running.add(gid)                                # claimed synchronously
        self._spawn(self._role_loop(guild))

    async def _role_loop(self, guild) -> None:
        gid = guild.id
        try:
            while True:
                if self.settle:
                    await self._sleep(self.settle)
                self._rc_dirty.discard(gid)
                try:
                    await self._role_incident(guild)
                except Exception:
                    log.exception("botguard role incident failed guild=%s", gid)
                if gid not in self._rc_dirty:
                    break
        finally:
            self._rc_running.discard(gid)

    async def _role_incident(self, guild) -> None:
        gid = guild.id
        async with self._lock(self._glock, gid):
            snap = self.snaps.get(gid)
            if snap is None:
                role = self.bot_role(guild)
                if role is not None:
                    await self._save_snap(gid, self._take(guild, role))
                return
            role = guild.get_role(snap.role_id)
            diff = diff_role(snap, role, guild.roles)
            if not diff.any:
                return                                          # already reconciled (duplicate gateway events)
            inc = Incident("role", gid, target_id=snap.role_id, started=self._now(), title=f"Bot role tampering: {diff.describe()}")
            inc.add("Detect", "ok", diff.describe())
            actions = [AL.role_delete] if diff.deleted else [AL.role_update]
            delays = AUDIT_DELAYS_SHORT if (not diff.deleted and not diff.lost and not diff.gained) else None
            found = await self._find_executor(guild, actions, snap.role_id, delays=delays)
            inc.via = found.via
            role = guild.get_role(snap.role_id)                  # state may have moved while we waited
            diff = diff_role(snap, role, guild.roles)
            if not diff.any:
                return
            if found.executor_id is None:
                why = {"no_audit_permission": "I lack View Audit Log (a stripped bot role usually loses it)",
                       "api_error": "audit-log requests kept failing", "not_found": f"no matching entry after {found.attempts} polls"}[found.reason]
                inc.add("Verify executor", "unverified", f"executor could not be identified ({why})")
                if diff.harmful:
                    inc.add("Strip attacker", "skipped", "no verified executor")
                    st, d = await self._restore(guild, snap, diff)
                    inc.add("Restore bot role", st, d + " (reverting only weakens-the-bot changes; nobody punished)")
                    inc.add("Ban attacker", "skipped", "nobody is punished on a guess")
                else:
                    await self._save_snap(gid, self._take(guild, role))
                    return
                await self._publish(guild, inc, "Security Log - Anti Bot Nuker", dm_owner=True)
                return
            uid = found.executor_id
            inc.executor_id, inc.executor_class = uid, self.classify(guild, uid)
            if inc.executor_class in ("self", "owner", "extra_owner"):
                if role is not None:
                    await self._save_snap(gid, self._take(guild, role))
                await self._event(gid, "botrole_change_authorized", uid, snap.role_id, {"diff": diff.describe()})
                return
            if not diff.harmful:                                 # only additions by a non-owner: absorb, record
                await self._save_snap(gid, self._take(guild, role))
                await self._event(gid, "botrole_gain", uid, snap.role_id, {"diff": diff.describe()})
                return
            if inc.executor_class == "trusted":
                fp = (gid, "trusted", uid, role.permissions.value if role else -1)
                if fp in self._alerted:
                    return
                self._alerted[fp] = self._now()
                inc.add("Verify executor", "ok", "whitelisted for Anti Integration / mainrole: not punished, not modified")
                inc.add("Recovery", "skipped", "left as is; use `antinuke integration snapshot` to accept or fix it yourself")
                await self._publish(guild, inc, "Security Log - Anti Bot Nuker", dm_owner=True)
                return
            inc.add("Verify executor", "ok", "executor is not the Server Owner / Extra Owner / whitelisted")
            fins = []

            def step(name, res):                                 # res = (status, detail) or (status, detail, finish)
                st = inc.add(name, res[0], res[1])
                if len(res) == 3:
                    fins.append((st, res[2]))

            step("Strip attacker", await self._strip(guild, uid, defer=True))                      # 3. strip
            step("Restore bot role", await self._restore(guild, snap, diff, defer=True))          # 4. restore
            step("Ban attacker", await self._ban(guild, uid, "Antinuke | Bot role / integration tampering"))   # 5. ban
            inc.ms_action = (time.perf_counter() - inc.t0) * 1000
            if fins:                                             # confirmations (API re-reads) AFTER the ban, in parallel
                done = await asyncio.gather(*(f() for _, f in fins))
                for (st, _), (new_st, new_d) in zip(fins, done):
                    st.status, st.detail = new_st, new_d
            await self._publish(guild, inc, "Security Log - Anti Bot Nuker", dm_owner=True)       # 6. log

    # ------------------------------------------------------------------ Anti Bot Nuker: integration events
    def _is_our_app(self, application_id) -> bool:
        return application_id is not None and int(application_id) == self.bot.user.id

    @commands.Cog.listener()
    async def on_integration_update(self, integration):
        app = getattr(getattr(integration, "application", None), "id", None)
        if self._is_our_app(app) and self._enabled(integration.guild.id, "integration"):
            self._kick_role_check(integration.guild)             # settings of our integration changed -> reconcile role

    @commands.Cog.listener()
    async def on_raw_integration_delete(self, payload):
        gid = payload.guild_id
        if not self._is_our_app(getattr(payload, "application_id", None)) or not self._enabled(gid, "integration"):
            return
        guild = self.bot.get_guild(gid)
        if guild is None:
            return
        self._spawn(self._integration_deleted(guild, payload.integration_id))

    async def _integration_deleted(self, guild, integration_id) -> None:
        found = await self._find_executor(guild, [AL.integration_delete], integration_id, delays=AUDIT_DELAYS_SHORT)
        inc = Incident("integration", guild.id, target_id=integration_id,
                       title="MY integration (bot application) was deleted from the server settings")
        inc.executor_id, inc.via = found.executor_id, found.via
        if found.executor_id is not None:
            inc.executor_class = self.classify(guild, found.executor_id)
        inc.add("Detect", "ok", "integration delete event for my application")
        inc.add("Verify executor", "ok" if found.executor_id else "unverified",
                "identified via audit log" if found.executor_id else f"not identified ({found.reason})")
        inc.add("Self-recovery", "impossible", "deleting the integration removes me from the server. I cannot re-add myself; "
                "an authorised owner must re-invite me")
        if found.executor_id and inc.executor_class == "untrusted":
            st, d = await self._strip(guild, found.executor_id)
            inc.add("Strip attacker", st, d)
            st, d = await self._ban(guild, found.executor_id, "Antinuke | Bot integration removed")
            inc.add("Ban attacker", st, d + " (may fail: I am being removed)")
        await self._publish(guild, inc, "Security Log - Anti Bot Nuker", dm_owner=True)

    @commands.Cog.listener()
    async def on_guild_remove(self, guild):
        if not (self.flag(guild.id, "integration") or self.flag(guild.id, "botadd")):
            return
        cfg = store.peek(guild.id)
        if cfg is None or not cfg.enabled:
            return
        inc = Incident("removed", guild.id, title=f"I was removed from **{guild.name}**")
        inc.add("Detect", "ok", "guild-remove event: kicked, banned, integration deleted, or the server was deleted "
                "(Discord does not say which)")
        inc.add("Self-recovery", "impossible", "I have no access to the server any more; an authorised owner must re-invite me")
        await self._event(guild.id, "incident_removed", None, None, inc.as_dict())
        ok = await self._dm_owner(guild, render_incident(inc, f"Security Log - {guild.name}", now=self._now()))
        log.warning("botguard: removed from guild %s (owner DM %s)", guild.id, "delivered" if ok else "FAILED")
