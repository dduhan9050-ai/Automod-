"""Antinuke engine - built for reaction time.

Why it is fast:
  * ONE gateway listener (`on_audit_log_entry_create`). Discord pushes the audit entry
    (executor id + target id) over the websocket the moment the action happens, so there
    is no audit-log REST polling, no sleeps and no retries.
  * The hot path is fully synchronous until the first REST call: config is read from RAM
    (utils.antinuke_store.peek), the verdict is a few dict/bit operations.
  * The ban is fired immediately, in parallel with the recovery job and the DM
    (asyncio.gather); logging happens afterwards and never delays the punishment.
  * Repeat actions of an already-punished user skip judging and go straight to recovery.

Rules:
  * Not whitelisted for that module            -> instant punishment (zero tolerance).
  * Whitelisted + betrayal guard ON            -> punished once they exceed their limit
                                                  inside the rolling WINDOW.
  * Server owner and the bot itself are always trusted.
"""
from __future__ import annotations

import asyncio
import gc
import logging
import os
import re
import time
from collections import deque
from datetime import timedelta
from urllib.parse import quote
from itertools import islice
from types import SimpleNamespace

import aiohttp
import aiosqlite
import discord
from discord.ext import commands, tasks

from utils import antinuke_store as store
from utils import antinuke_ui as ui

log = logging.getLogger("deathbot.antinuke")
AL = discord.AuditLogAction
BIT = store.BIT
WINDOW = store.WINDOW
FLAG_TTL = 120.0      # a punished user is not re-punished / re-judged for this long
SNAP_TTL = 60.0
REASON = "Antinuke | {}"
DANGEROUS = ("administrator", "ban_members", "kick_members", "manage_guild",
             "manage_channels", "manage_roles", "manage_webhooks", "mention_everyone")

REASONS = {
    "ban": "Unauthorized member ban.", "unban": "Unauthorized member unban.",
    "kick": "Unauthorized member kick.", "prune": "Unauthorized member prune.",
    "botadd": "Unauthorized bot add.", "chcr": "Unauthorized channel create.",
    "chdl": "Unauthorized channel delete.", "chup": "Unauthorized channel update.",
    "rlcr": "Unauthorized role create.", "rldl": "Unauthorized role delete.",
    "rlup": "Unauthorized role update.", "memup": "Unauthorized member role update.",
    "serverup": "Unauthorized server update.", "webhook": "Unauthorized webhook change.",
    "emoji": "Unauthorized emoji/sticker change.", "integration": "Unauthorized integration add.",
    "everyone": "Unauthorized @everyone/@here mention.",
    "linkrole": "Unauthorized linked role (role requirements) created.",
}


def _spawn(coro):
    """Start a task so it runs up to its first await RIGHT NOW (Python 3.12 eager start) instead of waiting
    behind every callback already queued on the loop.  3.11 falls back to a normal task."""
    loop = asyncio.get_running_loop()
    try:
        return asyncio.Task(coro, loop=loop, eager_start=True)
    except TypeError:
        return loop.create_task(coro)


def _dangerous(role: discord.Role) -> bool:
    p = role.permissions
    return any(getattr(p, name, False) for name in DANGEROUS)


def _raw_danger(guild, data: dict) -> bool:
    """Raw-gateway version of _danger_roles: did this member_role_update GRANT a dangerous role?"""
    for ch in data.get("changes") or ():
        if ch.get("key") == "$add":
            for r in ch.get("new_value") or ():
                role = guild.get_role(int(r["id"]))
                if role is not None and _dangerous(role):
                    return True
    return False


def _danger_roles(entry) -> list:
    """Dangerous roles that a member_role_update entry GRANTED."""
    added = getattr(getattr(entry, "after", None), "roles", None) or ()
    out = []
    for r in added:
        role = entry.guild.get_role(r.id)
        if role is not None and _dangerous(role):
            out.append(role)
    return out



# ------------------------------------------------------------------ linked roles
def _is_linked(role) -> bool:
    """True for a Discord *Linked Role* (a role with connection / app requirements)."""
    try:
        tags = getattr(role, "tags", None)
        return bool(tags is not None and tags.is_guild_connection())
    except Exception:
        return False


# ------------------------------------------------------------------ recovery jobs
# Each takes (engine, guild, entry) and raises on failure. entry may be a Message (everyone).
def _r(text: str) -> str:
    return REASON.format(text)


async def rec_unban(e, guild, entry):
    await guild.unban(discord.Object(id=entry.target_id), reason=_r("Ban reverted"))


async def rec_reban(e, guild, entry):
    await guild.ban(discord.Object(id=entry.target_id), reason=_r("Unban reverted"))


async def rec_kick_bot(e, guild, entry):
    await guild.kick(discord.Object(id=entry.target_id), reason=_r("Unauthorized bot removed"))


async def rec_del_channel(e, guild, entry):
    # by id: the audit entry can arrive BEFORE discord.py has cached the new channel, so get_channel() was
    # often None and the delete was silently skipped (recovery "worked" but nothing happened).
    try:
        await e.bot.http.delete_channel(entry.target_id, reason=_r("Channel create reverted"))
    except TypeError:
        ch = guild.get_channel(entry.target_id)
        if ch is not None:
            await ch.delete(reason=_r("Channel create reverted"))


async def _channel_from_audit(guild, before):
    """Fallback when no cached snapshot exists: rebuild the channel from the audit-log diff."""
    name = getattr(before, "name", None) or "restored-channel"
    ctype = getattr(before, "type", None)
    overwrites = {}
    for target, ow in (getattr(before, "overwrites", None) or []):
        real = guild.get_role(target.id) or guild.get_member(target.id)
        if real is not None:
            overwrites[real] = ow
    kw = {"overwrites": overwrites, "reason": _r("Channel delete reverted")}
    pos0 = getattr(before, "position", None)
    if pos0 is not None:
        kw["position"] = pos0
    parent = getattr(before, "category", None)
    category = guild.get_channel(parent.id) if parent is not None else None
    if ctype == discord.ChannelType.category:
        return await guild.create_category(name, **kw)
    if category is not None:
        kw["category"] = category
    if ctype == discord.ChannelType.voice:
        return await guild.create_voice_channel(name, bitrate=min(getattr(before, "bitrate", 64000) or 64000,
                                                                  int(guild.bitrate_limit)), **kw)
    if ctype == discord.ChannelType.stage_voice:
        return await guild.create_stage_channel(name, **kw)
    if ctype == discord.ChannelType.forum:
        return await guild.create_forum(name, **kw)
    return await guild.create_text_channel(name, topic=getattr(before, "topic", None),
                                           nsfw=bool(getattr(before, "nsfw", False)), **kw)


async def rec_restore_channel(e, guild, entry):
    try:
        old = await e.snapshot("chdl", entry.target_id)
    except LookupError:
        old = None
    if old is not None:
        new = await old.clone(reason=_r("Channel delete reverted"))
    else:                                              # snapshot missed -> use the audit-log data
        new = await _channel_from_audit(guild, entry.before)
        old = None
    pos = getattr(old, "position", None) if old is not None else getattr(entry.before, "position", None)
    if pos is not None:
        try:
            await new.edit(position=pos, reason=_r("Channel position restored"))
        except Exception:
            pass


_MISSING = object()


async def rec_revert_channel(e, guild, entry):
    ch = guild.get_channel(entry.target_id)
    if ch is None:
        return
    try:
        before = await e.snapshot("chup", entry.target_id)
    except LookupError:                                  # snapshot missed -> simple attrs from the audit diff
        kw = {a: getattr(entry.before, a) for a in ("name", "topic", "nsfw", "slowmode_delay", "bitrate", "user_limit")
              if getattr(entry.before, a, _MISSING) is not _MISSING}
        if not kw:
            raise
        await ch.edit(reason=_r("Channel update reverted"), **kw)
        return
    kwargs = {"overwrites": before.overwrites}
    for attr in ("name", "topic", "nsfw", "slowmode_delay", "bitrate", "user_limit", "category", "position"):
        if hasattr(before, attr):
            kwargs[attr] = getattr(before, attr)
    try:
        await ch.edit(reason=_r("Channel update reverted"), **kwargs)
    except (TypeError, discord.HTTPException):
        # some attribute is not valid for this channel type -> restore the essentials only
        await ch.edit(reason=_r("Channel update reverted"), name=before.name, overwrites=before.overwrites)


async def rec_del_role(e, guild, entry):
    try:                                                # by id, same cache race as rec_del_channel
        await e.bot.http.delete_role(guild.id, entry.target_id, reason=_r("Role create reverted"))
    except TypeError:
        role = guild.get_role(entry.target_id)
        if role is not None:
            await role.delete(reason=_r("Role create reverted"))


ROLE_MEMBERS: dict[tuple, tuple] = {}     # (guild_id, role_id) -> (monotonic ts, [member ids])


async def _give_back_members(guild, role, member_ids) -> None:
    """Re-assign a restored role to everybody who had it (bounded concurrency, runs in background)."""
    sem = asyncio.Semaphore(10)

    async def one(uid):
        member = guild.get_member(uid)
        if member is None or role in member.roles:
            return
        async with sem:
            try:
                await member.add_roles(role, reason=_r("Role members restored"), atomic=False)
            except Exception:
                pass

    await asyncio.gather(*(one(u) for u in member_ids[:1500]), return_exceptions=True)


async def rec_restore_role(e, guild, entry):
    try:
        old = await e.snapshot("rldl", entry.target_id)
        src = old
    except LookupError:
        old, src = None, entry.before                  # snapshot missed -> audit-log data
    perms = getattr(src, "permissions", None) or discord.Permissions.none()
    colour = getattr(src, "colour", None) or getattr(src, "color", None) or discord.Colour.default()
    new = await guild.create_role(name=getattr(src, "name", None) or "restored-role", permissions=perms,
                                  colour=colour, hoist=bool(getattr(src, "hoist", False)),
                                  mentionable=bool(getattr(src, "mentionable", False)),
                                  reason=_r("Role delete reverted"))
    pos = getattr(old, "position", None) if old is not None else None
    held = ROLE_MEMBERS.pop((guild.id, entry.target_id), None)
    if held and held[1]:                               # members get the role back in parallel with the reorder
        _spawn(_give_back_members(guild, new, held[1]))
    if pos:
        try:
            await new.edit(position=min(pos, guild.me.top_role.position - 1), reason=_r("Role position restored"))
        except Exception:
            pass


async def rec_revert_role(e, guild, entry):
    role = guild.get_role(entry.target_id)
    if role is None:
        return
    # 1) instant path: the audit entry already carries the OLD values of whatever changed
    b = entry.before
    kw = {}
    for attr in ("name", "permissions", "hoist", "mentionable"):
        v = getattr(b, attr, _MISSING)
        if v is not _MISSING and v is not None:
            kw[attr] = v
    col = getattr(b, "colour", getattr(b, "color", _MISSING))
    if col is not _MISSING and col is not None:
        kw["colour"] = col
    if role.is_default():
        kw = {k: v for k, v in kw.items() if k == "permissions"}
    if kw:
        await role.edit(reason=_r("Role update reverted"), **kw)
        return
    # 2) nothing useful in the diff -> fall back to the cached snapshot
    before = await e.snapshot("rlup", entry.target_id)
    if role.is_default():
        await role.edit(permissions=before.permissions, reason=_r("Role update reverted"))
    else:
        await role.edit(name=before.name, permissions=before.permissions, colour=before.colour,
                        hoist=before.hoist, mentionable=before.mentionable,
                        reason=_r("Role update reverted"))


async def rec_revert_member(e, guild, entry):
    roles = _danger_roles(entry)
    if not roles:
        return
    try:                                                # one parallel request per role, no member cache needed
        res = await asyncio.gather(*(e.bot.http.remove_role(guild.id, entry.target_id, r.id,
                                                            reason=_r("Dangerous role removed")) for r in roles),
                                   return_exceptions=True)
        for x in res:
            if isinstance(x, BaseException):
                raise x
    except TypeError:
        member = guild.get_member(entry.target_id)
        if member is not None:
            await member.remove_roles(*roles, reason=_r("Dangerous role removed"), atomic=False)


async def rec_revert_guild(e, guild, entry):
    before = await e.snapshot("serverup", guild.id)
    simple = ("name", "verification_level", "default_notifications", "explicit_content_filter",
              "afk_channel", "afk_timeout", "system_channel")
    kwargs = {a: getattr(before, a) for a in simple if hasattr(before, a)}
    for a in ("icon", "banner", "splash"):
        asset = getattr(before, a, None)
        if asset is not None and asset != getattr(guild, a, None):
            try:
                kwargs[a] = await asset.read()
            except Exception:
                pass
    await guild.edit(reason=_r("Server update reverted"), **kwargs)


async def rec_del_webhook(e, guild, entry):
    await e.bot.http.delete_webhook(entry.target_id, reason=_r("Webhook create reverted"))


async def rec_emoji_create(e, guild, entry):
    if entry.action == AL.sticker_create:
        await e.bot.http.delete_guild_sticker(guild.id, entry.target_id, _r("Sticker create reverted"))
    else:
        await e.bot.http.delete_custom_emoji(guild.id, entry.target_id, reason=_r("Emoji create reverted"))


async def rec_emoji_delete(e, guild, entry):
    old = await e.snapshot("emodl", entry.target_id)
    await guild.create_custom_emoji(name=old.name, image=await old.read(), roles=list(old.roles),
                                    reason=_r("Emoji delete reverted"))


async def rec_emoji_update(e, guild, entry):
    old = await e.snapshot("emoup", entry.target_id)
    emoji = guild.get_emoji(entry.target_id)
    if emoji is not None:
        await emoji.edit(name=old.name, reason=_r("Emoji update reverted"))


async def rec_integration(e, guild, entry):
    for integration in await guild.integrations():
        if integration.id == entry.target_id:
            await integration.delete(reason=_r("Integration reverted"))


async def rec_delete_message(e, guild, message):
    await message.delete()


# audit action -> (module key, recovery job or None)
def _build_actions() -> dict:
    spec = {
        AL.ban: ("ban", rec_unban),
        AL.unban: ("unban", rec_reban),
        AL.kick: ("kick", None),
        AL.member_prune: ("prune", None),
        AL.bot_add: ("botadd", rec_kick_bot),
        AL.channel_create: ("chcr", rec_del_channel),
        AL.channel_delete: ("chdl", rec_restore_channel),
        AL.channel_update: ("chup", rec_revert_channel),
        AL.overwrite_create: ("chup", rec_revert_channel),
        AL.overwrite_update: ("chup", rec_revert_channel),
        AL.overwrite_delete: ("chup", rec_revert_channel),
        AL.role_create: ("rlcr", rec_del_role),
        AL.role_delete: ("rldl", rec_restore_role),
        AL.role_update: ("rlup", rec_revert_role),
        AL.member_role_update: ("memup", rec_revert_member),
        AL.guild_update: ("serverup", rec_revert_guild),
        AL.webhook_create: ("webhook", rec_del_webhook),
        AL.webhook_update: ("webhook", None),
        AL.webhook_delete: ("webhook", None),
        AL.emoji_create: ("emoji", rec_emoji_create),
        AL.emoji_delete: ("emoji", rec_emoji_delete),
        AL.emoji_update: ("emoji", rec_emoji_update),
        AL.sticker_create: ("emoji", rec_emoji_create),
        AL.sticker_update: ("emoji", None),
        AL.sticker_delete: ("emoji", None),
        AL.integration_create: ("integration", rec_integration),
    }
    return spec


ACTIONS = _build_actions()
# recovery jobs that only need the target id: they can start straight from the raw gateway dict
RAW_REC = frozenset({rec_unban, rec_reban, rec_kick_bot, rec_del_channel, rec_del_role, rec_del_webhook})
# raw gateway action_type (int) -> (module key, recovery job): lets the raw hook decide without building objects
RAW = {a.value: v for a, v in ACTIONS.items()}
DISCORD_EPOCH = 1420070400000
BAN_BODY = b'{"delete_message_seconds":0}'


class AntinukeEngine(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.hits: dict[tuple, deque] = {}
        self.flagged: dict[tuple, float] = {}
        self.snap: dict[tuple, tuple] = {}
        self.waiters: dict[tuple, list] = {}        # snapshot key -> futures waiting for it
        self._barrier_tasks: dict[int, asyncio.Task] = {}
        self._barrier_locks: dict[int, asyncio.Lock] = {}
        self._barrier_cool: dict[int, float] = {}
        self._fast: dict[tuple, tuple] = {}         # (guild, user) -> (monotonic ts, running ban task)
        self._raw_orig = None
        self._bg: set = set()
        self._d = None                              # prebuilt direct-ban request parts (None = use bot.http.ban)
        self._hdrs: dict[str, dict] = {}
        self._judged: dict[int, tuple] = {}         # audit entry id -> (ts, verdict) decided by the raw hook
        self._tick = 0.0
        self._lr_seen: set = set()
        self._pres_orig = None
        self._pres_notify = True                    # stream-notify configured? (refreshed every 30s)
        self._vanity = None
        self._raw_rec: dict[int, tuple] = {}         # audit entry id -> (ts, recovery task started by the raw hook)

    async def cog_load(self) -> None:
        await store.load()
        self._hook_roles()
        self.sweep.start()
        self.keepwarm.start()
        self.lagwatch.start()
        self._hook_audit()
        self._hook_presence()
        self.presence_refresh.start()
        self._prep_direct()
        off = [g for g, c in store._cfg.items() if c.enabled and not c.autorec]
        if off:
            log.warning("antinuke: %d protected guild(s) have Auto Recovery OFF (nothing gets reverted there): "
                        "run `antinuke autorecovery enable` in them. e.g. %s", len(off), off[:5])
        self._startup = asyncio.create_task(self._startup_barriers())
        self._gc_task = asyncio.create_task(self._tune_gc())

    async def cog_unload(self) -> None:
        self.sweep.cancel()
        self.keepwarm.cancel()
        self.lagwatch.cancel()
        self.presence_refresh.cancel()
        if self._pres_orig is not None:
            try:
                self.bot._connection.parsers["PRESENCE_UPDATE"] = self._pres_orig
            except Exception:
                pass
            self._pres_orig = None
        if self._raw_orig is not None:
            try:
                self.bot._connection.parsers["GUILD_AUDIT_LOG_ENTRY_CREATE"] = self._raw_orig
            except Exception:
                pass
            self._raw_orig = None
        for t in (*self._barrier_tasks.values(), getattr(self, "_startup", None), getattr(self, "_gc_task", None)):
            if t is not None:
                t.cancel()
        orig = getattr(discord.Guild, "_deathbot_orig_remove_role", None)
        if orig is not None:
            discord.Guild._remove_role = orig
            del discord.Guild._deathbot_orig_remove_role

    @staticmethod
    def _hook_roles() -> None:
        """discord.py strips a deleted role from every member BEFORE any event reaches us, so the
        member list is gone by then.  Remember it right before the removal (antinuke guilds only)."""
        if getattr(discord.Guild, "_deathbot_orig_remove_role", None) is not None:
            return
        orig = discord.Guild._remove_role
        discord.Guild._deathbot_orig_remove_role = orig

        def _remove_role(self, role_id, *a, **k):
            try:
                cfg = store.peek(self.id)
                role = self._roles.get(role_id)
                if cfg is not None and cfg.enabled and role is not None:
                    ROLE_MEMBERS[(self.id, role_id)] = (time.monotonic(), [m.id for m in islice(role.members, 1500)])
            except Exception:
                log.exception("role member snapshot failed")
            return orig(self, role_id, *a, **k)

        discord.Guild._remove_role = _remove_role

    @tasks.loop(seconds=6)
    async def keepwarm(self) -> None:
        """Keep SEVERAL TLS connections to Discord alive. The ban, the recovery job and the DM go out at the
        same time and each needs its own connection; a cold one costs a fresh TLS handshake (50-150 ms)."""
        if not any(c.enabled for c in store._cfg.values()):
            return
        await asyncio.gather(*(self.bot.http.application_info() for _ in range(6)), return_exceptions=True)

    @tasks.loop(seconds=1)
    async def lagwatch(self) -> None:
        """Diagnostic: if the event loop is blocked (heavy cog, sync code) every reaction is late by that much."""
        now = time.monotonic()
        last, self._tick = self._tick, now
        if last and now - last - 1.0 > 0.05:
            log.warning("event loop lag %.0f ms - something is blocking the loop; antinuke reacts that late",
                        (now - last - 1.0) * 1000)

    @lagwatch.before_loop
    async def _lw_wait(self) -> None:
        await self.bot.wait_until_ready()

    # ------------------------------------------------------------ raw fast path
    def _hook_audit(self) -> None:
        """Sit in front of discord.py's GUILD_AUDIT_LOG_ENTRY_CREATE parser.  For the zero-tolerance case
        (executor not whitelisted for that module) the ban is queued straight from the raw gateway dict,
        before AuditLogEntry is built and before any listener / cog is dispatched."""
        try:
            parsers = self.bot._connection.parsers
            orig = parsers["GUILD_AUDIT_LOG_ENTRY_CREATE"]
        except Exception:
            log.warning("raw audit hook unavailable (discord.py internals differ) - using the normal listener")
            return
        if self._raw_orig is not None:
            return
        self._raw_orig = orig
        engine = self

        def parse(data):
            try:
                engine._fast_ban(data)
            except Exception:
                log.exception("raw fast-ban failed")
            return orig(data)

        parsers["GUILD_AUDIT_LOG_ENTRY_CREATE"] = parse

    # ------------------------------------------------------------ presence filter
    def _hook_presence(self) -> None:
        """PRESENCE_UPDATE is the busiest gateway event and is parsed on the same loop that runs antinuke
        (member copy before/after + dispatch to every cog). Drop it for guilds nobody listens to: only vanity-role
        guilds, and every guild while stream-notify is configured, still get presence. PRESENCE_FILTER=0 disables."""
        if os.getenv("PRESENCE_FILTER", "1") == "0" or self._pres_orig is not None:
            return
        try:
            parsers = self.bot._connection.parsers
            orig = parsers["PRESENCE_UPDATE"]
        except Exception:
            return
        self._pres_orig = orig
        engine = self

        def parse(data):
            if not engine._pres_notify:
                gid = data.get("guild_id")
                if gid is not None:
                    van = engine._vanity
                    if van is None:
                        van = engine._vanity = engine.bot.get_cog("VanityRoles")
                    if van is None or int(gid) not in van.cache:
                        return None
            return orig(data)

        parsers["PRESENCE_UPDATE"] = parse

    @tasks.loop(seconds=30)
    async def presence_refresh(self) -> None:
        try:
            async with aiosqlite.connect("db/notify.db") as db:
                async with db.execute("SELECT 1 FROM notifications LIMIT 1") as cur:
                    self._pres_notify = await cur.fetchone() is not None
        except Exception:
            self._pres_notify = True                      # unsure -> keep presence flowing

    def _prep_direct(self) -> None:
        """Everything a ban request needs is built ONCE here.  At ban time we skip discord.py's Route / rate-limit
        bookkeeping / header + JSON building and write the PUT straight onto the warm connection.  Anything
        unexpected (other discord.py internals, proxy, 429, 5xx) silently falls back to bot.http.ban."""
        try:
            http = self.bot.http
            token, ua = getattr(http, "token", None), getattr(http, "user_agent", None)
            base = discord.http.Route.BASE
            if not token or not ua or not base or getattr(http, "proxy", None):
                return
            self._d = {"base": base, "timeout": aiohttp.ClientTimeout(total=5),
                       "hdr": {"Authorization": f"Bot {token}", "User-Agent": ua, "Content-Type": "application/json"}}
        except Exception:
            self._d = None
            log.warning("direct ban unavailable - using bot.http.ban")

    async def _direct_ban(self, gid: int, uid: int, note: str):
        """-> True banned | False definitive refusal (403/404) | None = could not do it, use the normal path."""
        d = self._d
        if d is None:
            return None
        sess = getattr(self.bot.http, "_HTTPClient__session", None)
        if sess is None or sess.closed:
            return None
        hdr = self._hdrs.get(note)
        if hdr is None:
            if len(self._hdrs) > 500:
                self._hdrs.clear()
            hdr = self._hdrs[note] = {**d["hdr"], "X-Audit-Log-Reason": quote(note, safe="/ ")}
        try:
            async with sess.put(f"{d['base']}/guilds/{gid}/bans/{uid}", data=BAN_BODY, headers=hdr,
                                timeout=d["timeout"]) as r:
                st = r.status
        except Exception:
            return None
        if st in (200, 204):
            return True
        if st in (403, 404):
            return False
        return None                                      # 429 / 5xx / anything odd -> bot.http.ban handles it

    def _fast_ban(self, data: dict) -> None:
        """Pure CPU, no awaits.  The FULL verdict (whitelist, main roles, betrayal-guard limits) is decided here
        from the raw gateway dict and handed to the listener, so whitelisted users who exceed their limit are
        punished just as fast and nothing is judged / counted twice."""
        uid = data.get("user_id")
        spec = RAW.get(data.get("action_type"))
        if not uid or spec is None:
            return
        key = spec[0]
        gid, uid = int(data["guild_id"]), int(uid)
        cfg = store.peek(gid)
        if cfg is None or not cfg.enabled:
            return
        if not cfg.mods & BIT[key]:
            return
        guild = self.bot.get_guild(gid)
        if guild is None or uid == self.bot.user.id or uid == guild.owner_id:
            return
        if key == "memup" and not _raw_danger(guild, data):     # only dangerous role GRANTS count
            return
        k = (gid, uid)
        now = time.monotonic()
        if now - self.flagged.get(k, -1e9) < FLAG_TTL:
            self._raw_recover(guild, cfg, data, spec[1], now)   # already punished: recovery only, start it now
            return
        verdict = self._judge(guild, cfg, uid, key)
        try:
            self._judged[int(data["id"])] = (now, verdict)   # listener reuses it (no second judge / hit count)
        except (KeyError, TypeError, ValueError):
            pass
        if verdict is None or verdict[0] == "flagged":
            return
        self.flagged[k] = now                            # claim BEFORE any await
        age = None
        try:
            age = time.time() * 1000 - ((int(data["id"]) >> 22) + DISCORD_EPOCH)
        except Exception:
            pass
        task = _spawn(self._punish(guild, uid, guild.get_member(uid), verdict[1], age))
        self._fast[k] = (now, task)
        self._raw_recover(guild, cfg, data, spec[1], now)      # revert runs next to the ban, not behind the listeners

    def _raw_recover(self, guild, cfg, data: dict, job, now: float) -> None:
        """Start id-only recoveries (delete created channel/role/webhook, undo ban/unban, kick added bot) from the
        raw dict. Under a mass nuke the listener task would otherwise queue behind every other cog's listener.
        The listener finds this task by audit entry id and reuses it, so nothing runs twice."""
        if job not in RAW_REC or not cfg.autorec:
            return
        try:
            eid, tid = int(data["id"]), int(data["target_id"])
        except (KeyError, TypeError, ValueError):
            return
        if eid in self._raw_rec:
            return
        entry = SimpleNamespace(id=eid, target_id=tid, guild=guild)
        self._raw_rec[eid] = (now, _spawn(self._recover(job, guild, entry)))

    @keepwarm.before_loop
    async def _kw_wait(self) -> None:
        await self.bot.wait_until_ready()

    @tasks.loop(seconds=30)
    async def sweep(self) -> None:
        now = time.monotonic()
        for k in [k for k, dq in self.hits.items() if not dq or now - dq[-1] > WINDOW]:
            self.hits.pop(k, None)
        for k in [k for k, t in self.flagged.items() if now - t > FLAG_TTL]:
            self.flagged.pop(k, None)
        for k in [k for k, (t, _) in self.snap.items() if now - t > SNAP_TTL]:
            self.snap.pop(k, None)
        for k in [k for k, (t, _) in self._judged.items() if now - t > 30]:
            self._judged.pop(k, None)
        for k in [k for k, (t, _) in self._fast.items() if now - t > FLAG_TTL]:
            self._fast.pop(k, None)
        for k in [k for k, (t, _) in self._raw_rec.items() if now - t > 30]:
            self._raw_rec.pop(k, None)
        for k in [k for k, v in self.waiters.items() if not v]:
            self.waiters.pop(k, None)
        for k in [k for k, (t, _) in ROLE_MEMBERS.items() if now - t > SNAP_TTL]:
            ROLE_MEMBERS.pop(k, None)


    # ------------------------------------------------------------ barrier role
    @staticmethod
    def _my_other_roles(guild, barrier_id: int) -> list:
        return [r for r in guild.me.roles if r.id != barrier_id and not r.is_default()]

    def _barrier_perms(self, guild, barrier_id: int) -> discord.Permissions:
        """Administrator if the bot has it through any other role, otherwise exactly what the bot has."""
        value = 0
        for r in self._my_other_roles(guild, barrier_id):
            value |= r.permissions.value
        perms = discord.Permissions(value)
        return discord.Permissions(administrator=True) if perms.administrator else perms

    def _barrier_ok(self, guild, barrier) -> bool:
        me = guild.me
        if barrier not in me.roles:
            return False
        if barrier.permissions.value != self._barrier_perms(guild, barrier.id).value:
            return False
        others = self._my_other_roles(guild, barrier.id)
        if not others:
            return True
        top = max(others, key=lambda r: r.position)
        return barrier.position == max(1, top.position - 1)

    async def ensure_barrier(self, guild: discord.Guild):
        """Create / repair the barrier role: Administrator, worn by the bot, directly below the bot's
        highest role.  Returns (role | None, problem text)."""
        cfg = store.get(guild.id)
        lock = self._barrier_locks.setdefault(guild.id, asyncio.Lock())
        async with lock:
            me = guild.me
            barrier = guild.get_role(cfg.barrier) if cfg.barrier else None
            try:
                if barrier is None:
                    barrier = await guild.create_role(
                        name=f"{self.bot.user.name} Barrier", permissions=self._barrier_perms(guild, 0),
                        reason=_r("Barrier role created"))
                    await store.update(guild.id, barrier=barrier.id)
                elif barrier.permissions.value != self._barrier_perms(guild, barrier.id).value:
                    await barrier.edit(permissions=self._barrier_perms(guild, barrier.id),
                                       reason=_r("Barrier permissions fixed"))
                if barrier not in me.roles:
                    await me.add_roles(barrier, reason=_r("Barrier role assigned to the bot"))
                others = self._my_other_roles(guild, barrier.id)
                if others:
                    want = max(1, max(r.position for r in others) - 1)
                    if barrier.position != want:
                        try:
                            await guild.edit_role_positions({barrier: want}, reason=_r("Barrier role reordered"))
                        except (AttributeError, TypeError):
                            await barrier.edit(position=want, reason=_r("Barrier role reordered"))
                return barrier, ""
            except discord.Forbidden:
                return barrier, "Missing Manage Roles / my top role must be above the barrier role"
            except discord.HTTPException as exc:
                return barrier, f"Discord error {exc.status}"

    def _watch_barrier(self, guild: discord.Guild) -> None:
        """Called from role / member events: re-checks the barrier a moment later (debounced)."""
        cfg = store.peek(guild.id)
        if cfg is None or not cfg.enabled or not cfg.barrier:
            return
        t = self._barrier_tasks.get(guild.id)
        if t is not None and not t.done():
            return
        self._barrier_tasks[guild.id] = asyncio.create_task(self._fix_barrier(guild.id))

    async def _fix_barrier(self, gid: int) -> None:
        await asyncio.sleep(1.0)                       # let Discord finish shifting role positions
        guild = self.bot.get_guild(gid)
        cfg = store.peek(gid)
        if guild is None or cfg is None or not cfg.enabled or not cfg.barrier:
            return
        if time.monotonic() < self._barrier_cool.get(gid, 0):
            return
        barrier = guild.get_role(cfg.barrier)
        if barrier is not None and self._barrier_ok(guild, barrier):
            return
        role, problem = await self.ensure_barrier(guild)
        if problem:
            self._barrier_cool[gid] = time.monotonic() + 30      # do not hammer Discord when hierarchy blocks us
            log.warning("barrier fix failed in guild %s: %s", gid, problem)

    async def _tune_gc(self) -> None:
        """A full garbage collection over a big member/message cache can freeze the loop for tens of ms -
        exactly when a nuke hits.  Once the caches are warm: move everything alive into the permanent
        generation (never scanned again) and make full collections rarer."""
        await self.bot.wait_until_ready()
        await asyncio.sleep(45)
        gc.collect()
        gc.freeze()
        gc.set_threshold(20000, 20, 100)
        log.info("antinuke: gc tuned (frozen %d objects)", gc.get_freeze_count())

    async def _startup_barriers(self) -> None:
        await self.bot.wait_until_ready()
        for guild in list(self.bot.guilds):
            self._watch_barrier(guild)
            await asyncio.sleep(0.5)

    @commands.Cog.listener()
    async def on_guild_role_create(self, role):
        self._watch_barrier(role.guild)
        if _is_linked(role):
            li = self.bot.get_cog("LinkInvite")         # V44: strip dangerous perms + record candidate X (first, sync)
            if li is not None:
                li.linked_role_created(role)
            _spawn(self._linked_role(role))

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if before.roles != after.roles:
            li = self.bot.get_cog("LinkInvite")         # V44: monitored linked-role receipt check
            if li is not None:
                li.member_roles_changed(before, after)
        if after.id == self.bot.user.id and before.roles != after.roles:
            self._watch_barrier(after.guild)

    # ------------------------------------------------------------ linked roles
    async def _linked_role(self, role) -> None:
        """A role became a Linked Role (connection / app requirements): delete it at once, then find and
        punish whoever did it.  The delete does not wait for the audit-log lookup."""
        guild = role.guild
        cfg = store.peek(guild.id)
        if cfg is None or not cfg.enabled or not cfg.mods & BIT["linkrole"]:
            return
        if role.id in self._lr_seen:
            return
        self._lr_seen.add(role.id)
        if len(self._lr_seen) > 500:
            self._lr_seen.clear()
        delete = _spawn(self._lr_delete(guild, role))
        uid = await self._lr_executor(guild, role.id)
        ok = await delete
        if not uid or uid == self.bot.user.id or uid == guild.owner_id:
            return
        verdict = self._judge(guild, cfg, uid, "linkrole")
        if verdict is not None:
            await self._act(guild, cfg, None, uid, "linkrole", None, verdict)
        if not ok:
            log.warning("antinuke: could not delete linked role %s in guild %s", role.id, guild.id)

    async def _lr_delete(self, guild, role) -> bool:
        for attempt in range(2):
            try:
                await role.delete(reason=_r("Linked role removed"))
                return True
            except discord.NotFound:
                return True
            except discord.Forbidden:
                return False
            except discord.HTTPException:
                await asyncio.sleep(0.3)
        return False

    async def _lr_executor(self, guild, role_id: int):
        """Who created / changed this role?  The audit entry can lag a moment behind the gateway event."""
        for attempt in range(4):
            for action in (AL.role_update, AL.role_create):
                try:
                    async for entry in guild.audit_logs(limit=6, action=action):
                        if entry.target is not None and entry.target.id == role_id:
                            return entry.user_id
                except (discord.Forbidden, discord.HTTPException):
                    return None
            await asyncio.sleep(0.4)
        return None

    # ------------------------------------------------------------ snapshots
    def _keep(self, guild_id: int, kind: str, id_: int, obj, oldest: bool = False) -> None:
        cfg = store.peek(guild_id)
        if cfg is None or not cfg.enabled:      # cheap RAM copy; works even if autorecovery is switched on later
            return
        key, now = (kind, id_), time.monotonic()
        cur = self.snap.get(key)
        if oldest and cur and now - cur[0] < 10:
            return
        self.snap[key] = (now, obj)
        for fut in self.waiters.pop(key, ()):       # wake a recovery job that arrived before the event
            if not fut.done():
                fut.set_result(obj)

    async def snapshot(self, kind: str, id_: int, wait: float = 2.0):
        """Cached object, or wait (event-driven, zero polling delay) until the gateway event delivers it."""
        key = (kind, id_)
        hit = self.snap.get(key)
        if hit:
            return hit[1]
        fut = asyncio.get_running_loop().create_future()
        self.waiters.setdefault(key, []).append(fut)
        try:
            return await asyncio.wait_for(fut, wait)
        except asyncio.TimeoutError:
            raise LookupError(key) from None
        finally:
            lst = self.waiters.get(key)
            if lst is not None:
                if fut in lst:
                    lst.remove(fut)
                if not lst:
                    self.waiters.pop(key, None)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        self._keep(channel.guild.id, "chdl", channel.id, channel)

    @commands.Cog.listener()
    async def on_guild_channel_update(self, before, after):
        self._keep(after.guild.id, "chup", after.id, before, oldest=True)

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        self._keep(role.guild.id, "rldl", role.id, role)
        self._watch_barrier(role.guild)

    @commands.Cog.listener()
    async def on_guild_role_update(self, before, after):
        self._keep(after.guild.id, "rlup", after.id, before, oldest=True)
        if _is_linked(after) and not _is_linked(before):
            li = self.bot.get_cog("LinkInvite")         # V45: role turned into a Linked Role AFTER creation -> strip first too
            if li is not None:
                li.linked_role_created(after)
            _spawn(self._linked_role(after))
        if before.position != after.position or before.permissions != after.permissions:
            self._watch_barrier(after.guild)

    @commands.Cog.listener()
    async def on_guild_update(self, before, after):
        self._keep(after.id, "serverup", after.id, before, oldest=True)

    @commands.Cog.listener()
    async def on_guild_emojis_update(self, guild, before, after):
        new = {e.id: e for e in after}
        for emoji in before:
            cur = new.get(emoji.id)
            if cur is None:
                self._keep(guild.id, "emodl", emoji.id, emoji)
            elif cur.name != emoji.name:
                self._keep(guild.id, "emoup", emoji.id, emoji, oldest=True)

    # ------------------------------------------------------------ the hot path
    @commands.Cog.listener()
    async def on_audit_log_entry_create(self, entry: discord.AuditLogEntry):
        if entry.action in (AL.role_create, AL.role_update):
            li = self.bot.get_cog("LinkInvite")         # V44: free role-creator id for X (no REST call)
            if li is not None:
                li.note_role_audit(entry)
        spec = ACTIONS.get(entry.action)
        if spec is None:
            return
        guild = entry.guild
        cfg = store.peek(guild.id)
        if cfg is None or not cfg.enabled:
            return
        key, recover = spec
        if not cfg.mods & BIT[key]:
            return
        uid = entry.user_id
        if not uid or uid == self.bot.user.id or uid == guild.owner_id:
            return
        if key == "memup" and not _danger_roles(entry):
            return
        pre = self._judged.pop(entry.id, None)           # verdict already decided by the raw hook?
        verdict = pre[1] if pre is not None else self._judge(guild, cfg, uid, key)
        if verdict is not None:
            await self._act(guild, cfg, entry, uid, key, recover, verdict)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not message.mention_everyone:          # one attribute read for ~every message
            return
        guild = message.guild
        if guild is None or message.webhook_id:
            return
        cfg = store.peek(guild.id)
        if cfg is None or not cfg.enabled or not cfg.mods & BIT["everyone"]:
            return
        uid = message.author.id
        if uid == self.bot.user.id or uid == guild.owner_id:
            return
        verdict = self._judge(guild, cfg, uid, "everyone")
        if verdict is not None:
            await self._act(guild, cfg, message, uid, "everyone", rec_delete_message, verdict)

    def _judge(self, guild, cfg, uid: int, key: str):
        """-> None (allowed) | (kind, reason). Pure CPU, no awaits."""
        now = time.monotonic()
        if now - self.flagged.get((guild.id, uid), -1e9) < FLAG_TTL:
            return "flagged", None
        mask = cfg.wl.get(uid, 0)
        if cfg.mainroles:
            member = guild.get_member(uid)
            if member is not None and any(r.id in cfg.mainroles for r in member.roles):
                mask = store.ALL_MASK
        if mask & BIT[key]:
            if not cfg.betrayal:
                return None
            dq = self.hits.setdefault((guild.id, uid, key), deque())
            dq.append(now)
            while dq and now - dq[0] > WINDOW:
                dq.popleft()
            if len(dq) <= cfg.limit(key):
                return None
            return "betrayal", f"Betrayal guard: {store.LABELS[key]} limit exceeded."
        return "unauthorized", REASONS[key]

    # ------------------------------------------------------------ reaction
    async def _act(self, guild, cfg, entry, uid, key, recover, verdict) -> None:
        kind, reason = verdict
        first = kind != "flagged"
        jobs = []
        if first:
            self.flagged[(guild.id, uid)] = time.monotonic()      # claim BEFORE any await
            member = guild.get_member(uid)
            fast = self._fast.pop((guild.id, uid), None)          # raw hook already started the ban
            jobs.append(fast[1] if fast is not None else _spawn(self._punish(guild, uid, member, reason)))
        recovering = cfg.autorec and recover is not None
        if recovering:
            raw = self._raw_rec.pop(getattr(entry, "id", None), None)   # already started by the raw hook?
            jobs.append(raw[1] if raw is not None else _spawn(self._recover(recover, guild, entry)))
        if not jobs:
            return
        results = await asyncio.gather(*jobs, return_exceptions=True)
        if not first:
            return
        punished = results[0] if not isinstance(results[0], BaseException) else (None, False)
        emg = self.bot.get_cog("Emergency")              # optional: `emergency auto enable` -> lock the server down
        if emg is not None and getattr(emg, "auto_guilds", None) and guild.id in emg.auto_guilds:
            _spawn(emg.auto_trigger(guild, reason))
        rec = results[-1] if recovering and not isinstance(results[-1], BaseException) else (False, "")
        recovered = bool(recovering and rec[0])
        t = asyncio.get_running_loop().create_task(      # log card is low priority: ban + recovery go first
            self._log_later(guild, cfg, uid, member, reason, punished, recovered, rec[1] if recovering else ""))
        self._bg.add(t)
        t.add_done_callback(self._bg.discard)

    async def _recover(self, job, guild, entry):
        """-> (ok, error_text).  Retries only transient Discord errors; every result is logged with its timing."""
        last, t = "", time.perf_counter()
        name = getattr(job, "__name__", str(job))
        for attempt in range(3):
            try:
                await job(self, guild, entry)
                log.info("antinuke recovery %s ok guild=%s in %.0fms", name, guild.id, (time.perf_counter() - t) * 1000)
                return True, ""
            except discord.Forbidden:
                last = "Missing permissions / role hierarchy"
                break                                              # retrying will not help
            except discord.NotFound:
                last = "Target no longer exists"
                break
            except LookupError:
                last = "No snapshot available"
                break
            except discord.HTTPException as exc:
                last = f"Discord error {exc.status}/{exc.code}"
                if exc.status < 500 and exc.status != 429:         # 4xx = our request is wrong, retry is useless
                    break
                await asyncio.sleep(0.15 * (attempt + 1))
            except Exception as exc:                               # noqa: BLE001
                last = type(exc).__name__
                log.exception("antinuke recovery %s failed", name)
                break
        log.warning("antinuke recovery %s FAILED guild=%s: %s", name, guild.id, last)
        return False, last

    async def _soft_punish(self, guild, uid: int, member, mode: str, note: str):
        """kick | timeout (28 days) | strip (remove every role the bot can) -> label or None.
        If the chosen action is refused (hierarchy / admin) it falls back to stripping dangerous roles."""
        http = self.bot.http
        try:
            if mode == "kick":
                await http.kick(uid, guild.id, reason=note)
                return "kicked"
            if mode == "timeout":
                until = (discord.utils.utcnow() + timedelta(days=28)).isoformat()
                await http.edit_member(guild.id, uid, reason=note, communication_disabled_until=until)
                return "timed out"
            if mode == "strip" and member is not None:
                top = guild.me.top_role
                keep = [r.id for r in member.roles if not r.is_default() and (r.managed or r >= top)]
                await http.edit_member(guild.id, uid, reason=note, roles=keep)
                return "stripped"
        except (discord.Forbidden, discord.HTTPException, TypeError):
            pass
        if member is not None:
            try:
                top = guild.me.top_role
                roles = [r for r in member.roles if not r.is_default() and not r.managed and r < top and _dangerous(r)]
                if roles:
                    await member.remove_roles(*roles, reason=note, atomic=False)
                    return "stripped"
            except (discord.Forbidden, discord.HTTPException):
                pass
        return None

    async def _punish(self, guild: discord.Guild, uid: int, member, reason: str, age=None):
        """-> (label | None, False).  Ban ONLY: no DM, no extra request, nothing that can slow the ban down."""
        note = REASON.format(reason.rstrip("."))
        cfg = store.peek(guild.id)
        if cfg is not None and cfg.punish != "ban":
            label = await self._soft_punish(guild, uid, member, cfg.punish, note)
            return label, False
        t = time.perf_counter()
        ok = False
        res = await self._direct_ban(guild.id, uid, note)                   # prebuilt PUT, no discord.py overhead
        if res is not None:
            ok = res
        else:
            try:
                await self.bot.http.ban(uid, guild.id, 0, reason=note)      # discord.py path (rate limits, retries)
                ok = True
            except TypeError:                                               # discord.py signature differs
                try:
                    await guild.ban(discord.Object(id=uid), reason=note, delete_message_seconds=0)
                    ok = True
                except (discord.Forbidden, discord.HTTPException):
                    pass
            except (discord.Forbidden, discord.HTTPException):
                pass
        log.info("antinuke ban %s%s guild=%s user=%s rtt=%.0fms%s", "ok" if ok else "FAILED",
                 " (direct)" if res is not None else "", guild.id, uid,
                 (time.perf_counter() - t) * 1000, f" event_age={age:.0f}ms" if age is not None else "")
        if ok:
            return "banned", False
        if member is not None:                      # ban impossible (hierarchy) -> strip power instead
            try:
                top = guild.me.top_role
                roles = [r for r in member.roles
                         if not r.is_default() and not r.managed and r < top and _dangerous(r)]
                if roles:
                    await member.remove_roles(*roles, reason=note, atomic=False)
                    return "stripped", False
            except (discord.Forbidden, discord.HTTPException):
                pass
        return None, False

    async def _log_later(self, *args) -> None:
        await asyncio.sleep(1.0)
        await self._log(*args)

    async def _log(self, guild, cfg, uid, member, reason, punished, recovered, rec_err: str = "") -> None:
        channel = guild.get_channel(cfg.log) if cfg.log else None
        if channel is None:
            return
        label, dm_ok = punished
        user = member or self.bot.get_user(uid)
        name = getattr(user, "name", None) or str(uid)
        verb = {"banned": "banned", "kicked": "kicked", "timed out": "timed out",
                "stripped": "stripped of roles"}.get(label, "flagged")
        yes, no = ui.OK, ui.NO
        body = (f"### *{name} has been {verb} !*\n"
                f"{ui.TICK} **Reason :** *{reason}*\n"
                f"{ui.TICK} **Member :** <@{uid}>[{name}]\n\n"
                f"**More Details :**\n"
                f"{ui.TICK} **Action Applied :** {yes if label else no}\n"
                f"{ui.TICK} **Recovery :** {yes if recovered else no}{f' ({rec_err})' if rec_err and not recovered else ''}\n"
                f"-# <t:{int(time.time())}:T>")
        avatar = user.display_avatar.url if user is not None else None
        try:
            await channel.send(view=ui.view_of(ui.with_thumb(body, avatar)), allowed_mentions=ui.NO_PING)
        except (discord.Forbidden, discord.HTTPException):
            pass
