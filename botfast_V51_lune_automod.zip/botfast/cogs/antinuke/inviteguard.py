"""Anti Invite Role: stops unauthorized users from creating Discord invites that hand out roles.

Part of the AntiNuke package (see CHANGES_V48_INVITEROLE.md).  Additive: the engine, linkinvite, botguard and onboardguard are
untouched; the help page lives in the existing `antinuke` help menu and the commands under `antinuke inviterole`.

What Discord gives us (documented; nothing is assumed beyond this):
  * "Community invites": POST /channels/{id}/invites accepts `role_ids` (needs Manage Roles).  The INVITE_CREATE gateway event
    carries `code`, `channel_id`, `inviter` and `role_ids` in ONE payload, so detection needs no REST call.
  * Audit log action 40 (INVITE_CREATE) names the user who created it; used here to CONFIRM the creator before anyone is banned.
  * DELETE /invites/{code} needs Manage Channels on the channel or Manage Guild.
  * Roles already handed out stay with the members after the invite is deleted (so the role itself must be defanged).

Policy (Server Owner, Extra Owners and the antinuke whitelist are exempt):
  unauthorized creator, role-attached invite :
      1. verify (RAM): invite code well-formed, creator id valid, linked role ids exist in this server
      2. IN PARALLEL: delete the invite | strip privileged permissions from every linked role (role is KEPT, never deleted)
         | wait for the INVITE_CREATE audit entry
      3. ban the creator ONLY if the audit log confirms the same user and the same code (mismatch / no entry = nobody is banned)
      4. re-read everything (invite 404, roles, ban) before any step is called ok; failed steps are retried; if the invite could
         not be removed and a role is still privileged, the emergency lockdown starts.
  creator missing from the payload: identified through the audit log; if that fails the invite is still removed and privileged
      roles are stripped, but nobody is banned.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from typing import Callable, Optional

import discord
from discord.ext import commands

from utils import antinuke_store as store

try:                                                     # normal import inside the bot
    from .botguard import (Incident, Ledger, Step, _spawn_eager, global_extra_owner_ids, valid_id)  # noqa: F401
except ImportError:                                      # loaded by file path (unit tests)
    import importlib.util as _ilu
    import sys as _sys
    _p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "botguard.py")
    _spec = _ilu.spec_from_file_location("inviteguard_botguard_fallback", _p)
    _m = _ilu.module_from_spec(_spec)
    _sys.modules[_spec.name] = _m
    _spec.loader.exec_module(_m)
    Incident, Ledger, Step = _m.Incident, _m.Ledger, _m.Step
    _spawn_eager, global_extra_owner_ids, valid_id = _m._spawn_eager, _m.global_extra_owner_ids, _m.valid_id

log = logging.getLogger("deathbot.inviteguard")

DB_PATH = os.getenv("IG_DB_PATH", "db/inviteguard.db")
INVITE_CREATE_ACTION = 40          # audit log: INVITE_CREATE
AUDIT_WINDOW = 20.0                # an audit entry older than this cannot be the creation we just saw
CLOCK_SKEW = 10.0                  # tolerated difference between our clock and a snowflake timestamp
HINT_WAIT = 0.6                    # wait (event driven, RAM only) for the gateway audit entry before falling back to REST
CLAIM_TTL = 120.0
RETRY_DELAYS = (1.5, 4.0)          # bounded retries of failed steps (hierarchy-blocked steps are never retried)
LOCKDOWN_COOLDOWN = 120.0
MAX_ROLES = 15                     # linked roles processed per invite (Discord allows far fewer in practice)
BAN_NEEDS_AUDIT = False            # False: the creator named by Discord's own INVITE_CREATE event is banned in parallel with the
                                   # invite delete + role strip (fastest); the audit entry is still read and shown in the card.
                                   # True: the ban waits for the audit log to confirm the same user and invite code (V48 behaviour)
HOT_TTL = 900.0                    # roles of a neutralised invite are watched this long: whoever joins and receives them loses them again
MAX_CLEAN = 100                    # members cleaned per incident sweep
DM_COOLDOWN = 60.0                 # one owner DM per creator per minute (a burst of invites must not spam the owner)

PRIV_BITS = {
    "Administrator": 1 << 3, "Manage Guild": 1 << 5, "Manage Roles": 1 << 28, "Manage Channels": 1 << 4,
    "Ban Members": 1 << 2, "Kick Members": 1 << 1, "Manage Webhooks": 1 << 29, "Moderate Members": 1 << 40,
    "Manage Expressions": 1 << 30, "Manage Nicknames": 1 << 27, "View Audit Log": 1 << 7, "Manage Messages": 1 << 13,
    "Manage Threads": 1 << 34, "Manage Events": 1 << 33, "Mention Everyone": 1 << 17,
}
PRIV_MASK = 0
for _b in PRIV_BITS.values():
    PRIV_MASK |= _b
CODE_RE = re.compile(r"^[A-Za-z0-9-]{2,64}$")


# --------------------------------------------------------------------------- pure helpers (unit-tested)
def _to_int(v) -> Optional[int]:
    try:
        if isinstance(v, bool):
            return None
        i = int(v)
        return i if valid_id(i) else None
    except (TypeError, ValueError):
        return None


def valid_invite_code(code) -> bool:
    return isinstance(code, str) and bool(CODE_RE.match(code))


def priv_names(bits: int) -> list:
    return [n for n, b in PRIV_BITS.items() if bits & b]


def snowflake_ts(sf: int) -> float:
    return ((int(sf) >> 22) + 1420070400000) / 1000.0


@dataclass(frozen=True)
class InvitePayload:
    guild_id: int
    code: str
    channel_id: Optional[int]
    inviter_id: Optional[int]
    role_ids: tuple


def parse_invite_create(data) -> Optional[InvitePayload]:
    """INVITE_CREATE payload -> InvitePayload.  None when the payload is garbage (never raises).  `role_ids` entries that are
    not valid snowflakes are dropped, duplicates removed, and the list is capped."""
    if not isinstance(data, dict):
        return None
    gid, code = _to_int(data.get("guild_id")), data.get("code")
    if gid is None or not valid_invite_code(code):
        return None
    rids: list = []
    raw = data.get("role_ids")
    if isinstance(raw, (list, tuple)):
        for r in raw[:MAX_ROLES * 4]:
            i = _to_int(r)
            if i is not None and i not in rids:
                rids.append(i)
    inviter = data.get("inviter")
    iid = _to_int(inviter.get("id")) if isinstance(inviter, dict) else None
    return InvitePayload(gid, code, _to_int(data.get("channel_id")), iid, tuple(rids[:MAX_ROLES]))


def roles_from_invite_obj(obj) -> tuple:
    """REST invite object (`roles`: partial role objects) -> tuple of role ids.  Tolerates garbage."""
    out: list = []
    if isinstance(obj, dict):
        for r in obj.get("roles") or ():
            i = _to_int(r.get("id")) if isinstance(r, dict) else _to_int(r)
            if i is not None and i not in out:
                out.append(i)
    return tuple(out[:MAX_ROLES])


def audit_fields(entry: dict) -> tuple:
    """Raw audit entry -> (entry id, user id, code | None, inviter_id | None)."""
    code = inviter = None
    for ch in entry.get("changes") or ():
        if isinstance(ch, dict):
            if ch.get("key") == "code":
                code = ch.get("new_value")
            elif ch.get("key") == "inviter_id":
                inviter = _to_int(ch.get("new_value"))
    return _to_int(entry.get("id")), _to_int(entry.get("user_id")), (code if isinstance(code, str) else None), inviter


def pick_audit(cands, code: str, creator_id: Optional[int], now: float, window: float = AUDIT_WINDOW) -> tuple:
    """cands: [(entry id, user id, ts, code | None, inviter_id | None)] -> (state, entry | None, why).
    state: verified | mismatch | ambiguous | none.  The creator is only ever confirmed by an entry that carries THIS invite
    code (an entry without a code is accepted only when the payload already named the creator and the entry agrees)."""
    live = [c for c in cands if c[1] is not None and -CLOCK_SKEW <= now - c[2] <= window]
    exact = [c for c in live if c[3] == code]
    if exact:
        pool, how = exact, "audit entry carries this invite code"
    elif creator_id is not None:
        pool, how = [c for c in live if c[3] is None], "audit entry has no code; matched by creator and time"
    else:
        pool, how = [], ""
    uids = sorted({c[1] for c in pool})
    if not uids:
        return "none", None, "no INVITE_CREATE audit entry for this code"
    if len(uids) > 1:
        return "ambiguous", None, f"{len(uids)} different users have a matching audit entry"
    entry = max((c for c in pool if c[1] == uids[0]), key=lambda c: c[2])
    if entry[4] is not None and entry[4] != entry[1]:
        return "mismatch", entry, "audit entry is inconsistent (inviter_id differs from user_id)"
    if creator_id is not None and entry[1] != creator_id:
        return "mismatch", entry, f"event says <@{creator_id}> created it, audit log says <@{entry[1]}>"
    return "verified", entry, how


@dataclass
class AuditRes:
    state: str                    # verified | mismatch | ambiguous | none | unavailable
    uid: Optional[int] = None
    via: str = ""
    why: str = ""
    eid: Optional[int] = None


@dataclass
class IgIncident(Incident):
    code: str = ""
    channel_id: Optional[int] = None
    role_ids: list = field(default_factory=list)
    trigger: str = ""
    exec_via: str = ""


def render_ig(inc: IgIncident, header: str, ok="[OK]", no="[X]", warn="[!]", now: Optional[float] = None) -> str:
    icon = lambda st: ok if st == "ok" else no if st in ("failed", "blocked", "impossible") else warn  # noqa: E731
    who = "unidentified" if inc.executor_id is None else f"<@{inc.executor_id}> (`{inc.executor_id}`)"
    if inc.executor_class:
        who += f" - {inc.executor_class.replace('_', ' ')}"
    if inc.exec_via:
        who += f" [{inc.exec_via}]"
    lines = [f"## {header}", f"> **Incident :** {inc.title}"]
    if inc.trigger:
        lines.append(f"> **Trigger :** {inc.trigger}")
    lines.append(f"> **Creator :** {who}")
    if inc.code:
        lines.append(f"> **Invite :** `{inc.code}`" + (f" in <#{inc.channel_id}>" if inc.channel_id else ""))
    if inc.role_ids:
        lines.append("> **Linked roles :** " + ", ".join(f"<@&{r}> (`{r}`)" for r in inc.role_ids))
    lines.append("")
    for i, s in enumerate(inc.steps, 1):
        lines.append(f"{icon(s.status)} **{i}. {s.name}** - `{s.status}`" + ("\n " + s.detail if s.detail else ""))
    speed = ((f" | invite removal sent in {inc.ms_action:.0f} ms" if inc.ms_action is not None else "")
             + f" | handled in {inc.ms:.0f} ms" + (f" ({inc.via})" if inc.via else "")) if inc.ms is not None else ""
    lines.append(f"-# <t:{int(now if now is not None else time.time())}:T>{speed} | confirmed = Discord accepted it and the state was re-read")
    return "\n".join(lines)


def help_text(prefix: str, st: dict, ok="ON", no="OFF") -> list:
    """Page for the existing Antinuke help menu (pure text; the command cog wraps it in the Components V2 view).
    st: {inviterole}"""
    sw = lambda b: ok if b else no  # noqa: E731
    on = bool(st.get("inviterole"))
    return [(
        f"### ANTI INVITE ROLE {sw(on)}\n"
        f"**Role-Attached Invite Detection** {sw(on)}\n"
        f"**Instant Invite Revocation** {sw(on)}\n"
        f"**Audit-Verified Creator Ban** {sw(on)}\n"
        f"**Dangerous Permission Strip (role kept)** {sw(on)}\n"
        f"**Joiner Role Removal + Startup Sweep** {sw(on)}\n"
        f"**Owner / Extra Owner / Whitelist Protection** {sw(True)}\n\n"
        f"> `{prefix}antinuke inviterole on`\n> `{prefix}antinuke inviterole off`\n> `{prefix}antinuke inviterole status`\n"
        f"> `{prefix}antinuke inviterole scan`\n> `{prefix}antinuke inviterole sweep`\n> `{prefix}antinuke inviterole restore <role_id>`\n"
        "\u276f When someone who is not the Server Owner, an Extra Owner or whitelisted creates an invite that gives a role, "
        "the invite is deleted at once and every Administrator / Manage Server / Manage Roles / Manage Channels / Ban / Kick / "
        "Manage Webhooks (and other privileged) permission is removed from the linked role. The role itself is **kept**. "
        "The creator is banned at once (Discord's own invite event names them) and members who joined with the role lose it again."
    )]


# --------------------------------------------------------------------------- persistence
class IgLedger(Ledger):
    async def open(self) -> None:
        import sqlite3

        def _open():
            d = os.path.dirname(self.path)
            if d:
                os.makedirs(d, exist_ok=True)
            c = sqlite3.connect(self.path, check_same_thread=False)
            c.execute("PRAGMA journal_mode=WAL")
            c.executescript("""
                CREATE TABLE IF NOT EXISTS ig_config (guild_id INTEGER PRIMARY KEY, enabled INTEGER DEFAULT 0);
                CREATE TABLE IF NOT EXISTS ig_snapshots (guild_id INTEGER, role_id INTEGER, perms INTEGER, invite_code TEXT,
                                                         creator_id INTEGER, taken_at REAL, PRIMARY KEY (guild_id, role_id));
                CREATE TABLE IF NOT EXISTS ig_events (id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, guild_id INTEGER,
                                                      kind TEXT, executor_id INTEGER, target_id INTEGER, details TEXT);
                CREATE INDEX IF NOT EXISTS ig_events_g ON ig_events (guild_id, ts);
            """)
            c.commit()
            self._conn = c
        await self._run(_open)

    async def wipe_guild(self, gid: int) -> None:
        def _w():
            for t in ("ig_config", "ig_snapshots"):
                self._conn.execute(f"DELETE FROM {t} WHERE guild_id = ?", (gid,))
            self._conn.commit()
        await self._run(_w)


# --------------------------------------------------------------------------- the cog
class InviteGuard(commands.Cog):
    def __init__(self, bot, db_path: str = DB_PATH, clock: Callable = time.time, sleep=None, global_extra=None,
                 retry_delays=RETRY_DELAYS):
        self.bot = bot
        self._now = clock
        self._sleep = sleep or asyncio.sleep
        self.retry_delays = tuple(retry_delays)
        self.ledger = IgLedger(db_path)
        self.flags: dict = {}              # gid -> bool
        self.snaps: dict = {}              # (gid, role id) -> permission bits BEFORE the first strip (first original is never overwritten)
        self._global_extra = frozenset(global_extra) if global_extra is not None else None
        self.hint_wait = HINT_WAIT
        self._hints: dict = {}             # gid -> [(entry id, user id, ts, code | None, inviter_id | None)]  gateway INVITE_CREATE audit entries
        self._waiters: dict = {}           # gid -> [futures] woken the moment a gateway audit entry arrives (no polling)
        self._used: dict = {}              # audit entry ids already consumed
        self._claims: dict = {}            # dedupe keys -> ts
        self._role_locks: dict = {}        # (gid, role id) -> Lock: two incidents never edit the same role at the same time
        self._lockdown_at: dict = {}
        self._hot: dict = {}               # gid -> {role id: (expires, code)}  roles of neutralised invites (RAM)
        self._raw: dict = {}               # parser name -> (orig, wrapper)
        self._bg: set = set()
        self.stats = {"invites_seen": 0, "role_invites": 0, "incidents": 0, "invites_deleted": 0, "roles_stripped": 0,
                      "bans": 0, "lockdowns": 0}

    # ------------------------------------------------------------------ lifecycle
    async def cog_load(self) -> None:
        await store.load()
        await self.ledger.open()
        for gid, en in await self.ledger.query("SELECT guild_id, enabled FROM ig_config"):
            self.flags[gid] = bool(en)
        for gid, rid, perms in await self.ledger.query("SELECT guild_id, role_id, perms FROM ig_snapshots"):
            self.snaps[(gid, rid)] = perms
        if self._global_extra is None:
            self._global_extra = global_extra_owner_ids()
        self._hook_raw()
        try:
            if self.bot.is_ready():
                self._spawn(self._sweep_all())
        except Exception:
            pass

    async def cog_unload(self) -> None:
        self._unhook_raw()
        for t in list(self._bg):
            t.cancel()
        await self.ledger.close()

    def _spawn(self, coro) -> asyncio.Task:
        t = asyncio.get_running_loop().create_task(coro)
        self._bg.add(t)
        t.add_done_callback(self._bg.discard)
        return t

    def _spawn_now(self, coro) -> asyncio.Task:
        t = _spawn_eager(coro)
        self._bg.add(t)
        t.add_done_callback(self._bg.discard)
        return t

    def _claim(self, key, ttl: float = 10.0) -> bool:
        """Synchronous claim (before any await): True for the first caller within ttl.  Duplicate gateway events lose."""
        now = self._now()
        if len(self._claims) > 2000:
            for k in [k for k, t in self._claims.items() if now - t > CLAIM_TTL]:
                self._claims.pop(k, None)
        if now - self._claims.get(key, -1e9) < ttl:
            return False
        self._claims[key] = now
        return True

    def _role_lock(self, gid: int, rid: int) -> asyncio.Lock:
        lk = self._role_locks.get((gid, rid))
        if lk is None:
            if len(self._role_locks) > 500:
                self._role_locks.pop(next(iter(self._role_locks)))
            lk = self._role_locks[(gid, rid)] = asyncio.Lock()
        return lk

    def _mark_used(self, eid) -> None:
        self._used[eid] = True
        while len(self._used) > 1000:
            self._used.pop(next(iter(self._used)))

    # ------------------------------------------------------------------ config / authorization (sync, RAM)
    def flag(self, gid: int) -> bool:
        return bool(self.flags.get(gid))

    def _enabled(self, gid: int) -> bool:
        cfg = store.peek(gid)
        return bool(cfg is not None and cfg.enabled and self.flags.get(gid))

    def extra_ids(self, gid: int) -> frozenset:
        bgc = self.bot.get_cog("BotGuard")
        base = bgc.extra_ids(gid) if bgc is not None else (self._global_extra or frozenset())
        return frozenset(base)

    def classify(self, guild, uid: Optional[int]) -> str:
        """self | owner | extra_owner | whitelisted | untrusted | unknown.  The first four are exempt."""
        if uid is None:
            return "unknown"
        if uid == self.bot.user.id:
            return "self"
        if uid == guild.owner_id:
            return "owner"
        if uid in self.extra_ids(guild.id):
            return "extra_owner"
        cfg = store.peek(guild.id)
        if cfg is not None and uid in cfg.wl:
            return "whitelisted"
        return "untrusted"

    @staticmethod
    def exempt(cls: str) -> bool:
        return cls in ("self", "owner", "extra_owner", "whitelisted")

    async def set_flag(self, gid: int, value: bool) -> None:
        self.flags[gid] = bool(value)
        await self.ledger.exec("INSERT INTO ig_config (guild_id, enabled) VALUES (?, ?) "
                               "ON CONFLICT(guild_id) DO UPDATE SET enabled=excluded.enabled", (gid, int(bool(value))))

    async def enable_defaults(self, gid: int) -> None:
        if gid not in self.flags:                            # `antinuke enable` / wizard: new setups only
            await self.set_flag(gid, True)

    async def wipe(self, gid: int) -> None:
        self.flags.pop(gid, None)
        self._hot.pop(gid, None)
        for k in [k for k in self.snaps if k[0] == gid]:
            self.snaps.pop(k, None)
        await self.ledger.wipe_guild(gid)

    async def _event(self, gid, kind, executor, target, details: dict) -> None:
        try:
            await self.ledger.exec(
                "INSERT INTO ig_events (ts, guild_id, kind, executor_id, target_id, details) VALUES (?, ?, ?, ?, ?, ?)",
                (self._now(), gid, kind, executor, target, json.dumps(details, default=str)[:8000]))
        except Exception:
            log.exception("inviteguard: could not write audit event")

    async def recent_events(self, gid: int, n: int = 5) -> list:
        return await self.ledger.query(
            "SELECT ts, kind, executor_id, target_id FROM ig_events WHERE guild_id = ? ORDER BY id DESC LIMIT ?", (gid, n))

    async def _save_snap(self, gid: int, rid: int, perms: int, code: str, creator) -> None:
        try:
            await self.ledger.exec("INSERT OR IGNORE INTO ig_snapshots (guild_id, role_id, perms, invite_code, creator_id, taken_at) "
                                   "VALUES (?, ?, ?, ?, ?, ?)", (gid, rid, perms, code, creator, self._now()))
        except Exception:
            log.exception("inviteguard: could not save the role snapshot")

    # ------------------------------------------------------------------ Discord access (overridable in tests)
    async def _req(self, method: str, path: str, *, json_body=None, reason: Optional[str] = None, **params):
        """Plain REST through discord.py's own rate-limited client.  Route-based on purpose (like OnboardGuard._api): works on any
        discord.py 2.x without depending on the signature of its helper methods."""
        from discord.http import Route                        # lazy import: unit tests run without discord.py
        kw = {}
        if json_body is not None:
            kw["json"] = json_body
        if reason:
            kw["reason"] = reason
        return await self.bot.http.request(Route(method, path, **params), **kw)

    async def _http_delete_invite(self, code: str, reason: str):
        return await self._req("DELETE", "/invites/{invite_code}", reason=reason, invite_code=code)

    async def _http_get_invite(self, code: str):
        return await self._req("GET", "/invites/{invite_code}", invite_code=code)

    async def _http_edit_role(self, gid: int, rid: int, perms: int, reason: str):
        return await self._req("PATCH", "/guilds/{guild_id}/roles/{role_id}", json_body={"permissions": str(int(perms))},
                               reason=reason, guild_id=gid, role_id=rid)

    async def _http_remove_member_role(self, gid: int, uid: int, rid: int, reason: str):
        return await self._req("DELETE", "/guilds/{guild_id}/members/{user_id}/roles/{role_id}", reason=reason,
                               guild_id=gid, user_id=uid, role_id=rid)

    async def _http_guild_invites(self, gid: int):
        return await self._req("GET", "/guilds/{guild_id}/invites", guild_id=gid)

    async def _audit_rest(self, guild) -> tuple:
        """-> ([(entry id, user id, ts, code | None, inviter_id | None)] | None, reason).  One request, newest first."""
        try:
            try:
                data = await self.bot.http.get_audit_logs(guild.id, limit=25, action_type=INVITE_CREATE_ACTION)
            except TypeError:                                  # helper without the action filter: read the newest 100 and filter here
                data = await self.bot.http.get_audit_logs(guild.id, limit=100)
        except discord.Forbidden:
            return None, "no View Audit Log permission"
        except discord.HTTPException:
            return None, "audit log request failed"
        out = []
        for e in (data or {}).get("audit_log_entries", ()) or ():
            if not isinstance(e, dict) or e.get("action_type") != INVITE_CREATE_ACTION:
                continue
            eid, uid, code, inviter = audit_fields(e)
            if eid is not None:
                out.append((eid, uid, snowflake_ts(eid), code, inviter))
        return out, "ok"

    async def _retry(self, factory):
        for i in range(3):
            try:
                return await factory()
            except discord.HTTPException as exc:
                if isinstance(exc, (discord.Forbidden, discord.NotFound)) or getattr(exc, "status", 0) < 500 or i == 2:
                    raise
                await self._sleep(0.3 * (i + 1))

    # ------------------------------------------------------------------ role helpers
    def hierarchy_ok(self, guild, role) -> tuple:
        me = guild.me
        gp = me.guild_permissions
        if not (gp.administrator or gp.manage_roles):
            return False, "I lack Manage Roles"
        if not role < me.top_role:
            return False, "role is above or equal to my highest role"
        return True, "ok"

    # ------------------------------------------------------------------ raw gateway hooks (earliest signal, RAM only)
    def _hook_raw(self) -> None:
        try:
            parsers = self.bot._connection.parsers
            wanted = {"INVITE_CREATE": self._raw_invite, "GUILD_AUDIT_LOG_ENTRY_CREATE": self._raw_audit}
            origs = {k: parsers[k] for k in wanted}
            for k in ("GUILD_MEMBER_ADD", "GUILD_MEMBER_UPDATE"):       # optional: only the joiner cleanup needs them
                if k in parsers:
                    wanted[k], origs[k] = self._raw_member, parsers[k]
        except Exception:
            log.warning("inviteguard: raw gateway hook unavailable - using the normal listeners")
            return
        if self._raw:
            return
        for name, handler in wanted.items():
            orig = origs[name]

            def make(orig=orig, handler=handler):
                def parse(data):
                    try:
                        handler(data)
                    except Exception:
                        log.exception("inviteguard raw hook failed")
                    return orig(data)
                return parse
            wrapper = make()
            self._raw[name] = (orig, wrapper)
            parsers[name] = wrapper

    def _unhook_raw(self) -> None:
        try:
            parsers = self.bot._connection.parsers
            for name, (orig, wrapper) in self._raw.items():
                if parsers.get(name) is wrapper:             # only if nobody chained after us
                    parsers[name] = orig
        except Exception:
            pass
        self._raw = {}

    def _wake(self, gid: int) -> None:
        for fut in self._waiters.pop(gid, ()):
            if not fut.done():
                fut.set_result(None)

    async def _wait_for(self, gid: int, check, timeout: float):
        """Event driven: returns check() as soon as it is truthy (woken by the gateway entry itself), or check()'s last value
        after `timeout`."""
        val = check()
        if val:
            return val
        loop = asyncio.get_running_loop()
        end = loop.time() + timeout
        while True:
            rem = end - loop.time()
            if rem <= 0:
                return check()
            fut = loop.create_future()
            self._waiters.setdefault(gid, []).append(fut)
            try:
                await asyncio.wait_for(fut, rem)
            except asyncio.TimeoutError:
                pass
            finally:
                lst = self._waiters.get(gid)
                if lst is not None and fut in lst:
                    lst.remove(fut)
            val = check()
            if val:
                return val

    def _note_audit(self, gid: int, eid, uid, code, inviter) -> bool:
        """True if this entry is new (the raw hook and the normal listener both report every entry)."""
        lst = self._hints.setdefault(gid, [])
        if eid in self._used or any(h[0] == eid for h in lst):
            return False
        lst.append((eid, uid, self._now(), code, inviter))
        del lst[:-50]
        if len(self._hints) > 500:
            self._hints.pop(next(iter(self._hints)))
        self._wake(gid)
        return True

    def _raw_audit(self, data: dict) -> None:
        if not isinstance(data, dict) or data.get("action_type") != INVITE_CREATE_ACTION:
            return
        gid = _to_int(data.get("guild_id"))
        if gid is None or not self._enabled(gid):
            return
        eid, uid, code, inviter = audit_fields(data)
        if eid is not None:
            self._note_audit(gid, eid, uid, code, inviter)

    # ------------------------------------------------------------------ roles of a neutralised invite: nobody keeps them
    def _hot_add(self, gid: int, rids, code: str) -> None:
        exp = self._now() + HOT_TTL
        d = self._hot.setdefault(gid, {})
        for r in rids:
            d[r] = (exp, code)
        if len(self._hot) > 500:
            self._hot.pop(next(iter(self._hot)))

    def _hot_roles(self, gid: int) -> dict:
        d = self._hot.get(gid)
        if not d:
            return {}
        now = self._now()
        for r in [r for r, (exp, _c) in d.items() if exp < now]:
            d.pop(r, None)
        return d

    def _raw_member(self, data: dict) -> None:
        """GUILD_MEMBER_ADD / GUILD_MEMBER_UPDATE (raw, RAM only): a member holding a role of a neutralised invite loses it at once."""
        if not isinstance(data, dict):
            return
        gid = _to_int(data.get("guild_id"))
        if gid is None or gid not in self._hot or not self._enabled(gid):
            return
        user = data.get("user")
        uid = _to_int(user.get("id")) if isinstance(user, dict) else None
        raw = data.get("roles")
        if uid is None or not isinstance(raw, (list, tuple)):
            return
        hot = self._hot_roles(gid)
        bad = [r for r in (_to_int(x) for x in raw) if r is not None and r in hot]
        if not bad:
            return
        guild = self.bot.get_guild(gid)
        if guild is None or self.exempt(self.classify(guild, uid)):
            return
        bad = [r for r in bad if self._claim((gid, "mrole", uid, r), 30.0)]
        if bad:
            self._spawn_now(self._clean_member(guild, uid, bad, hot))

    async def _clean_member(self, guild, uid: int, rids, hot: dict) -> None:
        for r in rids:
            st, d = await self._p_remove_role(guild, uid, r, hot.get(r, (0, ""))[1])
            await self._event(guild.id, "member_role_removed", None, uid, {"role": r, "status": st, "detail": d, "code": hot.get(r, (0, ""))[1]})

    async def _p_remove_role(self, guild, uid: int, rid: int, code: str) -> tuple:
        role = guild.get_role(rid)
        if role is not None:
            okh, why = self.hierarchy_ok(guild, role)
            if not okh:
                return "blocked", why
        try:
            await self._retry(lambda: self._http_remove_member_role(guild.id, uid, rid, f"Anti Invite Role: role from unauthorized invite {code}"))
        except discord.Forbidden:
            return "failed", "Discord refused (403)"
        except discord.NotFound:
            return "ok", "member or role already gone"
        except discord.HTTPException as exc:
            return "failed", f"Discord error {getattr(exc, 'status', '?')}"
        return "ok", "role removed"

    async def _p_clean_members(self, guild, inv: InvitePayload, since: float) -> tuple:
        """Members who joined since the invite was created and hold one of its roles lose that role.  Owner / extra owners /
        whitelisted / me are never touched.  Later joiners are handled by the raw member hook (HOT_TTL)."""
        targets = []
        for m in list(getattr(guild, "members", None) or ()):
            ja = getattr(m, "joined_at", None)
            if ja is None or ja.timestamp() < since or m.bot and m.id == self.bot.user.id:
                continue
            mine = [r.id for r in m.roles if r.id in inv.role_ids]
            if mine and not self.exempt(self.classify(guild, m.id)):
                targets.append((m.id, mine))
        if not targets:
            return "ok", "no member joined with these role(s) so far; later joiners are watched for 15 min"
        results = await asyncio.gather(*[self._p_remove_role(guild, uid, r, inv.code) for uid, mine in targets[:MAX_CLEAN] for r in mine],
                                       return_exceptions=True)
        n_ok = sum(1 for r in results if isinstance(r, tuple) and r[0] == "ok")
        bad = len(results) - n_ok
        return ("ok" if not bad else "failed"), f"role removed from {n_ok} member(s)" + (f", {bad} failed" if bad else "") + "; later joiners are watched for 15 min"

    def _raw_invite(self, data: dict) -> None:
        """INVITE_CREATE before discord.py parses it.  Decided from the raw dict in RAM; the first await of the handler is the
        HTTP request that deletes the invite."""
        self.stats["invites_seen"] += 1
        inv = parse_invite_create(data)
        if inv is None or not inv.role_ids or not self._enabled(inv.guild_id):
            return
        guild = self.bot.get_guild(inv.guild_id)
        if guild is None or not self._claim((inv.guild_id, "invite", inv.code), CLAIM_TTL):
            return
        self._spawn_now(self._handle(guild, inv, raw=True))

    # ------------------------------------------------------------------ normal listeners (fallback; duplicates are claimed)
    @commands.Cog.listener()
    async def on_invite_create(self, invite):
        guild = getattr(invite, "guild", None)
        gid = getattr(guild, "id", None)
        code = getattr(invite, "code", None)
        if gid is None or not valid_invite_code(code) or not self._enabled(gid):
            return
        if self._raw:
            return                                            # the raw hook handles every invite (RAM only); this listener is the fallback
        guild = self.bot.get_guild(gid)
        if guild is None:
            return
        rids = tuple(_to_int(r) for r in (getattr(invite, "role_ids", None) or ()) if _to_int(r) is not None)
        if not rids and not getattr(invite, "roles", None):
            try:                                              # fallback only: this discord.py build does not expose the roles
                rids = roles_from_invite_obj(await self._http_get_invite(code))
            except discord.HTTPException:
                return
        elif not rids:
            rids = tuple(_to_int(getattr(r, "id", r)) for r in invite.roles if _to_int(getattr(r, "id", r)) is not None)
        if not rids or not self._claim((gid, "invite", code), CLAIM_TTL):
            return
        inviter = getattr(invite, "inviter", None)
        payload = InvitePayload(gid, code, getattr(getattr(invite, "channel", None), "id", None), _to_int(getattr(inviter, "id", None)),
                                tuple(rids[:MAX_ROLES]))
        self._spawn(self._handle(guild, payload, raw=False))

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if self._raw or getattr(after, "guild", None) is None:
            return
        gid = after.guild.id
        hot = self._hot_roles(gid) if gid in self._hot else {}
        bad = [r.id for r in after.roles if r.id in hot]
        if bad and self._enabled(gid) and not self.exempt(self.classify(after.guild, after.id)):
            bad = [r for r in bad if self._claim((gid, "mrole", after.id, r), 30.0)]
            if bad:
                self._spawn(self._clean_member(after.guild, after.id, bad, hot))

    @commands.Cog.listener()
    async def on_member_join(self, member):
        await self.on_member_update(None, member)

    @commands.Cog.listener()
    async def on_audit_log_entry_create(self, entry):
        guild = getattr(entry, "guild", None)
        if guild is None or not self._enabled(guild.id):
            return
        if getattr(entry.action, "value", entry.action) != INVITE_CREATE_ACTION:
            return
        code = getattr(getattr(entry, "after", None), "code", None) or getattr(getattr(entry, "target", None), "code", None)
        self._note_audit(guild.id, entry.id, getattr(entry, "user_id", None), code if isinstance(code, str) else None, None)

    # ------------------------------------------------------------------ creator verification (audit log)
    async def _audit_match(self, guild, inv: InvitePayload) -> AuditRes:
        """Confirm WHO created this invite from the audit log: gateway entry first (event driven, no REST), then one REST read."""
        gid = guild.id
        try:
            def check():
                cands = [h for h in self._hints.get(gid, ()) if h[0] not in self._used]
                st, ent, why = pick_audit(cands, inv.code, inv.inviter_id, self._now())
                return (st, ent, why) if st in ("verified", "mismatch") else None
            got = await self._wait_for(gid, check, self.hint_wait)
            via = "gateway audit entry"
            if got is None:
                rest, why = await self._audit_rest(guild)
                via = "audit-log REST"
                if rest is None:
                    return AuditRes("unavailable", None, via, why)
                st, ent, why = pick_audit([c for c in rest if c[0] not in self._used], inv.code, inv.inviter_id, self._now())
                got = (st, ent, why)
            st, ent, why = got
            if ent is not None:
                self._mark_used(ent[0])
            return AuditRes(st, ent[1] if ent is not None else None, via, why, ent[0] if ent is not None else None)
        except Exception as exc:                              # noqa: BLE001
            log.exception("inviteguard audit match failed guild=%s", gid)
            return AuditRes("unavailable", None, "", f"internal error: {type(exc).__name__}")

    # ------------------------------------------------------------------ neutralisation primitives (each re-reads before it claims ok)
    async def _p_delete_invite(self, guild, code: str, inc=None) -> tuple:
        try:
            await self._retry(lambda: self._http_delete_invite(code, "Anti Invite Role: unauthorized role-attached invite"))
            accepted = True
        except discord.Forbidden:
            return "failed", "Discord refused (403): I need Manage Channels on that channel or Manage Server"
        except discord.NotFound:
            accepted = False                                   # already gone (expired / deleted by someone else): the re-read decides
        except discord.HTTPException as exc:
            return "failed", f"Discord error {getattr(exc, 'status', '?')}"
        if accepted and inc is not None and inc.ms_action is None:
            inc.ms_action = (time.perf_counter() - inc.t0) * 1000       # Discord accepted the removal; the re-read below is extra
        try:
            await self._http_get_invite(code)
        except discord.NotFound:
            if accepted:
                self.stats["invites_deleted"] += 1
            return "ok", ("invite deleted; re-read returned 404" if accepted else "invite was already gone (re-read returned 404)")
        except discord.HTTPException:
            return "unverified", "delete accepted, but I could not re-read the invite to confirm"
        return "failed", "Discord accepted the request but the invite still exists"

    async def _p_strip(self, guild, rid: int, inv: InvitePayload, fresh: bool = False) -> tuple:
        """Remove the privileged bits from one linked role.  The role is never deleted and nothing else on it changes."""
        async with self._role_lock(guild.id, rid):
            role = guild.get_role(rid)
            if fresh or role is None:
                try:
                    role = next((r for r in await guild.fetch_roles() if r.id == rid), None)
                except discord.HTTPException:
                    return "unverified", "could not load the roles to verify the linked role id"
            if role is None:
                return "skipped", "linked role id does not exist in this server (re-read)"
            if role.is_default():
                return "skipped", "@everyone cannot be an invite role"
            cur = role.permissions.value
            bad = cur & PRIV_MASK
            if not bad:
                return "ok", "role has no privileged permission (nothing to strip); role kept"
            okh, why = self.hierarchy_ok(guild, role)
            if not okh:
                return "blocked", f"{why}; privileged: {', '.join(priv_names(bad))}"
            gid = guild.id
            if (gid, rid) not in self.snaps:                   # first original is never overwritten
                self.snaps[(gid, rid)] = cur
                self._spawn(self._save_snap(gid, rid, cur, inv.code, inv.inviter_id))
            new = cur & ~PRIV_MASK
            try:
                await self._retry(lambda: self._http_edit_role(gid, rid, new, "Anti Invite Role: privileged permissions removed"))
            except discord.Forbidden:
                return "failed", "Discord refused (403): Manage Roles / role hierarchy"
            except discord.NotFound:
                return "skipped", "role vanished (404)"
            except discord.HTTPException as exc:
                return "failed", f"Discord error {getattr(exc, 'status', '?')}"
            try:
                now_role = next((r for r in await guild.fetch_roles() if r.id == rid), None)
            except discord.HTTPException:
                return "unverified", "edit accepted, but I could not re-read the roles to confirm"
            if now_role is None:
                return "ok", "role no longer exists (re-read)"
            left = now_role.permissions.value & PRIV_MASK
            if left:
                return "failed", "Discord accepted the edit but the role still has: " + ", ".join(priv_names(left))
            self.stats["roles_stripped"] += 1
            return "ok", f"removed {', '.join(priv_names(bad))}; role re-read and confirmed; role kept (not deleted)"

    async def _p_ban(self, guild, uid: int, reason: str, inc=None) -> tuple:
        if self.exempt(self.classify(guild, uid)):
            return "skipped", "protected (owner / extra owner / whitelisted)"
        bgc = self.bot.get_cog("BotGuard")
        if bgc is not None:
            st, detail = await bgc._ban(guild, uid, reason)          # shares the punishment claim with the engine + botguard (no double ban)
        else:
            if not self._claim((guild.id, "ban", uid), CLAIM_TTL):          # a burst of invites by one creator: ban once, then only verify
                st, detail = "ok", "another incident of this burst already sent the ban; verifying it below"
                return await self._confirm_only(guild, uid, detail)
            try:
                await self._retry(lambda: guild.ban(discord.Object(id=uid), reason=reason, delete_message_seconds=0))
                st, detail = "ok", "ban accepted by Discord"
            except discord.Forbidden:
                return "failed", "Discord refused the ban (Ban Members missing or the creator's role is above mine)"
            except discord.HTTPException as exc:
                return "failed", f"Discord error {getattr(exc, 'status', '?')}"
        if st != "ok":
            return st, detail
        try:
            await guild.fetch_ban(discord.Object(id=uid))
        except discord.NotFound:
            return "failed", "Discord accepted the ban but fetch_ban says the user is not banned"
        except discord.HTTPException:
            return "unverified", detail + "; could not re-read the ban list to confirm"
        self.stats["bans"] += 1
        return "ok", "ban re-read from Discord (fetch_ban) and confirmed"

    async def _confirm_only(self, guild, uid: int, detail: str) -> tuple:
        for i in range(2):
            try:
                await guild.fetch_ban(discord.Object(id=uid))
                return "ok", detail + " (confirmed with fetch_ban; no second ban sent)"
            except discord.NotFound:
                if i == 0:
                    await self._sleep(1.0)
            except discord.HTTPException:
                break
        return "unverified", "another incident claimed this ban but I could not confirm it"

    async def _p_ban_verified(self, guild, inv: InvitePayload, creator: int, audit_task, inc) -> tuple:
        """The creator is banned ONLY when the audit log names the same user for the same invite code."""
        res = await audit_task
        if res.state != "verified":
            what = {"mismatch": "the audit log names a different user than the event", "ambiguous": "several users match in the audit log",
                    "none": "no matching audit entry", "unavailable": "audit log unavailable"}.get(res.state, res.state)
            return "unverified", f"NOT banned: creator not confirmed ({what}: {res.why}). The invite was still removed and the roles stripped."
        if res.uid != creator:
            return "unverified", "NOT banned: audit user differs from the creator"
        return await self._p_ban(guild, creator, "Anti Invite Role | unauthorized role-attached invite", inc)

    async def _threat_alive(self, guild, inv: InvitePayload, rids) -> tuple:
        """-> (invite_alive: True | False | None, roles_privileged: True | False | None)"""
        try:
            await self._http_get_invite(inv.code)
            invite = True
        except discord.NotFound:
            invite = False
        except discord.HTTPException:
            invite = None
        try:
            roles = {r.id: r for r in await guild.fetch_roles()}
            priv = any(rid in roles and roles[rid].permissions.value & PRIV_MASK for rid in rids)
        except discord.HTTPException:
            priv = None
        return invite, priv

    # ------------------------------------------------------------------ the response
    async def _handle(self, guild, inv: InvitePayload, raw: bool = False, stale: bool = False) -> None:
        try:
            await self._handle_inner(guild, inv, raw, stale)
        except Exception:
            log.exception("inviteguard handler failed guild=%s code=%s", guild.id, inv.code)

    async def _handle_inner(self, guild, inv: InvitePayload, raw: bool, stale: bool = False) -> None:
        gid = guild.id
        if not self._enabled(gid):
            return
        self.stats["role_invites"] += 1
        inc = IgIncident("invite_role", gid, started=self._now(), code=inv.code, channel_id=inv.channel_id, role_ids=list(inv.role_ids),
                         trigger=("role-attached invite found by the startup sweep (created while I was offline): invite removed, roles stripped, nobody banned"
                                  if stale else "invite created with attached role(s)"))
        inc.via = "startup sweep" if stale else "raw gateway" if raw else "gateway event"
        creator = inv.inviter_id
        cls = self.classify(guild, creator)
        inc.executor_id, inc.executor_class = creator, ("" if creator is None else cls)
        if creator is not None and self.exempt(cls):                      # Owner / Extra Owner / whitelist / me: nothing happens
            await self._event(gid, "invite_role_authorized", creator, None, {"code": inv.code, "roles": list(inv.role_ids), "class": cls})
            log.info("inviteguard: authorized role invite guild=%s code=%s by=%s (%s)", gid, inv.code, creator, cls)
            return

        self._hot_add(gid, inv.role_ids, inv.code)                          # later joiners with these roles lose them (RAM, sync)
        # ---- 1. verification, RAM only, BEFORE any request is sent
        found = [r for r in inv.role_ids if guild.get_role(r) is not None]
        unknown = [r for r in inv.role_ids if r not in found]
        inc.title = "Unauthorized invite with attached role(s)"
        inc.add("Detect", "ok", f"INVITE_CREATE carried role_ids {list(inv.role_ids)}")
        inc.add("Verify invite", "ok", f"code `{inv.code}` is well-formed; creator " + (f"`{creator}` from the event" if creator else "not in the event")
                + f"; {len(found)}/{len(inv.role_ids)} linked role id(s) exist in this server"
                + (f" ({len(unknown)} not in cache: re-read before any edit)" if unknown else ""))
        audit_task = self._spawn_now(self._no_audit() if stale else self._audit_match(guild, inv))        # runs in parallel with everything below

        # ---- creator missing from the payload: the audit log has to name them first
        ban_creator = creator is not None and not stale
        if creator is None:
            res = await audit_task
            if res.state == "verified":
                creator, ban_creator = res.uid, True
                cls = self.classify(guild, creator)
                inc.executor_id, inc.executor_class, inc.exec_via = creator, cls, res.via
                if self.exempt(cls):
                    await self._event(gid, "invite_role_authorized", creator, None, {"code": inv.code, "via": "audit", "class": cls})
                    return
            else:
                priv = any(guild.get_role(r).permissions.value & PRIV_MASK for r in found)
                if not priv:
                    inc.add("Verify creator (audit log)", "unverified", f"creator unknown ({res.state}: {res.why}): nobody will be banned")
                    inc.add("Action", "skipped", "creator unknown and no linked role is privileged: alert only")
                    await self._publish(guild, inc, "Security Log - Anti Invite Role", dm_owner=True)
                    return
                ban_creator = False

        # ---- 2. parallel response: delete invite | strip roles | confirm creator and ban
        jobs: dict = {"Delete invite": lambda: self._p_delete_invite(guild, inv.code, inc)}
        labels: dict = {}
        for rid in inv.role_ids:
            role = guild.get_role(rid)
            key = f"Strip role {rid}"
            labels[key] = f"Strip permissions: {role.name if role is not None else rid}"
            jobs[key] = (lambda rid=rid: self._p_strip(guild, rid, inv))
        jobs["Clean members"] = lambda: self._p_clean_members(guild, inv, self._now() - CLOCK_SKEW)
        labels["Clean members"] = "Remove role from members who joined with it"
        if ban_creator:
            if BAN_NEEDS_AUDIT:
                jobs["Ban creator"] = lambda: self._p_ban_verified(guild, inv, creator, audit_task, inc)
            else:                                                  # fastest: the event itself names the creator, ban leaves in this same tick
                jobs["Ban creator"] = lambda: self._p_ban(guild, creator, "Anti Invite Role | unauthorized role-attached invite", inc)
        tasks = {name: _spawn_eager(self._guard(f)) for name, f in jobs.items()}      # eager: every request leaves in this same tick
        results = await asyncio.gather(*tasks.values(), return_exceptions=True)
        if inc.ms_action is None:
            inc.ms_action = (time.perf_counter() - inc.t0) * 1000
        res_by = {}
        for name, r in zip(tasks, results):
            if isinstance(r, BaseException):
                log.exception("inviteguard step %s crashed", name, exc_info=r)
                r = ("failed", f"internal error: {type(r).__name__}")
            res_by[name] = r

        if not audit_task.done():                             # all actions are already confirmed here; the card only waits for the audit read
            try:
                await asyncio.wait_for(asyncio.shield(audit_task), self.hint_wait + 2.0)
            except Exception:                                 # noqa: BLE001
                pass
        ares = audit_task.result() if audit_task.done() and not audit_task.cancelled() and audit_task.exception() is None \
            else AuditRes("unavailable", None, "", "not finished")
        if creator is not None or ares.state != "verified":
            inc.add("Verify creator (audit log)", "ok" if ares.state == "verified" else "unverified",
                    (f"`{ares.uid}` confirmed for this invite code ({ares.why}) via {ares.via}" if ares.state == "verified"
                     else f"{ares.state}: {ares.why}"))
        if inc.exec_via == "" and ares.via:
            inc.exec_via = ares.via
        for name, r in res_by.items():
            inc.add(labels.get(name, name), *r)
        inc.add("Roles kept", "ok", "linked role(s) were not deleted; only privileged bits were removed")

        # ---- 3. emergency: a neutralising step failed and the threat is still there
        bad = [n for n in res_by if n not in ("Ban creator", "Clean members") and res_by[n][0] in ("failed", "blocked")]
        if bad:
            invite_alive, priv = await self._threat_alive(guild, inv, inv.role_ids)
            if invite_alive is False:
                inc.add("Emergency lockdown", "skipped",
                        "a step failed but the invite is gone (re-read 404): no new member can receive the role; "
                        + ("a linked role is still privileged: fix it by hand or retry" if priv else "roles are clean"))
            else:
                st, d = await self._lockdown(guild, f"Anti Invite Role: could not neutralise invite {inv.code} ({', '.join(bad)})")
                inc.add("Emergency lockdown", st, d + ("" if invite_alive else " (could not re-read the invite; locking down to be safe)"))
            await self._retry_failed(inv, inc, jobs, labels, [n for n in bad if res_by[n][0] == "failed"], guild)
        await self._publish(guild, inc, "Security Log - Anti Invite Role", dm_owner=self._claim((gid, "dm", creator), DM_COOLDOWN))

    async def _no_audit(self) -> AuditRes:
        return AuditRes("none", None, "startup sweep", "stale invite: the audit entry is not matched, so nobody is banned")

    async def _guard(self, factory):
        return await factory()

    async def _retry_failed(self, inv, inc: IgIncident, jobs: dict, labels: dict, bad: list, guild) -> None:
        for name in bad:
            step = next((s for s in inc.steps if s.name == labels.get(name, name)), None)
            for n, delay in enumerate(self.retry_delays, 1):
                await self._sleep(delay)
                try:
                    st, d = await (self._p_strip(guild, int(name.split()[-1]), inv, fresh=True) if name.startswith("Strip role")
                                   else jobs[name]())
                except Exception as exc:                          # noqa: BLE001
                    st, d = "failed", f"internal error: {type(exc).__name__}"
                if step is not None:
                    step.status, step.detail = st, f"retry {n}/{len(self.retry_delays)}: {d}"
                if st in ("ok", "skipped", "blocked"):
                    break

    async def _lockdown(self, guild, why: str) -> tuple:
        now = self._now()
        if now - self._lockdown_at.get(guild.id, -1e9) < LOCKDOWN_COOLDOWN:
            return "skipped", "a lockdown was already triggered in the last 2 minutes"
        self._lockdown_at[guild.id] = now
        emg = self.bot.get_cog("Emergency")
        if emg is None:
            return "failed", "the Emergency module is not loaded: no lockdown possible; the owner must act"
        try:
            n = await emg._lockdown(guild)
        except Exception as exc:                                  # noqa: BLE001
            log.exception("inviteguard lockdown failed")
            return "failed", f"lockdown crashed: {type(exc).__name__}"
        if getattr(emg, "auto_guilds", None) and guild.id in emg.auto_guilds:
            self._spawn(emg.auto_trigger(guild, why))             # owner opted into full emergency mode as well
        self.stats["lockdowns"] += 1
        return ("ok", f"{n} channel(s) locked for @everyone (undo with `emergency unlock`)") if n else \
               ("failed", "no channel could be locked (missing Manage Channels / already locked)")

    # ------------------------------------------------------------------ reporting
    def _channel(self, guild):
        cfg = store.peek(guild.id)
        return guild.get_channel(cfg.log) if cfg is not None and cfg.log else None

    async def _publish(self, guild, inc: IgIncident, header: str, dm_owner: bool = True) -> None:
        self.stats["incidents"] += 1
        inc.ms = (time.perf_counter() - inc.t0) * 1000
        await self._event(guild.id, f"incident_{inc.kind}", inc.executor_id, None, {
            **inc.as_dict(), "code": inc.code, "roles": inc.role_ids, "channel": inc.channel_id, "trigger": inc.trigger, "ts": self._now()})
        channel = self._channel(guild)
        dm_task = asyncio.ensure_future(self._dm_owner(guild, render_ig(inc, header + f" ({guild.name})", now=self._now()))) if dm_owner else None
        sent = False
        if channel is not None:
            try:
                from utils import antinuke_ui as ui
            except Exception:
                ui = None
            try:
                if ui is not None:
                    await channel.send(view=ui.view_of(ui.text(render_ig(inc, header, ok=ui.OK, no=ui.NO, now=self._now()))), allowed_mentions=ui.NO_PING)
                else:
                    await channel.send(content=render_ig(inc, header, now=self._now())[:1990], allowed_mentions=discord.AllowedMentions.none())
                sent = True
            except (discord.Forbidden, discord.HTTPException):
                sent = False
        if dm_task is not None:                                   # the DM ran in parallel with the log card
            ok = await dm_task
            inc.add("Notify owner", "ok" if ok else "failed", "DM delivered" if ok else "could not DM the owner (DMs closed)" + ("; see log channel" if channel else ""))
        log.info("inviteguard incident guild=%s code=%s creator=%s roles=%s ts=%s log_channel=%s steps=%s", guild.id, inc.code, inc.executor_id,
                 inc.role_ids, int(self._now()), "sent" if sent else "unavailable", [(s.name, s.status) for s in inc.steps])

    async def _dm_owner(self, guild, text: str) -> bool:
        try:
            user = self.bot.get_user(guild.owner_id) or await self.bot.fetch_user(guild.owner_id)
            await user.send(content=text[:1990], allowed_mentions=discord.AllowedMentions.none())
            return True
        except (discord.Forbidden, discord.HTTPException):
            return False

    # ------------------------------------------------------------------ startup sweep (invites created while the bot was offline)
    async def sweep_guild(self, guild, force: bool = False) -> int:
        """Delete + defang role-attached invites of untrusted creators that already exist.  Never bans (nothing proves they are fresh)."""
        if not self._enabled(guild.id) or (not force and not self._claim((guild.id, "sweep"), 300.0)):
            return 0
        rows, _why = await self.scan(guild)
        n = 0
        for code, inviter, rids, _priv in rows or ():
            if not valid_invite_code(code) or (inviter is not None and self.exempt(self.classify(guild, inviter))):
                continue
            if not self._claim((guild.id, "invite", code), CLAIM_TTL):
                continue
            n += 1
            self._spawn(self._handle(guild, InvitePayload(guild.id, code, None, inviter, tuple(rids[:MAX_ROLES])), raw=False, stale=True))
        return n

    async def _sweep_all(self) -> None:
        for g in list(self.bot.guilds):
            try:
                await self.sweep_guild(g)
            except Exception:
                log.exception("inviteguard sweep failed guild=%s", getattr(g, "id", "?"))

    @commands.Cog.listener()
    async def on_ready(self):
        self._spawn(self._sweep_all())

    # ------------------------------------------------------------------ owner commands
    async def scan(self, guild) -> tuple:
        """Read-only: -> (rows | None, reason).  rows: [(code, inviter id | None, [role ids], privileged: bool)]"""
        try:
            data = await self._http_guild_invites(guild.id)
        except discord.Forbidden:
            return None, "forbidden"
        except discord.HTTPException:
            return None, "error"
        rows = []
        for inv in data or ():
            if not isinstance(inv, dict):
                continue
            rids = roles_from_invite_obj(inv)
            if rids:
                inviter = inv.get("inviter")
                priv = any((r := guild.get_role(x)) is not None and r.permissions.value & PRIV_MASK for x in rids)
                rows.append((inv.get("code"), _to_int(inviter.get("id")) if isinstance(inviter, dict) else None, list(rids), priv))
        return rows, "ok"

    async def restore_role(self, guild, rid: int, by: int) -> tuple:
        """`antinuke inviterole restore <role_id>`: put back ONLY the bits this module stripped (a role edited since keeps its
        other changes).  -> (status, detail)"""
        gid = guild.id
        orig = self.snaps.get((gid, rid))
        if orig is None:
            return "failed", "no snapshot for this role: nothing was stripped by Anti Invite Role"
        async with self._role_lock(gid, rid):
            role = guild.get_role(rid)
            if role is None:
                return "failed", "role no longer exists"
            okh, why = self.hierarchy_ok(guild, role)
            if not okh:
                return "failed", why
            new = role.permissions.value | (orig & PRIV_MASK)
            try:
                await self._retry(lambda: self._http_edit_role(gid, rid, new, f"Anti Invite Role: restored by {by}"))
                cur = next((r for r in await guild.fetch_roles() if r.id == rid), None)
            except discord.HTTPException as exc:
                return "failed", f"Discord error {getattr(exc, 'status', '?')}"
            if cur is None or (cur.permissions.value & orig & PRIV_MASK) != (orig & PRIV_MASK):
                return "failed", "Discord accepted the edit but the permissions differ when re-read"
            self.snaps.pop((gid, rid), None)
            await self.ledger.exec("DELETE FROM ig_snapshots WHERE guild_id = ? AND role_id = ?", (gid, rid))
            await self._event(gid, "role_restored", by, rid, {"perms": new})
            return "ok", "stripped permissions restored: " + (", ".join(priv_names(orig & PRIV_MASK)) or "none")

    def status_info(self, guild) -> dict:
        gp = guild.me.guild_permissions
        full = gp.administrator
        return {"on": self.flag(guild.id), "engine": bool(store.get(guild.id).enabled),
                "audit": full or gp.view_audit_log, "manage_roles": full or gp.manage_roles,
                "manage_guild": full or gp.manage_guild, "ban": full or gp.ban_members,
                "raw_hook": bool(self._raw), "snapshots": sum(1 for k in self.snaps if k[0] == guild.id),
                "invites_seen": self.stats["invites_seen"], "role_invites": self.stats["role_invites"]}
