"""Linked Role protection, invite attribution, X/Y cross-verification and selective lockdown.

This cog does NOT own any of the role / audit-log / member-update listeners: the Antinuke engine
(cogs/antinuke/engine.py) already has them and calls the three hooks below, so no event handler is
duplicated:

    linked_role_created(role)           <- engine.on_guild_role_create   (role has connection requirements)
    note_role_audit(entry)              <- engine.on_audit_log_entry_create  (free executor id from the gateway)
    member_roles_changed(before, after) <- engine.on_member_update

It owns only the invite events (on_invite_create / on_invite_delete / on_member_join), which nothing else
in the antinuke package listens to.

Definitions used by the cross-verification (see CHANGES_V44_LINKINVITE.md):
    X = the account that CREATED the flagged Linked Role (audit-log executor)  - kept for at most 1 hour.
    Y = the account whose invite the role RECEIVER joined with                 - recorded at join time.

Honest limits: Discord does not say which invite a member used.  Y is inferred from invite use-count
differences and can be UNKNOWN (vanity URL, several joins at once, missing Manage Server, bot restarted
mid-join).  UNKNOWN is never treated as proof of guilt: it only ever leads to a (reversible) lockdown
and an alert, never to a ban.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sqlite3
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Optional

import discord
from discord.ext import commands

from utils import antinuke_store as store

log = logging.getLogger("deathbot.linkinvite")
AL = discord.AuditLogAction
BIT = store.BIT

# --------------------------------------------------------------------------- constants
PERM_ADMIN = 1 << 3
PERM_MANAGE_GUILD = 1 << 5
PERM_MANAGE_ROLES = 1 << 28
DANGER_MASK = PERM_ADMIN | PERM_MANAGE_GUILD | PERM_MANAGE_ROLES      # the ONLY bits this module ever removes

X_WAIT = 1.5                    # max wait for the gateway audit entry that names the role creator
X_TTL = 3600.0                  # candidate X lives at most one hour
MONITOR_TTL = 86400.0           # a flagged role stays "monitored" for receipt checks this long
RECEIPT_TTL = 600.0             # dedupe window for (guild, member, role) receipt events
DEFAULT_THRESHOLD = int(os.getenv("LI_THRESHOLD", "2"))
DEFAULT_WINDOW = float(os.getenv("LI_WINDOW", "600"))
EDIT_CONCURRENCY = 8            # bounded parallel role edits during lockdown / restore
JOIN_KEEP = 30 * 86400
EVENT_KEEP = 90 * 86400
DB_PATH = os.getenv("LI_DB_PATH", "db/linkinvite.db")

# attribution kinds (how Y was derived)
NORMAL, VANITY, UNKNOWN, UNAVAILABLE, AMBIGUOUS, BOT = (
    "NORMAL", "VANITY", "UNKNOWN", "UNAVAILABLE", "AMBIGUOUS", "BOT")
# cross-verification verdicts
CONFIRMED, MISMATCH, Y_MISSING, X_MISSING, V_UNKNOWN = (
    "CONFIRMED", "MISMATCH", "Y_MISSING", "X_MISSING", "UNKNOWN")


# --------------------------------------------------------------------------- pure helpers (unit-tested)
def valid_id(value) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and 0 < value < (1 << 63)


def cross_verify(x: Optional[int], y: Optional[int]) -> str:
    """X/Y rule.  Only CONFIRMED can ever lead to a ban (and only after the evidence checks)."""
    if valid_id(x) and valid_id(y):
        return CONFIRMED if x == y else MISMATCH
    if valid_id(x):
        return Y_MISSING
    if valid_id(y):
        return X_MISSING
    return V_UNKNOWN


def lockdown_wanted(verdict: str, score: int, threshold: int) -> bool:
    """Lockdown only when the inviter cannot be identified (Y unknown) AND the incident is big enough."""
    return verdict in (V_UNKNOWN, Y_MISSING) and score >= max(1, threshold)


def strip_value(perms: int) -> int:
    """Remove exactly Administrator / Manage Server / Manage Roles; every other bit is preserved."""
    return perms & ~DANGER_MASK


def evidence_check(ev: dict) -> list:
    """-> list of FAILED evidence checks (empty list = evidence supports punishment)."""
    failed = []
    if not ev.get("role_was_dangerous"):
        failed.append("role_not_dangerous")
    if not ev.get("x_alive"):
        failed.append("candidate_x_expired")
    if not ev.get("same_inviter"):
        failed.append("x_not_equal_y")
    if ev.get("attribution") != NORMAL:
        failed.append("attribution_not_normal_invite")
    if ev.get("inviter_trusted"):
        failed.append("inviter_trusted")
    if ev.get("receiver_trusted"):
        failed.append("receiver_trusted")
    return failed


def _scrub(text: str) -> str:
    secret = os.getenv("TOKEN") or ""
    if len(secret) >= 20:
        text = text.replace(secret, "[redacted]")
    return text


def _spawn(coro):
    """Run up to the first await immediately (Python 3.12 eager start); plain task on 3.11."""
    loop = asyncio.get_running_loop()
    try:
        return asyncio.Task(coro, loop=loop, eager_start=True)
    except TypeError:
        return loop.create_task(coro)


# --------------------------------------------------------------------------- X candidate store
@dataclass(slots=True)
class Candidate:
    guild_id: int
    role_id: int
    x: Optional[int]
    original: int
    ts: float


class CandidateStore:
    """Candidate X per flagged role, bounded and expiring after X_TTL (default one hour)."""

    def __init__(self, clock=time.time, ttl: float = X_TTL, cap: int = 5000):
        self._d: dict = {}
        self._clock, self.ttl, self.cap = clock, ttl, cap

    def put(self, guild_id, role_id, x, original) -> Candidate:
        self.purge()
        if len(self._d) >= self.cap:                               # drop the oldest, never grow unbounded
            oldest = min(self._d, key=lambda k: self._d[k].ts)
            self._d.pop(oldest, None)
        c = self._d[(guild_id, role_id)] = Candidate(guild_id, role_id, x, original, self._clock())
        return c

    def get(self, guild_id, role_id) -> Optional[Candidate]:
        c = self._d.get((guild_id, role_id))
        if c is None:
            return None
        if self._clock() - c.ts > self.ttl:
            self._d.pop((guild_id, role_id), None)
            return None
        return c

    def purge(self) -> int:
        now = self._clock()
        dead = [k for k, c in self._d.items() if now - c.ts > self.ttl]
        for k in dead:
            del self._d[k]
        return len(dead)

    def __len__(self) -> int:
        return len(self._d)


# --------------------------------------------------------------------------- persistence
class Ledger:
    """SQLite behind ONE worker thread: strictly ordered, never blocks the event loop, no 'database is locked'."""

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS li_events (id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, guild_id INTEGER,
        kind TEXT, role_id INTEGER, member_id INTEGER, x_id INTEGER, y_id INTEGER, verdict TEXT, detail TEXT);
    CREATE INDEX IF NOT EXISTS li_events_g ON li_events (guild_id, id);
    CREATE TABLE IF NOT EXISTS li_roles (guild_id INTEGER, role_id INTEGER, creator_id INTEGER,
        original_perms INTEGER, stripped_perms INTEGER, ts REAL, status TEXT, PRIMARY KEY (guild_id, role_id));
    CREATE TABLE IF NOT EXISTS li_candidates (guild_id INTEGER, role_id INTEGER, x_id INTEGER,
        original_perms INTEGER, ts REAL, PRIMARY KEY (guild_id, role_id));
    CREATE TABLE IF NOT EXISTS li_invites (guild_id INTEGER, code TEXT, uses INTEGER, inviter_id INTEGER,
        max_uses INTEGER, ts REAL, PRIMARY KEY (guild_id, code));
    CREATE TABLE IF NOT EXISTS li_joins (guild_id INTEGER, member_id INTEGER, ts REAL, code TEXT,
        inviter_id INTEGER, kind TEXT, PRIMARY KEY (guild_id, member_id));
    CREATE TABLE IF NOT EXISTS li_lockdown (guild_id INTEGER PRIMARY KEY, state TEXT, reason TEXT,
        ts REAL, lockdown_id TEXT);
    CREATE TABLE IF NOT EXISTS li_snapshots (guild_id INTEGER, role_id INTEGER, original INTEGER,
        applied INTEGER, stripped INTEGER, ts REAL, lockdown_id TEXT, PRIMARY KEY (guild_id, role_id));
    CREATE TABLE IF NOT EXISTS li_config (guild_id INTEGER PRIMARY KEY, threshold INTEGER, window REAL);
    """

    def __init__(self, path: str = DB_PATH):
        self.path = path
        self._ex = ThreadPoolExecutor(max_workers=1, thread_name_prefix="li-db")
        self._conn: Optional[sqlite3.Connection] = None

    # -- plumbing
    def _open(self) -> None:
        d = os.path.dirname(self.path)
        if d:
            os.makedirs(d, exist_ok=True)
        c = sqlite3.connect(self.path, check_same_thread=False, timeout=30)
        for p in ("journal_mode=WAL", "synchronous=NORMAL", "temp_store=MEMORY"):
            try:
                c.execute(f"PRAGMA {p}")
            except sqlite3.Error:
                pass
        c.executescript(self.SCHEMA)
        c.commit()
        self._conn = c

    async def open(self) -> None:
        await asyncio.get_running_loop().run_in_executor(self._ex, self._open)

    def submit(self, fn, *args):
        """Fire-and-forget (ordered).  Errors are logged, never raised into a gateway handler."""
        fut = self._ex.submit(fn, *args)

        def done(f):
            exc = f.exception()
            if exc is not None:
                log.warning("linkinvite ledger write %s failed: %s", getattr(fn, "__name__", fn), type(exc).__name__)
        fut.add_done_callback(done)
        return fut

    async def run(self, fn, *args, timeout: Optional[float] = None):
        fut = asyncio.wrap_future(self._ex.submit(fn, *args))
        return await (asyncio.wait_for(fut, timeout) if timeout else fut)

    async def close(self) -> None:
        def _close():
            if self._conn is not None:
                self._conn.commit()
                self._conn.close()
                self._conn = None
        await asyncio.get_running_loop().run_in_executor(self._ex, _close)
        self._ex.shutdown(wait=True)

    # -- writes (run on the worker thread)
    def w_event(self, ts, gid, kind, role_id, member_id, x, y, verdict, detail):
        with self._conn:
            self._conn.execute(
                "INSERT INTO li_events (ts,guild_id,kind,role_id,member_id,x_id,y_id,verdict,detail) "
                "VALUES (?,?,?,?,?,?,?,?,?)", (ts, gid, kind, role_id, member_id, x, y, verdict, detail))

    def w_role(self, gid, rid, creator, original, stripped, ts, status):
        with self._conn:           # INSERT OR IGNORE: the FIRST original bitfield is never overwritten
            self._conn.execute("INSERT OR IGNORE INTO li_roles VALUES (?,?,?,?,?,?,?)",
                               (gid, rid, creator, original, stripped, ts, status))
            self._conn.execute("UPDATE li_roles SET status=?, creator_id=COALESCE(?,creator_id) "
                               "WHERE guild_id=? AND role_id=?", (status, creator, gid, rid))

    def w_candidate(self, gid, rid, x, original, ts):
        with self._conn:
            self._conn.execute("INSERT OR REPLACE INTO li_candidates VALUES (?,?,?,?,?)", (gid, rid, x, original, ts))

    def w_invites(self, gid, rows, drop_codes=()):
        with self._conn:
            self._conn.executemany("INSERT OR REPLACE INTO li_invites VALUES (?,?,?,?,?,?)",
                                   [(gid, c, u, i, m, time.time()) for c, u, i, m in rows])
            self._conn.executemany("DELETE FROM li_invites WHERE guild_id=? AND code=?", [(gid, c) for c in drop_codes])

    def w_join(self, gid, mid, ts, code, inviter, kind):
        with self._conn:
            self._conn.execute("INSERT OR REPLACE INTO li_joins VALUES (?,?,?,?,?,?)", (gid, mid, ts, code, inviter, kind))

    def w_lockdown(self, gid, state, reason, ts, lid):
        with self._conn:
            self._conn.execute("INSERT OR REPLACE INTO li_lockdown VALUES (?,?,?,?,?)", (gid, state, reason, ts, lid))

    def w_snapshots(self, gid, lid, rows, ts):
        """INSERT OR IGNORE on (guild, role): a second lockdown can never overwrite the first original bitfield."""
        with self._conn:
            self._conn.executemany("INSERT OR IGNORE INTO li_snapshots VALUES (?,?,?,?,?,?,?)",
                                   [(gid, rid, o, a, s, ts, lid) for rid, o, a, s in rows])

    def w_drop_snapshot(self, gid, rid):
        with self._conn:
            self._conn.execute("DELETE FROM li_snapshots WHERE guild_id=? AND role_id=?", (gid, rid))

    def w_config(self, gid, threshold, window):
        with self._conn:
            self._conn.execute("INSERT OR REPLACE INTO li_config VALUES (?,?,?)", (gid, threshold, window))

    def w_prune(self, now):
        with self._conn:
            self._conn.execute("DELETE FROM li_joins WHERE ts < ?", (now - JOIN_KEEP,))
            self._conn.execute("DELETE FROM li_events WHERE ts < ?", (now - EVENT_KEEP,))
            self._conn.execute("DELETE FROM li_candidates WHERE ts < ?", (now - X_TTL,))

    # -- reads
    def r_all(self, sql, args=()):
        return self._conn.execute(sql, args).fetchall()

    def r_one(self, sql, args=()):
        return self._conn.execute(sql, args).fetchone()


# --------------------------------------------------------------------------- invite model
@dataclass(slots=True)
class Inv:
    uses: int
    inviter: Optional[int]
    max_uses: int = 0


@dataclass(slots=True)
class Attribution:
    kind: str
    inviter: Optional[int] = None
    code: Optional[str] = None


def diff_invites(old: dict, fresh: dict, recent_deleted: dict) -> Attribution:
    """Pure invite-use differencing: old/fresh = {code: Inv}; recent_deleted = {code: Inv} (just deleted).
    Never fabricates an inviter: anything not provable is AMBIGUOUS / UNKNOWN."""
    bumped = [c for c, inv in fresh.items() if inv.uses > (old[c].uses if c in old else 0)]
    if len(bumped) == 1:
        inv = fresh[bumped[0]]
        delta = inv.uses - (old[bumped[0]].uses if bumped[0] in old else 0)
        if delta == 1:
            return Attribution(NORMAL if valid_id(inv.inviter) else UNKNOWN, inv.inviter if valid_id(inv.inviter) else None, bumped[0])
        return Attribution(AMBIGUOUS, None, bumped[0])         # several joins collapsed into one diff
    if len(bumped) > 1:
        return Attribution(AMBIGUOUS)
    # nothing went up: an invite may have just been consumed (max_uses reached) and deleted
    gone = [c for c in old if c not in fresh]
    cand = [c for c in gone if old[c].max_uses and old[c].uses + 1 >= old[c].max_uses]
    cand += [c for c in recent_deleted if c not in cand and recent_deleted[c].max_uses
             and recent_deleted[c].uses + 1 >= recent_deleted[c].max_uses]
    if len(cand) == 1:
        inv = old.get(cand[0]) or recent_deleted[cand[0]]
        return Attribution(NORMAL if valid_id(inv.inviter) else UNKNOWN, inv.inviter if valid_id(inv.inviter) else None, cand[0])
    if len(cand) > 1:
        return Attribution(AMBIGUOUS)
    return Attribution(UNKNOWN)


# --------------------------------------------------------------------------- the cog
class LinkInvite(commands.Cog):
    def __init__(self, bot, db_path: str = DB_PATH, clock=time.time):
        self.bot = bot
        self._now = clock
        self.ledger = Ledger(db_path)
        self.cand = CandidateStore(clock=clock)
        self.invites: dict = {}                    # guild -> {code: Inv}
        self._primed: set = set()
        self._noperm: set = set()                  # guilds where invites cannot be read
        self._deleted: dict = {}                   # guild -> {code: (Inv, ts)}
        self._vanity_uses: dict = {}
        self._jlock: dict = {}
        self._joins: dict = {}                     # (guild, member) -> Attribution(+ts)  bounded LRU
        self._monitored: dict = {}                 # (guild, role) -> original perms, ts, creator
        self._seen_roles: dict = {}
        self._seen_rcpt: dict = {}
        self._events: dict = {}                    # guild -> deque[(ts, kind, id)] incident score window
        self._hint: dict = {}                      # (guild, role) -> executor id (gateway audit entry)
        self._hint_wait: dict = {}
        self._glock: dict = {}                     # per-guild lock for lockdown / restore
        self._state: dict = {}                     # guild -> idle|applying|locked|restoring
        self._snap: dict = {}                      # guild -> {role_id: (original, applied, stripped)}
        self._cfg: dict = {}                       # guild -> (threshold, window)
        self._sem = asyncio.Semaphore(EDIT_CONCURRENCY)
        self._bg: set = set()
        self._tasks: list = []
        self.bench: deque = deque(maxlen=500)
        self.stats = {"strips": 0, "strip_fail": 0, "lockdowns": 0, "bans": 0, "alerts": 0}

    # ------------------------------------------------------------------ lifecycle
    async def cog_load(self) -> None:
        await self.ledger.open()
        await self._load_state()
        self._tasks.append(asyncio.create_task(self._startup()))
        self._tasks.append(asyncio.create_task(self._maintenance()))

    async def cog_unload(self) -> None:
        for t in self._tasks:
            t.cancel()
        for t in list(self._bg):
            t.cancel()
        await asyncio.gather(*self._tasks, *self._bg, return_exceptions=True)
        try:
            await self.ledger.close()                  # flushes every queued forensic write
        except Exception:
            log.exception("linkinvite: ledger close failed")

    async def _load_state(self) -> None:
        now = self._now()
        for gid, rid, creator, orig, ts in await self.ledger.run(
                self.ledger.r_all, "SELECT guild_id, role_id, creator_id, original_perms, ts FROM li_roles WHERE ts > ?",
                (now - MONITOR_TTL,)):
            self._monitored[(gid, rid)] = (orig, ts, creator)
        for gid, rid, x, orig, ts in await self.ledger.run(
                self.ledger.r_all, "SELECT guild_id, role_id, x_id, original_perms, ts FROM li_candidates WHERE ts > ?",
                (now - X_TTL,)):
            self.cand._d[(gid, rid)] = Candidate(gid, rid, x, orig, ts)
        for gid, state in await self.ledger.run(self.ledger.r_all, "SELECT guild_id, state FROM li_lockdown"):
            self._state[gid] = state
        for gid, rid, o, a, s in await self.ledger.run(
                self.ledger.r_all, "SELECT guild_id, role_id, original, applied, stripped FROM li_snapshots"):
            self._snap.setdefault(gid, {})[rid] = (o, a, s)
        for gid, th, win in await self.ledger.run(self.ledger.r_all, "SELECT guild_id, threshold, window FROM li_config"):
            self._cfg[gid] = (th, win)

    async def _startup(self) -> None:
        try:
            await self.bot.wait_until_ready()
            for guild in list(self.bot.guilds):             # resume interrupted lockdown / recovery first
                st = self._state.get(guild.id)
                if st in ("applying", "restoring"):
                    await self._resume(guild, st)
            for guild in list(self.bot.guilds):
                if self._tracked(guild):
                    await self._prime(guild)
                    await asyncio.sleep(0.4)                # gentle: never a burst of invite fetches
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("linkinvite startup failed")

    async def _maintenance(self) -> None:
        try:
            while True:
                await asyncio.sleep(60)
                now = self._now()
                self.cand.purge()
                for k in [k for k, v in self._monitored.items() if now - v[1] > MONITOR_TTL]:
                    del self._monitored[k]
                for d in (self._seen_roles, self._seen_rcpt, self._hint):
                    for k in [k for k, v in d.items() if now - (v if isinstance(v, float) else v[1]) > RECEIPT_TTL * 2]:
                        del d[k]
                for gid, d in self._deleted.items():
                    for c in [c for c, (_, ts) in d.items() if now - ts > 10]:
                        del d[c]
                if len(self._joins) > 20000:
                    for k in list(self._joins)[:5000]:
                        del self._joins[k]
                self.ledger.submit(self.ledger.w_prune, now)
                for guild in list(self.bot.guilds):         # lazily prime guilds that became tracked later
                    if self._tracked(guild) and guild.id not in self._primed and guild.id not in self._noperm:
                        await self._prime(guild)
                        await asyncio.sleep(0.4)
        except asyncio.CancelledError:
            raise

    # ------------------------------------------------------------------ small helpers
    def _cfg_of(self, guild):
        cfg = store.peek(guild.id)
        return cfg if cfg is not None and cfg.enabled else None

    def _tracked(self, guild) -> bool:
        cfg = self._cfg_of(guild)
        return cfg is not None and bool(cfg.mods & BIT["linkrole"])

    def _threshold(self, gid: int):
        return self._cfg.get(gid, (DEFAULT_THRESHOLD, DEFAULT_WINDOW))

    def _spawn_bg(self, coro):
        t = _spawn(coro)
        self._bg.add(t)
        t.add_done_callback(self._bg.discard)
        return t

    def _emit(self, kind: str, guild_id: int, role_id=None, member_id=None, x=None, y=None, verdict=None, **detail):
        """Structured forensic log line + async DB row.  Never on the critical path, never contains secrets."""
        ts = self._now()
        detail = {k: v for k, v in detail.items() if k.lower() not in ("token", "authorization", "secret")}
        text = _scrub(json.dumps(detail, sort_keys=True, default=str))
        log.info("li_event %s", _scrub(json.dumps(
            {"kind": kind, "guild": guild_id, "role": role_id, "member": member_id, "x": x, "y": y,
             "verdict": verdict, "detail": detail}, sort_keys=True, default=str)))
        if self.ledger._conn is not None:
            self.ledger.submit(self.ledger.w_event, ts, guild_id, kind, role_id, member_id, x, y, verdict, text)

    def _trusted(self, guild, cfg, uid: int, member=None) -> bool:
        """Existing exemptions only: server owner, this bot, linked-role whitelist, trusted (main) roles,
        whitelisted bots.  No new exemption concept is invented."""
        if not valid_id(uid) or uid == guild.owner_id or uid == self.bot.user.id:
            return True
        mask = cfg.wl.get(uid, 0)
        if mask & BIT["linkrole"] or (mask and mask == store.ALL_MASK):
            return True
        member = member or guild.get_member(uid)
        if member is not None:
            if cfg.mainroles and any(r.id in cfg.mainroles for r in member.roles):
                return True
            if getattr(member, "bot", False) and uid in cfg.wl:
                return True
        return False

    # ================================================================== 1. LINKED ROLE CREATION
    def linked_role_created(self, role) -> None:
        """Engine hook (sync).  Starts stripping in the SAME loop iteration; nothing awaited before the PATCH."""
        guild = getattr(role, "guild", None)
        if guild is None or not valid_id(getattr(role, "id", None)) or not self._tracked(guild):
            return
        key = (guild.id, role.id)
        if key in self._seen_roles:                          # idempotency: duplicate gateway dispatch
            return
        self._seen_roles[key] = self._now()
        self._spawn_bg(self._handle_linked_role(guild, role, time.perf_counter()))

    async def _handle_linked_role(self, guild, role, t0: float) -> None:
        original = int(role.permissions.value)
        bits = original & DANGER_MASK
        gid, rid, now = guild.id, role.id, self._now()
        if not bits:                                         # nothing dangerous: do not touch, do not monitor
            self._emit("linked_role_clean", gid, rid, original=original)
            return
        new = strip_value(original)
        self._monitored[(gid, rid)] = (original, now, None)  # RAM first: receipts are checked against this
        self._events.setdefault(gid, deque(maxlen=200)).append((now, "role", rid))
        # ---- critical path: strip first; DB write is queued concurrently and is never awaited here
        if self.ledger._conn is not None:
            self.ledger.submit(self.ledger.w_role, gid, rid, None, original, bits, now, "flagged")
        ok, err = await self._edit_perms(guild, role, new, "Antinuke | Linked role: dangerous permissions removed", t0, "strip")
        self.stats["strips" if ok else "strip_fail"] += 1
        self._emit("linked_role_stripped" if ok else "linked_role_strip_failed", gid, rid,
                   original=original, stripped_bits=bits, error=err,
                   latency_ms=round((time.perf_counter() - t0) * 1000, 1))
        # ---- non-critical: who created it (X)
        x = await self._resolve_x(guild, rid)
        self.cand.put(gid, rid, x, original)
        self._monitored[(gid, rid)] = (original, now, x)
        if self.ledger._conn is not None:
            self.ledger.submit(self.ledger.w_candidate, gid, rid, x, original, now)
            self.ledger.submit(self.ledger.w_role, gid, rid, x, original, bits, now, "stripped" if ok else "strip_failed")
        self._emit("candidate_x", gid, rid, x=x, original=original)

    def note_role_audit(self, entry) -> None:
        """Engine hook (sync): the gateway already tells us who created/edited a role - no REST needed."""
        try:
            target = getattr(entry, "target", None)
            rid, uid, gid = getattr(target, "id", None), getattr(entry, "user_id", None), entry.guild.id
        except Exception:
            return
        if not (valid_id(rid) and valid_id(uid)):
            return
        key = (gid, rid)
        self._hint[key] = (uid, self._now())
        fut = self._hint_wait.pop(key, None)
        if fut is not None and not fut.done():
            fut.set_result(uid)

    async def _resolve_x(self, guild, rid: int) -> Optional[int]:
        hit = self._hint.get((guild.id, rid))
        if hit:
            return self._clean_x(hit[0])
        fut = asyncio.get_running_loop().create_future()
        self._hint_wait[(guild.id, rid)] = fut
        try:
            return self._clean_x(await asyncio.wait_for(fut, X_WAIT))
        except asyncio.TimeoutError:
            pass
        finally:
            self._hint_wait.pop((guild.id, rid), None)
        for _ in range(2):                                  # fallback: audit-log REST, twice at most
            for action in (AL.role_create, AL.role_update):
                try:
                    async for entry in guild.audit_logs(limit=6, action=action):
                        if entry.target is not None and entry.target.id == rid:
                            return self._clean_x(entry.user_id)
                except (discord.Forbidden, discord.HTTPException):
                    self._emit("audit_unavailable", guild.id, rid)
                    return None
            await asyncio.sleep(0.4)
        return None

    def _clean_x(self, uid) -> Optional[int]:
        return uid if valid_id(uid) and uid != self.bot.user.id else None

    async def _edit_perms(self, guild, role, value: int, reason: str, t0: float, what: str):
        """-> (ok, error).  Hierarchy-checked, retries only transient errors, records event->request latency."""
        try:
            if role >= guild.me.top_role and not role.is_default():
                return False, "hierarchy"
        except Exception:
            pass
        last = ""
        for attempt in range(4):
            try:
                sent = time.perf_counter()
                try:
                    await self.bot.http.edit_role(guild.id, role.id, reason=reason, permissions=str(value))
                except TypeError:                            # discord.py signature differs: use the object API
                    await role.edit(permissions=discord.Permissions(value), reason=reason)
                done = time.perf_counter()
                self.bench.append({"what": what, "to_request_ms": (sent - t0) * 1000, "to_done_ms": (done - t0) * 1000})
                return True, ""
            except discord.NotFound:
                return True, "gone"
            except discord.Forbidden:
                return False, "forbidden"                     # missing permission / hierarchy: retry is useless
            except discord.HTTPException as exc:
                last = f"http_{exc.status}"
                if exc.status == 429:
                    await asyncio.sleep(min(float(getattr(exc, "retry_after", 1.0) or 1.0), 5.0))
                elif exc.status >= 500:
                    await asyncio.sleep(0.15 * (attempt + 1))
                else:
                    return False, last
            except Exception as exc:                         # noqa: BLE001
                log.exception("linkinvite edit failed")
                return False, type(exc).__name__
        return False, last

    # ================================================================== 2. MEMBER MONITORING
    def member_roles_changed(self, before, after) -> None:
        """Engine hook (sync): only a set-difference and dict lookups unless a monitored role was gained."""
        guild = getattr(after, "guild", None)
        if guild is None or not self._monitored:
            return
        old = {r.id for r in before.roles}
        for role in after.roles:
            if role.id in old:
                continue
            key = (guild.id, role.id)
            if key not in self._monitored:
                continue
            rk = (guild.id, after.id, role.id)
            now = self._now()
            if now - self._seen_rcpt.get(rk, -1e9) < RECEIPT_TTL:
                continue
            self._seen_rcpt[rk] = now
            self._spawn_bg(self._on_receipt(guild, after, role, time.perf_counter()))

    async def _on_receipt(self, guild, member, role, t0: float) -> None:
        gid, rid, mid = guild.id, role.id, member.id
        cfg = self._cfg_of(guild)
        if cfg is None or not valid_id(mid) or role.guild.id != gid:
            return
        orig, mts, _ = self._monitored.get((gid, rid), (0, 0, None))
        self._emit("receipt", gid, rid, mid, original=orig)
        # strip again if the role regained dangerous bits (someone re-edited it) - same critical path
        if int(role.permissions.value) & DANGER_MASK:
            self._spawn_bg(self._edit_perms(guild, role, strip_value(int(role.permissions.value)),
                                    "Antinuke | Linked role regained dangerous permissions", t0, "restrip"))
        if self._trusted(guild, cfg, mid, member):
            self._emit("receipt_trusted", gid, rid, mid)
            return
        now = self._now()
        self._events.setdefault(gid, deque(maxlen=200)).append((now, "receipt", mid))
        att = await self._attribution_for(gid, mid)
        c = self.cand.get(gid, rid)
        x = c.x if c else None
        y = att.inviter if att.kind == NORMAL else None
        verdict = cross_verify(x, y)
        score = self._score(gid)
        threshold, _ = self._threshold(gid)
        ev = {"role_was_dangerous": bool(orig & DANGER_MASK), "x_alive": c is not None, "same_inviter": verdict == CONFIRMED,
              "attribution": att.kind, "inviter_trusted": bool(y) and self._trusted(guild, cfg, y),
              "receiver_trusted": False}
        self._emit("cross_verify", gid, rid, mid, x, y, verdict, attribution=att.kind, code=att.code, score=score,
                   threshold=threshold, evidence=ev)

        # ---- V45_DECISION: X/Y + Administrator verification
        x_admin = self._x_is_admin(guild, x)
        ev["x_admin"] = x_admin
        self._emit("v45_decision", gid, rid, mid, x, y, verdict, x_admin=x_admin, attribution=att.kind, evidence=ev)
        if verdict == CONFIRMED and x_admin:
            failed = evidence_check(ev)
            if not failed:
                targets = [u for u in dict.fromkeys((x, y)) if valid_id(u)]
                await asyncio.gather(*(self._ban_inviter(guild, u, rid, mid, ev) for u in targets))
                await self._delete_linked_role(guild, role)
                await self._alert(guild, cfg, "Linked role: X/Y confirmed + Administrator", rid, mid, x, y, verdict,
                                  "X has Administrator and invite attribution confirms X. X and Y banned, Linked Role deleted.")
            else:
                self._spawn_bg(self.lockdown(guild, f"linked role {rid}: evidence failed {failed}"))
                await self._delete_linked_role(guild, role)
                await self._alert(guild, cfg, "Linked role: lockdown, no ban", rid, mid, x, y, verdict,
                                  "Evidence checks failed: " + ", ".join(failed) + ". Emergency lockdown + role deleted.")
        elif verdict == X_MISSING and att.kind == NORMAL:  # V45_XMISSING
            im = guild.get_member(y) if valid_id(y) else None
            ip = im.guild_permissions if im else None
            failed = [] if ip and (ip.administrator or ip.manage_roles) else ["inviter_no_admin_or_manage_roles"]
            rm = guild.get_member(mid)
            if rm and not any(r.id == rid for r in rm.roles): failed.append("receiver_lacks_linked_role")
            if ev.get("inviter_trusted"): failed.append("inviter_trusted")
            if not failed:
                for u in dict.fromkeys((y, mid)):
                    if valid_id(u): self._spawn_bg(self._ban_inviter(guild, u, rid, mid, ev))
                await self._delete_linked_role(guild, role)
                await self._alert(guild, cfg, "Linked role: inviter + receiver banned", rid, mid, x, y, verdict, "Inviter and receiver banned, Linked Role deleted.")
            else:
                self._spawn_bg(self.lockdown(guild, f"linked role {rid}: not banned"))
                await self._delete_linked_role(guild, role)
                await self._alert(guild, cfg, "Linked role: NOT banned", rid, mid, x, y, verdict, "Failed: " + ", ".join(failed))
        elif verdict == MISMATCH:
            self._spawn_bg(self.lockdown(guild, f"linked role {rid} received by {mid}: X/Y mismatch"))
            await self._delete_linked_role(guild, role)
            await self._alert(guild, cfg, "Linked role: X/Y mismatch, lockdown", rid, mid, x, y, verdict,
                              "Role creator and inviter are different people. Emergency lockdown + Linked Role deleted. No automatic ban; investigate.")
        else:
            if verdict == CONFIRMED:
                why = "X does not have Administrator"
            elif att.kind in (UNAVAILABLE, UNKNOWN, AMBIGUOUS):
                why = f"Invite tracking unavailable/unknown (attribution {att.kind})"
            else:
                why = "Attribution incomplete (only one of X/Y known)"
            self._spawn_bg(self.lockdown(guild, f"linked role {rid} received by {mid}: {why}"))
            await self._delete_linked_role(guild, role)
            await self._alert(guild, cfg, "Linked role: emergency lockdown", rid, mid, x, y, verdict,
                              f"{why}. Emergency lockdown + Linked Role deleted. No automatic ban.")

    def _x_is_admin(self, guild, x) -> bool:
        if not valid_id(x):
            return False
        m = guild.get_member(x)
        if m is None:
            return False
        try:
            return bool(m.guild_permissions.administrator)
        except Exception:
            return any(r.permissions.administrator for r in m.roles)

    async def _delete_linked_role(self, guild, role) -> bool:
        try:
            await role.delete(reason="Antinuke | Linked role removed")
            return True
        except discord.NotFound:
            return True
        except (discord.Forbidden, discord.HTTPException) as exc:
            log.warning("linkinvite delete err: %r status=%s code=%s", exc, getattr(exc,"status",None), getattr(exc,"code",None))
            log.warning("linkinvite: could not delete linked role %s in guild %s", role.id, guild.id)
            return False

    def _score(self, gid: int) -> int:
        _, window = self._threshold(gid)
        dq = self._events.get(gid)
        if not dq:
            return 0
        now = self._now()
        while dq and now - dq[0][0] > window:
            dq.popleft()
        return len({(k, i) for _, k, i in dq})                 # distinct flagged roles + distinct receivers

    async def _attribution_for(self, gid: int, mid: int) -> Attribution:
        hit = self._joins.get((gid, mid))
        if hit:
            return hit
        row = None
        if self.ledger._conn is not None:
            row = await self.ledger.run(self.ledger.r_one, "SELECT code, inviter_id, kind FROM li_joins "
                                        "WHERE guild_id=? AND member_id=?", (gid, mid))
        if row:
            return Attribution(row[2], row[1], row[0])
        return Attribution(UNKNOWN)                            # joined before tracking: honest UNKNOWN

    async def _ban_inviter(self, guild, uid: int, rid: int, receiver: int, ev: dict) -> None:
        cfg = self._cfg_of(guild)
        if cfg is None or not valid_id(uid) or self._trusted(guild, cfg, uid):
            return
        member = guild.get_member(uid)
        try:
            if member is not None and member.top_role >= guild.me.top_role:
                self._emit("ban_skipped_hierarchy", guild.id, rid, receiver, uid, uid, CONFIRMED)
                return
        except Exception:
            pass
        reason = f"Antinuke | Linked role {rid}: X=Y confirmed inviter of {receiver}"
        ok, err = False, ""
        for attempt in range(3):
            try:
                eng = self.bot.get_cog("AntinukeEngine")
                res = None
                if eng is not None and hasattr(eng, "_direct_ban"):
                    eng.flagged[(guild.id, uid)] = time.monotonic()    # engine will not double-punish
                    res = await eng._direct_ban(guild.id, uid, reason)
                if res:
                    ok = True
                else:
                    await self.bot.http.ban(uid, guild.id, 0, reason=reason)
                    ok = True
                break
            except discord.Forbidden:
                err = "forbidden"
                break
            except discord.HTTPException as exc:
                err = f"http_{exc.status}"
                if exc.status < 500 and exc.status != 429:
                    break
                await asyncio.sleep(0.2 * (attempt + 1))
        if ok:
            self.stats["bans"] += 1
        self._emit("ban" if ok else "ban_failed", guild.id, rid, receiver, uid, uid, CONFIRMED,
                   reason=reason, executor=getattr(self.bot.user, "id", None), evidence=ev, error=err)

    async def _alert(self, guild, cfg, title, rid, mid, x, y, verdict, text) -> None:
        self.stats["alerts"] += 1
        channel = guild.get_channel(cfg.log) if cfg.log else None
        if channel is None:
            return
        fmt = lambda v: f"<@{v}>" if v else "`unknown`"               # noqa: E731
        body = (f"### {title}\n> {text}\n"
                f"**Role:** `{rid}`  **Receiver:** {fmt(mid)}\n"
                f"**X (role creator):** {fmt(x)}  **Y (inviter):** {fmt(y)}\n**Verdict:** `{verdict}`\n-# <t:{int(self._now())}:T>")
        try:
            try:
                from utils import antinuke_ui as ui
                await channel.send(view=ui.view_of(ui.with_thumb(body, None)), allowed_mentions=ui.NO_PING)
            except ImportError:
                await channel.send(content=body, allowed_mentions=discord.AllowedMentions.none())
        except (discord.Forbidden, discord.HTTPException):
            pass

    # ================================================================== 5/7. LOCKDOWN + RECOVERY
    def eligible_roles(self, guild, cfg) -> list:
        """Roles below the bot's top role, not trusted, holding at least one dangerous bit."""
        me = guild.me
        top = me.top_role
        own = {r.id for r in me.roles if not r.is_default()}      # me.roles contains @everyone: it must stay eligible
        trusted = set(cfg.mainroles) | ({cfg.barrier} if cfg.barrier else set())
        out = []
        for role in guild.roles:
            if role.id in own or role.id in trusted:
                continue
            if role >= top:
                continue
            if not int(role.permissions.value) & DANGER_MASK:
                continue
            if getattr(role, "is_integration", lambda: False)() or getattr(role, "is_premium_subscriber", lambda: False)():
                continue
            bot_id = getattr(getattr(role, "tags", None), "bot_id", None)
            if bot_id and (bot_id == me.id or bot_id in cfg.wl):          # trusted bot role
                continue
            out.append(role)
        return out

    def _glock_of(self, gid):
        return self._glock.setdefault(gid, asyncio.Lock())

    async def lockdown(self, guild, reason: str, t0: Optional[float] = None) -> str:
        """Selective lockdown.  Idempotent per guild; never touches anything but the three dangerous bits."""
        gid = guild.id
        cfg = self._cfg_of(guild)
        if cfg is None:
            return "disabled"
        if self._state.get(gid) in ("applying", "locked", "restoring"):    # claim is synchronous: no race
            return "duplicate"
        self._state[gid] = "applying"
        t0 = t0 or time.perf_counter()
        async with self._glock_of(gid):
            roles = self.eligible_roles(guild, cfg)
            lid = f"{gid}-{int(self._now())}"
            snap = self._snap.setdefault(gid, {})
            rows = []
            for r in roles:
                o = int(r.permissions.value)
                if r.id not in snap:                                         # never overwrite an existing original
                    snap[r.id] = (o, strip_value(o), o & DANGER_MASK)
                    rows.append((r.id, o, strip_value(o), o & DANGER_MASK))
            now = self._now()
            if self.ledger._conn is not None:
                try:   # durable snapshot BEFORE the first PATCH (one small transaction), bounded wait
                    await self.ledger.run(self.ledger.w_lockdown, gid, "applying", reason, now, lid, timeout=0.5)
                    await self.ledger.run(self.ledger.w_snapshots, gid, lid, rows, now, timeout=0.5)
                except Exception:
                    log.warning("linkinvite: snapshot persist slow/failed; applying lockdown from RAM snapshot")
            results = await asyncio.gather(*(self._lock_one(guild, r, snap[r.id], t0) for r in roles))
            failed = [(r.id, e) for r, (ok, e) in zip(roles, results) if not ok]
            self._state[gid] = "locked"
            self.stats["lockdowns"] += 1
            if self.ledger._conn is not None:
                self.ledger.submit(self.ledger.w_lockdown, gid, "locked", reason, now, lid)
            self._emit("lockdown", gid, detail_reason=reason, roles=[r.id for r in roles], failed=failed,
                       latency_ms=round((time.perf_counter() - t0) * 1000, 1))
        return "locked"

    async def _lock_one(self, guild, role, snap, t0):
        async with self._sem:
            return await self._edit_perms(guild, role, snap[1], "Antinuke | Selective lockdown", t0, "lockdown")

    async def unlock(self, guild, force: bool = False, actor: Optional[int] = None) -> dict:
        """Safe restore.  Unchanged roles get their ORIGINAL bitfield back; roles someone edited after the
        lockdown are not overwritten (reported) unless force=True, which re-adds only the stripped bits."""
        gid = guild.id
        if self._state.get(gid) not in ("locked", "restoring", "applying"):
            return {"status": "not_locked"}
        self._state[gid] = "restoring"
        out = {"status": "ok", "restored": [], "skipped_changed": [], "gone": [], "failed": []}
        async with self._glock_of(gid):
            if self.ledger._conn is not None:
                self.ledger.submit(self.ledger.w_lockdown, gid, "restoring", f"unlock by {actor}", self._now(), "")
            snap = self._snap.get(gid, {})
            for rid, (o, a, s) in list(snap.items()):
                role = guild.get_role(rid)
                if role is None:
                    out["gone"].append(rid)
                    self._drop(gid, rid)
                    continue
                cur = int(role.permissions.value)
                if cur == a:
                    target = o
                elif force:
                    target = cur | s
                else:
                    out["skipped_changed"].append({"role": rid, "original": o, "current": cur})
                    self._emit("recovery_skipped_changed", gid, rid, original=o, applied=a, current=cur)
                    self._drop(gid, rid)
                    continue
                ok, err = await self._edit_perms(guild, role, target, f"Antinuke | Lockdown restore by {actor}",
                                                 time.perf_counter(), "restore")
                if ok:
                    out["restored"].append(rid)
                    self._emit("recovery_restored", gid, rid, original=o, restored_to=target, forced=force, actor=actor)
                    self._drop(gid, rid)
                else:
                    out["failed"].append({"role": rid, "error": err})       # row stays: a rerun / restart resumes
                    self._emit("recovery_failed", gid, rid, error=err, actor=actor)
            if out["failed"]:
                self._state[gid] = "locked"
                out["status"] = "partial"
            else:
                self._state[gid] = "idle"
            if self.ledger._conn is not None:
                self.ledger.submit(self.ledger.w_lockdown, gid, self._state[gid], f"unlock by {actor}", self._now(), "")
        return out

    def _drop(self, gid: int, rid: int) -> None:
        self._snap.get(gid, {}).pop(rid, None)
        if self.ledger._conn is not None:
            self.ledger.submit(self.ledger.w_drop_snapshot, gid, rid)

    async def _resume(self, guild, state: str) -> None:
        """Bot restarted in the middle of a lockdown / recovery: finish it, never start it twice."""
        gid = guild.id
        snap = self._snap.get(gid, {})
        self._emit("resume", gid, state=state, pending=len(snap))
        if state == "restoring":
            await self.unlock(guild, False, actor=0)
            return
        cfg = self._cfg_of(guild)
        self._state[gid] = "locked" if snap else "idle"
        if cfg is None or not snap:
            return
        for rid, (o, a, s) in snap.items():                     # finish stripping whatever is still dangerous
            role = guild.get_role(rid)
            if role is not None and int(role.permissions.value) & DANGER_MASK:
                await self._lock_one(guild, role, (o, a, s), time.perf_counter())
        if self.ledger._conn is not None:
            self.ledger.submit(self.ledger.w_lockdown, gid, "locked", "resumed after restart", self._now(), "")

    async def restore_role(self, guild, role_id: int, actor: Optional[int] = None):
        """Give a wrongly-flagged Linked Role its recorded original bitfield back (owner command)."""
        row = await self.ledger.run(self.ledger.r_one, "SELECT original_perms FROM li_roles WHERE guild_id=? AND role_id=?",
                                    (guild.id, role_id))
        role = guild.get_role(role_id)
        if not row or role is None:
            return False, "unknown_role"
        ok, err = await self._edit_perms(guild, role, int(row[0]), f"Antinuke | Linked role restored by {actor}",
                                         time.perf_counter(), "restore_role")
        self._emit("role_restored" if ok else "role_restore_failed", guild.id, role_id, original=row[0], actor=actor, error=err)
        if ok:
            self._monitored.pop((guild.id, role_id), None)
        return ok, err

    # ================================================================== 3. INVITE TRACKING
    async def _prime(self, guild) -> None:
        gid = guild.id
        try:
            fresh = await guild.invites()
        except (discord.Forbidden, discord.HTTPException):
            self._noperm.add(gid)                                # attribution UNAVAILABLE for this guild
            self._emit("invites_unavailable", gid)
            return
        new = {i.code: Inv(i.uses or 0, getattr(getattr(i, "inviter", None), "id", None), i.max_uses or 0) for i in fresh}
        self._noperm.discard(gid)
        if self.ledger._conn is not None:                        # gap detection: uses that grew while we were offline
            rows = await self.ledger.run(self.ledger.r_all, "SELECT code, uses FROM li_invites WHERE guild_id=?", (gid,))
            gap = sum(max(0, new[c].uses - u) for c, u in rows if c in new)
            if gap:
                self._emit("offline_gap", gid, joins_without_attribution=gap)
            self.ledger.submit(self.ledger.w_invites, gid, [(c, v.uses, v.inviter, v.max_uses) for c, v in new.items()],
                               [c for c, _ in rows if c not in new])
        self.invites[gid] = new
        self._primed.add(gid)
        if getattr(guild, "vanity_url_code", None):
            try:
                self._vanity_uses[gid] = (await guild.vanity_invite()).uses or 0
            except (discord.Forbidden, discord.HTTPException):
                pass

    @commands.Cog.listener()
    async def on_invite_create(self, invite):
        guild = getattr(invite, "guild", None)
        if guild is None or guild.id not in self._primed:
            return
        inv = Inv(invite.uses or 0, getattr(getattr(invite, "inviter", None), "id", None), invite.max_uses or 0)
        self.invites.setdefault(guild.id, {})[invite.code] = inv
        if self.ledger._conn is not None:
            self.ledger.submit(self.ledger.w_invites, guild.id, [(invite.code, inv.uses, inv.inviter, inv.max_uses)])
        self._emit("invite_create", guild.id, y=inv.inviter, code=invite.code)

    @commands.Cog.listener()
    async def on_invite_delete(self, invite):
        guild = getattr(invite, "guild", None)
        if guild is None or guild.id not in self._primed:
            return
        gone = self.invites.get(guild.id, {}).pop(invite.code, None)
        if gone is not None:                                      # may be the invite consumed by the join in flight
            self._deleted.setdefault(guild.id, {})[invite.code] = (gone, self._now())
        if self.ledger._conn is not None:
            self.ledger.submit(self.ledger.w_invites, guild.id, [], [invite.code])
        self._emit("invite_delete", guild.id, code=invite.code)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        guild = member.guild
        if not self._tracked(guild):
            return
        if getattr(member, "bot", False):
            return self._record_join(guild.id, member.id, Attribution(BOT))
        if guild.id in self._noperm or guild.id not in self._primed:
            if guild.id not in self._noperm:
                await self._prime(guild)
            if guild.id in self._noperm or guild.id not in self._primed:
                return self._record_join(guild.id, member.id, Attribution(UNAVAILABLE))
            return self._record_join(guild.id, member.id, Attribution(UNKNOWN))   # cache was just built: nothing to diff
        async with self._jlock.setdefault(guild.id, asyncio.Lock()):             # joins are attributed one at a time
            try:
                fresh_list = await guild.invites()
            except (discord.Forbidden, discord.HTTPException):
                self._noperm.add(guild.id)
                return self._record_join(guild.id, member.id, Attribution(UNAVAILABLE))
            fresh = {i.code: Inv(i.uses or 0, getattr(getattr(i, "inviter", None), "id", None), i.max_uses or 0)
                     for i in fresh_list}
            old = self.invites.get(guild.id, {})
            recent = {c: inv for c, (inv, ts) in self._deleted.get(guild.id, {}).items() if self._now() - ts < 10}
            att = diff_invites(old, fresh, recent)
            if att.kind == UNKNOWN and getattr(guild, "vanity_url_code", None):
                att = await self._vanity_check(guild, att)
            changed = [(c, v.uses, v.inviter, v.max_uses) for c, v in fresh.items()
                       if c not in old or old[c].uses != v.uses]
            self.invites[guild.id] = fresh
            if changed and self.ledger._conn is not None:
                self.ledger.submit(self.ledger.w_invites, guild.id, changed, [c for c in old if c not in fresh])
        self._record_join(guild.id, member.id, att)

    async def _vanity_check(self, guild, att: Attribution) -> Attribution:
        try:
            uses = (await guild.vanity_invite()).uses or 0
        except (discord.Forbidden, discord.HTTPException):
            return att
        prev = self._vanity_uses.get(guild.id)
        self._vanity_uses[guild.id] = uses
        if prev is not None and uses > prev:
            return Attribution(VANITY, None, getattr(guild, "vanity_url_code", None))   # inviter stays None: never fabricated
        return att

    def _record_join(self, gid: int, mid: int, att: Attribution) -> None:
        if not (valid_id(gid) and valid_id(mid)):
            return
        self._joins[(gid, mid)] = att
        if self.ledger._conn is not None:
            self.ledger.submit(self.ledger.w_join, gid, mid, self._now(), att.code, att.inviter, att.kind)
        self._emit("join", gid, member_id=mid, y=att.inviter, attribution=att.kind, code=att.code)

    # ================================================================== owner commands
    def _owner(self, ctx) -> bool:
        return ctx.guild is not None and ctx.author.id == ctx.guild.owner_id

    @commands.group(name="linkinvite", aliases=["lrp"], invoke_without_command=True,
                    help="Linked role protection status (server owner).")
    @commands.guild_only()
    async def linkinvite(self, ctx):
        if not self._owner(ctx):
            return await ctx.send("Only the **server owner** can use this.", allowed_mentions=discord.AllowedMentions.none())
        gid = ctx.guild.id
        th, win = self._threshold(gid)
        lat = sorted(b["to_request_ms"] for b in self.bench if b["what"] in ("strip", "lockdown"))
        p = lambda q: f"{lat[min(len(lat) - 1, int(len(lat) * q))]:.1f}ms" if lat else "n/a"   # noqa: E731
        await ctx.send(
            f"**Linked role protection**\nlockdown state: `{self._state.get(gid, 'idle')}`  pending snapshots: "
            f"`{len(self._snap.get(gid, {}))}`\nthreshold: `{th}` events / `{int(win)}s`\n"
            f"invite cache: `{'ready' if gid in self._primed else 'not ready'}`"
            f"{' (missing Manage Server)' if gid in self._noperm else ''}\n"
            f"strips `{self.stats['strips']}` lockdowns `{self.stats['lockdowns']}` bans `{self.stats['bans']}`\n"
            f"event->request latency (bot-side only): p50 `{p(0.5)}` p95 `{p(0.95)}`",
            allowed_mentions=discord.AllowedMentions.none())

    @linkinvite.command(name="threshold", help="Set the lockdown threshold: linkinvite threshold <events> [window_seconds]")
    async def li_threshold(self, ctx, events: int, window: int = 600):
        if not self._owner(ctx):
            return await ctx.send("Only the **server owner** can use this.")
        events, window = max(1, min(events, 20)), max(30, min(window, 3600))
        self._cfg[ctx.guild.id] = (events, float(window))
        self.ledger.submit(self.ledger.w_config, ctx.guild.id, events, float(window))
        await ctx.send(f"Lockdown threshold set to `{events}` events in `{window}s`.")

    @linkinvite.command(name="unlock", help="Restore permissions removed by the lockdown. Add `force` to reconcile edited roles.")
    async def li_unlock(self, ctx, mode: str = ""):
        if not self._owner(ctx):
            return await ctx.send("Only the **server owner** can use this.")
        res = await self.unlock(ctx.guild, force=mode.lower() == "force", actor=ctx.author.id)
        await ctx.send(
            f"Unlock `{res['status']}`: restored `{len(res.get('restored', []))}`, skipped (edited since) "
            f"`{len(res.get('skipped_changed', []))}`, role gone `{len(res.get('gone', []))}`, failed `{len(res.get('failed', []))}`.")

    @linkinvite.command(name="restore", help="Restore the original permissions of one flagged linked role by id.")
    async def li_restore(self, ctx, role_id: int):
        if not self._owner(ctx):
            return await ctx.send("Only the **server owner** can use this.")
        ok, err = await self.restore_role(ctx.guild, role_id, ctx.author.id)
        await ctx.send("Role restored." if ok else f"Could not restore: `{err}`")

    @linkinvite.command(name="evidence", help="Show the latest forensic events.")
    async def li_evidence(self, ctx, count: int = 8):
        if not self._owner(ctx):
            return await ctx.send("Only the **server owner** can use this.")
        rows = await self.ledger.run(self.ledger.r_all, "SELECT ts, kind, role_id, member_id, x_id, y_id, verdict FROM li_events "
                                     "WHERE guild_id=? ORDER BY id DESC LIMIT ?", (ctx.guild.id, max(1, min(count, 20))))
        text = "\n".join(f"<t:{int(r[0])}:T> `{r[1]}` role `{r[2]}` member `{r[3]}` X `{r[4]}` Y `{r[5]}` `{r[6]}`" for r in rows)
        await ctx.send(text or "No events recorded.", allowed_mentions=discord.AllowedMentions.none())
