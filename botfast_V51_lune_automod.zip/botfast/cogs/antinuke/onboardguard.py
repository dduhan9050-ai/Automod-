"""Anti-Onboarding: stops Administrator / dangerous roles from being handed out through Discord Server Onboarding.

Part of the AntiNuke package (see CHANGES_V47_ANTIONBOARDING.md).  Additive: the engine, linkinvite and botguard are
untouched; the help page lives in the existing `antinuke` help menu and the commands under `antinuke onboarding`.

What Discord does and does NOT give us (do not assume more):
  * Onboarding config changes -> audit actions 163..167 (prompt create/update/delete, onboarding create/update).  They tell
    us WHO touched onboarding, not which role was added; the added role is found by diffing `GET /guilds/{id}/onboarding`.
  * Roles handed out by onboarding -> only a GUILD_MEMBER_UPDATE.  There is no dedicated event and (as far as is known) no
    member-role audit entry, so the person behind it is the person who CONFIGURED the role, found via the config audit entry.
  * A role already in onboarding can later be given Administrator -> role-update audit entry (action 31).
All of that is combined with fallbacks (raw gateway -> normal listeners -> periodic poll).  Nothing is punished on a guess.

Policy (executor must be VERIFIED; Server Owner, Extra Owners and the trusted list are exempt):
  verified unauthorized + Administrator : remove from member, delete the role (if safe), clean onboarding, ban executor
  verified unauthorized + other dangerous: remove from member / revert, clean onboarding, alert (no ban)
  executor unverified + Administrator    : remove from member, clean onboarding, alert  (no delete, no ban)
  executor unverified + other dangerous  : alert only
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from dataclasses import dataclass
from typing import Callable, Optional

import discord
from discord.ext import commands

from utils import antinuke_store as store

try:                                                     # normal import inside the bot
    from .botguard import (Incident, Ledger, Step, _spawn_eager, global_extra_owner_ids, perm_names, valid_id)  # noqa: F401
except ImportError:                                      # loaded by file path (unit tests)
    import importlib.util as _ilu
    import sys as _sys
    _p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "botguard.py")
    _spec = _ilu.spec_from_file_location("onboardguard_botguard_fallback", _p)
    _m = _ilu.module_from_spec(_spec)
    _sys.modules[_spec.name] = _m
    _spec.loader.exec_module(_m)
    Incident, Ledger, Step = _m.Incident, _m.Ledger, _m.Step
    _spawn_eager, global_extra_owner_ids, perm_names, valid_id = _m._spawn_eager, _m.global_extra_owner_ids, _m.perm_names, _m.valid_id

log = logging.getLogger("deathbot.onboardguard")
AL = discord.AuditLogAction

DB_PATH = os.getenv("OB_DB_PATH", "db/onboardguard.db")
ONB_ACTIONS = (163, 164, 165, 166, 167)    # onboarding prompt create/update/delete, onboarding create/update (verify on a real server)
ROLE_UPDATE = 31
CFG_WINDOW = 20.0            # an onboarding audit entry older than this cannot be the cause of the config change just seen
ASSIGN_LOOKBACK = 600.0      # config entry that may be blamed for a role handed out later (10 min; older = unverified)
HINT_WAIT = 0.6              # wait (RAM only, 50 ms steps) for the gateway audit entry before using REST
AUDIT_MAX_AGE = 60.0
CLAIM_TTL = 120.0
SWEEP_INTERVAL = 600.0       # poll fallback: every enabled guild once per interval, spread evenly
RETRY_DELAYS = (1.5, 4.0)    # bounded retries of failed neutralisation steps (after the lockdown, never before the ban)
LOCKDOWN_COOLDOWN = 120.0
DELETE_MAX_OTHER_HOLDERS = 0  # never delete a role that other (non-affected) members already hold: that would demote them
MAX_TRUSTED = 25

ADMIN_BIT = 1 << 3
TIER_B_BITS = {"Manage Guild": 1 << 5, "Manage Roles": 1 << 28, "Manage Channels": 1 << 4, "Manage Webhooks": 1 << 29,
               "Ban Members": 1 << 2, "Kick Members": 1 << 1, "Moderate Members": 1 << 40}
TIER_B_MASK = sum(TIER_B_BITS.values())
DANGER_MASK = ADMIN_BIT | TIER_B_MASK
NEUTRAL_STEPS = ("Remove from member", "Delete role", "Revert permissions", "Clean onboarding")
DISCORD_EPOCH_MS = 1420070400000


# --------------------------------------------------------------------------- pure helpers (unit-tested)
def danger_tier(perms: int) -> int:
    """2 = Administrator (ban-eligible), 1 = other dangerous permission (clean + alert only), 0 = harmless."""
    if perms & ADMIN_BIT:
        return 2
    return 1 if perms & TIER_B_MASK else 0


def snowflake_ts(sf: int) -> float:
    return ((int(sf) >> 22) + DISCORD_EPOCH_MS) / 1000.0


def _to_int(v) -> Optional[int]:
    try:
        if isinstance(v, bool):
            return None
        i = int(v)
        return i if valid_id(i) else None
    except (TypeError, ValueError):
        return None


def role_ids_in(config) -> set:
    """Every role id that onboarding can hand out.  Tolerates garbage (missing keys, string ids)."""
    out: set = set()
    if not isinstance(config, dict):
        return out
    for prompt in config.get("prompts") or ():
        if not isinstance(prompt, dict):
            continue
        for opt in prompt.get("options") or ():
            if isinstance(opt, dict):
                for rid in opt.get("role_ids") or ():
                    i = _to_int(rid)
                    if i is not None:
                        out.add(i)
    return out


def _option_out(opt: dict, keep_roles: list) -> dict:
    """Option as the PUT endpoint wants it (emoji_* fields instead of the `emoji` object)."""
    out = {k: opt[k] for k in ("id", "title", "description", "channel_ids") if k in opt}
    out["role_ids"] = keep_roles
    out.setdefault("channel_ids", [])
    emoji = opt.get("emoji")
    if isinstance(emoji, dict):
        out["emoji_id"], out["emoji_name"], out["emoji_animated"] = emoji.get("id"), emoji.get("name"), bool(emoji.get("animated"))
    else:
        for k in ("emoji_id", "emoji_name", "emoji_animated"):
            if k in opt:
                out[k] = opt[k]
    return out


def sanitize_config(config: dict, remove: set) -> tuple:
    """-> (put_payload, removed).  Removes `remove` role ids from every option and changes NOTHING else.  An option left with
    neither roles nor channels (invalid for Discord) is dropped, and a prompt left without options is dropped; every such
    drop is listed in `removed` so the owner can rebuild it."""
    prompts_out, removed = [], []
    for prompt in config.get("prompts") or ():
        opts_out = []
        for opt in prompt.get("options") or ():
            roles = [r for r in (opt.get("role_ids") or ())]
            hit = [r for r in roles if _to_int(r) in remove]
            if not hit:
                opts_out.append(_option_out(opt, roles))
                continue
            keep = [r for r in roles if _to_int(r) not in remove]
            dropped = not keep and not (opt.get("channel_ids") or ())
            for r in hit:
                removed.append({"prompt": prompt.get("title"), "option": opt.get("title"), "role_id": _to_int(r),
                                "dropped_option": dropped})
            if not dropped:
                opts_out.append(_option_out(opt, keep))
        if prompt.get("options") and not opts_out:
            removed.append({"prompt": prompt.get("title"), "dropped_prompt": True})
            continue
        p = {k: prompt[k] for k in ("id", "title", "single_select", "required", "in_onboarding", "type") if k in prompt}
        p["options"] = opts_out
        prompts_out.append(p)
    payload = {"prompts": prompts_out, "default_channel_ids": list(config.get("default_channel_ids") or ()),
               "enabled": bool(config.get("enabled")), "mode": config.get("mode", 0)}
    return payload, removed


def pick_executor(cands, window_start: float) -> tuple:
    """cands: [(entry_id, user_id, ts, action)].  -> (state, uids).  verified = exactly ONE distinct person touched onboarding
    in the window.  Two or more people = ambiguous (nobody is punished), none = unverified."""
    uids = sorted({c[1] for c in cands if c[1] is not None and c[2] >= window_start})
    if len(uids) == 1:
        return "verified", uids
    return ("ambiguous" if uids else "none"), uids


def entry_mentions_role(entry: dict, role_id: int) -> bool:
    """Crude on purpose: a role id (17-19 digits) appearing anywhere in the entry's changes/options."""
    try:
        blob = json.dumps({"c": entry.get("changes"), "o": entry.get("options")})
    except (TypeError, ValueError):
        return False
    return str(role_id) in blob


@dataclass
class OnbIncident(Incident):
    member_id: Optional[int] = None
    role_id: Optional[int] = None
    role_name: str = ""
    perms: int = 0
    trigger: str = ""
    exec_via: str = ""


def render_onb(inc: OnbIncident, header: str, ok="[OK]", no="[X]", warn="[!]", now: Optional[float] = None) -> str:
    icon = lambda st: ok if st == "ok" else no if st in ("failed", "blocked", "impossible") else warn  # noqa: E731
    who = "unidentified" if inc.executor_id is None else f"<@{inc.executor_id}> (`{inc.executor_id}`)"
    if inc.executor_class:
        who += f" - {inc.executor_class.replace('_', ' ')}"
    if inc.exec_via:
        who += f" [{inc.exec_via}]"
    lines = [f"## {header}", f"> **Incident :** {inc.title}"]
    if inc.trigger:
        lines.append(f"> **Trigger :** {inc.trigger}")
    lines.append(f"> **Executor :** {who}")
    if inc.member_id:
        lines.append(f"> **Affected member :** <@{inc.member_id}> (`{inc.member_id}`) - never punished")
    if inc.role_id:
        lines.append(f"> **Role :** <@&{inc.role_id}> `{inc.role_name or '?'}` (`{inc.role_id}`)")
    if inc.perms:
        lines.append(f"> **Permissions :** {', '.join(perm_names(inc.perms))} (`{inc.perms}`)")
    lines.append("")
    for i, s in enumerate(inc.steps, 1):
        lines.append(f"{icon(s.status)} **{i}. {s.name}** - `{s.status}`" + ("\n " + s.detail if s.detail else ""))
    speed = ((f" | punishment sent in {inc.ms_action:.0f} ms" if inc.ms_action is not None else "")
             + f" | handled in {inc.ms:.0f} ms" + (f" ({inc.via})" if inc.via else "")) if inc.ms is not None else ""
    lines.append(f"-# <t:{int(now if now is not None else time.time())}:T>{speed} | confirmed = Discord accepted it and the state was re-read")
    return "\n".join(lines)


def help_text(prefix: str, st: dict, ok="ON", no="OFF") -> list:
    """Page for the existing Antinuke help menu (pure text; the command cog wraps it in the Components V2 view).
    st: {onboarding, trusted_count}"""
    sw = lambda b: ok if b else no  # noqa: E731
    on = bool(st.get("onboarding"))
    return [(
        f"### ANTI-ONBOARDING {sw(on)}\n"
        f"**Administrator Role Detection** {sw(on)}\n"
        f"**Onboarding Configuration Guard** {sw(on)}\n"
        f"**Instant Role Removal & Deletion** {sw(on)}\n"
        f"**Verified Executor Punishment** {sw(on)}\n"
        f"**Emergency Lockdown on Failure** {sw(on)}\n"
        f"**Trusted Administrators** {sw(True)} ({st.get('trusted_count', 0)} trusted)\n\n"
        f"> `{prefix}antinuke onboarding on`\n> `{prefix}antinuke onboarding off`\n> `{prefix}antinuke onboarding status`\n"
        f"> `{prefix}antinuke onboarding scan`\n> `{prefix}antinuke onboarding clean`\n"
        f"> `{prefix}antinuke onboarding trust add <user>`\n> `{prefix}antinuke onboarding trust remove <user>`\n"
        f"> `{prefix}antinuke onboarding trust list`\n"
        "❯ Detects Administrator (and other dangerous) roles added to Server Onboarding or handed out by it. "
        "The affected member only loses that role. Only a **verified** unauthorized executor is banned; the Server Owner, "
        "Extra Owners and trusted administrators are exempt. If a removal or deletion fails, the emergency lockdown starts."
    )]


# --------------------------------------------------------------------------- persistence
class ObLedger(Ledger):
    async def open(self) -> None:
        import sqlite3

        def _open():
            d = os.path.dirname(self.path)
            if d:
                os.makedirs(d, exist_ok=True)
            c = sqlite3.connect(self.path, check_same_thread=False)
            c.execute("PRAGMA journal_mode=WAL")
            c.executescript("""
                CREATE TABLE IF NOT EXISTS ob_config (guild_id INTEGER PRIMARY KEY, enabled INTEGER DEFAULT 0);
                CREATE TABLE IF NOT EXISTS ob_trusted (guild_id INTEGER, user_id INTEGER, added_by INTEGER, added_at REAL,
                                                       PRIMARY KEY (guild_id, user_id));
                CREATE TABLE IF NOT EXISTS ob_events (id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, guild_id INTEGER,
                                                      kind TEXT, executor_id INTEGER, target_id INTEGER, details TEXT);
                CREATE INDEX IF NOT EXISTS ob_events_g ON ob_events (guild_id, ts);
            """)
            c.commit()
            self._conn = c
        await self._run(_open)

    async def wipe_guild(self, gid: int) -> None:
        def _w():
            for t in ("ob_config", "ob_trusted"):
                self._conn.execute(f"DELETE FROM {t} WHERE guild_id = ?", (gid,))
            self._conn.commit()
        await self._run(_w)


# --------------------------------------------------------------------------- the cog
class OnboardGuard(commands.Cog):
    def __init__(self, bot, db_path: str = DB_PATH, clock: Callable = time.time, sleep=None, global_extra=None,
                 retry_delays=RETRY_DELAYS):
        self.bot = bot
        self._now = clock
        self._sleep = sleep or asyncio.sleep
        self.retry_delays = tuple(retry_delays)
        self.ledger = ObLedger(db_path)
        self.flags: dict = {}              # gid -> bool
        self.trusted: dict = {}            # gid -> set(user ids)
        self.cfg_roles: dict = {}          # gid -> frozenset(role ids referenced by onboarding) at the last confirmed read
        self._global_extra = frozenset(global_extra) if global_extra is not None else None
        self._glock: dict = {}
        self._wlocks: dict = {}
        self._cfg_snap: dict = {}          # gid -> (config, ts) just read by the check; the clean step reuses it once (saves a GET)
        self._waiters: dict = {}           # gid -> [futures] woken the moment a gateway audit entry arrives (no polling)
        self.hint_wait = HINT_WAIT
        self.settle = 0.02                 # ms-scale pause before an executor is verified (only when an incident is already certain)
        self._cfg_running: set = set()
        self._cfg_dirty: dict = {}         # gid -> source of the pending re-check
        self._ob_hints: dict = {}          # gid -> [(entry id, user id, ts, action)]   gateway onboarding audit entries
        self._hints: dict = {}             # (gid, action, target) -> (entry id, user id, ts)   role-update entries
        self._used: dict = {}              # audit entry ids already consumed (insertion ordered)
        self._blame: dict = {}             # (gid, role id) -> (uid, class, ts)   who configured a dangerous role
        self._claims: dict = {}            # dedupe keys -> ts
        self._affected: dict = {}          # (gid, role id) -> {member id: ts} members who received the role through onboarding
        self._alerted: dict = {}
        self._lockdown_at: dict = {}
        self._raw: dict = {}               # parser name -> (orig, wrapper)
        self._bg: set = set()
        self._tasks: list = []
        self.stats = {"incidents": 0, "bans": 0, "roles_deleted": 0, "members_cleaned": 0, "configs_cleaned": 0, "lockdowns": 0}

    # ------------------------------------------------------------------ lifecycle
    async def cog_load(self) -> None:
        await store.load()
        await self.ledger.open()
        for gid, en in await self.ledger.query("SELECT guild_id, enabled FROM ob_config"):
            self.flags[gid] = bool(en)
        for gid, uid in await self.ledger.query("SELECT guild_id, user_id FROM ob_trusted"):
            self.trusted.setdefault(gid, set()).add(uid)
        if self._global_extra is None:
            self._global_extra = global_extra_owner_ids()
        self._hook_raw()
        self._tasks += [asyncio.create_task(self._startup()), asyncio.create_task(self._sweep_loop())]

    async def cog_unload(self) -> None:
        self._unhook_raw()
        for t in (*self._tasks, *self._bg):
            t.cancel()
        await self.ledger.close()

    def _spawn(self, coro) -> asyncio.Task:
        t = asyncio.get_running_loop().create_task(coro)
        self._bg.add(t)
        t.add_done_callback(self._bg.discard)
        return t

    def _spawn_now(self, coro) -> None:
        t = _spawn_eager(coro)
        self._bg.add(t)
        t.add_done_callback(self._bg.discard)

    def _lock(self, gid: int) -> asyncio.Lock:
        lk = self._glock.get(gid)
        if lk is None:
            lk = self._glock[gid] = asyncio.Lock()
        return lk

    def _claim(self, key, ttl: float = 10.0) -> bool:
        """Synchronous claim (before any await): True for the first caller within ttl.  Duplicate gateway events lose."""
        now = self._now()
        if len(self._claims) > 2000:
            for k in [k for k, t in self._claims.items() if now - t > CLAIM_TTL]:
                self._claims.pop(k, None)
        if now - self._claims.get(key, -1e9) < ttl:
            return False
        self._claims[key] = now
        return True

    def _note_affected(self, gid: int, rid: int, uid: int) -> None:
        """Called synchronously at detection time: everybody who just received the role through onboarding is an AFFECTED
        member, not an established holder (otherwise a burst of joiners would block the deletion of the role)."""
        d = self._affected.setdefault((gid, rid), {})
        d[uid] = self._now()
        if len(self._affected) > 500:
            self._affected.pop(next(iter(self._affected)))

    def _recent_affected(self, gid: int, rid: int) -> set:
        now = self._now()
        return {u for u, t in self._affected.get((gid, rid), {}).items() if now - t < 600.0}

    def _wlock(self, gid: int) -> asyncio.Lock:
        """Serialises OUR writes to the onboarding configuration (separate from the check lock: no re-entrancy deadlock)."""
        lk = self._wlocks.get(gid)
        if lk is None:
            lk = self._wlocks[gid] = asyncio.Lock()
        return lk

    def _mark_used(self, eid) -> None:
        self._used[eid] = True
        while len(self._used) > 1000:
            self._used.pop(next(iter(self._used)))

    # ------------------------------------------------------------------ config / authorization (sync, RAM)
    def flag(self, gid: int) -> bool:
        return bool(self.flags.get(gid))

    def _enabled(self, gid: int) -> bool:
        cfg = store.peek(gid)
        return bool(cfg is not None and cfg.enabled and self.flags.get(gid))

    def extra_ids(self, gid: int) -> frozenset:
        bgc = self.bot.get_cog("BotGuard")
        base = bgc.extra_ids(gid) if bgc is not None else (self._global_extra or frozenset())
        return frozenset(base)

    def is_manager(self, guild, uid: int) -> bool:
        return uid == guild.owner_id or uid in self.extra_ids(guild.id)

    def classify(self, guild, uid: Optional[int]) -> str:
        """self | owner | extra_owner | trusted | untrusted.  The first four are exempt."""
        if uid is None:
            return "unknown"
        if uid == self.bot.user.id:
            return "self"
        if uid == guild.owner_id:
            return "owner"
        if uid in self.extra_ids(guild.id):
            return "extra_owner"
        if uid in self.trusted.get(guild.id, ()):
            return "trusted"
        return "untrusted"

    @staticmethod
    def exempt(cls: str) -> bool:
        return cls in ("self", "owner", "extra_owner", "trusted")

    async def set_flag(self, gid: int, value: bool) -> None:
        self.flags[gid] = bool(value)
        await self.ledger.exec("INSERT INTO ob_config (guild_id, enabled) VALUES (?, ?) "
                               "ON CONFLICT(guild_id) DO UPDATE SET enabled=excluded.enabled", (gid, int(bool(value))))
        if not value:
            self.cfg_roles.pop(gid, None)

    async def enable_defaults(self, gid: int) -> None:
        if gid not in self.flags:                            # `antinuke enable` / wizard: new setups only
            await self.set_flag(gid, True)

    async def add_trusted(self, guild, uid: int, by: int, is_bot: bool = False) -> str:
        if not valid_id(uid) or is_bot:
            return "invalid"
        if uid == guild.owner_id or uid in self.extra_ids(guild.id):
            return "implicit"
        s = self.trusted.setdefault(guild.id, set())
        if uid in s:
            return "exists"
        if len(s) >= MAX_TRUSTED:
            return "limit"
        s.add(uid)
        await self.ledger.exec("INSERT OR IGNORE INTO ob_trusted (guild_id, user_id, added_by, added_at) VALUES (?, ?, ?, ?)",
                               (guild.id, uid, by, self._now()))
        await self._event(guild.id, "trusted_add", by, uid, {})
        return "added"

    async def remove_trusted(self, gid: int, uid: int, by: int) -> str:
        s = self.trusted.get(gid, set())
        if uid not in s:
            return "absent"
        s.discard(uid)
        await self.ledger.exec("DELETE FROM ob_trusted WHERE guild_id = ? AND user_id = ?", (gid, uid))
        await self._event(gid, "trusted_remove", by, uid, {})
        return "removed"

    async def wipe(self, gid: int) -> None:
        self.flags.pop(gid, None)
        self.trusted.pop(gid, None)
        self.cfg_roles.pop(gid, None)
        await self.ledger.wipe_guild(gid)

    async def _event(self, gid, kind, executor, target, details: dict) -> None:
        try:
            await self.ledger.exec(
                "INSERT INTO ob_events (ts, guild_id, kind, executor_id, target_id, details) VALUES (?, ?, ?, ?, ?, ?)",
                (self._now(), gid, kind, executor, target, json.dumps(details, default=str)[:8000]))
        except Exception:
            log.exception("onboardguard: could not write audit event")

    async def recent_events(self, gid: int, n: int = 5) -> list:
        return await self.ledger.query(
            "SELECT ts, kind, executor_id, target_id FROM ob_events WHERE guild_id = ? ORDER BY id DESC LIMIT ?", (gid, n))

    # ------------------------------------------------------------------ Discord access (overridable in tests)
    async def _api(self, method: str, gid: int, suffix: str, *, json_body=None, reason: Optional[str] = None):
        from discord.http import Route                        # lazy: works on any discord.py 2.x, no onboarding helpers needed
        route = Route(method, "/guilds/{guild_id}/" + suffix, guild_id=gid)
        kw = {}
        if json_body is not None:
            kw["json"] = json_body
        if reason:
            kw["reason"] = reason
        return await self.bot.http.request(route, **kw)

    async def _get_onboarding(self, guild) -> tuple:
        """-> (config dict | None, reason)  reason: ok | forbidden | error"""
        try:
            data = await self._api("GET", guild.id, "onboarding")
        except discord.Forbidden:
            return None, "forbidden"
        except discord.HTTPException:
            return None, "error"
        return (data, "ok") if isinstance(data, dict) else (None, "error")

    async def _audit_rest(self, guild) -> tuple:
        """-> ([(entry id, user id, ts, action, raw)] | None, reason).  One request, newest first."""
        try:
            data = await self.bot.http.get_audit_logs(guild.id, limit=25)
        except discord.Forbidden:
            return None, "no_audit_permission"
        except discord.HTTPException:
            return None, "api_error"
        out = []
        for e in (data or {}).get("audit_log_entries", ()) or ():
            eid, uid, act = _to_int(e.get("id")), _to_int(e.get("user_id")), e.get("action_type")
            if eid is not None:
                out.append((eid, uid, snowflake_ts(eid), act, e))
        return out, "ok"

    async def _retry(self, factory):
        for i in range(3):
            try:
                return await factory()
            except discord.HTTPException as exc:
                if isinstance(exc, (discord.Forbidden, discord.NotFound)) or getattr(exc, "status", 0) < 500 or i == 2:
                    raise
                await self._sleep(0.3 * (i + 1))

    # ------------------------------------------------------------------ role helpers
    def _tier(self, guild, rid: int) -> int:
        role = guild.get_role(rid)
        return danger_tier(role.permissions.value) if role is not None else 0

    def _watched(self, guild, rid: int) -> bool:
        return rid in self.cfg_roles.get(guild.id, ())

    def delete_check(self, guild, role, exclude=()) -> tuple:
        """-> (ok, reason).  Deleting is destructive, so the role must be disposable."""
        cfg = store.peek(guild.id)
        if role.is_default():
            return False, "@everyone cannot be deleted"
        if getattr(role, "managed", False):
            return False, "managed (bot / integration / booster) role"
        if cfg is not None and (role.id in cfg.mainroles or role.id == cfg.barrier):
            return False, "protected antinuke role (mainrole / barrier)"
        if not getattr(guild, "chunked", True):
            return False, "member cache is incomplete, so I cannot tell who else holds the role"
        others = [m for m in getattr(role, "members", ()) if m.id not in exclude]
        if len(others) > DELETE_MAX_OTHER_HOLDERS:
            return False, f"{len(others)} other member(s) already hold this role; deleting it would demote them"
        return True, "ok"

    def hierarchy_ok(self, guild, role) -> tuple:
        me = guild.me
        gp = me.guild_permissions
        if not (gp.administrator or gp.manage_roles):
            return False, "I lack Manage Roles"
        if not role < me.top_role:
            return False, "role is above or equal to my highest role"
        return True, "ok"

    # ------------------------------------------------------------------ raw gateway hooks (earliest signal, RAM only)
    def _hook_raw(self) -> None:
        try:
            parsers = self.bot._connection.parsers
            wanted = {"GUILD_AUDIT_LOG_ENTRY_CREATE": self._raw_audit, "GUILD_MEMBER_UPDATE": self._raw_member}
            origs = {k: parsers[k] for k in wanted}
        except Exception:
            log.warning("onboardguard: raw gateway hook unavailable - using the normal listeners and the poll fallback")
            return
        if self._raw:
            return
        for name, handler in wanted.items():
            orig = origs[name]

            def make(orig=orig, handler=handler):
                def parse(data):
                    try:
                        handler(data)
                    except Exception:
                        log.exception("onboardguard raw hook failed")
                    return orig(data)
                return parse
            wrapper = make()
            self._raw[name] = (orig, wrapper)
            parsers[name] = wrapper

    def _unhook_raw(self) -> None:
        try:
            parsers = self.bot._connection.parsers
            for name, (orig, wrapper) in self._raw.items():
                if parsers.get(name) is wrapper:             # only if nobody chained after us
                    parsers[name] = orig
        except Exception:
            pass
        self._raw = {}

    def _put_hint(self, gid, action, tid, eid, uid) -> None:
        self._hints[(gid, action, tid)] = (eid, uid, self._now())
        while len(self._hints) > 500:
            self._hints.pop(next(iter(self._hints)))
        self._wake(gid)

    def _wake(self, gid: int) -> None:
        for fut in self._waiters.pop(gid, ()):
            if not fut.done():
                fut.set_result(None)

    async def _wait_for(self, gid: int, check, timeout: float):
        """Event driven: returns check() as soon as it is truthy, woken by the gateway entry itself (0 ms latency),
        or check()'s last value after `timeout`."""
        val = check()
        if val:
            return val
        loop = asyncio.get_running_loop()
        end = loop.time() + timeout
        while True:
            rem = end - loop.time()
            if rem <= 0:
                return check()
            fut = loop.create_future()
            self._waiters.setdefault(gid, []).append(fut)
            try:
                await asyncio.wait_for(fut, rem)
            except asyncio.TimeoutError:
                pass
            finally:
                lst = self._waiters.get(gid)
                if lst is not None and fut in lst:
                    lst.remove(fut)
            val = check()
            if val:
                return val

    def _note_cfg_entry(self, gid, eid, uid, action) -> bool:
        """True if this entry is new (the raw hook and the normal listener both report every entry)."""
        lst = self._ob_hints.setdefault(gid, [])
        if eid in self._used or any(h[0] == eid for h in lst):
            return False
        lst.append((eid, uid, self._now(), action))
        del lst[:-50]
        self._wake(gid)
        return True

    def _raw_audit(self, data: dict) -> None:
        at = data.get("action_type")
        if at not in ONB_ACTIONS and at != ROLE_UPDATE:
            return
        try:
            gid, eid = int(data["guild_id"]), int(data["id"])
            uid = _to_int(data.get("user_id"))
        except (KeyError, TypeError, ValueError):
            return
        if not self._enabled(gid):
            return
        guild = self.bot.get_guild(gid)
        if guild is None:
            return
        if at in ONB_ACTIONS:
            if self._note_cfg_entry(gid, eid, uid, at):
                self._kick_cfg_check(guild, "audit")
            return
        tid = _to_int(data.get("target_id"))
        if tid is None:
            return
        self._put_hint(gid, ROLE_UPDATE, tid, eid, uid)
        if not self._watched(guild, tid):
            return
        for ch in data.get("changes") or ():
            if isinstance(ch, dict) and ch.get("key") == "permissions":
                try:
                    old, new = int(ch.get("old_value") or 0), int(ch.get("new_value") or 0)
                except (TypeError, ValueError):
                    return
                if danger_tier(new) > danger_tier(old) and self._claim((gid, "gain", tid, new)):
                    self._mark_used(eid)
                    self._spawn_now(self._role_gain(guild, tid, old, new, uid, eid, raw=True))
                return

    def _raw_member(self, data: dict) -> None:
        """GUILD_MEMBER_UPDATE before discord.py applies it: the cached member still has the OLD roles."""
        try:
            gid, uid = int(data["guild_id"]), int(data["user"]["id"])
            new_roles = {int(r) for r in data.get("roles") or ()}
        except (KeyError, TypeError, ValueError):
            return
        watch = self.cfg_roles.get(gid)
        if not watch or not new_roles or not self._enabled(gid):
            return
        hit = new_roles & watch
        if not hit:
            return
        guild = self.bot.get_guild(gid)
        member = guild.get_member(uid) if guild is not None else None
        if member is None:
            return
        old = {r.id for r in member.roles}
        added = [r for r in hit if r not in old and self._tier(guild, r)]
        for rid in added:
            if self._claim((gid, "assign", uid, rid), 5.0):
                self._note_affected(gid, rid, uid)
                self._spawn_now(self._assigned(guild, uid, rid, raw=True))

    # ------------------------------------------------------------------ normal listeners (fallback + duplicates are claimed)
    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        gid = after.guild.id
        watch = self.cfg_roles.get(gid)
        if not watch or not self._enabled(gid):
            return
        old = {r.id for r in before.roles}
        for r in after.roles:
            if r.id in watch and r.id not in old and self._tier(after.guild, r.id) and self._claim((gid, "assign", after.id, r.id), 5.0):
                self._note_affected(gid, r.id, after.id)
                self._spawn(self._assigned(after.guild, after.id, r.id, raw=False))

    @commands.Cog.listener()
    async def on_member_join(self, member):
        """A (re)joining member can arrive with roles already attached."""
        gid = member.guild.id
        watch = self.cfg_roles.get(gid)
        if not watch or not self._enabled(gid) or getattr(member, "bot", False):
            return
        for r in member.roles:
            if r.id in watch and self._tier(member.guild, r.id) and self._claim((gid, "assign", member.id, r.id), 5.0):
                self._note_affected(gid, r.id, member.id)
                self._spawn(self._assigned(member.guild, member.id, r.id, raw=False))

    @commands.Cog.listener()
    async def on_guild_role_update(self, before, after):
        gid = after.guild.id
        if not self._watched(after.guild, after.id) or not self._enabled(gid):
            return
        old, new = before.permissions.value, after.permissions.value
        if danger_tier(new) > danger_tier(old) and self._claim((gid, "gain", after.id, new)):
            self._spawn(self._role_gain(after.guild, after.id, old, new, None, None, raw=False))

    @commands.Cog.listener()
    async def on_audit_log_entry_create(self, entry):
        """Fallback when the raw hook is unavailable (the raw path has already stored it, which is harmless)."""
        guild = getattr(entry, "guild", None)
        if guild is None or not self._enabled(guild.id):
            return
        action = getattr(entry.action, "value", entry.action)
        if action in ONB_ACTIONS:
            if self._note_cfg_entry(guild.id, entry.id, entry.user_id, action):
                self._kick_cfg_check(guild, "audit")
        elif action == ROLE_UPDATE:
            tid = getattr(getattr(entry, "target", None), "id", None)
            if tid is not None and entry.id not in self._used:
                self._put_hint(guild.id, ROLE_UPDATE, tid, entry.id, entry.user_id)

    # ------------------------------------------------------------------ startup + poll fallback
    async def _startup(self) -> None:
        await self.bot.wait_until_ready()
        for guild in list(self.bot.guilds):
            if self._enabled(guild.id):
                self._kick_cfg_check(guild, "startup")
            await self._sleep(0.2)

    async def _sweep_loop(self) -> None:
        await self.bot.wait_until_ready()
        await self._sleep(SWEEP_INTERVAL / 2)                     # the startup pass already covered everyone
        while True:
            guilds = [g for g in list(self.bot.guilds) if self._enabled(g.id)]
            gap = max(0.2, SWEEP_INTERVAL / max(1, len(guilds)))
            for g in guilds:
                if self._enabled(g.id):
                    self._kick_cfg_check(g, "poll")
                await self._sleep(gap)
            if not guilds:
                await self._sleep(60.0)

    # ------------------------------------------------------------------ executor resolution
    def _fresh_hints(self, gid: int) -> list:
        now = self._now()
        return [h for h in self._ob_hints.get(gid, ()) if h[0] not in self._used and now - h[2] <= CFG_WINDOW]

    async def _config_executor(self, guild, wait: bool = True) -> tuple:
        """Who touched onboarding just now?  -> (state, uids, via, why).  state: verified | ambiguous | none.
        Every candidate entry is consumed, so one entry can never be blamed for two different config changes."""
        gid = guild.id
        cands, via = self._fresh_hints(gid), "gateway audit entry"
        if wait and not cands:
            cands = await self._wait_for(gid, lambda: self._fresh_hints(gid), self.hint_wait) or []
        why = "ok"
        if not cands:
            rest, why = await self._audit_rest(guild)
            via = "audit-log REST"
            now = self._now()
            if rest is not None:
                cands = [(e, u, t, a) for e, u, t, a, _ in rest if a in ONB_ACTIONS and e not in self._used and now - t <= CFG_WINDOW]
        for c in cands:
            self._mark_used(c[0])
        if gid in self._ob_hints:
            self._ob_hints[gid] = [h for h in self._ob_hints[gid] if h[0] not in self._used]
        state, uids = pick_executor(cands, self._now() - CFG_WINDOW)
        return state, uids, via, why

    async def _assign_executor(self, guild, rid: int) -> tuple:
        """Who configured this role for onboarding?  -> (uid | None, via).  Remembered blame first, then ONE audit-log
        lookup limited to the last ASSIGN_LOOKBACK seconds; exactly one distinct person must have touched it."""
        blame = self._blame.get((guild.id, rid))
        if blame is not None:
            return blame[0], "recorded when the role was added to onboarding"
        rest, _ = await self._audit_rest(guild)
        if rest is None:
            return None, "audit log unavailable"
        now = self._now()
        uids = {u for _, u, t, a, raw in rest if a in ONB_ACTIONS and u and now - t <= ASSIGN_LOOKBACK and entry_mentions_role(raw, rid)}
        return (next(iter(uids)), "audit-log REST (config entry names the role)") if len(uids) == 1 else (None, "no single matching config entry")

    async def _role_executor(self, guild, rid: int) -> tuple:
        key = (guild.id, ROLE_UPDATE, rid)
        def fresh():
            h = self._hints.get(key)
            return h if h is not None and h[0] not in self._used and self._now() - h[2] <= AUDIT_MAX_AGE else None
        h = await self._wait_for(guild.id, fresh, self.hint_wait)
        if h is not None:
            self._mark_used(h[0])
            return h[1], "gateway audit entry"
        rest, _ = await self._audit_rest(guild)
        if rest is not None:
            now = self._now()
            for e, u, t, a, raw in rest:
                if a == ROLE_UPDATE and str(raw.get("target_id")) == str(rid) and e not in self._used and now - t <= AUDIT_MAX_AGE:
                    self._mark_used(e)
                    return u, "audit-log REST"
        return None, "audit-log REST (no entry)"

    # ------------------------------------------------------------------ neutralisation primitives (each re-reads before it claims ok)
    async def _p_remove(self, guild, uid: int, rid: int) -> tuple:
        role = guild.get_role(rid)
        member = guild.get_member(uid)
        if member is None:
            try:
                member = await guild.fetch_member(uid)
            except discord.NotFound:
                return "skipped", "member is no longer in the server"
            except discord.HTTPException:
                return "unverified", "could not load the member"
        if role is not None:
            okh, why = self.hierarchy_ok(guild, role)
            if not okh:
                return "blocked", why
        try:
            await self._retry(lambda: member.remove_roles(role or discord.Object(id=rid), reason="Anti-Onboarding: dangerous role removed", atomic=False))
        except discord.Forbidden:
            return "failed", "Discord refused (403): Manage Roles / role hierarchy"
        except discord.NotFound:
            pass                                                          # role or member vanished: the re-read decides
        except discord.HTTPException as exc:
            return "failed", f"Discord error {getattr(exc, 'status', '?')}"
        try:
            fresh = await guild.fetch_member(uid)
        except discord.NotFound:
            return "ok", "member left; role is gone with them (re-read: 404)"
        except discord.HTTPException:
            return "unverified", "removal accepted, but I could not re-read the member to confirm"
        if any(r.id == rid for r in fresh.roles):
            return "failed", "Discord accepted the request but the member still has the role"
        self.stats["members_cleaned"] += 1
        return "ok", "role removed; member re-read and no longer has it (other roles untouched)"

    async def _give_back(self, guild, uid: int, rid: int) -> None:
        """The configurer turned out to be exempt after we already removed the role: put it back (and say so in the ledger)."""
        role, member = guild.get_role(rid), guild.get_member(uid)
        try:
            member = member or await guild.fetch_member(uid)
            if role is not None:
                await member.add_roles(role, reason="Anti-Onboarding: configurer is authorized, role restored", atomic=False)
            await self._event(guild.id, "assign_role_restored", uid, rid, {})
        except discord.HTTPException:
            log.warning("onboardguard: could not give the role back guild=%s member=%s role=%s", guild.id, uid, rid)

    async def _p_delete(self, guild, rid: int) -> tuple:
        role = guild.get_role(rid)
        if role is not None:
            okh, why = self.hierarchy_ok(guild, role)
            if not okh:
                return "blocked", why
            try:
                await self._retry(lambda: role.delete(reason="Anti-Onboarding: unauthorized Administrator role"))
            except discord.Forbidden:
                return "failed", "Discord refused (403): Manage Roles / role hierarchy"
            except discord.NotFound:
                pass
            except discord.HTTPException as exc:
                return "failed", f"Discord error {getattr(exc, 'status', '?')}"
        try:
            roles = await guild.fetch_roles()
        except discord.HTTPException:
            return "unverified", "delete accepted, but I could not re-read the roles to confirm"
        if any(r.id == rid for r in roles):
            return "failed", "Discord accepted the request but the role still exists"
        self.stats["roles_deleted"] += 1
        return "ok", "role deleted; roles re-read and it is gone"

    async def _p_revert(self, guild, rid: int, strip: int) -> tuple:
        role = guild.get_role(rid)
        if role is None:
            return "skipped", "role no longer exists"
        okh, why = self.hierarchy_ok(guild, role)
        if not okh:
            return "blocked", why
        new = role.permissions.value & ~strip
        try:
            if new != role.permissions.value:
                await self._retry(lambda: role.edit(permissions=discord.Permissions(new), reason="Anti-Onboarding: dangerous permissions reverted"))
        except discord.Forbidden:
            return "failed", "Discord refused (403): Manage Roles / role hierarchy"
        except discord.NotFound:
            return "failed", "role vanished (404)"
        except discord.HTTPException as exc:
            return "failed", f"Discord error {getattr(exc, 'status', '?')}"
        try:
            cur = next((r for r in await guild.fetch_roles() if r.id == rid), None)
        except discord.HTTPException:
            return "unverified", "edit accepted, but I could not re-read the roles to confirm"
        if cur is None:
            return "ok", "role no longer exists (re-read)"
        if cur.permissions.value & strip:
            return "failed", "Discord accepted the edit but the role still has: " + ", ".join(perm_names(cur.permissions.value & strip))
        return "ok", "dangerous permissions removed; role re-read and confirmed"

    async def _p_clean(self, guild, remove: set, by: str = "incident") -> tuple:
        """Remove `remove` from the onboarding configuration (read fresh -> edit only role_ids -> write -> read again)."""
        async with self._wlock(guild.id):
            return await self._p_clean_locked(guild, remove, by)

    async def _p_clean_locked(self, guild, remove: set, by: str) -> tuple:
        snap = self._cfg_snap.pop(guild.id, None)
        if snap is not None and self._now() - snap[1] < 1.0:
            cfg, why = snap[0], "ok"                                  # read milliseconds ago by the check that found the role
        else:
            cfg, why = await self._get_onboarding(guild)
        if cfg is None:
            return ("failed", "Discord refused (403): reading onboarding needs Manage Server + Manage Roles") if why == "forbidden" \
                else ("unverified", "could not read the onboarding configuration")
        payload, removed = sanitize_config(cfg, remove)
        if not removed:
            self.cfg_roles[guild.id] = frozenset(role_ids_in(cfg))
            return "ok", "role is not in the onboarding configuration (re-read)"
        self._cfg_snap.pop(guild.id, None)
        try:
            await self._retry(lambda: self._api("PUT", guild.id, "onboarding", json_body=payload, reason="Anti-Onboarding: dangerous role removed from onboarding"))
        except discord.Forbidden:
            return "failed", "Discord refused (403): editing onboarding needs Manage Server + Manage Roles"
        except discord.HTTPException as exc:
            return "failed", f"Discord rejected the edited configuration (HTTP {getattr(exc, 'status', '?')}); remove the role by hand in Server Settings > Onboarding"
        cfg2, _ = await self._get_onboarding(guild)
        if cfg2 is None:
            return "unverified", "edit accepted, but I could not re-read the configuration to confirm"
        left = role_ids_in(cfg2) & remove
        self.cfg_roles[guild.id] = frozenset(role_ids_in(cfg2))
        if left:
            return "failed", "Discord accepted the edit but the configuration still contains: " + ", ".join(map(str, sorted(left)))
        self.stats["configs_cleaned"] += 1
        drops = sum(1 for r in removed if r.get("dropped_option") or r.get("dropped_prompt"))
        await self._event(guild.id, "onboarding_cleaned", None, None, {"by": by, "removed": removed})
        return "ok", (f"removed from {len(removed)} option(s)" + (f"; {drops} option/prompt had nothing else and was dropped (listed in the event ledger)" if drops else "")
                      + "; configuration re-read and confirmed")

    async def _p_ban(self, guild, uid: int, reason: str, inc=None) -> tuple:
        if self.exempt(self.classify(guild, uid)):
            return "skipped", "protected (owner / extra owner / trusted)"
        bgc = self.bot.get_cog("BotGuard")
        if bgc is not None:
            st, detail = await bgc._ban(guild, uid, reason)          # shares the punishment claim with the engine + botguard
        else:
            try:
                await self._retry(lambda: guild.ban(discord.Object(id=uid), reason=reason, delete_message_seconds=0))
                st, detail = "ok", "ban accepted by Discord"
            except discord.Forbidden:
                return "failed", "Discord refused the ban (Ban Members missing or executor's role is above mine)"
            except discord.HTTPException as exc:
                return "failed", f"Discord error {getattr(exc, 'status', '?')}"
        if st != "ok":
            return st, detail
        if inc is not None:
            inc.ms_action = (time.perf_counter() - inc.t0) * 1000       # ban accepted by Discord; the confirmation below is extra
        try:
            await guild.fetch_ban(discord.Object(id=uid))
        except discord.NotFound:
            return "failed", "Discord accepted the ban but fetch_ban says the user is not banned"
        except discord.HTTPException:
            return "unverified", detail + "; could not re-read the ban list to confirm"
        self.stats["bans"] += 1
        return "ok", "ban re-read from Discord (fetch_ban) and confirmed"

    async def _threat_alive(self, guild, rid: int):
        """True / False / None (could not check): does the role still exist with dangerous permissions?"""
        try:
            roles = await guild.fetch_roles()
        except discord.HTTPException:
            return None
        cur = next((r for r in roles if r.id == rid), None)
        return bool(cur is not None and danger_tier(cur.permissions.value))

    # ------------------------------------------------------------------ the shared response
    async def _respond(self, guild, inc: OnbIncident, *, member_id=None, destroy="none",
                       strip=0, clean=True, ban_uid=None, pre=None) -> None:
        """Run the response in PARALLEL (member, role, config and ban are independent), log every step honestly, then
        lock down if the threat could not be neutralised, retry, publish, and re-check the configuration."""
        gid, rid = guild.id, inc.role_id
        jobs: dict = {}
        if member_id is not None:
            jobs["Remove from member"] = lambda: self._p_remove(guild, member_id, rid)
        if destroy == "delete":
            jobs["Delete role"] = lambda: self._p_delete(guild, rid)
        elif destroy == "revert":
            jobs["Revert permissions"] = lambda: self._p_revert(guild, rid, strip)
        if clean:
            jobs["Clean onboarding"] = lambda: self._p_clean(guild, {rid})
        if ban_uid is not None:
            jobs["Ban executor"] = lambda: self._p_ban(guild, ban_uid, "Anti-Onboarding | unauthorized dangerous onboarding role", inc)
        runnable, pre = jobs, pre or {}
        results = await asyncio.gather(*(pre[n] if n in pre else f() for n, f in runnable.items()), return_exceptions=True)
        if inc.ms_action is None:
            inc.ms_action = (time.perf_counter() - inc.t0) * 1000
        res = {}
        for (name, _), r in zip(runnable.items(), results):
            if isinstance(r, BaseException):
                log.exception("onboardguard step %s crashed", name, exc_info=r)
                r = ("failed", f"internal error: {type(r).__name__}")
            res[name] = r
        for name in ("Remove from member", "Delete role", "Revert permissions", "Clean onboarding", "Ban executor"):
            if name in res:
                inc.add(name, *res[name])
        # ---- emergency: a neutralising step failed and the threat is still there
        bad = [n for n in NEUTRAL_STEPS if n in res and res[n][0] in ("failed", "blocked")]
        if bad:
            alive = await self._threat_alive(guild, rid)
            if alive is False:
                inc.add("Emergency lockdown", "skipped", "a step failed but the role no longer exists (re-read): threat gone")
            else:
                st, d = await self._lockdown(guild, f"Anti-Onboarding: could not neutralise role {rid} ({', '.join(bad)})")
                inc.add("Emergency lockdown", st, d + ("" if alive else " (could not re-read the role; locking down to be safe)"))
                await self._retry_failed(guild, inc, jobs, bad)
        await self._publish(guild, inc, "Security Log - Anti-Onboarding", dm_owner=True)
        self._kick_cfg_check(guild, "post-incident")                  # spec: re-check the configuration after every incident

    async def _retry_failed(self, guild, inc: OnbIncident, jobs: dict, bad: list) -> None:
        for name in bad:
            step = next((s for s in inc.steps if s.name == name), None)
            for n, delay in enumerate(self.retry_delays, 1):
                await self._sleep(delay)
                try:
                    st, d = await jobs[name]()
                except Exception as exc:                              # noqa: BLE001
                    st, d = "failed", f"internal error: {type(exc).__name__}"
                if step is not None:
                    step.status, step.detail = st, f"retry {n}/{len(self.retry_delays)}: {d}"
                if st in ("ok", "skipped", "blocked"):                # blocked = hierarchy; retrying cannot change it
                    break

    async def _lockdown(self, guild, why: str) -> tuple:
        now = self._now()
        if now - self._lockdown_at.get(guild.id, -1e9) < LOCKDOWN_COOLDOWN:
            return "skipped", "a lockdown was already triggered in the last 2 minutes"
        self._lockdown_at[guild.id] = now
        emg = self.bot.get_cog("Emergency")
        if emg is None:
            return "failed", "the Emergency module is not loaded: no lockdown possible; the owner must act"
        try:
            n = await emg._lockdown(guild)
        except Exception as exc:                                      # noqa: BLE001
            log.exception("onboardguard lockdown failed")
            return "failed", f"lockdown crashed: {type(exc).__name__}"
        if getattr(emg, "auto_guilds", None) and guild.id in emg.auto_guilds:
            self._spawn(emg.auto_trigger(guild, why))                 # owner opted into full emergency mode as well
        self.stats["lockdowns"] += 1
        return ("ok", f"{n} channel(s) locked for @everyone (undo with `emergency unlock`)") if n else \
               ("failed", "no channel could be locked (missing Manage Channels / already locked)")

    # ------------------------------------------------------------------ reporting
    def _channel(self, guild):
        cfg = store.peek(guild.id)
        return guild.get_channel(cfg.log) if cfg is not None and cfg.log else None

    async def _publish(self, guild, inc: OnbIncident, header: str, dm_owner: bool = True) -> None:
        self.stats["incidents"] += 1
        inc.ms = (time.perf_counter() - inc.t0) * 1000
        await self._event(guild.id, f"incident_{inc.kind}", inc.executor_id, inc.role_id, {
            **inc.as_dict(), "member": inc.member_id, "role": inc.role_id, "role_name": inc.role_name, "perms": inc.perms,
            "trigger": inc.trigger, "ts": self._now()})
        channel = self._channel(guild)
        dm_task = asyncio.ensure_future(self._dm_owner(guild, render_onb(inc, header + f" ({guild.name})", now=self._now()))) if dm_owner else None
        sent = False
        if channel is not None:
            try:
                from utils import antinuke_ui as ui
            except Exception:
                ui = None
            try:
                if ui is not None:
                    await channel.send(view=ui.view_of(ui.text(render_onb(inc, header, ok=ui.OK, no=ui.NO, now=self._now()))), allowed_mentions=ui.NO_PING)
                else:
                    await channel.send(content=render_onb(inc, header, now=self._now())[:1990], allowed_mentions=discord.AllowedMentions.none())
                sent = True
            except (discord.Forbidden, discord.HTTPException):
                sent = False
        if dm_task is not None:                                       # DM ran in parallel with the log card
            ok = await dm_task
            inc.add("Notify owner", "ok" if ok else "failed", "DM delivered" if ok else "could not DM the owner (DMs closed)" + ("; see log channel" if channel else ""))
        log.info("onboardguard incident guild=%s kind=%s executor=%s member=%s role=%s perms=%s ts=%s log_channel=%s steps=%s",
                 guild.id, inc.kind, inc.executor_id, inc.member_id, inc.role_id, inc.perms, int(self._now()),
                 "sent" if sent else "unavailable", [(s.name, s.status) for s in inc.steps])

    async def _dm_owner(self, guild, text: str) -> bool:
        try:
            user = self.bot.get_user(guild.owner_id) or await self.bot.fetch_user(guild.owner_id)
            await user.send(content=text[:1990], allowed_mentions=discord.AllowedMentions.none())
            return True
        except (discord.Forbidden, discord.HTTPException):
            return False

    # ------------------------------------------------------------------ flow 1: a role was handed out by onboarding
    async def _assigned(self, guild, uid: int, rid: int, raw: bool = False) -> None:
        try:
            await self._assigned_inner(guild, uid, rid, raw)
        except Exception:
            log.exception("onboardguard assignment handler failed guild=%s", guild.id)

    async def _assigned_inner(self, guild, uid: int, rid: int, raw: bool) -> None:
        gid = guild.id
        role = guild.get_role(rid)
        if role is None or not self._enabled(gid):
            return
        tier, perms = danger_tier(role.permissions.value), role.permissions.value
        if not tier:
            return
        inc = OnbIncident("assigned", gid, started=self._now(), member_id=uid, role_id=rid, role_name=role.name, perms=perms,
                          target_id=rid, trigger="role handed out by Server Onboarding (member update)")
        inc.via = "raw gateway" if raw else "gateway event"
        inc.title = f"{'Administrator' if tier == 2 else 'Dangerous'} role assigned through onboarding"
        inc.add("Detect", "ok", f"member gained a role that onboarding hands out; role has {', '.join(perm_names(perms & DANGER_MASK))}")
        member_cls = self.classify(guild, uid)
        affected_exempt = self.exempt(member_cls)
        early = None
        if tier == 2 and not affected_exempt and (gid, rid) not in self._blame:
            # speed: no remembered configurer means a REST audit lookup (one round trip).  The member loses the Administrator
            # role NOW, in parallel with that lookup; if the lookup then shows an exempt configurer the role is given back.
            early = asyncio.ensure_future(self._p_remove(guild, uid, rid))
        executor, how = await self._assign_executor(guild, rid)
        cls = self.classify(guild, executor)
        inc.executor_id, inc.executor_class, inc.exec_via = executor, ("" if executor is None else cls), how
        if executor is not None and self.exempt(cls):
            if early is not None:
                st, _d = await early
                if st == "ok":
                    await self._give_back(guild, uid, rid)
            await self._event(gid, "assign_authorized", executor, rid, {"member": uid, "perms": perms})
            log.info("onboardguard: authorized onboarding role guild=%s role=%s member=%s by=%s (%s)", gid, rid, uid, executor, cls)
            return
        verified = executor is not None and cls == "untrusted"
        inc.add("Verify executor", "ok" if verified else "unverified",
                "configured by an unauthorized user" if verified else f"could not be verified ({how}): nobody will be punished")
        if tier == 1 and not verified:
            inc.add("Action", "skipped", "other dangerous permissions + unverified executor: alert only (not Administrator)")
            await self._publish(guild, inc, "Security Log - Anti-Onboarding", dm_owner=True)
            return
        first = self._claim((gid, "role-incident", rid), CLAIM_TTL)   # role-level work (delete / ban) only once per burst
        self._note_affected(gid, rid, uid)
        aff = self._recent_affected(gid, rid)
        destroy, ban_uid = "none", None
        if tier == 2 and verified:
            ok_del, why = self.delete_check(guild, role, exclude=aff)
            if first and ok_del:
                destroy = "delete"
            else:
                inc.add("Delete role", "skipped", "role-level actions already done for this burst" if not first else f"not deleted: {why}")
            if first:
                ban_uid = executor
        elif tier == 2:
            inc.add("Delete role", "skipped", "executor not verified: a role is only deleted when its configurer is verified unauthorized")
        if affected_exempt:
            inc.add("Remove from member", "skipped", f"affected member is exempt ({member_cls.replace('_', ' ')}); their roles are untouched")
        await self._respond(guild, inc, member_id=None if affected_exempt else uid, destroy=destroy, clean=True, ban_uid=ban_uid,
                            pre={"Remove from member": early} if early is not None else None)

    # ------------------------------------------------------------------ flow 2: onboarding configuration changed
    def _kick_cfg_check(self, guild, source: str) -> None:
        gid = guild.id
        if gid in self._cfg_running:
            self._cfg_dirty[gid] = source                              # the running check re-reads once more
            return
        self._cfg_running.add(gid)                                     # claimed synchronously
        self._spawn_now(self._cfg_loop(guild, source))                 # eager: the GET is sent before the loop yields

    async def _cfg_loop(self, guild, source: str) -> None:
        gid = guild.id
        try:
            while True:
                self._cfg_dirty.pop(gid, None)
                try:
                    await self._cfg_check(guild, source)
                except Exception:
                    log.exception("onboardguard config check failed guild=%s", gid)
                if gid not in self._cfg_dirty:
                    break
                source = self._cfg_dirty[gid]
        finally:
            self._cfg_running.discard(gid)

    async def _cfg_check(self, guild, source: str) -> None:
        gid = guild.id
        if not self._enabled(gid):
            return
        async with self._lock(gid):
            cfg, why = await self._get_onboarding(guild)
            if cfg is None:
                if why == "forbidden" and self._claim((gid, "unreadable"), 3600):
                    inc = OnbIncident("config", gid, title="Cannot read the onboarding configuration", trigger=source)
                    inc.add("Detect", "failed", "Discord refused (403): reading onboarding needs Manage Server + Manage Roles. "
                            "Config monitoring is blind; role assignments are still guarded.")
                    await self._publish(guild, inc, "Security Log - Anti-Onboarding", dm_owner=True)
                return
            cur = role_ids_in(cfg)
            prev = self.cfg_roles.get(gid)
            self.cfg_roles[gid] = frozenset(cur)
            danger = {r: self._tier(guild, r) for r in cur if self._tier(guild, r)}
            if prev is None:                                           # first look: history unknown -> report, never auto-revert
                if danger and self._claim((gid, "baseline", tuple(sorted(danger))), 3600):
                    inc = OnbIncident("baseline", gid, trigger=source,
                                      title="Dangerous role(s) already configured in onboarding (before I watched)")
                    inc.add("Detect", "ok", "roles: " + ", ".join(f"<@&{r}> ({'Administrator' if t == 2 else 'dangerous'})" for r, t in danger.items()))
                    inc.add("Verify executor", "unverified", "no live event exists for changes made before / while I was offline")
                    inc.add("Action", "skipped", f"not changed automatically: it may be intentional. Run `antinuke onboarding clean` to remove them. "
                            "Members who receive an Administrator role from it are still stripped.")
                    await self._publish(guild, inc, "Security Log - Anti-Onboarding", dm_owner=True)
                return
            added = {r: t for r, t in danger.items() if r not in prev}
            if not added:
                return
            if self.settle:
                await asyncio.sleep(self.settle)     # let a second person's simultaneous entry land: ambiguity must stay detectable
            state, uids, via, awhy = await self._config_executor(guild, wait=source != "poll")
            self._cfg_snap[gid] = (cfg, self._now())         # ONCE: only the first clean may reuse it (later ones re-read)
            for rid, tier in added.items():
                await self._config_incident(guild, rid, tier, state, uids, via, awhy, source)

    async def _config_incident(self, guild, rid: int, tier: int, state: str, uids: list, via: str, awhy: str, source: str) -> None:
        gid = guild.id
        role = guild.get_role(rid)
        if role is None:
            return
        inc = OnbIncident("config", gid, started=self._now(), role_id=rid, role_name=role.name, perms=role.permissions.value, target_id=rid,
                          trigger=f"onboarding configuration changed ({source})")
        inc.via, inc.exec_via = via, via
        inc.title = f"{'Administrator' if tier == 2 else 'Dangerous'} role added to onboarding"
        inc.add("Detect", "ok", f"role newly referenced by onboarding; permissions: {', '.join(perm_names(role.permissions.value & DANGER_MASK))}")
        executor = uids[0] if state == "verified" else None
        cls = self.classify(guild, executor)
        inc.executor_id, inc.executor_class = executor, ("" if executor is None else cls)
        if executor is not None:
            self._blame[(gid, rid)] = (executor, cls, self._now())
            if len(self._blame) > 500:
                self._blame.pop(next(iter(self._blame)))
            if self.exempt(cls):
                await self._event(gid, "config_authorized", executor, rid, {"perms": role.permissions.value})
                log.info("onboardguard: authorized onboarding config guild=%s role=%s by=%s (%s)", gid, rid, executor, cls)
                return
        verified = executor is not None and cls == "untrusted"
        if verified:
            inc.add("Verify executor", "ok", "the only person who touched onboarding in the window; not Owner / Extra Owner / trusted")
        else:
            inc.add("Verify executor", "unverified", {"ambiguous": f"{len(uids)} different people touched onboarding at the same time",
                                                      "none": f"no onboarding audit entry found ({awhy})"}.get(state, "unknown") + ": nobody will be punished")
        if tier == 1 and not verified:
            inc.add("Action", "skipped", "other dangerous permissions + unverified executor: alert only")
            await self._publish(guild, inc, "Security Log - Anti-Onboarding", dm_owner=True)
            return
        destroy, ban_uid = "none", None
        if tier == 2 and verified:
            ok_del, why = self.delete_check(guild, role)
            if ok_del:
                destroy = "delete"
            else:
                inc.add("Delete role", "skipped", f"not deleted: {why}")
            ban_uid = executor
        elif tier == 2:
            inc.add("Delete role", "skipped", "executor not verified: a role is only deleted when its configurer is verified unauthorized")
        self._claims[(gid, "role-incident", rid)] = self._now()
        await self._respond(guild, inc, destroy=destroy, clean=True, ban_uid=ban_uid)

    # ------------------------------------------------------------------ flow 3: a role already in onboarding gained dangerous permissions
    async def _role_gain(self, guild, rid: int, old: int, new: int, uid, eid, raw: bool = False) -> None:
        try:
            await self._role_gain_inner(guild, rid, old, new, uid, eid, raw)
        except Exception:
            log.exception("onboardguard role-gain handler failed guild=%s", guild.id)

    async def _role_gain_inner(self, guild, rid, old, new, uid, eid, raw) -> None:
        gid = guild.id
        role = guild.get_role(rid)
        if role is None or not self._enabled(gid):
            return
        tier = danger_tier(role.permissions.value)
        if not tier:
            return                                                    # already reverted (e.g. by the antinuke engine)
        inc = OnbIncident("rolegain", gid, started=self._now(), role_id=rid, role_name=role.name, perms=role.permissions.value, target_id=rid,
                          trigger="a role that onboarding hands out gained dangerous permissions")
        inc.via = "raw gateway" if raw else "gateway event"
        inc.title = f"Onboarding role became {'Administrator' if tier == 2 else 'dangerous'}"
        gained = new & ~old & DANGER_MASK
        inc.add("Detect", "ok", f"permissions gained: {', '.join(perm_names(gained)) or 'n/a'}")
        how = "gateway audit entry" if uid is not None else ""
        if uid is None:
            uid, how = await self._role_executor(guild, rid)
        cls = self.classify(guild, uid)
        inc.executor_id, inc.executor_class, inc.exec_via = uid, ("" if uid is None else cls), how
        if uid is not None and self.exempt(cls):
            await self._event(gid, "rolegain_authorized", uid, rid, {"perms": role.permissions.value})
            return
        verified = uid is not None and cls == "untrusted"
        inc.add("Verify executor", "ok" if verified else "unverified",
                "role changed by an unauthorized user" if verified else f"could not be verified ({how}): nobody will be punished, roles are not edited")
        if tier == 1 and not verified:
            inc.add("Action", "skipped", "other dangerous permissions + unverified executor: alert only")
            await self._publish(guild, inc, "Security Log - Anti-Onboarding", dm_owner=True)
            return
        self._claims[(guild.id, "role-incident", rid)] = self._now()
        await self._respond(guild, inc, destroy="revert" if verified else "none", strip=gained or DANGER_MASK, clean=True,
                            ban_uid=uid if (verified and tier == 2) else None)

    # ------------------------------------------------------------------ owner commands
    async def scan(self, guild) -> tuple:
        """Read-only: -> (config | None, reason, [(role id, name, tier, perms)])"""
        cfg, why = await self._get_onboarding(guild)
        if cfg is None:
            return None, why, []
        rows = []
        for rid in sorted(role_ids_in(cfg)):
            r = guild.get_role(rid)
            if r is not None:
                rows.append((rid, r.name, danger_tier(r.permissions.value), r.permissions.value))
        self.cfg_roles[guild.id] = frozenset(role_ids_in(cfg))
        return cfg, "ok", rows

    async def clean_now(self, guild, by: int) -> tuple:
        """`antinuke onboarding clean`: remove every dangerous role from the onboarding configuration (owner / extra owners)."""
        async with self._lock(guild.id):
            cfg, why = await self._get_onboarding(guild)
            if cfg is None:
                return "failed" if why == "forbidden" else "unverified", "could not read the onboarding configuration", []
            bad = {r for r in role_ids_in(cfg) if self._tier(guild, r)}
            if not bad:
                return "ok", "no dangerous role in the onboarding configuration", []
            st, d = await self._p_clean(guild, bad, by=f"command by {by}")
            await self._event(guild.id, "clean_command", by, None, {"roles": sorted(bad), "status": st})
            return st, d, sorted(bad)

    def status_info(self, guild) -> dict:
        gp = guild.me.guild_permissions
        full = gp.administrator
        return {"on": self.flag(guild.id), "engine": bool(store.get(guild.id).enabled),
                "known_roles": len(self.cfg_roles.get(guild.id, ())), "baseline": guild.id in self.cfg_roles,
                "audit": full or gp.view_audit_log, "manage_roles": full or gp.manage_roles, "manage_guild": full or gp.manage_guild,
                "ban": full or gp.ban_members, "trusted": len(self.trusted.get(guild.id, ()))}
