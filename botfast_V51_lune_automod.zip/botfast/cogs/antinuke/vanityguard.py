"""Anti Vanity: stops unauthorized users from changing or removing the server's vanity URL.

Part of the AntiNuke package (see CHANGES_V50_VANITY.md).  Additive: the engine, linkinvite, botguard, onboardguard and inviteguard are
untouched; the help page lives in the existing `antinuke` help menu and the commands under `antinuke vanity`.

What Discord gives us:
  * The GUILD_UPDATE gateway event carries the full guild object, including `vanity_url_code`.  The code is compared in RAM against
    the protected code (no REST call, no member cache needed).
  * Audit log action 1 (GUILD_UPDATE) carries a `vanity_url_code` change (old_value / new_value) and names the user who made it.
    GUILD_AUDIT_LOG_ENTRY_CREATE delivers that entry over the gateway, so the actor is usually known within milliseconds.
  * Restoring the code: PATCH /guilds/{id}/vanity-url {"code": ...} (needs Manage Server).  This endpoint is NOT in Discord's
    official docs; it is what the Discord client itself uses.  The result is always re-read with GET /guilds/{id}/vanity-url.
  * A released vanity code can be claimed by any other server in the meantime.  Nothing can prevent that; if it happens the card
    says so honestly and the restore is reported as failed.

Policy (Server Owner, Extra Owners, the antinuke whitelist and the bot itself are exempt):
  1. the code in the event is compared with the protected code (RAM).  Same code = nothing to do.
  2. the actor is read from the audit log (gateway entry first, then REST).  The restore and the ban only ever happen when the audit
     log names ONE user for THIS change.  Unknown / mismatching / ambiguous actor = alert only (it may be the owner).
  3. exempt actor = the protected code moves to the new code (authorized change).
  4. untrusted actor: IN PARALLEL restore the old code | ban the actor.  The restore is re-read (GET) before it is called ok, and the
     ban is re-read (fetch_ban).  Owner DM + log card.
  FAST MODE (default ON, `antinuke vanity fast off` to disable): the old code is restored THE MOMENT the change is seen, in parallel
     with the audit lookup, over a pre-built direct request.  Untrusted actor = already restored, ban follows.  Exempt actor (the owner
     etc.) = their change is applied again right away and becomes the protected code.  Actor not provable = stays restored, alert only.
     Price: a legitimate change by the owner is reverted and re-applied within about a second, and in that moment the code is free.
  5. a change made while the bot was offline is never acted on (nobody can prove who did it): the owner gets an alert and uses
     `antinuke vanity restore` or `antinuke vanity sync`.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from urllib.parse import quote
from dataclasses import dataclass, field
from typing import Callable, Optional

import discord
from discord.ext import commands

from utils import antinuke_store as store

try:                                                     # normal import inside the bot
    from .botguard import (Incident, Ledger, Step, _spawn_eager, global_extra_owner_ids, valid_id)  # noqa: F401
except ImportError:                                      # loaded by file path (unit tests)
    import importlib.util as _ilu
    import sys as _sys
    _p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "botguard.py")
    _spec = _ilu.spec_from_file_location("vanityguard_botguard_fallback", _p)
    _m = _ilu.module_from_spec(_spec)
    _sys.modules[_spec.name] = _m
    _spec.loader.exec_module(_m)
    Incident, Ledger, Step = _m.Incident, _m.Ledger, _m.Step
    _spawn_eager, global_extra_owner_ids, valid_id = _m._spawn_eager, _m.global_extra_owner_ids, _m.valid_id

log = logging.getLogger("deathbot.vanityguard")

DB_PATH = os.getenv("VG_DB_PATH", "db/vanityguard.db")
GUILD_UPDATE_ACTION = 1            # audit log: GUILD_UPDATE
AUDIT_WINDOW = 20.0                # an audit entry older than this cannot be the change we just saw
CLOCK_SKEW = 10.0                  # tolerated difference between our clock and a snowflake timestamp
HINT_WAIT = 0.6                    # wait (event driven, RAM only) for the gateway audit entry before falling back to REST
REST_RECHECK = 0.8                 # the audit log is sometimes a moment behind: one more REST read after this delay
CLAIM_TTL = 120.0
RETRY_DELAYS = (1.0, 3.0)          # bounded retries of a failed restore (only 5xx / network style errors)
DM_COOLDOWN = 60.0                 # one owner DM per actor per minute
CODE_RE = re.compile(r"^[A-Za-z0-9-]{2,64}$")
FAST_DEFAULT = True                # speculative restore (see module doc) is ON unless the owner runs `antinuke vanity fast off`


# --------------------------------------------------------------------------- pure helpers (unit-tested)
def _to_int(v) -> Optional[int]:
    try:
        if isinstance(v, bool):
            return None
        i = int(v)
        return i if valid_id(i) else None
    except (TypeError, ValueError):
        return None


def valid_code(code) -> bool:
    return isinstance(code, str) and bool(CODE_RE.match(code))


def canon(code) -> Optional[str]:
    """Vanity codes are case-insensitive: compare canonical forms.  None = no vanity."""
    return code.lower() if isinstance(code, str) else None


def same_code(a, b) -> bool:
    return canon(a) == canon(b)


def snowflake_ts(sf: int) -> float:
    return ((int(sf) >> 22) + 1420070400000) / 1000.0


def parse_guild_update(data) -> Optional[tuple]:
    """GUILD_UPDATE payload -> (guild id, vanity code | None).  None when the payload is garbage or carries no vanity field
    (never raises).  A present-but-null vanity_url_code means \"no vanity\"."""
    if not isinstance(data, dict) or "vanity_url_code" not in data:
        return None
    gid, code = _to_int(data.get("id")), data.get("vanity_url_code")
    if gid is None or not (code is None or valid_code(code)):
        return None
    return gid, code


def audit_vanity(entry) -> Optional[tuple]:
    """Raw GUILD_UPDATE audit entry -> (entry id, user id, old code | None, new code | None) when it contains a vanity_url_code
    change, else None."""
    if not isinstance(entry, dict):
        return None
    for ch in entry.get("changes") or ():
        if isinstance(ch, dict) and ch.get("key") == "vanity_url_code":
            old, new = ch.get("old_value"), ch.get("new_value")
            eid = _to_int(entry.get("id"))
            if eid is None:
                return None
            return eid, _to_int(entry.get("user_id")), old if isinstance(old, str) else None, new if isinstance(new, str) else None
    return None


def pick_audit(cands, new, now: float, window: float = AUDIT_WINDOW) -> tuple:
    """cands: [(entry id, user id, ts, old code | None, new code | None)] -> (state, entry | None, why).
    state: verified | ambiguous | none.  Only an entry whose new code equals the code we saw counts, and only when it names exactly
    one user."""
    live = [c for c in cands if c[1] is not None and -CLOCK_SKEW <= now - c[2] <= window]
    pool = [c for c in live if same_code(c[4], new)]
    uids = sorted({c[1] for c in pool})
    if not uids:
        return "none", None, "no GUILD_UPDATE audit entry with this vanity change"
    if len(uids) > 1:
        return "ambiguous", None, f"{len(uids)} different users have a matching audit entry"
    entry = max((c for c in pool if c[1] == uids[0]), key=lambda c: c[2])
    return "verified", entry, "audit entry carries this vanity change"


def shown(code) -> str:
    return f"`discord.gg/{code}`" if code else "`none`"


@dataclass
class AuditRes:
    state: str                    # verified | ambiguous | none | unavailable
    uid: Optional[int] = None
    via: str = ""
    why: str = ""
    eid: Optional[int] = None


@dataclass
class VgIncident(Incident):
    old_code: Optional[str] = None
    new_code: Optional[str] = None
    trigger: str = ""
    exec_via: str = ""


def render_vg(inc: VgIncident, header: str, ok="[OK]", no="[X]", warn="[!]", now: Optional[float] = None) -> str:
    icon = lambda st: ok if st == "ok" else no if st in ("failed", "blocked", "impossible") else warn  # noqa: E731
    who = "unidentified" if inc.executor_id is None else f"<@{inc.executor_id}> (`{inc.executor_id}`)"
    if inc.executor_class:
        who += f" - {inc.executor_class.replace('_', ' ')}"
    if inc.exec_via:
        who += f" [{inc.exec_via}]"
    lines = [f"## {header}", f"> **Incident :** {inc.title}"]
    if inc.trigger:
        lines.append(f"> **Trigger :** {inc.trigger}")
    lines.append(f"> **Changed by :** {who}")
    lines.append(f"> **Protected code :** {shown(inc.old_code)}")
    lines.append(f"> **Code now :** {shown(inc.new_code)}")
    lines.append("")
    for i, s in enumerate(inc.steps, 1):
        lines.append(f"{icon(s.status)} **{i}. {s.name}** - `{s.status}`" + ("\n " + s.detail if s.detail else ""))
    speed = ((f" | actions sent in {inc.ms_action:.0f} ms" if inc.ms_action is not None else "")
             + f" | handled in {inc.ms:.0f} ms" + (f" ({inc.via})" if inc.via else "")) if inc.ms is not None else ""
    lines.append(f"-# <t:{int(now if now is not None else time.time())}:T>{speed} | confirmed = Discord accepted it and the state was re-read")
    return "\n".join(lines)


def help_text(prefix: str, st: dict, ok="ON", no="OFF") -> list:
    """Page for the existing Antinuke help menu (pure text; the command cog wraps it in the Components V2 view).  st: {vanity}"""
    sw = lambda b: ok if b else no  # noqa: E731
    on = bool(st.get("vanity"))
    return [(
        f"### ANTI VANITY {sw(on)}\n"
        f"**Vanity Change / Removal Detection** {sw(on)}\n"
        f"**Audit-Verified Actor** {sw(on)}\n"
        f"**Instant Vanity Restore (re-read)** {sw(on)}\n"
        f"**Actor Ban** {sw(on)}\n"
        f"**Owner / Extra Owner / Whitelist Protection** {sw(True)}\n\n"
        f"> `{prefix}antinuke vanity on`\n> `{prefix}antinuke vanity off`\n> `{prefix}antinuke vanity status`\n"
        f"> `{prefix}antinuke vanity restore`\n> `{prefix}antinuke vanity sync`\n> `{prefix}antinuke vanity fast on|off`\n"
        "\u276f When someone who is not the Server Owner, an Extra Owner or whitelisted changes or removes the vanity URL, the audit log "
        "names them, the old code is put back at once and they are banned. **Fast mode** (default) puts the old code back the moment the "
        "change is seen, before the audit log answers; a change by the owner is applied again right after. If the audit log cannot name the user, nobody is banned "
        "and the owner is alerted. A code another server claims in the meantime cannot be taken back (Discord limitation)."
    )]


# --------------------------------------------------------------------------- persistence
class VgLedger(Ledger):
    async def open(self) -> None:
        import sqlite3

        def _open():
            d = os.path.dirname(self.path)
            if d:
                os.makedirs(d, exist_ok=True)
            c = sqlite3.connect(self.path, check_same_thread=False)
            c.execute("PRAGMA journal_mode=WAL")
            c.executescript("""
                CREATE TABLE IF NOT EXISTS vg_config (guild_id INTEGER PRIMARY KEY, enabled INTEGER DEFAULT 0);
                CREATE TABLE IF NOT EXISTS vg_codes (guild_id INTEGER PRIMARY KEY, code TEXT, updated REAL);
                CREATE TABLE IF NOT EXISTS vg_fast (guild_id INTEGER PRIMARY KEY, fast INTEGER);
                CREATE TABLE IF NOT EXISTS vg_events (id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, guild_id INTEGER,
                                                      kind TEXT, executor_id INTEGER, target_id INTEGER, details TEXT);
                CREATE INDEX IF NOT EXISTS vg_events_g ON vg_events (guild_id, ts);
            """)
            c.commit()
            self._conn = c
        await self._run(_open)

    async def wipe_guild(self, gid: int) -> None:
        def _w():
            for t in ("vg_config", "vg_codes", "vg_fast"):
                self._conn.execute(f"DELETE FROM {t} WHERE guild_id = ?", (gid,))
            self._conn.commit()
        await self._run(_w)


# --------------------------------------------------------------------------- the cog
class VanityGuard(commands.Cog):
    def __init__(self, bot, db_path: str = DB_PATH, clock: Callable = time.time, sleep=None, global_extra=None,
                 retry_delays=RETRY_DELAYS):
        self.bot = bot
        self._now = clock
        self._sleep = sleep or asyncio.sleep
        self.retry_delays = tuple(retry_delays)
        self.ledger = VgLedger(db_path)
        self.flags: dict = {}              # gid -> bool
        self.base: dict = {}               # gid -> protected code | None (a key present = tracked)
        self.fast: dict = {}               # gid -> bool (missing = FAST_DEFAULT)
        self._d = None                     # pre-built direct request pieces (see _prep_direct)
        self._hdrs: dict = {}
        self._off: dict = {}               # gid -> (code,)  a difference we already reported (offline change / unverified actor)
        self._global_extra = frozenset(global_extra) if global_extra is not None else None
        self.hint_wait = HINT_WAIT
        self.rest_recheck = REST_RECHECK
        self._hints: dict = {}             # gid -> [(entry id, user id, ts, old, new)]  gateway GUILD_UPDATE audit entries
        self._waiters: dict = {}
        self._used: dict = {}
        self._claims: dict = {}
        self._locks: dict = {}
        self._raw: dict = {}
        self._bg: set = set()
        self.stats = {"changes_seen": 0, "incidents": 0, "restores": 0, "bans": 0}

    # ------------------------------------------------------------------ lifecycle
    async def cog_load(self) -> None:
        await store.load()
        await self.ledger.open()
        for gid, en in await self.ledger.query("SELECT guild_id, enabled FROM vg_config"):
            self.flags[gid] = bool(en)
        for gid, fa in await self.ledger.query("SELECT guild_id, fast FROM vg_fast"):
            self.fast[gid] = bool(fa)
        for gid, code in await self.ledger.query("SELECT guild_id, code FROM vg_codes"):
            if self.flags.get(gid):
                self.base[gid] = code
        if self._global_extra is None:
            self._global_extra = global_extra_owner_ids()
        self._prep_direct()
        self._hook_raw()
        try:
            if self.bot.is_ready():
                self._spawn(self._sync_all())
        except Exception:
            pass

    async def cog_unload(self) -> None:
        self._unhook_raw()
        for t in list(self._bg):
            t.cancel()
        await self.ledger.close()

    def _spawn(self, coro) -> asyncio.Task:
        t = asyncio.get_running_loop().create_task(coro)
        self._bg.add(t)
        t.add_done_callback(self._bg.discard)
        return t

    def _spawn_now(self, coro) -> asyncio.Task:
        t = _spawn_eager(coro)
        self._bg.add(t)
        t.add_done_callback(self._bg.discard)
        return t

    def _claim(self, key, ttl: float = 10.0) -> bool:
        now = self._now()
        if len(self._claims) > 2000:
            for k in [k for k, t in self._claims.items() if now - t > CLAIM_TTL]:
                self._claims.pop(k, None)
        if now - self._claims.get(key, -1e9) < ttl:
            return False
        self._claims[key] = now
        return True

    def _lock(self, gid: int) -> asyncio.Lock:
        lk = self._locks.get(gid)
        if lk is None:
            if len(self._locks) > 500:
                self._locks.pop(next(iter(self._locks)))
            lk = self._locks[gid] = asyncio.Lock()
        return lk

    def _mark_used(self, eid) -> None:
        self._used[eid] = True
        while len(self._used) > 1000:
            self._used.pop(next(iter(self._used)))

    # ------------------------------------------------------------------ config / authorization (sync, RAM)
    def flag(self, gid: int) -> bool:
        return bool(self.flags.get(gid))

    def _enabled(self, gid: int) -> bool:
        cfg = store.peek(gid)
        return bool(cfg is not None and cfg.enabled and self.flags.get(gid))

    def extra_ids(self, gid: int) -> frozenset:
        bgc = self.bot.get_cog("BotGuard")
        base = bgc.extra_ids(gid) if bgc is not None else (self._global_extra or frozenset())
        return frozenset(base)

    def classify(self, guild, uid: Optional[int]) -> str:
        """self | owner | extra_owner | whitelisted | untrusted | unknown.  The first four are exempt."""
        if uid is None:
            return "unknown"
        if uid == self.bot.user.id:
            return "self"
        if uid == guild.owner_id:
            return "owner"
        if uid in self.extra_ids(guild.id):
            return "extra_owner"
        cfg = store.peek(guild.id)
        if cfg is not None and uid in cfg.wl:
            return "whitelisted"
        return "untrusted"

    @staticmethod
    def exempt(cls: str) -> bool:
        return cls in ("self", "owner", "extra_owner", "whitelisted")

    async def _save_base(self, gid: int, code) -> None:
        self.base[gid] = code
        try:
            await self.ledger.exec("INSERT INTO vg_codes (guild_id, code, updated) VALUES (?, ?, ?) "
                                   "ON CONFLICT(guild_id) DO UPDATE SET code=excluded.code, updated=excluded.updated",
                                   (gid, code, self._now()))
        except Exception:
            log.exception("vanityguard: could not save the protected code")

    async def set_flag(self, gid: int, value: bool, guild=None) -> None:
        self.flags[gid] = bool(value)
        await self.ledger.exec("INSERT INTO vg_config (guild_id, enabled) VALUES (?, ?) "
                               "ON CONFLICT(guild_id) DO UPDATE SET enabled=excluded.enabled", (gid, int(bool(value))))
        if value:
            guild = guild or self.bot.get_guild(gid)
            if guild is not None:                              # turning on = the CURRENT code becomes the protected one
                self._off.pop(gid, None)
                await self._save_base(gid, getattr(guild, "vanity_url_code", None))
        else:
            self.base.pop(gid, None)
            self._off.pop(gid, None)
            await self.ledger.exec("DELETE FROM vg_codes WHERE guild_id = ?", (gid,))

    def is_fast(self, gid: int) -> bool:
        return self.fast.get(gid, FAST_DEFAULT)

    async def set_fast(self, gid: int, value: bool) -> None:
        self.fast[gid] = bool(value)
        await self.ledger.exec("INSERT INTO vg_fast (guild_id, fast) VALUES (?, ?) "
                               "ON CONFLICT(guild_id) DO UPDATE SET fast=excluded.fast", (gid, int(bool(value))))

    async def enable_defaults(self, gid: int) -> None:
        if gid not in self.flags:                            # `antinuke enable` / wizard: new setups only
            await self.set_flag(gid, True)

    async def wipe(self, gid: int) -> None:
        self.flags.pop(gid, None)
        self.base.pop(gid, None)
        self.fast.pop(gid, None)
        self._off.pop(gid, None)
        await self.ledger.wipe_guild(gid)

    async def _event(self, gid, kind, executor, target, details: dict) -> None:
        try:
            await self.ledger.exec(
                "INSERT INTO vg_events (ts, guild_id, kind, executor_id, target_id, details) VALUES (?, ?, ?, ?, ?, ?)",
                (self._now(), gid, kind, executor, target, json.dumps(details, default=str)[:8000]))
        except Exception:
            log.exception("vanityguard: could not write audit event")

    async def recent_events(self, gid: int, n: int = 5) -> list:
        return await self.ledger.query(
            "SELECT ts, kind, executor_id, target_id FROM vg_events WHERE guild_id = ? ORDER BY id DESC LIMIT ?", (gid, n))

    # ------------------------------------------------------------------ Discord access (overridable in tests)
    async def _req(self, method: str, path: str, *, json_body=None, reason: Optional[str] = None, **params):
        from discord.http import Route                        # lazy import: unit tests run without discord.py
        kw = {}
        if json_body is not None:
            kw["json"] = json_body
        if reason:
            kw["reason"] = reason
        return await self.bot.http.request(Route(method, path, **params), **kw)

    def _prep_direct(self) -> None:
        """Everything the restore request needs is built ONCE here (same idea as the engine's direct ban): at restore time the PATCH is
        written straight onto the warm connection.  Anything unexpected (proxy, 429, 5xx, odd internals) falls back to bot.http."""
        try:
            import aiohttp
            http = self.bot.http
            token, ua = getattr(http, "token", None), getattr(http, "user_agent", None)
            base = discord.http.Route.BASE
            if not token or not ua or not base or getattr(http, "proxy", None):
                return
            self._d = {"base": base, "timeout": aiohttp.ClientTimeout(total=5),
                       "hdr": {"Authorization": f"Bot {token}", "User-Agent": ua, "Content-Type": "application/json"}}
        except Exception:
            self._d = None
            log.warning("vanityguard: direct restore unavailable - using bot.http")

    async def _direct_set_vanity(self, gid: int, code: str, reason: str):
        """-> (status, body | None) from Discord, or None = could not do it here, use the normal path."""
        d = self._d
        if d is None:
            return None
        sess = getattr(self.bot.http, "_HTTPClient__session", None)
        if sess is None or sess.closed:
            return None
        hdr = self._hdrs.get(reason)
        if hdr is None:
            if len(self._hdrs) > 100:
                self._hdrs.clear()
            hdr = self._hdrs[reason] = {**d["hdr"], "X-Audit-Log-Reason": quote(reason, safe="/ ")}
        try:
            async with sess.patch(f"{d['base']}/guilds/{gid}/vanity-url", data=json.dumps({"code": code}).encode(), headers=hdr,
                                  timeout=d["timeout"]) as r:
                st = r.status
                body = None
                if st == 200:
                    try:
                        body = await r.json(content_type=None)
                    except Exception:
                        body = None
                return st, body
        except Exception:
            return None

    async def _http_set_vanity(self, gid: int, code: str, reason: str):
        return await self._req("PATCH", "/guilds/{guild_id}/vanity-url", json_body={"code": code}, reason=reason, guild_id=gid)

    async def _http_get_vanity(self, gid: int):
        return await self._req("GET", "/guilds/{guild_id}/vanity-url", guild_id=gid)

    async def _audit_rest(self, guild) -> tuple:
        """-> ([(entry id, user id, ts, old, new)] | None, reason).  One request, newest first."""
        try:
            try:
                data = await self.bot.http.get_audit_logs(guild.id, limit=25, action_type=GUILD_UPDATE_ACTION)
            except TypeError:                                  # helper without the action filter: read the newest 100 and filter here
                data = await self.bot.http.get_audit_logs(guild.id, limit=100)
        except discord.Forbidden:
            return None, "no View Audit Log permission"
        except discord.HTTPException:
            return None, "audit log request failed"
        out = []
        for e in (data or {}).get("audit_log_entries", ()) or ():
            if not isinstance(e, dict) or e.get("action_type") != GUILD_UPDATE_ACTION:
                continue
            f = audit_vanity(e)
            if f is not None:
                out.append((f[0], f[1], snowflake_ts(f[0]), f[2], f[3]))
        return out, "ok"

    async def _retry(self, factory):
        for i in range(3):
            try:
                return await factory()
            except discord.HTTPException as exc:
                if isinstance(exc, (discord.Forbidden, discord.NotFound)) or getattr(exc, "status", 0) < 500 or i == 2:
                    raise
                await self._sleep(0.3 * (i + 1))

    # ------------------------------------------------------------------ raw gateway hooks (earliest signal, RAM only)
    def _hook_raw(self) -> None:
        try:
            parsers = self.bot._connection.parsers
            wanted = {"GUILD_UPDATE": self._raw_guild, "GUILD_AUDIT_LOG_ENTRY_CREATE": self._raw_audit}
            origs = {k: parsers[k] for k in wanted}
        except Exception:
            log.warning("vanityguard: raw gateway hook unavailable - using the normal listeners")
            return
        if self._raw:
            return
        for name, handler in wanted.items():
            orig = origs[name]

            def make(orig=orig, handler=handler):
                def parse(data):
                    try:
                        handler(data)
                    except Exception:
                        log.exception("vanityguard raw hook failed")
                    return orig(data)
                return parse
            wrapper = make()
            self._raw[name] = (orig, wrapper)
            parsers[name] = wrapper

    def _unhook_raw(self) -> None:
        try:
            parsers = self.bot._connection.parsers
            for name, (orig, wrapper) in self._raw.items():
                if parsers.get(name) is wrapper:             # only if nobody chained after us
                    parsers[name] = orig
        except Exception:
            pass
        self._raw = {}

    def _wake(self, gid: int) -> None:
        for fut in self._waiters.pop(gid, ()):
            if not fut.done():
                fut.set_result(None)

    async def _wait_for(self, gid: int, check, timeout: float):
        val = check()
        if val:
            return val
        loop = asyncio.get_running_loop()
        end = loop.time() + timeout
        while True:
            rem = end - loop.time()
            if rem <= 0:
                return check()
            fut = loop.create_future()
            self._waiters.setdefault(gid, []).append(fut)
            try:
                await asyncio.wait_for(fut, rem)
            except asyncio.TimeoutError:
                pass
            finally:
                lst = self._waiters.get(gid)
                if lst is not None and fut in lst:
                    lst.remove(fut)
            val = check()
            if val:
                return val

    def _note_audit(self, gid: int, eid, uid, old, new) -> bool:
        lst = self._hints.setdefault(gid, [])
        if eid in self._used or any(h[0] == eid for h in lst):
            return False
        lst.append((eid, uid, self._now(), old, new))
        del lst[:-50]
        if len(self._hints) > 500:
            self._hints.pop(next(iter(self._hints)))
        self._wake(gid)
        return True

    def _raw_audit(self, data: dict) -> None:
        if not isinstance(data, dict) or data.get("action_type") != GUILD_UPDATE_ACTION:
            return
        gid = _to_int(data.get("guild_id"))
        if gid is None or gid not in self.base or not self._enabled(gid):
            return
        f = audit_vanity(data)
        if f is not None:
            self._note_audit(gid, *f)

    def _raw_guild(self, data: dict) -> None:
        """Runs BEFORE discord.py updates its own cache: the protected code is compared with the code in the payload (RAM only)."""
        parsed = parse_guild_update(data)
        if parsed is None:
            return
        self._changed(parsed[0], parsed[1], "raw gateway")

    def _changed(self, gid: int, new, via: str) -> None:
        if gid not in self.base or not self._enabled(gid):
            return
        old = self.base[gid]
        if same_code(old, new):
            self._off.pop(gid, None)                          # back to the protected code: nothing is pending any more
            return
        known = self._off.get(gid)
        if known is not None and same_code(known[0], new):
            return                                           # a difference that was already reported: not a new change
        if not self._claim((gid, "chg", canon(old), canon(new)), CLAIM_TTL):
            return
        guild = self.bot.get_guild(gid)
        if guild is None:
            return
        self.stats["changes_seen"] += 1
        spec = None
        gp = getattr(getattr(guild, "me", None), "guild_permissions", None)
        can_audit = bool(gp is not None and (gp.administrator or gp.view_audit_log))
        if self.is_fast(gid) and old is not None and can_audit:     # FAST MODE (never without View Audit Log: the owner could not be recognised): the PATCH leaves in THIS tick, before anyone is identified
            spec = self._spawn_now(self._p_restore(guild, old, "Anti Vanity | immediate restore (actor being verified)"))
        self._spawn_now(self._handle(guild, old, new, via, spec))

    @commands.Cog.listener()
    async def on_guild_update(self, before, after):
        if self._raw:
            return                                            # the raw hook already saw it; this listener is the fallback
        gid = getattr(after, "id", None)
        if gid is not None:
            self._changed(gid, getattr(after, "vanity_url_code", None), "gateway event")

    @commands.Cog.listener()
    async def on_audit_log_entry_create(self, entry):
        guild = getattr(entry, "guild", None)
        if guild is None or guild.id not in self.base or not self._enabled(guild.id):
            return
        if getattr(entry.action, "value", entry.action) != GUILD_UPDATE_ACTION:
            return
        before, after = getattr(entry, "before", None), getattr(entry, "after", None)
        old, new = getattr(before, "vanity_url_code", None), getattr(after, "vanity_url_code", None)
        if hasattr(after, "vanity_url_code") or hasattr(before, "vanity_url_code"):
            self._note_audit(guild.id, entry.id, getattr(entry, "user_id", None),
                             old if isinstance(old, str) else None, new if isinstance(new, str) else None)

    # ------------------------------------------------------------------ actor verification (audit log)
    async def _audit_match(self, guild, new) -> AuditRes:
        """WHO made this change: gateway entry first (event driven, no REST), then REST (twice: the log can be a moment behind)."""
        gid = guild.id
        try:
            def check():
                cands = [h for h in self._hints.get(gid, ()) if h[0] not in self._used]
                st, ent, why = pick_audit(cands, new, self._now())
                return (st, ent, why) if st in ("verified", "ambiguous") else None
            got = await self._wait_for(gid, check, self.hint_wait)
            via = "gateway audit entry"
            if got is None:
                for attempt in range(2):
                    rest, why = await self._audit_rest(guild)
                    via = "audit-log REST"
                    if rest is None:
                        return AuditRes("unavailable", None, via, why)
                    got = pick_audit([c for c in rest if c[0] not in self._used], new, self._now())
                    if got[0] != "none" or attempt == 1:
                        break
                    await self._sleep(self.rest_recheck)
            st, ent, why = got
            if ent is not None:
                self._mark_used(ent[0])
            return AuditRes(st, ent[1] if ent is not None else None, via, why, ent[0] if ent is not None else None)
        except Exception as exc:                              # noqa: BLE001
            log.exception("vanityguard audit match failed guild=%s", gid)
            return AuditRes("unavailable", None, "", f"internal error: {type(exc).__name__}")

    # ------------------------------------------------------------------ primitives (each re-reads before it claims ok)
    async def _p_restore(self, guild, code: Optional[str], reason: str) -> tuple:
        """Set the vanity code and confirm it.  Confirmation = Discord's own PATCH response carries the code (no extra round trip);
        a response without a code is confirmed with GET.  Serialised per guild: two edits never run at the same time."""
        if code is None:
            return "skipped", "there was no vanity code on record, nothing to put back"
        gid = guild.id
        async with self._lock(gid):
            body, via = None, ""
            res = await self._direct_set_vanity(gid, code, reason)
            if res is not None and res[0] == 200:
                body, via = res[1], "direct request"
            elif res is not None and res[0] in (400, 403, 404):
                return self._restore_refused(res[0])
            else:                                                       # no direct path / 429 / 5xx: the normal client (with retries)
                try:
                    body = await self._retry(lambda: self._http_set_vanity(gid, code, reason))
                    via = "bot.http"
                except discord.Forbidden:
                    return self._restore_refused(403)
                except discord.HTTPException as exc:
                    return self._restore_refused(getattr(exc, "status", "?"))
            now_code, how = (body.get("code") if isinstance(body, dict) and "code" in body else None), "Discord's response"
            if not (isinstance(body, dict) and "code" in body):
                try:
                    cur = await self._http_get_vanity(gid)
                except discord.HTTPException:
                    return "unverified", "Discord accepted the edit but the vanity URL could not be re-read to confirm it"
                now_code, how = (cur.get("code") if isinstance(cur, dict) else None), "re-read (GET)"
            if not same_code(now_code, code):
                return "failed", f"Discord accepted the edit but the code reads {shown(now_code)} afterwards"
        self.stats["restores"] += 1
        return "ok", f"{shown(code)} set and confirmed by {how} ({via})"

    @staticmethod
    def _restore_refused(st) -> tuple:
        if st == 403:
            return "failed", "Discord refused: I need **Manage Server** (and the server needs its vanity feature)"
        extra = " - the code was probably claimed by another server in the meantime; it must be set again by hand" if st == 400 else ""
        return "failed", f"Discord error {st}{extra}"

    async def _p_ban(self, guild, uid: int, reason: str) -> tuple:
        if self.exempt(self.classify(guild, uid)):
            return "skipped", "protected (owner / extra owner / whitelisted)"
        bgc = self.bot.get_cog("BotGuard")
        if bgc is not None:
            st, detail = await bgc._ban(guild, uid, reason)          # shares the punishment claim with the engine + botguard (no double ban)
        else:
            if not self._claim((guild.id, "ban", uid), CLAIM_TTL):
                return await self._confirm_only(guild, uid, "another incident already sent the ban; verifying it below")
            try:
                await self._retry(lambda: guild.ban(discord.Object(id=uid), reason=reason, delete_message_seconds=0))
                st, detail = "ok", "ban accepted by Discord"
            except discord.Forbidden:
                return "failed", "Discord refused the ban (Ban Members missing or the user's role is above mine)"
            except discord.HTTPException as exc:
                return "failed", f"Discord error {getattr(exc, 'status', '?')}"
        if st != "ok":
            return st, detail
        try:
            await guild.fetch_ban(discord.Object(id=uid))
        except discord.NotFound:
            return "failed", "Discord accepted the ban but fetch_ban says the user is not banned"
        except discord.HTTPException:
            return "unverified", detail + "; could not re-read the ban list to confirm"
        self.stats["bans"] += 1
        return "ok", "ban re-read from Discord (fetch_ban) and confirmed"

    async def _confirm_only(self, guild, uid: int, detail: str) -> tuple:
        for i in range(2):
            try:
                await guild.fetch_ban(discord.Object(id=uid))
                return "ok", detail + " (confirmed with fetch_ban; no second ban sent)"
            except discord.NotFound:
                if i == 0:
                    await self._sleep(1.0)
            except discord.HTTPException:
                break
        return "unverified", "another incident claimed this ban but I could not confirm it"

    async def _guard(self, factory):
        return await factory()

    # ------------------------------------------------------------------ the response
    async def _handle(self, guild, old, new, via: str, spec=None) -> None:
        try:
            await self._handle_inner(guild, old, new, via, spec)
        except Exception:
            log.exception("vanityguard handler failed guild=%s", guild.id)

    async def _spec_result(self, spec) -> tuple:
        try:
            return await spec
        except Exception as exc:                                       # noqa: BLE001
            log.exception("vanityguard speculative restore crashed")
            return "failed", f"internal error: {type(exc).__name__}"

    async def _handle_inner(self, guild, old, new, via: str, spec=None) -> None:
        gid = guild.id
        if not self._enabled(gid) or gid not in self.base:
            return
        inc = VgIncident("vanity", gid, started=self._now(), old_code=old, new_code=new, via=via,
                         trigger="vanity URL " + ("removed" if new is None else "changed"))
        inc.title = "Vanity URL " + ("removed" if new is None else "changed")

        res = await self._audit_match(guild, new)                        # who did it (gateway entry, else REST)
        creator = res.uid if res.state == "verified" else None
        cls = self.classify(guild, creator)
        inc.executor_id, inc.executor_class, inc.exec_via = creator, ("" if creator is None else cls), res.via

        if creator is not None and self.exempt(cls):                      # Owner / Extra Owner / whitelist / me: the new code is the new truth
            self.base[gid] = new                                          # RAM first: events caused by the re-apply below must not look like a change
            if spec is not None:
                self._off[gid] = (old,)                                   # sync, before any await: the old code flashing through is not a change
                sres = await self._spec_result(spec)                      # the immediate restore ran before we knew it was an authorized user
                if sres[0] != "ok":
                    self._off.pop(gid, None)                              # nothing was reverted: the owner's code is still live
                if sres[0] == "ok":
                    back = await self._p_restore(guild, new, f"Anti Vanity | re-applying the change made by {creator} ({cls})")
                    inc.add("Detect", "ok", f"GUILD_UPDATE changed the vanity code {shown(old)} -> {shown(new)} (reverted at once, actor not known yet)")
                    inc.add("Verify actor (audit log)", "ok", f"`{creator}` confirmed ({cls}) via {res.via}")
                    inc.add("Re-apply authorized change", *back)
                    if back[0] != "ok":
                        inc.add("Manual action", "failed", f"your change to {shown(new)} was reverted by the immediate restore and could NOT be "
                                "applied again. Set it in Server Settings now. (`antinuke vanity fast off` stops the immediate restore.)")
                        await self._publish(guild, inc, "Security Log - Anti Vanity", dm_owner=True)
                    await self._save_base(gid, new)
                    await self._event(gid, "vanity_authorized", creator, None, {"old": old, "new": new, "class": cls, "reapplied": back[0]})
                    return
            if spec is None:
                self._off.pop(gid, None)
            await self._save_base(gid, new)
            await self._event(gid, "vanity_authorized", creator, None, {"old": old, "new": new, "class": cls})
            log.info("vanityguard: authorized vanity change guild=%s by=%s (%s)", gid, creator, cls)
            return

        inc.add("Detect", "ok", f"GUILD_UPDATE changed the vanity code {shown(old)} -> {shown(new)}")
        if creator is None:                                              # the actor cannot be proven: it may be the owner: no ban
            why = {"ambiguous": "several users match in the audit log", "none": "no matching audit entry",
                   "unavailable": "audit log unavailable"}.get(res.state, res.state)
            inc.add("Verify actor (audit log)", "unverified", f"{why}: {res.why}")
            sres = await self._spec_result(spec) if spec is not None else None
            if sres is not None:
                inc.add("Restore vanity", *sres)
            if sres is not None and sres[0] == "ok":
                inc.add("Action", "skipped", "actor not confirmed, so nobody was banned (it may have been the owner). The old code was already put "
                        "back. If YOU changed it, set it again; if it keeps reverting run `antinuke vanity fast off`.")
            else:
                self._off[gid] = (new,)
                inc.add("Action", "skipped", "actor not confirmed, so nothing was restored and nobody was banned "
                        "(it may have been the owner). Put the old code back with `antinuke vanity restore`, or accept the new one with `antinuke vanity sync`.")
            await self._publish(guild, inc, "Security Log - Anti Vanity", dm_owner=self._claim((gid, "dm", "unknown"), DM_COOLDOWN))
            return

        inc.add("Verify actor (audit log)", "ok", f"`{creator}` confirmed for this change ({res.why}) via {res.via}")
        reason = "Anti Vanity | unauthorized vanity URL change"
        jobs = {"Restore vanity": (lambda: self._spec_result(spec)) if spec is not None else (lambda: self._p_restore(guild, old, reason)),
                "Ban actor": lambda: self._p_ban(guild, creator, reason)}
        tasks = {n: _spawn_eager(self._guard(f)) for n, f in jobs.items()}     # eager: the ban leaves in this same tick (the restore may already be done)
        results = await asyncio.gather(*tasks.values(), return_exceptions=True)
        inc.ms_action = (time.perf_counter() - inc.t0) * 1000
        restored = False
        for name, r in zip(tasks, results):
            if isinstance(r, BaseException):
                log.exception("vanityguard step %s crashed", name, exc_info=r)
                r = ("failed", f"internal error: {type(r).__name__}")
            inc.add(name, *r)
            if name == "Restore vanity" and r[0] == "ok":
                restored = True
        if restored:
            self._off.pop(gid, None)
        else:
            self._off[gid] = (new,)                                      # the unrestored code is already reported: no new incident for it
            inc.add("Manual action", "failed" if old is not None else "skipped",
                    "the vanity URL is NOT back. Run `antinuke vanity restore` (or set it in Server Settings) as soon as possible."
                    if old is not None else "no previous code on record")
        await self._event(gid, "vanity_incident", creator, None, {"old": old, "new": new, "restored": restored})
        await self._publish(guild, inc, "Security Log - Anti Vanity", dm_owner=self._claim((gid, "dm", creator), DM_COOLDOWN))

    # ------------------------------------------------------------------ reporting
    def _channel(self, guild):
        cfg = store.peek(guild.id)
        return guild.get_channel(cfg.log) if cfg is not None and cfg.log else None

    async def _publish(self, guild, inc: VgIncident, header: str, dm_owner: bool = True) -> None:
        self.stats["incidents"] += 1
        inc.ms = (time.perf_counter() - inc.t0) * 1000
        channel = self._channel(guild)
        dm_task = asyncio.ensure_future(self._dm_owner(guild, render_vg(inc, header + f" ({guild.name})", now=self._now()))) if dm_owner else None
        sent = False
        if channel is not None:
            try:
                from utils import antinuke_ui as ui
            except Exception:
                ui = None
            try:
                if ui is not None:
                    await channel.send(view=ui.view_of(ui.text(render_vg(inc, header, ok=ui.OK, no=ui.NO, now=self._now()))), allowed_mentions=ui.NO_PING)
                else:
                    await channel.send(content=render_vg(inc, header, now=self._now())[:1990], allowed_mentions=discord.AllowedMentions.none())
                sent = True
            except (discord.Forbidden, discord.HTTPException):
                sent = False
        if dm_task is not None:
            ok = await dm_task
            inc.add("Notify owner", "ok" if ok else "failed", "DM delivered" if ok else "could not DM the owner (DMs closed)" + ("; see log channel" if channel else ""))
        log.info("vanityguard incident guild=%s old=%s new=%s actor=%s ts=%s log_channel=%s steps=%s", guild.id, inc.old_code, inc.new_code,
                 inc.executor_id, int(self._now()), "sent" if sent else "unavailable", [(s.name, s.status) for s in inc.steps])

    async def _dm_owner(self, guild, text: str) -> bool:
        try:
            user = self.bot.get_user(guild.owner_id) or await self.bot.fetch_user(guild.owner_id)
            await user.send(content=text[:1990], allowed_mentions=discord.AllowedMentions.none())
            return True
        except (discord.Forbidden, discord.HTTPException):
            return False

    # ------------------------------------------------------------------ startup: a change made while the bot was offline
    async def _sync_guild(self, guild) -> None:
        gid = guild.id
        if not self._enabled(gid):
            return
        live = getattr(guild, "vanity_url_code", None)
        if gid not in self.base:
            await self._save_base(gid, live)
            return
        if same_code(self.base[gid], live) or (gid in self._off and same_code(self._off[gid][0], live)):
            return
        if not self._claim((gid, "offline", canon(live)), CLAIM_TTL):
            return
        self._off[gid] = (live,)
        inc = VgIncident("vanity", gid, started=self._now(), old_code=self.base[gid], new_code=live,
                         trigger="the vanity code differs from the protected one (changed while I was offline)", via="startup check")
        inc.title = "Vanity URL differs from the protected code"
        inc.add("Detect", "ok", f"protected {shown(self.base[gid])}, server has {shown(live)}")
        inc.add("Action", "skipped", "nobody can prove who changed it while I was offline: nothing restored, nobody banned. "
                "Use `antinuke vanity restore` to put the protected code back, or `antinuke vanity sync` to accept the current one.")
        await self._publish(guild, inc, "Security Log - Anti Vanity", dm_owner=self._claim((gid, "dm", "offline"), DM_COOLDOWN))

    async def _sync_all(self) -> None:
        for g in list(self.bot.guilds):
            try:
                await self._sync_guild(g)
            except Exception:
                log.exception("vanityguard startup check failed guild=%s", getattr(g, "id", "?"))

    @commands.Cog.listener()
    async def on_ready(self):
        self._spawn(self._sync_all())

    # ------------------------------------------------------------------ owner commands
    async def restore_now(self, guild, by: int) -> tuple:
        """`antinuke vanity restore`: put the protected code back.  -> (status, detail)"""
        gid = guild.id
        if gid not in self.base or self.base[gid] is None:
            return "failed", "no protected vanity code on record (turn Anti Vanity on while the server has its vanity set)"
        code = self.base[gid]
        if same_code(getattr(guild, "vanity_url_code", None), code):
            self._off.pop(gid, None)
            return "ok", f"the server already uses {shown(code)}"
        st, detail = await self._p_restore(guild, code, f"Anti Vanity: restored by {by}")
        if st == "ok":
            self._off.pop(gid, None)
            await self._event(gid, "vanity_restored", by, None, {"code": code})
        return st, detail

    async def sync_now(self, guild, by: int) -> tuple:
        """`antinuke vanity sync`: accept the code the server has right now as the protected one."""
        gid = guild.id
        if gid not in self.base:
            return "failed", "Anti Vanity is off for this server"
        try:
            cur = await self._http_get_vanity(gid)
            live = cur.get("code") if isinstance(cur, dict) else None
        except discord.HTTPException:
            live = getattr(guild, "vanity_url_code", None)
        await self._save_base(gid, live)
        self._off.pop(gid, None)
        await self._event(gid, "vanity_synced", by, None, {"code": live})
        return "ok", f"protected code is now {shown(live)}"

    def status_info(self, guild) -> dict:
        gp = guild.me.guild_permissions
        full = gp.administrator
        gid = guild.id
        return {"on": self.flag(gid), "engine": bool(store.get(gid).enabled),
                "audit": full or gp.view_audit_log, "manage_guild": full or gp.manage_guild, "ban": full or gp.ban_members,
                "raw_hook": bool(self._raw), "protected": self.base.get(gid), "tracked": gid in self.base,
                "pending": gid in self._off, "live": getattr(guild, "vanity_url_code", None),
                "changes_seen": self.stats["changes_seen"], "restores": self.stats["restores"],
                "fast": self.is_fast(gid), "direct": self._d is not None}
