"""Automod engine (port of Lune's ``handleExecution`` + rule events).

Discord itself scans the messages (native AutoMod rules).  This cog only reacts to what Discord reports:

* ``on_automod_action``       -> violation log, daily stats, escalation (5 hits / 10 min = 1 h timeout),
                                  moderator notice in the log channel, optional DM to the offender.
* ``on_automod_rule_update``  -> keeps the local state of a rule in sync when someone edits it in Discord.
* ``on_automod_rule_delete``  -> marks the rule ``pending`` again (press *Sync Rules to Discord*).

Needs the ``automod_configuration`` + ``automod_execution`` intents (``Intents.all()`` already has them) and
the *Manage Server* permission for the bot.
"""
from __future__ import annotations

import asyncio
import time
from datetime import timedelta
from typing import Dict, Optional, Set

import discord
from discord.ext import commands, tasks

from utils.automod_core import (
    DEDUPE_SECONDS, ESCALATION_COUNT, ESCALATION_TIMEOUT, ESCALATION_WINDOW, RULE_TYPES, TRIGGER_TO_TYPE,
)

from .store import AutomodManager, get_store

NO_PING = discord.AllowedMentions.none()


class AutomodEngine(commands.Cog):
    """Listens to Discord's AutoMod gateway events."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.store: AutomodManager = get_store(bot)
        self._seen: Dict[tuple, float] = {}        # incident key -> monotonic ts (alert + block count once)
        self._tasks: Set[asyncio.Task] = set()

    # ------------------------------------------------------------ lifecycle
    async def cog_load(self) -> None:
        await self.store.start()
        self._cleanup.start()

    async def cog_unload(self) -> None:
        self._cleanup.cancel()
        await self.store.close()

    @tasks.loop(minutes=2)
    async def _cleanup(self) -> None:
        now = time.monotonic()
        for key in [k for k, ts in self._seen.items() if now - ts > 30]:
            self._seen.pop(key, None)

    def _spawn(self, coro) -> None:
        task = asyncio.create_task(coro)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    # ------------------------------------------------------------ helpers
    @staticmethod
    def _action_name(action_type: discord.AutoModRuleActionType) -> str:
        if action_type is discord.AutoModRuleActionType.timeout:
            return "timeout"
        if action_type is discord.AutoModRuleActionType.send_alert_message:
            return "alert"
        return "block"

    async def _send_log(self, guild: discord.Guild, content: str) -> None:
        channel_id = self.store.guild(guild.id).log_channel
        channel = guild.get_channel(channel_id) if channel_id else None
        if channel is None or not hasattr(channel, "send"):
            return
        try:
            await channel.send(content, allowed_mentions=NO_PING)
        except discord.HTTPException:
            pass

    async def _escalate(self, guild: discord.Guild, member: Optional[discord.Member], user_id: int) -> bool:
        """5 violations within 10 minutes -> 1 hour timeout (never for admins / unmoderatable members)."""
        if not self.store.guild(guild.id).escalation:
            return False
        if await self.store.count_violations(guild.id, user_id, ESCALATION_WINDOW) < ESCALATION_COUNT:
            return False
        if member is None:
            try:
                member = await guild.fetch_member(user_id)
            except discord.HTTPException:
                return False
        me = guild.me
        if (member.guild_permissions.administrator or member.id == guild.owner_id or me is None
                or not me.guild_permissions.moderate_members or me.top_role <= member.top_role):
            return False
        try:
            await member.timeout(timedelta(seconds=ESCALATION_TIMEOUT), reason="AutoMod: repeated violations")
        except discord.HTTPException:
            return False
        return True

    # ------------------------------------------------------------ execution
    @commands.Cog.listener()
    async def on_automod_action(self, execution: discord.AutoModAction) -> None:
        try:
            await self._handle_execution(execution)
        except Exception as exc:                      # never let a listener crash the bot
            print(f"[AutoMod] execution handler error: {exc!r}")

    async def _handle_execution(self, execution: discord.AutoModAction) -> None:
        guild = execution.guild
        if guild is None or not self.store.is_enabled(guild.id):
            return

        user_id = execution.user_id
        rule = self.store.find_by_discord_id(guild.id, execution.rule_id)
        rule_type = rule.type if rule else TRIGGER_TO_TYPE.get(execution.rule_trigger_type, "keyword")
        rule_name = rule.name if rule else RULE_TYPES[rule_type]["label"]
        action = self._action_name(execution.action.type)

        # Stats count every executed action (blocked / timeouts / alerts) ...
        await self.store.record_stat(guild.id, action)

        # ... but alert + block of the SAME message are one violation (escalation, notice, DM once).
        now = time.monotonic()
        key = (guild.id, user_id, execution.rule_id, execution.channel_id, execution.content or "")
        last = self._seen.get(key)
        self._seen[key] = now
        if last is not None and now - last < DEDUPE_SECONDS:
            return

        await self.store.add_violation(guild.id, user_id, str(rule.discord_id if rule else execution.rule_id),
                                       rule_name, execution.channel_id, action)

        escalated = await self._escalate(guild, execution.member, user_id)
        if escalated and action != "timeout":
            self._spawn(self._send_log(
                guild, f"**AutoMod Escalation** — <@{user_id}> was timed out for repeated violations."))

        cfg = self.store.guild(guild.id)
        if cfg.notifications:
            self._spawn(self._send_log(guild, f"**AutoMod** — <@{user_id}> flagged ({rule_type}: {action})."))
        if cfg.dm:
            self._spawn(self._dm(execution, guild, rule_type))

    async def _dm(self, execution: discord.AutoModAction, guild: discord.Guild, rule_type: str) -> None:
        user = execution.member or self.bot.get_user(execution.user_id)
        if user is None:
            return
        try:
            await user.send(f"Your message in **{guild.name}** was flagged by AutoMod ({rule_type}).")
        except discord.HTTPException:
            pass

    # ------------------------------------------------------------ rule events
    @commands.Cog.listener()
    async def on_automod_rule_update(self, rule: discord.AutoModRule) -> None:
        try:
            await self.store.on_rule_updated(rule.guild.id, rule.id, rule.enabled)
        except Exception as exc:
            print(f"[AutoMod] rule update handler error: {exc!r}")

    @commands.Cog.listener()
    async def on_automod_rule_delete(self, rule: discord.AutoModRule) -> None:
        try:
            await self.store.on_rule_deleted(rule.guild.id, rule.id)
        except Exception as exc:
            print(f"[AutoMod] rule delete handler error: {exc!r}")

    @commands.Cog.listener()
    async def on_guild_remove(self, guild: discord.Guild) -> None:
        try:
            await self.store.drop(guild.id)
        except Exception:
            pass
