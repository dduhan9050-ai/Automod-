"""Automod store + manager (port of Lune's ``AutoModManager.js`` + its SQLite tables).

* Per-guild settings and the 4 rule definitions live in RAM (write-through cache over SQLite,
  ``db/automod.db``).  Violations and daily stats are written to SQLite and read on demand
  (dashboard only).
* The manager creates / edits / deletes the *native Discord AutoMod rules* of a guild
  (``Guild.create_automod_rule`` ...), exactly like Lune's "Sync Rules to Discord".

Tables (same names as Lune): guild_automod, automod_rules, automod_violations, automod_stats.
The old ``am_*`` tables of the previous heat-based automod are not touched.
"""
from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional

import aiosqlite
import discord

from utils.automod_core import (
    DEFAULT_KEYWORDS, DEFAULT_MENTION_LIMIT, MAX_EXEMPT_CHANNELS, MAX_EXEMPT_ROLES, MODES, RULE_TYPES,
    TIMEOUT_TYPES, TYPES, VIOLATION_KEEP_DAYS, clamp_timeout, default_action_config,
)

DB_PATH = "db/automod.db"


def _iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _today() -> str:
    return datetime.now(timezone.utc).date().isoformat()


class GuildCfg:
    __slots__ = ("guild_id", "enabled", "log_channel", "notifications", "dm", "escalation")

    def __init__(self, guild_id: int) -> None:
        self.guild_id = guild_id
        self.enabled = True              # Lune default
        self.log_channel: Optional[int] = None
        self.notifications = True
        self.dm = False
        self.escalation = True


class Rule:
    __slots__ = ("guild_id", "type", "name", "discord_id", "enabled", "state", "action",
                 "exempt_roles", "exempt_channels", "error")

    def __init__(self, guild_id: int, rtype: str, name: str, action: dict) -> None:
        self.guild_id = guild_id
        self.type = rtype
        self.name = name
        self.discord_id: Optional[int] = None
        self.enabled = True
        self.state = "pending"
        self.action = action
        self.exempt_roles: List[int] = []
        self.exempt_channels: List[int] = []
        self.error: Optional[str] = None     # last Discord error (memory only)

    @property
    def mode(self) -> str:
        mode = self.action.get("mode", "block")
        return mode if mode in MODES else "block"


class AutomodManager:
    def __init__(self, bot=None) -> None:
        self.bot = bot
        self.db: Optional[aiosqlite.Connection] = None
        self.guilds: Dict[int, GuildCfg] = {}
        self.rules: Dict[int, Dict[str, Rule]] = {}
        self._lock = asyncio.Lock()
        self._start_lock = asyncio.Lock()
        self._apply_locks: Dict[int, asyncio.Lock] = {}

    # ------------------------------------------------------------------ naming
    @property
    def bot_name(self) -> str:
        user = getattr(self.bot, "user", None)
        return getattr(user, "name", None) or "Luna"

    # ------------------------------------------------------------------ lifecycle
    async def start(self) -> None:
        async with self._start_lock:
            if self.db is not None:
                return
            db = await aiosqlite.connect(DB_PATH)
            await db.execute("PRAGMA journal_mode=WAL")
            await db.execute("PRAGMA synchronous=NORMAL")
            await db.executescript(
                """
                CREATE TABLE IF NOT EXISTS guild_automod (
                    guildId TEXT PRIMARY KEY,
                    enabled INTEGER DEFAULT 1,
                    logChannelId TEXT,
                    notificationsEnabled INTEGER DEFAULT 1,
                    notificationDuration INTEGER DEFAULT 5000,
                    dmEnabled INTEGER DEFAULT 0,
                    escalationEnabled INTEGER DEFAULT 1,
                    updatedAt TEXT
                );
                CREATE TABLE IF NOT EXISTS automod_rules (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guildId TEXT,
                    discordRuleId TEXT,
                    type TEXT,
                    name TEXT,
                    enabled INTEGER DEFAULT 1,
                    state TEXT DEFAULT 'pending',
                    actionConfig TEXT,
                    exemptRoles TEXT,
                    exemptChannels TEXT,
                    createdAt TEXT,
                    updatedAt TEXT
                );
                CREATE UNIQUE INDEX IF NOT EXISTS idx_automod_rules_guild_type ON automod_rules (guildId, type);
                CREATE INDEX IF NOT EXISTS idx_automod_rules_discordId ON automod_rules (discordRuleId);
                CREATE TABLE IF NOT EXISTS automod_violations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guildId TEXT,
                    userId TEXT,
                    ruleId TEXT,
                    ruleName TEXT,
                    channelId TEXT,
                    action TEXT,
                    createdAt TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_automod_violations_guild ON automod_violations (guildId, createdAt);
                CREATE INDEX IF NOT EXISTS idx_automod_violations_user ON automod_violations (guildId, userId, createdAt);
                CREATE TABLE IF NOT EXISTS automod_stats (
                    guildId TEXT,
                    date TEXT,
                    blocked INTEGER DEFAULT 0,
                    warnings INTEGER DEFAULT 0,
                    timeouts INTEGER DEFAULT 0,
                    alerts INTEGER DEFAULT 0,
                    PRIMARY KEY (guildId, date)
                );
                """
            )
            cutoff = (datetime.now(timezone.utc) - timedelta(days=VIOLATION_KEEP_DAYS)).isoformat()
            await db.execute("DELETE FROM automod_violations WHERE createdAt < ?", (cutoff,))
            await db.commit()
            self.db = db
            await self._load()

    async def close(self) -> None:
        if self.db is not None:
            await self.db.close()
            self.db = None

    async def _load(self) -> None:
        guilds: Dict[int, GuildCfg] = {}
        rules: Dict[int, Dict[str, Rule]] = {}
        async with self.db.execute(
            "SELECT guildId, enabled, logChannelId, notificationsEnabled, dmEnabled, escalationEnabled "
            "FROM guild_automod"
        ) as cur:
            async for gid, en, log, notif, dm, esc in cur:
                cfg = GuildCfg(int(gid))
                cfg.enabled, cfg.notifications, cfg.dm, cfg.escalation = bool(en), bool(notif), bool(dm), bool(esc)
                cfg.log_channel = int(log) if log else None
                guilds[cfg.guild_id] = cfg
        async with self.db.execute(
            "SELECT guildId, type, name, discordRuleId, enabled, state, actionConfig, exemptRoles, exemptChannels "
            "FROM automod_rules ORDER BY id ASC"
        ) as cur:
            async for gid, typ, name, did, en, state, action, roles, chans in cur:
                if typ not in RULE_TYPES:
                    continue
                rule = Rule(int(gid), typ, name or RULE_TYPES[typ]["label"], {})
                rule.discord_id = int(did) if did else None
                rule.enabled = bool(en)
                rule.state = (state or "pending").lower()
                try:
                    rule.action = json.loads(action) if action else default_action_config(self.bot_name)
                    rule.exempt_roles = [int(x) for x in json.loads(roles)] if roles else []
                    rule.exempt_channels = [int(x) for x in json.loads(chans)] if chans else []
                except (ValueError, TypeError):
                    rule.action = default_action_config(self.bot_name)
                if rule.state == "loading":      # crashed mid-sync
                    rule.state = "pending"
                rules.setdefault(rule.guild_id, {})[typ] = rule
        self.guilds, self.rules = guilds, rules

    async def _write(self, sql: str, params: tuple = ()) -> None:
        if self.db is None:
            return
        async with self._lock:
            await self.db.execute(sql, params)
            await self.db.commit()

    # ------------------------------------------------------------------ guild settings
    def guild(self, guild_id: int) -> GuildCfg:
        """In-RAM settings (created with Lune's defaults the first time; saved on first change)."""
        cfg = self.guilds.get(guild_id)
        if cfg is None:
            cfg = self.guilds[guild_id] = GuildCfg(guild_id)
        return cfg

    def is_enabled(self, guild_id: int) -> bool:
        return self.guild(guild_id).enabled

    async def save_guild(self, guild_id: int) -> None:
        cfg = self.guild(guild_id)
        await self._write(
            """INSERT INTO guild_automod (guildId, enabled, logChannelId, notificationsEnabled,
                   notificationDuration, dmEnabled, escalationEnabled, updatedAt)
               VALUES (?, ?, ?, ?, 5000, ?, ?, ?)
               ON CONFLICT(guildId) DO UPDATE SET enabled=excluded.enabled, logChannelId=excluded.logChannelId,
                   notificationsEnabled=excluded.notificationsEnabled, dmEnabled=excluded.dmEnabled,
                   escalationEnabled=excluded.escalationEnabled, updatedAt=excluded.updatedAt""",
            (str(guild_id), int(cfg.enabled), str(cfg.log_channel) if cfg.log_channel else None,
             int(cfg.notifications), int(cfg.dm), int(cfg.escalation), _iso()))

    # ------------------------------------------------------------------ rule definitions
    def get_rules(self, guild_id: int) -> Dict[str, Rule]:
        return self.rules.setdefault(guild_id, {})

    async def ensure_rules(self, guild_id: int) -> bool:
        """Create the 4 local rule definitions (state ``pending``) when missing."""
        rules = self.get_rules(guild_id)
        created = False
        for typ, definition in RULE_TYPES.items():
            if typ not in rules:
                rules[typ] = Rule(guild_id, typ, f"{self.bot_name} · {definition['label']}",
                                  default_action_config(self.bot_name))
                await self.persist_rule(rules[typ])
                created = True
        return created

    async def persist_rule(self, rule: Rule) -> None:
        now = _iso()
        await self._write(
            """INSERT INTO automod_rules (guildId, discordRuleId, type, name, enabled, state, actionConfig,
                   exemptRoles, exemptChannels, createdAt, updatedAt)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(guildId, type) DO UPDATE SET discordRuleId=excluded.discordRuleId, name=excluded.name,
                   enabled=excluded.enabled, state=excluded.state, actionConfig=excluded.actionConfig,
                   exemptRoles=excluded.exemptRoles, exemptChannels=excluded.exemptChannels,
                   updatedAt=excluded.updatedAt""",
            (str(rule.guild_id), str(rule.discord_id) if rule.discord_id else None, rule.type, rule.name,
             int(rule.enabled), rule.state, json.dumps(rule.action),
             json.dumps(rule.exempt_roles), json.dumps(rule.exempt_channels), now, now))

    def find_by_discord_id(self, guild_id: int, discord_id: int) -> Optional[Rule]:
        for rule in self.get_rules(guild_id).values():
            if rule.discord_id == discord_id:
                return rule
        return None

    # ------------------------------------------------------------------ Discord payloads
    def effective_mode(self, rule: Rule) -> str:
        """Discord allows the Timeout action on keyword + mention-spam rules only."""
        mode = rule.mode
        if mode == "timeout" and rule.type not in TIMEOUT_TYPES:
            return "block"
        return mode

    def build_trigger(self, rule: Rule) -> discord.AutoModTrigger:
        cfg = rule.action
        if rule.type == "keyword":
            keywords = [k for k in (cfg.get("keywords") or []) if k] or list(DEFAULT_KEYWORDS)
            regex = [r for r in str(cfg.get("regex") or "").split("\n") if r.strip()][:10]
            return discord.AutoModTrigger(
                type=discord.AutoModRuleTriggerType.keyword,
                keyword_filter=keywords[:1000],
                regex_patterns=regex,
                allow_list=(cfg.get("allowlist") or [])[:100])
        if rule.type == "spam":
            return discord.AutoModTrigger(type=discord.AutoModRuleTriggerType.spam)
        if rule.type == "mention":
            limit = int(cfg.get("mentionLimit") or DEFAULT_MENTION_LIMIT)
            return discord.AutoModTrigger(
                type=discord.AutoModRuleTriggerType.mention_spam,
                mention_limit=max(1, min(limit, 50)),
                mention_raid_protection=bool(cfg.get("raidProtection")))
        return discord.AutoModTrigger(
            type=discord.AutoModRuleTriggerType.keyword_preset,
            presets=discord.AutoModPresets(profanity=True, sexual_content=True, slurs=True),
            allow_list=(cfg.get("allowlist") or [])[:1000])

    def build_actions(self, rule: Rule, alert_channel: Optional[int]) -> List[discord.AutoModRuleAction]:
        cfg = rule.action
        actions: List[discord.AutoModRuleAction] = []
        if alert_channel:
            actions.append(discord.AutoModRuleAction(
                type=discord.AutoModRuleActionType.send_alert_message, channel_id=alert_channel))
        mode = self.effective_mode(rule)
        if mode == "timeout":
            actions.append(discord.AutoModRuleAction(
                type=discord.AutoModRuleActionType.timeout,
                duration=timedelta(seconds=clamp_timeout(cfg.get("timeoutSeconds")))))
        elif mode == "block":
            message = (cfg.get("customMessage") or default_action_config(self.bot_name)["customMessage"])[:150]
            actions.append(discord.AutoModRuleAction(
                type=discord.AutoModRuleActionType.block_message, custom_message=message))
        return actions

    @staticmethod
    def _objs(ids: List[int]) -> List[discord.Object]:
        return [discord.Object(id=i) for i in ids]

    # ------------------------------------------------------------------ Discord sync
    def _apply_lock(self, guild_id: int) -> asyncio.Lock:
        return self._apply_locks.setdefault(guild_id, asyncio.Lock())

    async def apply_rule(self, guild: discord.Guild, rule: Rule) -> Rule:
        """Create or update the native rule (Lune ``applyRule``)."""
        async with self._apply_lock(guild.id):
            rule.state = "loading"
            rule.error = None
            alert_channel = self.guild(guild.id).log_channel
            actions = self.build_actions(rule, alert_channel)
            if not actions:
                rule.state = "error"
                rule.error = "Alert only needs a log channel: set one in Settings first."
                await self.persist_rule(rule)
                return rule
            trigger = self.build_trigger(rule)
            roles, channels = self._objs(rule.exempt_roles[:MAX_EXEMPT_ROLES]), self._objs(
                rule.exempt_channels[:MAX_EXEMPT_CHANNELS])
            reason = f"{self.bot_name} AutoMod"
            try:
                existing = None
                if rule.discord_id:
                    try:
                        existing = await guild.fetch_automod_rule(rule.discord_id)
                    except discord.NotFound:
                        rule.discord_id = None
                if existing is not None:
                    await existing.edit(name=rule.name, trigger=trigger, actions=actions, enabled=rule.enabled,
                                        exempt_roles=roles, exempt_channels=channels, reason=reason)
                else:
                    created = await guild.create_automod_rule(
                        name=rule.name, event_type=discord.AutoModRuleEventType.message_send, trigger=trigger,
                        actions=actions, enabled=rule.enabled, exempt_roles=roles, exempt_channels=channels,
                        reason=reason)
                    rule.discord_id = created.id
                rule.state = "ready" if rule.enabled else "disabled"
            except discord.Forbidden:
                rule.state, rule.error = "error", "I need the Manage Server permission."
            except discord.HTTPException as exc:
                rule.state, rule.error = "error", (getattr(exc, "text", None) or str(exc))[:200]
            await self.persist_rule(rule)
            return rule

    async def provision(self, guild: discord.Guild) -> None:
        """Lune ``provision``: create every rule that is not ready yet."""
        await self.ensure_rules(guild.id)
        for rule in list(self.get_rules(guild.id).values()):
            if rule.state == "ready":
                continue
            await self.apply_rule(guild, rule)

    async def resync_provisioned(self, guild: discord.Guild) -> None:
        """Push settings that are baked into the Discord rules (alert channel) to every created rule."""
        for rule in list(self.get_rules(guild.id).values()):
            if rule.discord_id:
                await self.apply_rule(guild, rule)

    async def toggle_rule(self, guild: discord.Guild, typ: str, enabled: bool) -> Rule:
        rule = self.get_rules(guild.id)[typ]
        rule.enabled = enabled
        if not rule.discord_id:
            rule.state = "pending"
            await self.persist_rule(rule)
            return rule
        return await self.apply_rule(guild, rule)

    async def update_rule_config(self, guild: discord.Guild, typ: str, **cfg) -> Rule:
        rule = self.get_rules(guild.id)[typ]
        rule.action = {**rule.action, **cfg}
        await self.persist_rule(rule)
        if rule.discord_id:
            return await self.apply_rule(guild, rule)
        return rule

    async def set_exempt(self, guild: discord.Guild, typ: str, *, roles: Optional[List[int]] = None,
                         channels: Optional[List[int]] = None) -> Rule:
        rule = self.get_rules(guild.id)[typ]
        if roles is not None:
            rule.exempt_roles = roles[:MAX_EXEMPT_ROLES]
        if channels is not None:
            rule.exempt_channels = channels[:MAX_EXEMPT_CHANNELS]
        await self.persist_rule(rule)
        if rule.discord_id:
            return await self.apply_rule(guild, rule)
        return rule

    async def delete_rule(self, guild: discord.Guild, typ: str) -> None:
        rule = self.get_rules(guild.id).pop(typ, None)
        if rule is None:
            return
        if rule.discord_id:
            try:
                await (await guild.fetch_automod_rule(rule.discord_id)).delete(reason=f"{self.bot_name} AutoMod")
            except discord.HTTPException:
                pass
        await self._write("DELETE FROM automod_rules WHERE guildId = ? AND type = ?", (str(guild.id), typ))

    # ------------------------------------------------------------------ gateway rule events
    async def on_rule_deleted(self, guild_id: int, discord_id: int) -> None:
        rule = self.find_by_discord_id(guild_id, discord_id)
        if rule is None:
            return
        rule.discord_id, rule.state = None, "pending"
        await self.persist_rule(rule)

    async def on_rule_updated(self, guild_id: int, discord_id: int, enabled: bool) -> None:
        rule = self.find_by_discord_id(guild_id, discord_id)
        if rule is None or rule.state == "loading":
            return
        state = "ready" if enabled else "disabled"
        if rule.enabled != enabled or rule.state != state:
            rule.enabled, rule.state = enabled, state
            await self.persist_rule(rule)

    # ------------------------------------------------------------------ violations + stats
    async def add_violation(self, guild_id: int, user_id: int, rule_id: str, rule_name: str,
                            channel_id: Optional[int], action: str) -> None:
        await self._write(
            "INSERT INTO automod_violations (guildId, userId, ruleId, ruleName, channelId, action, createdAt) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (str(guild_id), str(user_id), str(rule_id), rule_name, str(channel_id) if channel_id else None,
             action, _iso()))

    async def record_stat(self, guild_id: int, action: str) -> None:
        col = {"block": "blocked", "timeout": "timeouts", "warn": "warnings"}.get(action, "alerts")
        await self._write(
            f"""INSERT INTO automod_stats (guildId, date, {col}) VALUES (?, ?, 1)
                ON CONFLICT(guildId, date) DO UPDATE SET {col} = {col} + 1""",
            (str(guild_id), _today()))

    async def count_violations(self, guild_id: int, user_id: int, window_seconds: int) -> int:
        if self.db is None:
            return 0
        since = (datetime.now(timezone.utc) - timedelta(seconds=window_seconds)).isoformat()
        async with self._lock:
            async with self.db.execute(
                "SELECT COUNT(*) FROM automod_violations WHERE guildId = ? AND userId = ? AND createdAt >= ?",
                (str(guild_id), str(user_id), since)) as cur:
                row = await cur.fetchone()
        return int(row[0]) if row else 0

    async def get_stats(self, guild_id: int, days: int = 7) -> dict:
        out = {"blocked": 0, "warnings": 0, "timeouts": 0, "alerts": 0}
        if self.db is None:
            return out
        since = (datetime.now(timezone.utc) - timedelta(days=days)).date().isoformat()
        async with self._lock:
            async with self.db.execute(
                "SELECT COALESCE(SUM(blocked),0), COALESCE(SUM(warnings),0), COALESCE(SUM(timeouts),0), "
                "COALESCE(SUM(alerts),0) FROM automod_stats WHERE guildId = ? AND date >= ?",
                (str(guild_id), since)) as cur:
                row = await cur.fetchone()
        if row:
            out = dict(zip(("blocked", "warnings", "timeouts", "alerts"), (int(x) for x in row)))
        return out

    async def get_violations(self, guild_id: int, limit: int = 20) -> List[dict]:
        if self.db is None:
            return []
        async with self._lock:
            async with self.db.execute(
                "SELECT userId, ruleName, action, createdAt FROM automod_violations "
                "WHERE guildId = ? ORDER BY createdAt DESC LIMIT ?", (str(guild_id), limit)) as cur:
                rows = await cur.fetchall()
        out = []
        for uid, name, action, created in rows:
            try:
                ts = int(datetime.fromisoformat(created).timestamp())
            except (TypeError, ValueError):
                ts = int(time.time())
            out.append({"user_id": int(uid), "rule": name, "action": action, "ts": ts})
        return out

    async def drop(self, guild_id: int) -> None:
        """Forget a guild completely (bot removed)."""
        self.guilds.pop(guild_id, None)
        self.rules.pop(guild_id, None)
        for table in ("guild_automod", "automod_rules", "automod_violations", "automod_stats"):
            await self._write(f"DELETE FROM {table} WHERE guildId = ?", (str(guild_id),))


# Names kept from the previous module so every import keeps working.
AutomodStore = AutomodManager


def get_store(bot) -> AutomodManager:
    """The single manager shared by the commands cog and the engine."""
    store = getattr(bot, "automod_store", None)
    if store is None:
        store = bot.automod_store = AutomodManager(bot)
    return store
