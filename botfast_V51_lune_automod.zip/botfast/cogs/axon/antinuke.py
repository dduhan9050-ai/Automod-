import discord
from discord.ext import commands


class _antinuke(commands.Cog):
    """Help-menu category: Security (antinuke + mainrole)."""

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        emoji = "<a:emoji_71:1567130056093077665>"  # <a:emoji_71:1567130056093077665>
        label = "Security"
        description = "Antinuke, Mainrole, Nightmode & Emergency"
        return emoji, label, description

    def _names(self, group_name: str) -> str:
        """`antinuke`, `antinuke enable`, ... generated from the live command tree."""
        group = self.bot.get_command(group_name)
        if group is None:
            return ""
        names = [group.qualified_name]
        names += [c.qualified_name for c in getattr(group, "walk_commands", lambda: [])() if not c.hidden]
        return ", ".join(f"`{n}`" for n in names)

    def help_body(self, prefix: str = "") -> str:
        emg = ", ".join(x for x in (self._names('emergency'), "`emergencysituation`, `emergencyrestore`") if x)
        return (f"__**Antinuke**__\n{self._names('antinuke')}\n\n"
                f"__**Anti Bot Nuker**__\n`antinuke integration on|off|status` - bot role permission / position protection + recovery\n\n"
                f"__**Bot Add Protection**__\n`antinuke botadd on|off|status`, `antinuke extraowner add|remove|list`\n\n"
                f"__**Anti-Onboarding**__\n`antinuke onboarding on|off|status|scan|clean`, `antinuke onboarding trust add|remove|list`\n\n"
                f"__**Anti Invite Role**__\n`antinuke inviterole on|off|status|scan|sweep|restore`\n\n"
                f"__**Anti Vanity**__\n`antinuke vanity on|off|status|restore|sync|fast`\n\n"
                f"__**Mainrole**__\n{self._names('mainrole')}\n\n"
                f"__**Nightmode**__\n{self._names('nightmode')}\n\n"
                f"__**Emergency**__\n{emg}")
