import discord
from discord.ext import commands

# Order = order of the "Automod" page in the help menu.
AUTOMOD_HELP_COMMANDS = (
    "automod", "automod overview", "automod modules", "automod rules", "automod stats", "automod logs",
)


class _automod(commands.Cog):
    """Help-menu category: Automod."""

    # The module page in the help menu stays plain (no white accent bar):
    # #ffffff is only used for the command replies themselves.
    help_plain = True

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        emoji = "<:521449_bot:1567119077330133122>"  # <:521449_bot:1567119077330133122>
        label = "Automod"
        description = "Advance Automod Commands"
        return emoji, label, description

    def help_body(self, prefix: str = "") -> str:
        auto = ", ".join(f"`{name}`" for name in AUTOMOD_HELP_COMMANDS)
        return (f"__**Automod**__\n{auto}\n\n"
                "Native Discord AutoMod rules (keyword, spam, mention spam, profanity) managed from one "
                "dashboard. Also available as slash commands: `/automod`.")
