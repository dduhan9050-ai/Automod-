import discord
from discord.ext import commands

AUTORESPONDER_COMMANDS = (
    "autoresponder",
    "autoresponder create",
    "autoresponder delete",
    "autoresponder edit",
    "autoresponder config",
)

AUTOREACT_COMMANDS = (
    "react",
    "react add",
    "react remove",
    "react list",
    "react reset",
)


def _line(names) -> str:
    return ", ".join(f"`{name}`" for name in names)


class _autoresponder(commands.Cog):
    """Help-menu category: Autoresponder"""

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        emoji = "<:emoji_19:1566458847613419591>"  # <:emoji_19:1566458847613419591>
        label = "Autoresponder"
        description = "Show you Commands of Autoresponder"
        return emoji, label, description

    def help_body(self, prefix: str = "") -> str:
        """Page shown in the help menu (same layout as the reference bot)."""
        return (
            f"__Autoresponder__\n{_line(AUTORESPONDER_COMMANDS)}\n\n"
            f"__Autoreact__\n{_line(AUTOREACT_COMMANDS)}"
        )
