from discord.ext import commands

from utils.grouphelp import entry_text, ordered

# (group name, heading, sub-command order)
OWNER_GROUPS = (
    ("premium", "Premium", ["list", "add", "activate", "revoke", "remove", "status"]),
    ("team", "Bot Team", ["list", "add", "remove"]),
    ("tempblock", "Temporary Blacklist", ["list", "add", "clear"]),
)


class _botowner(commands.Cog):
    """Help-menu category: Bot Owner (only shown to the bot owners)."""

    help_owner_only = True

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        return "<a:crownn:1567121063194918967>", "Bot Owner", "Bot owner only commands"      # <a:crownn:1567121063194918967>

    def help_body(self, prefix: str = "") -> str:
        blocks = []
        for name, heading, order in OWNER_GROUPS:
            group = self.bot.get_command(name)
            if group is None or not hasattr(group, "commands"):
                continue
            lines = [entry_text(prefix, c) for c in ordered(group, order)]
            blocks.append(f"__**{heading}**__\n" + "\n\n".join(lines))
        return "\n\n".join(blocks) or "No owner commands are loaded."
