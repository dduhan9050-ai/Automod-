"""Help-menu category: CustomRole (ZEON style, container without an accent colour)."""
from __future__ import annotations

from core import Cog

COMMANDS = (
    "customrole",
    "customrole list",
    "customrole reqrole",
    "customrole reset",
    "customrole create",
    "customrole delete",
)


class _customrole(Cog, name="CustomRoleHelp"):
    """Help-menu category: CustomRole"""

    # the help menu renders this module's container with NO accent colour (no hex bar)
    help_plain = True

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        return "\U0001f3ad", "CustomRole", "Show you Commands of CustomRole"  # 🎭

    def help_body(self, prefix: str = "") -> str:
        return "__**Custom Role**__\n" + " , ".join(f"`{name}`" for name in COMMANDS)
