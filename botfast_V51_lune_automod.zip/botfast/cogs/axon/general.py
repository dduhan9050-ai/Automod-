import discord
from discord.ext import commands

BASIC = ["afk", "membercount", "boostcount", "joinedat", "serverinfo", "userinfo", "channelinfo", "roleinfo",
         "avatar", "banner", "servericon", "serverbanner", "profile", "vote"]
BOT = ["invite", "stats", "botinfo", "ping", "prefix"]
LISTS = ["users", "emojis", "boosters", "bots", "admins", "mods", "roles", "inrole", "invoice", "joinedat",
         "createdat", "early", "bans", "activedeveloper", "bughunters", "hypesquad", "pending", "channels",
         "timeouts", "hasperms"]


class _general(commands.Cog):
    """Help-menu category: General."""

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        emoji = "\U0001f4cc"  # 📌
        label = "General"
        description = "Show you Commands of General"
        return emoji, label, description

    def _fmt(self, names, prefix=""):
        out = [f"`{prefix}{n}`" for n in names if self.bot.get_command(f"{prefix}{n}")]
        return ", ".join(out)

    def help_body(self, prefix: str = "") -> str:
        return (f"__**Basic Commands**__\n{self._fmt(BASIC)}\n\n"
                f"__**Bot Information**__\n{self._fmt(BOT)}\n\n"
                f"__**List Commands**__\n`list`, {self._fmt(LISTS, 'list ')}")
