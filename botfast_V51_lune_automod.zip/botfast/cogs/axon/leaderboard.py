import discord
from discord.ext import commands

# One entry per section of the help page (same order / names as the reference bot).
SECTIONS = (
    ("VoiceLeaderboard", (
        "voicelb on", "voicelb off", "vcstats", "voiceleaderboard", "dailyvoice", "weeklyvoice",
        "addvctime", "reducevctime", "clearvoice", "resetmyvoice",
    )),
    ("MessageLeaderboard", (
        "msglb on", "msglb off", "msgstats", "leaderboard messages", "leaderboard dailymessages",
        "leaderboard weeklymessages", "addmessages", "removemessages", "clearmsgs", "resetmymessages",
        "blacklistchannel", "unblacklistchannel", "blacklistedchannels", "blacklistcategory",
        "unblacklistcategory", "blacklistedcategories", "setmessagerole", "unsetmessagerole",
        "viewmessageroles",
    )),
    ("InviteLeaderboard", (
        "invitelb on", "invitelb off", "invites", "inviter", "invited", "inviteinfo",
        "inviteleaderboard total", "inviteleaderboard regular", "inviteleaderboard fake",
        "inviteleaderboard left", "addinvites", "removeinvites", "clearinvites", "resetmyinvites",
        "setaltthreshold", "unsetaltthreshold", "setinviterole", "unsetinviterole", "viewinviteroles",
    )),
    ("LiveLeaderboard", ("createlivelb", "deletelivelb", "showlivelbs")),
    ("TopLeaderboard", ("top messages", "top voice", "top invites")),
)


class _leaderboard(commands.Cog):
    """Help-menu category: Leaderboard"""

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        emoji = "<a:emoji_234:1567120330386833540>"  # <a:emoji_234:1567120330386833540>
        label = "Leaderboard"
        description = "Show you Commands of Leaderboard"
        return emoji, label, description

    def help_body(self, prefix: str = "") -> str:
        """Page shown in the help menu: underlined section name + comma separated commands."""
        return "\n\n".join(
            f"__{title}__\n" + ", ".join(f"`{name}`" for name in names) for title, names in SECTIONS
        )
