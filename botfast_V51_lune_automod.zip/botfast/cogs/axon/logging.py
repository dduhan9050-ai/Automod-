import discord
from discord.ext import commands

# Order = order of the "Logging Commands" page in the help menu.
LOGGING_HELP_COMMANDS = (
    "logging", "logging config", "logging remove", "logging enable", "logging disable",
    "logging wizard", "logging setup", "logging setup clear", "logging setup auto",
    "logging setup channel", "logging ignore", "logging ignore remove", "logging ignore add",
    "logging ignore embed", "logging ignore voice",
)


class _logging(commands.Cog):
    """Help-menu category: Logging."""

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        emoji = "\U0001f4dc"  # 📜
        label = "Logging"
        description = "Advance Logging Command"
        return emoji, label, description

    def help_body(self, prefix: str = "") -> str:
        names = ", ".join(f"`{name}`" for name in LOGGING_HELP_COMMANDS)
        return f"__**Logging Commands**__\n{names}"
