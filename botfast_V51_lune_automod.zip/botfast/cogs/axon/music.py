import discord
from discord.ext import commands

MUSIC_COMMANDS = (
    "247", "play", "search", "loop", "autoplay", "nowplaying", "shuffle", "stop",
    "skip", "seek", "join", "disconnect", "replay", "queue", "clearqueue", "pause",
    "resume", "volume", "filter", "filter enable", "filter disable", "platforms",
)


class _music(commands.Cog):
    """Music commands (help category)."""

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        emoji = '<:music:1330393374271737896>'
        label = "Music Commands"
        description = "Show you Commands of Music"
        return emoji, label, description

    def help_body(self, prefix: str = "") -> str:
        names = ", ".join(f"`{name}`" for name in MUSIC_COMMANDS)
        return f"__**Music**__\n{names}"
