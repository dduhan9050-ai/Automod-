import discord
from discord.ext import commands


class _permit(commands.Cog):
    """Help-menu category: Permit (extraowner, trusted, fake permissions, ignore)."""

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        emoji = "<:emoji_18:1566457796973826100>"  # <:emoji_18:1566457796973826100>
        label = "Permit"
        description = "Show you Commands of Permit"
        return emoji, label, description

    def _names(self, group_name: str) -> str:
        group = self.bot.get_command(group_name)
        if group is None:
            return ""
        names = [group.qualified_name]
        names += [c.qualified_name for c in getattr(group, "walk_commands", lambda: [])() if not c.hidden]
        return ", ".join(f"`{n}`" for n in names)

    def help_body(self, prefix: str = "") -> str:
        return (f"__**Extraowner**__\n{self._names('extraowner')}\n\n"
                f"__**Trusted**__\n{self._names('trusted')}\n\n"
                f"__**Fake Permissions**__\n{self._names('permissions')}\n\n"
                f"__**Ignore**__\n{self._names('ignore')}")
