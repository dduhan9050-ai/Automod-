import discord
from discord.ext import commands

from utils.grouphelp import entry_text


class _premium(commands.Cog):
    """Help-menu category: Customize (the Premium commands)"""

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        emoji = "<a:pinfloat:1567124641347145809>"  # <a:pinfloat:1567124641347145809>
        label = "Customize"
        description = "Show you Commands of Customize"
        return emoji, label, description

    def help_body(self, prefix: str = "") -> str:
        """Page shown in the help menu: `usage` + ❯ description per command."""
        cog = self.bot.get_cog("Premium")
        if cog is None:
            return "Customize commands are not loaded."
        visible = sorted((c for c in cog.get_commands() if not c.hidden), key=lambda c: c.name)
        blocks = [entry_text(prefix, c) for c in visible]     # `usage` + ❯ description (same card style)
        blocks.append(f"-# {len(visible)} commands in this category")
        return "\n\n".join(blocks)
