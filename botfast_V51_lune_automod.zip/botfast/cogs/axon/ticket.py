import discord
from discord.ext import commands

# Same order as the `?ticket` group help (5 / 5 / 2 per page) + the variables command.
TICKET_COMMANDS = (
    "ticket",
    "ticket delete",
    "ticket transcript <channel>",
    "ticket staff <role>",
    "ticket adduser <member>",
    "ticket reset",
    "ticket close",
    "ticket edit",
    "ticket setcategory <category>",
    "ticket removeuser <member>",
    "ticket config",
    "ticket panel [channel]",
    "ticket setup",
    "ticketvariables",
)


class _ticket(commands.Cog):
    """Help-menu category: Ticket"""

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        emoji = '<:ticket:1355527347335467191>'
        label = "Ticket"
        description = "Show you Commands of Ticket"
        return emoji, label, description

    def help_body(self, prefix: str = "") -> str:
        """Page shown in the help menu: one command per line."""
        lines = "\n".join(f"`{name}`" for name in TICKET_COMMANDS)
        return f"__**Tickets**__\n{lines}"
