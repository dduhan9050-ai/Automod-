from core import Cog

COMMANDS = ("vanityroles", "vanityroles setup", "vanityroles reset", "vanityroles config")


class _vanity(Cog):
    """Help-menu category: Vanityroles"""

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        return "<a:star_white:1567124664558297180>", "Vanityroles", "Show you Commands of Vanityroles"

    def help_body(self, prefix: str = "") -> str:
        return "__Vanityroles__\n" + ", ".join(f"`{c}`" for c in COMMANDS)
