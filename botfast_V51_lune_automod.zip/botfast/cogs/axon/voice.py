"""Help-menu category: Voice Commands (ZEON style, container without an accent colour)."""
from __future__ import annotations

from core import Cog

VOICE = ("voice", "voice muteall", "voice moveall", "voice unmuteall", "voice pullall", "voice private",
         "voice deafenall", "voice move", "voice unmute", "voice kickall", "voice lock", "voice pull",
         "voice undeafen", "voice unlock", "voice mute", "voice unprivate", "voice undeafenall", "voice kick",
         "voice deafen")
VCROLE = ("vcrole", "vcrole enable", "vcrole set", "vcrole reset", "vcrole show", "vcrole disable")


def _line(names) -> str:
    return " , ".join(f"`{n}`" for n in names)


class _voice(Cog, name="VoiceHelp"):
    """Help-menu category: Voice"""

    help_plain = True  # no accent colour on this module's help container

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        return "<:emoji_77:1567148151440146533>", "Voice Commands", "Show you Command Of Voice"  # <:emoji_77:1567148151440146533>

    def help_body(self, prefix: str = "") -> str:
        return f"__**Voice Commands**__\n{_line(VOICE)}\n\n__**VC Roles**__\n{_line(VCROLE)}"
