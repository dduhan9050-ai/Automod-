import discord
import aiosqlite
from discord.ext import commands
from utils.Tools import blacklist_check, ignore_check
from collections import defaultdict
import time

class Media(commands.Cog):
    def __init__(self, client):
        self.client = client
        self.infractions = defaultdict(list)
        self._chan: dict[int, int] = {}      # guild_id -> media channel id (0 = none)
        

    async def set_db(self):
        async with aiosqlite.connect('db/media.db') as db:
            await db.execute('''
                CREATE TABLE IF NOT EXISTS media_channels (
                    guild_id INTEGER PRIMARY KEY,
                    channel_id INTEGER NOT NULL
                )
            ''')
            await db.execute('''
                CREATE TABLE IF NOT EXISTS media_bypass (
                    guild_id INTEGER,
                    user_id INTEGER,
                    PRIMARY KEY (guild_id, user_id)
                )
            ''')
            await db.commit()

    async def cog_load(self):
        await self.set_db()

    @commands.Cog.listener()
    async def on_ready(self):
        await self.set_db()

    async def _media_channel(self, guild_id: int) -> int:
        cid = self._chan.get(guild_id)
        if cid is None:
            try:
                async with aiosqlite.connect('db/media.db') as db:
                    async with db.execute('SELECT channel_id FROM media_channels WHERE guild_id = ?', (guild_id,)) as cur:
                        row = await cur.fetchone()
            except aiosqlite.Error:
                return 0
            cid = row[0] if row else 0
            self._chan[guild_id] = cid
        return cid

    async def _skip_media_check(self, guild_id: int, user_id: int) -> bool:
        """True when the user is blacklisted or on the bypass list. Cached 10 s (was 2 SQLite queries per message)."""
        cache = self.__dict__.setdefault("_skip_cache", {})
        key, now = (guild_id, user_id), time.monotonic()
        hit = cache.get(key)
        if hit is not None and hit[0] > now:
            return hit[1]
        try:
            async with aiosqlite.connect('db/block.db') as block_db:
                async with block_db.execute('SELECT 1 FROM user_blacklist WHERE user_id = ?', (user_id,)) as cur:
                    skip = await cur.fetchone() is not None
            if not skip:
                async with aiosqlite.connect('db/media.db') as db:
                    async with db.execute('SELECT 1 FROM media_bypass WHERE guild_id = ? AND user_id = ?',
                                          (guild_id, user_id)) as cur:
                        skip = await cur.fetchone() is not None
        except aiosqlite.Error:
            return False
        if len(cache) > 5000:
            cache.clear()
        cache[key] = (now + 10.0, skip)
        return skip

    @commands.hybrid_group(name="media", help="Setup Media channel, Media channel will not allow users to send messages other than media files.", invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def media(self, ctx):
        if ctx.subcommand_passed is None:
            await ctx.send_help(ctx.command)
            ctx.command.reset_cooldown(ctx)

    @media.command(name="setup", aliases=["set", "add"], help="Sets up a media-only channel for the server")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def setup(self, ctx, *, channel: discord.TextChannel):
        async with aiosqlite.connect('db/media.db') as db:
            async with db.execute('SELECT channel_id FROM media_channels WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
                result = await cursor.fetchone()
                if result:
                    embed = discord.Embed(
                        title="<:CrossIcon:1327829124894429235> Error",
                        description="A media channel is already set. Please remove it before setting a new one.",
                        color=0x000000
                    )
                    await ctx.reply(embed=embed)
                    return

            await db.execute('INSERT INTO media_channels (guild_id, channel_id) VALUES (?, ?)', (ctx.guild.id, channel.id))
            await db.commit()
        self._chan.pop(ctx.guild.id, None)

        embed = discord.Embed(
            title="<:emoji_4:1566043104551768114> Success",
            description=f"Successfully set {channel.mention} as the media-only channel.",
            color=0x000000
        )
        embed.set_footer(text="Make sure to grant me \"Manage Messages\" permission for functioning of media channel.")
        await ctx.reply(embed=embed)

    @media.command(name="remove", aliases=["reset", "delete"], help="Removes the current media-only channel")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def remove(self, ctx):
        async with aiosqlite.connect('db/media.db') as db:
            async with db.execute('SELECT channel_id FROM media_channels WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
                result = await cursor.fetchone()
                if not result:
                    embed = discord.Embed(
                        title="<:CrossIcon:1327829124894429235> Error",
                        description="There is no media-only channel set for this server.",
                        color=0x000000
                    )
                    await ctx.reply(embed=embed)
                    return

            await db.execute('DELETE FROM media_channels WHERE guild_id = ?', (ctx.guild.id,))
            await db.commit()
        self._chan.pop(ctx.guild.id, None)

        embed = discord.Embed(
            title="<:emoji_4:1566043104551768114> Success",
            description="Successfully removed the media-only channel.",
            color=0x000000
        )
        await ctx.reply(embed=embed)

    @media.command(name="config", aliases=["settings", "show"], help="Shows the configured media-only channel")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def config(self, ctx):
        async with aiosqlite.connect('db/media.db') as db:
            async with db.execute('SELECT channel_id FROM media_channels WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
                result = await cursor.fetchone()
                if not result:
                    embed = discord.Embed(
                        title="<:CrossIcon:1327829124894429235> Error",
                        description="There is no media-only channel set for this server.",
                        color=0x000000
                    )
                    await ctx.reply(embed=embed)
                    return

        channel = self.client.get_channel(result[0])
        embed = discord.Embed(
            title="Media Only Channel",
            description=f"The configured media-only channel is {channel.mention}.",
            color=0x000000
        )
        await ctx.reply(embed=embed)

    @media.group(name="bypass", help="Add/Remove user to bypass in Media only channel, Bypassed users can send messages in Media channel.", invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def bypass(self, ctx):
        if ctx.subcommand_passed is None:
            await ctx.send_help(ctx.command)
            ctx.command.reset_cooldown(ctx)

    @bypass.command(name="add", help="Adds a user to the bypass list")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def bypass_add(self, ctx, user: discord.Member):
        async with aiosqlite.connect('db/media.db') as db:
            async with db.execute('SELECT COUNT(*) FROM media_bypass WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
                count = await cursor.fetchone()
                if count[0] >= 25:
                    embed = discord.Embed(
                        title="<:CrossIcon:1327829124894429235> Error",
                        description="The bypass list can only hold up to 25 users.",
                        color=0x000000
                    )
                    await ctx.reply(embed=embed)
                    return

            async with db.execute('SELECT 1 FROM media_bypass WHERE guild_id = ? AND user_id = ?', (ctx.guild.id, user.id)) as cursor:
                result = await cursor.fetchone()
                if result:
                    embed = discord.Embed(
                        title="<:CrossIcon:1327829124894429235> Error",
                        description=f"{user.mention} is already in the bypass list.",
                        color=0x000000
                    )
                    await ctx.reply(embed=embed)
                    return

            await db.execute('INSERT INTO media_bypass (guild_id, user_id) VALUES (?, ?)', (ctx.guild.id, user.id))
            await db.commit()

        embed = discord.Embed(
            title="<:emoji_4:1566043104551768114> Success",
            description=f"{user.mention} has been added to the bypass list.",
            color=0x000000
        )
        await ctx.reply(embed=embed)

    @bypass.command(name="remove", help="Removes a user from the bypass list")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def bypass_remove(self, ctx, user: discord.Member):
        async with aiosqlite.connect('db/media.db') as db:
            async with db.execute('SELECT 1 FROM media_bypass WHERE guild_id = ? AND user_id = ?', (ctx.guild.id, user.id)) as cursor:
                result = await cursor.fetchone()
                if not result:
                    embed = discord.Embed(
                        title="<:CrossIcon:1327829124894429235> Error",
                        description=f"{user.mention} is not in the bypass list.",
                        color=0x000000
                    )
                    await ctx.reply(embed=embed)
                    return

            await db.execute('DELETE FROM media_bypass WHERE guild_id = ? AND user_id = ?', (ctx.guild.id, user.id))
            await db.commit()

        embed = discord.Embed(
            title="<:emoji_4:1566043104551768114> Success",
            description=f"{user.mention} has been removed from the bypass list.",
            color=0x000000
        )
        await ctx.reply(embed=embed)

    @bypass.command(name="show", aliases=["list", "view"], help="Shows the bypass list")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def bypass_show(self, ctx):
        async with aiosqlite.connect('db/media.db') as db:
            async with db.execute('SELECT user_id FROM media_bypass WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
                result = await cursor.fetchall()
                if not result:
                    embed = discord.Embed(
                        title="Bypass List",
                        description="There are no users in the bypass list.",
                        color=0x000000
                    )
                    await ctx.reply(embed=embed)
                    return

        users = [self.client.get_user(user_id).mention for user_id, in result]
        user_mentions = "\n".join(users)

        embed = discord.Embed(
            title="Bypass List",
            description=user_mentions,
            color=0x000000
        )
        await ctx.reply(embed=embed)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or message.guild is None:
            return

        media_channel = await self._media_channel(message.guild.id)

        if media_channel and message.channel.id == media_channel:
            if not message.attachments:
                if await self._skip_media_check(message.guild.id, message.author.id):
                    return

            if not message.attachments:
                try:
                    await message.delete()
                    await message.channel.send(f"{message.author.mention} This channel is configured for Media only. Please send only media files.",
                    delete_after=5
                )
                except discord.Forbidden:
                    pass
                except discord.HTTPException:
                    pass
                except Exception:
                    pass

                current_time = time.time()
                self.infractions[message.author.id].append(current_time)

                
                self.infractions[message.author.id] = [
                    infraction for infraction in self.infractions[message.author.id]
                    if current_time - infraction <= 5
                ]

                if len(self.infractions[message.author.id]) >= 5:  
                    from utils import ratelimit
                    block = await ratelimit.punish(message.author.id)   # temporary + escalating, not permanent

                    embed = discord.Embed(
                        title="You Have Been Temporarily Blacklisted",
                        description=(
                            "<:icons_warning:1327829522573430864> You are blacklisted from using my commands for "
                            f"**{ratelimit.human(block.until - time.time())}** due to spamming in the media channel "
                            f"(strike #{block.strikes}, every repeat doubles the time)."
                        ),
                        color=0x000000
                    )
                    await message.channel.send(f"{message.author.mention}", embed=embed)
                    del self.infractions[message.author.id]

"""
@Author: Sonu Jana
    + Discord: me.sonu
    + Community: https://discord.gg/cfYmz4634n (Death Development)
    + for any queries reach out Community or DM me.
"""