import discord
from discord.ext import commands
import aiosqlite
import os
import time
from typing import Optional
from utils.Tools import *

DB_PATH = "db/afk.db"
ARROW = "<:arrow_2:1453021997092307076>"
GREEN = discord.ButtonStyle.success
RED = discord.ButtonStyle.danger


def _avatar(user: discord.abc.User) -> str:
    return user.display_avatar.url


def _make_button(label: str, style: discord.ButtonStyle, callback, *, emoji=None, custom_id=None):
    button = discord.ui.Button(label=label, style=style, emoji=emoji, custom_id=custom_id)
    button.callback = callback
    return button


def _afk_view(author: discord.abc.User, heading: str, body: str, footer: str, buttons=(), timeout=180):
    view = discord.ui.LayoutView(timeout=timeout)
    container = discord.ui.Container()
    text = f"# {heading}\n\n{body}"
    section = discord.ui.Section(
        discord.ui.TextDisplay(text),
        accessory=discord.ui.Thumbnail(media=_avatar(author)),
    )
    container.add_item(section)
    container.add_item(discord.ui.Separator())
    container.add_item(discord.ui.TextDisplay(f"{ARROW}  {footer}"))
    if buttons:
        container.add_item(discord.ui.Separator())
        row = discord.ui.ActionRow()
        for button in buttons:
            row.add_item(button)
        container.add_item(row)
    container.add_item(discord.ui.Separator())
    container.add_item(discord.ui.TextDisplay(f"-# Requested by: {author.display_name}"))
    view.add_item(container)
    return view


class BasicView(discord.ui.LayoutView):
    def __init__(self, ctx: commands.Context, timeout: Optional[int] = 180):
        super().__init__(timeout=timeout)
        self.ctx = ctx

    async def interaction_check(self, interaction: discord.Interaction):
        if interaction.user.id != self.ctx.author.id:
            await interaction.response.send_message(
                f"Only **{self.ctx.author}** can use this AFK setup.", ephemeral=True
            )
            return False
        return True


class afk(commands.Cog):
    def __init__(self, client, *args, **kwargs):
        self.client = client
        self._afk: set[int] = set()          # user ids currently AFK (fast path for on_message)
        self.client.loop.create_task(self.initialize_db())

    async def initialize_db(self):
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS afk (
                    user_id INTEGER PRIMARY KEY,
                    AFK TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    time INTEGER NOT NULL,
                    mentions INTEGER NOT NULL,
                    dm TEXT NOT NULL,
                    scope TEXT NOT NULL DEFAULT 'server'
                )
            """)
            columns = await (await db.execute("PRAGMA table_info(afk)")).fetchall()
            if "scope" not in [column[1] for column in columns]:
                await db.execute("ALTER TABLE afk ADD COLUMN scope TEXT NOT NULL DEFAULT 'server'")
            await db.execute("""
                CREATE TABLE IF NOT EXISTS afk_guild (
                    user_id INTEGER NOT NULL,
                    guild_id INTEGER NOT NULL,
                    PRIMARY KEY (user_id, guild_id)
                )
            """)
            await db.commit()
            async with db.execute("SELECT user_id FROM afk WHERE AFK = 'True'") as cur:
                self._afk = {row[0] async for row in cur}

    async def cog_after_invoke(self, ctx):
        ctx.command.reset_cooldown(ctx)

    async def update_data(self, user, guild_id):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "INSERT OR IGNORE INTO afk (user_id, AFK, reason, time, mentions, dm, scope) VALUES (?, 'False', 'None', 0, 0, 'False', 'server')",
                (user.id,),
            )
            await db.execute("INSERT OR IGNORE INTO afk_guild (user_id, guild_id) VALUES (?, ?)", (user.id, guild_id))
            await db.commit()

    async def time_formatter(self, seconds: float):
        minutes, seconds = divmod(int(seconds), 60)
        hours, minutes = divmod(minutes, 60)
        days, hours = divmod(hours, 24)
        tmp = ((str(days) + " days, ") if days else "") + \
              ((str(hours) + " hours, ") if hours else "") + \
              ((str(minutes) + " minutes, ") if minutes else "") + \
              ((str(seconds) + " seconds, ") if seconds else "")
        return tmp[:-2] or "0 seconds"

    async def _is_active_here(self, db, user_id: int, guild_id: int, scope: str) -> bool:
        if scope == "global":
            return True
        cursor = await db.execute("SELECT 1 FROM afk_guild WHERE user_id = ? AND guild_id = ?", (user_id, guild_id))
        found = await cursor.fetchone()
        await cursor.close()
        return found is not None

    @commands.Cog.listener()
    async def on_message(self, message):
        try:
            if message.author.bot or message.guild is None:
                return
            if message.author.id not in self._afk and not (
                    message.mentions and any(m.id in self._afk for m in message.mentions)):
                return

            async with aiosqlite.connect(DB_PATH) as db:
                cursor = await db.execute("SELECT AFK, time, mentions, reason, scope FROM afk WHERE user_id = ?", (message.author.id,))
                author_afk = await cursor.fetchone()
                await cursor.close()

                if author_afk and author_afk[0] == "True" and await self._is_active_here(db, message.author.id, message.guild.id, author_afk[4]):
                    self._afk.discard(message.author.id)
                    elapsed = int(time.time()) - int(author_afk[1])
                    duration = await self.time_formatter(elapsed)
                    mention_count = author_afk[2]
                    await db.execute("UPDATE afk SET AFK = 'False', reason = 'None', scope = 'server' WHERE user_id = ?", (message.author.id,))
                    await db.execute("DELETE FROM afk_guild WHERE user_id = ?", (message.author.id,))
                    await db.commit()
                    welcome_back = discord.Embed(
                        title=f"{message.author.display_name} Welcome Back!",
                        description=f"I removed your AFK\nTotal Mentions: **{mention_count}**\nAFK Timing: **{duration}**",
                        color=0x0c0606,
                    )
                    try:
                        await message.reply(embed=welcome_back)
                    except discord.Forbidden:
                        print(f"(AFK module) Missing permissions in channel: {message.channel.id}")

                if message.mentions:
                    for mentioned in message.mentions:
                        cursor = await db.execute("SELECT AFK, reason, time, mentions, dm, scope FROM afk WHERE user_id = ?", (mentioned.id,))
                        data = await cursor.fetchone()
                        await cursor.close()
                        if not data or data[0] != "True":
                            continue
                        if not await self._is_active_here(db, mentioned.id, message.guild.id, data[5]):
                            continue

                        reason, started, mention_count, dm_enabled = data[1], data[2], data[3], data[4]
                        notice = discord.Embed(
                            description=f"**<@{mentioned.id}>** went AFK <t:{started}:R> for the following reason:\n**{reason}**",
                            color=0x0c0606,
                        )
                        try:
                            await message.reply(embed=notice)
                        except discord.Forbidden:
                            print(f"(AFK module) Missing permissions to notify {mentioned.id}")

                        mention_count += 1
                        await db.execute("UPDATE afk SET mentions = ? WHERE user_id = ?", (mention_count, mentioned.id))
                        await db.commit()

                        if dm_enabled == "True":
                            dm_embed = discord.Embed(
                                description=f"You were mentioned in **{message.guild.name}** by **{message.author}**",
                                color=discord.Color.blurple(),
                            )
                            dm_embed.add_field(name="Total mentions:", value=mention_count, inline=False)
                            dm_embed.add_field(name="Message:", value=message.content or "[No text content]", inline=False)
                            dm_embed.add_field(name="Jump Message:", value=f"[Jump to message]({message.jump_url})", inline=False)
                            try:
                                await mentioned.send(embed=dm_embed)
                            except discord.Forbidden:
                                print(f"(AFK module) Missing permissions to DM {mentioned.id}")

            await self.update_data(message.author, message.guild.id)
        except Exception as exc:
            print(f"Ignoring exception in AFK on_message: {exc}")

    @commands.hybrid_command(description="Shows an AFK status when you're mentioned")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def afk(self, ctx, *, reason=None):
        if not reason:
            reason = "I am AFK :/"
        if any(invite in reason.lower() for invite in ["discord.gg", "gg/"]):
            return await ctx.send("<a:emoji_250:1567101252712530020> You can't advertise server invites in the AFK reason.")

        mode_view = BasicView(ctx, timeout=180)
        mode_view.add_item(discord.ui.Container(
            discord.ui.Section(
                discord.ui.TextDisplay(
                    "# Choose your preferred AFK status type\n\n"
                    "Select whether your AFK status should apply everywhere or only in this server."
                ),
                accessory=discord.ui.Thumbnail(media=_avatar(ctx.author)),
            ),
            discord.ui.Separator(),
            discord.ui.TextDisplay(f"{ARROW}  Choose your preferred AFK status type below."),
            discord.ui.Separator(),
            discord.ui.ActionRow(
                _make_button("Global AFK", RED, None, emoji="<:ping:1567099428660052048>", custom_id=f"afk_global_{ctx.author.id}"),
                _make_button("Server AFK", GREEN, None, emoji="<a:emoji_71:1567130056093077665>", custom_id=f"afk_server_{ctx.author.id}"),
            ),
            discord.ui.Separator(),
            discord.ui.TextDisplay(f"-# Requested by: {ctx.author.display_name}"),
        ))
        selected = {"scope": None}

        async def choose_global(interaction):
            selected["scope"] = "global"
            await ask_dm(interaction)

        async def choose_server(interaction):
            selected["scope"] = "server"
            await ask_dm(interaction)

        # Bind callbacks after creating the buttons in the first view.
        mode_container = mode_view.children[0]
        mode_row = mode_container.children[4]
        mode_row.children[0].callback = choose_global
        mode_row.children[1].callback = choose_server

        async def ask_dm(interaction):
            dm_view = BasicView(ctx, timeout=180)
            dm_view.add_item(discord.ui.Container(
                discord.ui.Section(
                    discord.ui.TextDisplay(
                        f"# { 'Global AFK' if selected['scope'] == 'global' else 'Server AFK' } Selected\n\n"
                        "Do you want to receive a DM when someone mentions you while you're AFK?"
                    ),
                    accessory=discord.ui.Thumbnail(media=_avatar(ctx.author)),
                ),
                discord.ui.Separator(),
                discord.ui.TextDisplay(f"{ARROW}  Choose your preference below."),
                discord.ui.Separator(),
                discord.ui.ActionRow(
                    _make_button("Yes", GREEN, None, emoji="<:emoji_4:1566043104551768114>", custom_id=f"afk_dm_yes_{ctx.author.id}"),
                    _make_button("No", RED, None, emoji="<a:emoji_38:1567096105299214336>", custom_id=f"afk_dm_no_{ctx.author.id}"),
                ),
                discord.ui.Separator(),
                discord.ui.TextDisplay(f"-# Requested by: {ctx.author.display_name}"),
            ))

            async def save_choice(interaction, enabled: bool):
                dm_status = "True" if enabled else "False"
                scope = selected["scope"]
                async with aiosqlite.connect(DB_PATH) as db:
                    await db.execute(
                        "INSERT OR REPLACE INTO afk (user_id, AFK, reason, time, mentions, dm, scope) VALUES (?, 'True', ?, ?, 0, ?, ?)",
                        (ctx.author.id, reason, int(time.time()), dm_status, scope),
                    )
                    await db.execute("DELETE FROM afk_guild WHERE user_id = ?", (ctx.author.id,))
                    if scope == "server":
                        await db.execute("INSERT OR IGNORE INTO afk_guild (user_id, guild_id) VALUES (?, ?)", (ctx.author.id, ctx.guild.id))
                    await db.commit()

                self._afk.add(ctx.author.id)
                status_text = "Enabled" if enabled else "Disabled"
                mode_text = "Global" if scope == "global" else "Server"
                activated = BasicView(ctx, timeout=180)
                activated.add_item(discord.ui.Container(
                    discord.ui.Section(
                        discord.ui.TextDisplay(
                            f"# <:emoji_4:1566043104551768114> AFK Activated\n\n"
                            f"{ctx.author.mention} Your AFK status is now set to **{mode_text}**\n\n"
                            f"**Reason:** {reason}\n"
                            f"**DM Notifications:** {status_text}\n\n"
                            f"{ARROW}  You are now away from keyboard."
                        ),
                        accessory=discord.ui.Thumbnail(media=_avatar(ctx.author)),
                    ),
                ))
                await interaction.response.edit_message(view=activated, content=None)
                activated.stop()

            yes_button = dm_view.children[0].children[4].children[0]
            no_button = dm_view.children[0].children[4].children[1]
            yes_button.callback = lambda interaction: save_choice(interaction, True)
            no_button.callback = lambda interaction: save_choice(interaction, False)
            await interaction.response.edit_message(view=dm_view, content=None)
            mode_view.stop()

        prompt = await ctx.reply(view=mode_view, mention_author=False)
        await mode_view.wait()
        if selected["scope"] is None:
            try:
                await prompt.edit(content="AFK setup timed out. Please run the command again.", view=None)
            except discord.HTTPException:
                pass


async def setup(client):
    await client.add_cog(afk(client))
