from __future__ import annotations

import time
from typing import Awaitable, Callable, Optional

import discord
from discord.ext import commands

from cogs.antinuke.engine import _dangerous as is_dangerous
from cogs.antinuke.botguard import help_text as botguard_help_text
from cogs.antinuke.onboardguard import help_text as onboard_help_text
from cogs.antinuke.inviteguard import help_text as inviterole_help_text
from cogs.antinuke.vanityguard import help_text as vanity_help_text
from utils import antinuke_store as store
from utils import antinuke_ui as ui
from utils.Tools import blacklist_check, ignore_check

_BLACKLIST = blacklist_check().predicate
_IGNORE = ignore_check().predicate

ON_WORDS = {"enable", "enabled", "on", "true", "yes", "1", "activate"}
OFF_WORDS = {"disable", "disabled", "off", "false", "no", "0", "deactivate"}
NEED_PERMS = ("view_audit_log", "ban_members", "kick_members", "manage_roles",
              "manage_channels", "manage_guild", "manage_webhooks", "moderate_members")


def parse_toggle(word: str) -> Optional[bool]:
    word = word.lower()
    if word in ON_WORDS:
        return True
    if word in OFF_WORDS:
        return False
    return None


def missing_perms(me: discord.Member) -> list[str]:
    perms = me.guild_permissions
    if perms.administrator:
        return []
    return [p.replace("_", " ").title() for p in NEED_PERMS if not getattr(perms, p)]


# ------------------------------------------------------------------ views
class ConfirmView(ui.BaseView):
    def __init__(self, ctx, title: str, body: str, action: Callable[[], Awaitable[None]],
                 done_title: str, done_body: str):
        super().__init__(ctx, timeout=60)

        async def confirm(i: discord.Interaction):
            self.stop()
            try:
                await action()
            except Exception:
                return await i.response.edit_message(view=ui.fail("Failed", "Something went wrong."))
            await i.response.edit_message(view=ui.ok(done_title, done_body), allowed_mentions=ui.NO_PING)

        async def cancel(i: discord.Interaction):
            self.stop()
            await i.response.edit_message(view=ui.fail("Cancelled", "No changes were made."))

        self.add_item(ui.box(
            ui.text(f"## {title}\n{body}"),
            ui.row(ui.button("Confirm", ui.BS.success, confirm), ui.button("Cancel", ui.BS.danger, cancel)),
        ))


class ManageView(ui.BaseView):
    """Toggle antinuke modules with one multi-select."""

    def __init__(self, ctx):
        super().__init__(ctx)
        self.build()

    def build(self) -> None:
        self.clear_items()
        cfg = store.get(self.guild.id)
        lines = [f"{ui.OK if cfg.mods & store.BIT[k] else ui.NO} **{label}** {ui.ARROW} limit `{cfg.limit(k)}`"
                 for k, label in store.MODULES]
        select = discord.ui.Select(
            placeholder="Select the modules to keep enabled", min_values=0, max_values=len(store.MODULES),
            options=[discord.SelectOption(label=label, value=k, default=bool(cfg.mods & store.BIT[k]))
                     for k, label in store.MODULES])

        async def picked(i: discord.Interaction):
            await store.update(self.guild.id, mods=store.mask_of(select.values))
            await self.refresh(i)

        async def all_on(i):
            await store.update(self.guild.id, mods=store.ALL_MASK)
            await self.refresh(i)

        async def all_off(i):
            await store.update(self.guild.id, mods=0)
            await self.refresh(i)

        async def trash(i): await self.close(i)

        select.callback = picked
        self.add_item(ui.box(
            ui.text("## Antinuke Modules\nToggle which events the engine protects."),
            ui.sep(), ui.text("\n".join(lines)), ui.sep(),
            ui.row(select),
            ui.row(ui.button("Enable All", ui.BS.success, all_on),
                   ui.button("Disable All", ui.BS.danger, all_off),
                   ui.button(None, ui.BS.secondary, trash, emoji="<:bin:1567102784552304640>")),
        ))

    async def refresh(self, i: discord.Interaction) -> None:
        self.build()
        await i.response.edit_message(view=self, allowed_mentions=ui.NO_PING)


class WhitelistView(ui.BaseView):
    """Pick which modules a user is trusted for."""

    def __init__(self, ctx, user: discord.abc.User):
        super().__init__(ctx)
        self.user = user
        self.build()

    def build(self) -> None:
        self.clear_items()
        mask = store.get(self.guild.id).wl.get(self.user.id, 0)
        lines = [f"{ui.OK if mask & store.BIT[k] else ui.NO} {label}" for k, label in store.MODULES]
        select = discord.ui.Select(
            placeholder="Select modules to whitelist", min_values=0, max_values=len(store.MODULES),
            options=[discord.SelectOption(label=label, value=k, default=bool(mask & store.BIT[k]))
                     for k, label in store.MODULES])

        async def picked(i: discord.Interaction):
            await store.set_wl(self.guild.id, self.user.id, store.mask_of(select.values))
            await self.refresh(i)

        async def grant_all(i):
            await store.set_wl(self.guild.id, self.user.id, store.ALL_MASK)
            await self.refresh(i)

        async def remove(i):
            await store.set_wl(self.guild.id, self.user.id, 0)
            await self.refresh(i)

        async def trash(i): await self.close(i)

        select.callback = picked
        status = "whitelisted" if mask else "not whitelisted"
        self.add_item(ui.box(
            ui.text(f"## Antinuke Whitelist\n{self.user.mention} is currently **{status}**."),
            ui.sep(), ui.text("\n".join(lines)), ui.sep(),
            ui.row(select),
            ui.row(ui.button("Whitelist All", ui.BS.success, grant_all),
                   ui.button("Remove", ui.BS.danger, remove),
                   ui.button(None, ui.BS.secondary, trash, emoji="<:bin:1567102784552304640>")),
        ))

    async def refresh(self, i: discord.Interaction) -> None:
        self.build()
        await i.response.edit_message(view=self, allowed_mentions=ui.NO_PING)


# ------------------------------------------------------------------ cog
class Antinuke(commands.Cog):
    """Antinuke security commands."""

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self) -> None:
        await store.load()

    async def cog_check(self, ctx: commands.Context) -> bool:
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        return bool(await _BLACKLIST(ctx) and await _IGNORE(ctx))

    # ---- helpers
    async def _send(self, ctx, view) -> Optional[discord.Message]:
        return await ctx.send(view=view, allowed_mentions=ui.NO_PING)

    async def _gate(self, ctx, owner_only: bool = False) -> bool:
        """Server owner always; whitelisted users too unless owner-only mode / owner-only command."""
        if ctx.author.id == ctx.guild.owner_id:
            return True
        cfg = store.get(ctx.guild.id)
        if not owner_only and not cfg.owneronly and ctx.author.id in cfg.wl:
            return True
        who = "the **server owner**" if (owner_only or cfg.owneronly) else "the **server owner** or **whitelisted users**"
        await self._send(ctx, ui.fail("Access Denied", f"Only {who} can run this command."))
        return False

    async def _flag(self, ctx, action: str, field: str, title: str, on_text: str, off_text: str,
                    owner_only: bool = False) -> None:
        if not await self._gate(ctx, owner_only):
            return
        value = parse_toggle(action)
        if value is None:
            return await self._send(ctx, ui.command_help_view(ctx.clean_prefix, ctx.command))
        await store.update(ctx.guild.id, **{field: value})
        await self._send(ctx, ui.toggled(title, value, on_text, off_text))

    # ---- BotGuard (Anti Bot Nuker + Bot Add Protection) helpers
    def _bg(self):
        return self.bot.get_cog("BotGuard")

    def _module_pages(self, ctx) -> list:
        bg, cfg = self._bg(), store.get(ctx.guild.id)
        st = {"integration": bool(bg and bg.flag(ctx.guild.id, "integration")),
              "botadd": bool(bg and bg.flag(ctx.guild.id, "botadd")),
              "autorec": cfg.autorec, "extra_count": len(bg.extra_ids(ctx.guild.id)) if bg else 0}
        ob = self._ob()
        ost = {"onboarding": bool(ob and ob.flag(ctx.guild.id)), "trusted_count": len(ob.trusted.get(ctx.guild.id, ())) if ob else 0}
        ig = self._ig()
        ist = {"inviterole": bool(ig and ig.flag(ctx.guild.id))}
        vg = self._vg()
        vst = {"vanity": bool(vg and vg.flag(ctx.guild.id))}
        return (botguard_help_text(ctx.clean_prefix, st, ui.OK + " ON", ui.NO + " OFF")
                + onboard_help_text(ctx.clean_prefix, ost, ui.OK + " ON", ui.NO + " OFF")      # Anti-Onboarding: same menu, no new category
                + inviterole_help_text(ctx.clean_prefix, ist, ui.OK + " ON", ui.NO + " OFF")   # Anti Invite Role: same menu, no new category
                + vanity_help_text(ctx.clean_prefix, vst, ui.OK + " ON", ui.NO + " OFF"))      # Anti Vanity: same menu, no new category

    def _ob(self):
        return self.bot.get_cog("OnboardGuard")

    def _ig(self):
        return self.bot.get_cog("InviteGuard")

    def _vg(self):
        return self.bot.get_cog("VanityGuard")

    async def _manager_gate(self, ctx) -> bool:
        """Server Owner and Extra Owners ONLY (a normal / whitelisted admin never passes)."""
        bg = self._bg()
        if ctx.author.id == ctx.guild.owner_id or (bg is not None and bg.is_extra_owner(ctx.guild.id, ctx.author.id)):
            return True
        await self._send(ctx, ui.fail("Access Denied", "Only the **server owner** or an **extra owner** can run this command."))
        return False

    async def _bg_toggle(self, ctx, which: str, action: str, title: str) -> None:
        bg = self._bg()
        if bg is None:
            return await self._send(ctx, ui.fail("Module Not Loaded", "The BotGuard module is not loaded."))
        action = (action or "status").lower()
        if action in ("status", "show", "info"):
            if not await self._gate(ctx):
                return
            return await self._send(ctx, await self._bg_status(ctx, bg, which, title))
        if which == "integration" and action in ("snapshot", "resync", "accept"):
            if not await self._manager_gate(ctx):
                return
            snap = await bg.resnapshot(ctx.guild)
            if snap is None:
                return await self._send(ctx, ui.fail("No Bot Role", "I have no integration (bot) role in this server."))
            return await self._send(ctx, ui.ok("Snapshot Saved", f"Expected state of **{snap.name}** saved: "
                                                f"`{bin(snap.perms).count('1')}` permissions, rank `{snap.rank_above}` roles above."))
        value = parse_toggle(action)
        if value is None:
            return await self._send(ctx, ui.command_help_view(ctx.clean_prefix, ctx.command))
        if not await self._manager_gate(ctx):
            return
        await bg.set_flag(ctx.guild.id, which, value)
        body_on = "Protection is now active."
        if value:
            if not store.get(ctx.guild.id).enabled:
                body_on += f"\n{ui.CORNER} **Antinuke is not enabled** - run `{ctx.clean_prefix}antinuke enable`, otherwise nothing is checked."
            if which == "integration":
                snap = await bg.resnapshot(ctx.guild)
                ok, why = bg.restore_possible(ctx.guild)
                if not ok:
                    body_on += f"\n{ui.CORNER} **Recovery limit:** {why}"
            gp = ctx.guild.me.guild_permissions
            missing = [n for n, a in (("View Audit Log", gp.view_audit_log), ("Ban Members", gp.ban_members),
                                      ("Kick Members", gp.kick_members)) if not (a or gp.administrator)]
            if missing:
                body_on += f"\n{ui.CORNER} **Missing permissions:** {', '.join(missing)}"
        await self._send(ctx, ui.toggled(title, value, body_on, "Protection is now inactive."))

    async def _bg_status(self, ctx, bg, which: str, title: str):
        on = bg.flag(ctx.guild.id, which)
        yn = lambda b: ui.OK if b else ui.NO  # noqa: E731
        lines = [f"## {title}", f"> `Status` \u2192 {yn(on)}", f"> `Antinuke engine` \u2192 {yn(store.get(ctx.guild.id).enabled)}"]
        gp = ctx.guild.me.guild_permissions
        lines.append(f"> `View Audit Log` \u2192 {yn(gp.view_audit_log or gp.administrator)}")
        if which == "integration":
            snap = bg.snaps.get(ctx.guild.id)
            ok, why = bg.restore_possible(ctx.guild)
            lines.append(f"> `Snapshot` \u2192 " + (f"`{snap.name}` ({bin(snap.perms).count('1')} perms)" if snap else "`none yet`"))
            lines.append(f"> `Auto Recovery` \u2192 {yn(store.get(ctx.guild.id).autorec)}")
            lines.append(f"> `Can restore now` \u2192 {yn(ok)}" + ("" if ok else f"\n{ui.CORNER} {why}"))
        else:
            lines.append(f"> `Extra owners` \u2192 `{len(bg.extra_ids(ctx.guild.id))}`")
        ev = await bg.recent_events(ctx.guild.id, 3)
        if ev:
            lines.append("**Recent events**\n" + "\n".join(f"{ui.TICK} <t:{int(t)}:R> `{k}`" for t, k, *_ in ev))
        return ui.view_of(ui.text("\n".join(lines)))

    # ---- .antinuke
    @commands.group(name="antinuke", aliases=["anti"], invoke_without_command=True,
                    help="Manage the antinuke security system.")
    @commands.guild_only()
    async def antinuke(self, ctx):
        view = ui.group_help_view(ctx, ctx.command, extra_pages=self._module_pages(ctx))
        view.message = await self._send(ctx, view)

    @antinuke.command(name="enable", help="Enable and configure antinuke on the server.")
    async def antinuke_enable(self, ctx):
        if not await self._gate(ctx):
            return
        cfg = store.get(ctx.guild.id)
        if cfg.enabled:
            return await self._send(ctx, ui.ok("Antinuke Already Enabled", "The engine is already protecting this server."))
        # Auto recovery is ON by default now: a fresh enable must be able to repair a nuke.
        fresh = True                                   # enabling always switches Auto Recovery ON
        await store.update(ctx.guild.id, enabled=True, autorec=True)
        if self._bg() is not None:
            await self._bg().enable_defaults(ctx.guild.id)       # Anti Bot Nuker + Bot Add Protection on for new setups
        if self._ob() is not None:
            await self._ob().enable_defaults(ctx.guild.id)       # Anti-Onboarding on for new setups
            self._ob()._kick_cfg_check(ctx.guild, "enabled")
        if self._ig() is not None:
            await self._ig().enable_defaults(ctx.guild.id)       # Anti Invite Role on for new setups
        if self._vg() is not None:
            await self._vg().enable_defaults(ctx.guild.id)       # Anti Vanity on for new setups
        body = "The engine is now live and protecting this server."
        if fresh:
            body += f"\n{ui.CORNER} **Auto Recovery** is enabled (channels, roles & more get restored)."
        elif not store.get(ctx.guild.id).autorec:
            body += (f"\n{ui.CORNER} Auto Recovery is **off** - run `{ctx.clean_prefix}antinuke autorecovery enable` "
                     "so deleted channels/roles get restored.")
        missing = missing_perms(ctx.guild.me)
        if missing:
            body += f"\n{ui.CORNER} **Missing permissions:** {', '.join(missing)}"
        if not cfg.log:
            body += f"\n{ui.CORNER} Run `{ctx.clean_prefix}antinuke wizard` for the full setup."
        await self._send(ctx, ui.ok("Antinuke Enabled", body))

    @antinuke.command(name="disable", help="Disable and reset antinuke on the server.")
    async def antinuke_disable(self, ctx):
        if not await self._gate(ctx, owner_only=True):
            return
        gid = ctx.guild.id

        async def action():
            await store.wipe(gid)
            if self._bg() is not None:
                await self._bg().wipe(gid)
            if self._ob() is not None:
                await self._ob().wipe(gid)
            if self._ig() is not None:
                await self._ig().wipe(gid)
            if self._vg() is not None:
                await self._vg().wipe(gid)

        view = ConfirmView(ctx, "Disable Antinuke",
                           "This turns antinuke off and **resets every setting**, the whitelist and the mainroles.",
                           action, "Antinuke Disabled", "Antinuke was disabled and all settings were reset.")
        view.message = await self._send(ctx, view)

    @antinuke.command(name="config", help="Shows the current antinuke configuration.")
    async def antinuke_config(self, ctx):
        if not await self._gate(ctx):
            return
        cfg = store.get(ctx.guild.id)
        yn = lambda b: ui.OK if b else ui.NO  # noqa: E731
        head = ("## Antinuke Configuration\n"
                f"> `Engine Status` \u2192 {yn(cfg.enabled)}\n"
                f"> `Auto Recovery` \u2192 {yn(cfg.autorec)}\n"
                f"> `Betrayal Guard` \u2192 {yn(cfg.betrayal)}\n"
                f"> `Owner Only` \u2192 {yn(cfg.owneronly)}\n"
                f"> `Punishment` \u2192 `{cfg.punish}`")
        bg = self._bg()
        if bg is not None:
            head += (f"\n> `Anti Bot Nuker` \u2192 {yn(bg.flag(ctx.guild.id, 'integration'))}\n"
                     f"> `Bot Add Protection` \u2192 {yn(bg.flag(ctx.guild.id, 'botadd'))}")
        if self._ob() is not None:
            head += f"\n> `Anti-Onboarding` \u2192 {yn(self._ob().flag(ctx.guild.id))}"
        if self._ig() is not None:
            head += f"\n> `Anti Invite Role` \u2192 {yn(self._ig().flag(ctx.guild.id))}"
        if self._vg() is not None:
            head += f"\n> `Anti Vanity` \u2192 {yn(self._vg().flag(ctx.guild.id))}"
        on = bin(cfg.mods).count("1")
        barrier = f"<@&{cfg.barrier}>" if cfg.barrier else "`Not set`"
        log = f"<#{cfg.log}>" if cfg.log else "`Not set`"
        roles = (f"__**Channels & Roles**__\n"
                 f"{ui.TICK} **Barrier Role :** {barrier}\n"
                 f"{ui.TICK} **Log Channel :** {log}\n"
                 f"{ui.TICK} **Modules :** `{on}/{len(store.MODULES)}` enabled\n"
                 f"{ui.TICK} **Whitelisted :** `{len(cfg.wl)}` user(s) | **Mainroles :** `{len(cfg.mainroles)}`")
        avatar = self.bot.user.display_avatar.url
        foot = f"-# Requested by {ctx.author.mention} (`{ctx.author.name}`)"
        await self._send(ctx, ui.view_of(ui.with_thumb(head, avatar), ui.sep(), ui.text(roles), ui.sep(), ui.text(foot)))

    @antinuke.command(name="manage", help="Manage and toggle specific antinuke modules.")
    async def antinuke_manage(self, ctx):
        if not await self._gate(ctx):
            return
        view = ManageView(ctx)
        view.message = await self._send(ctx, view)

    @antinuke.command(name="limit", help="Set limits for whitelisted users before betrayal triggers.")
    async def antinuke_limit(self, ctx, module: str, amount: int):
        if not await self._gate(ctx):
            return
        if module.lower() == "all":
            keys, label = list(store.KEYS), "all modules"
        else:
            key = store.resolve(module)
            if key is None:
                names = ", ".join(f"`{k}`" for k in store.KEYS)
                return await self._send(ctx, ui.fail("Unknown Module", f"Valid modules: {names}, `all`"))
            keys, label = [key], f"**{store.LABELS[key]}**"
        if not 1 <= amount <= store.MAX_LIMIT:
            return await self._send(ctx, ui.fail("Invalid Limit", f"The limit must be between `1` and `{store.MAX_LIMIT}`."))
        await store.set_limits(ctx.guild.id, keys, amount)
        await self._send(ctx, ui.ok("Limit Updated", f"Whitelisted users can now do `{amount}` actions per minute on "
                                                   f"{label} before betrayal triggers."))

    @antinuke.command(name="punishment", aliases=["punish", "pt"],
                      help="Set what happens to a nuker: ban, kick, timeout or strip.")
    async def antinuke_punishment(self, ctx, kind: str = None):
        if not await self._gate(ctx):
            return
        cur = store.get(ctx.guild.id).punish
        kind = (kind or "").lower()
        alias = {"mute": "timeout", "tmo": "timeout", "removeroles": "strip", "stripper": "strip", "roles": "strip"}
        kind = alias.get(kind, kind)
        if kind not in store.PUNISHMENTS:
            return await self._send(ctx, ui.ok("Antinuke Punishment",
                f"Current: **{cur}**\n"
                f"`{ctx.clean_prefix}antinuke punishment ban` - ban (fastest, recommended)\n"
                f"`{ctx.clean_prefix}antinuke punishment kick` - kick\n"
                f"`{ctx.clean_prefix}antinuke punishment timeout` - 28 day timeout\n"
                f"`{ctx.clean_prefix}antinuke punishment strip` - remove all roles I can"))
        await store.update(ctx.guild.id, punish=kind)
        await self._send(ctx, ui.ok("Punishment Updated",
            f"Nukers will now be **{ {'ban': 'banned', 'kick': 'kicked', 'timeout': 'timed out for 28 days', 'strip': 'stripped of their roles'}[kind] }**.\n"
            "If I can't do that (role hierarchy / admin), I strip their dangerous roles instead."))

    @antinuke.command(name="linkedrole", aliases=["linkedroles", "linkrole", "linkroles", "lr", "linkinvite", "lrp"],
                      help="Linked Role protection: enable | disable | status | threshold | unlock | restore | evidence")
    async def antinuke_linkedrole(self, ctx, *, rest: str = None):
        first = (rest or "").split(None, 1)[0].lower() if rest else ""
        if first and parse_toggle(first) is None:           # status / threshold / unlock / restore / evidence -> LinkInvite cog
            import copy
            msg = copy.copy(ctx.message)
            msg.content = f"{ctx.prefix}linkinvite {rest}"
            return await self.bot.process_commands(msg)
        if not await self._gate(ctx):
            return
        value = parse_toggle(first)
        cfg = store.get(ctx.guild.id)
        bit = store.BIT["linkrole"]
        if value is None:
            state = "enabled" if cfg.mods & bit else "disabled"
            p = ctx.clean_prefix
            return await self._send(ctx, ui.ok("Anti Linked Role",
                f"Currently **{state}**.\nUse `{p}antinuke linkedrole enable` / `disable`.\n"
                f"{ui.CORNER} More: `{p}antinuke linkedrole status` | `threshold` | `unlock` | `restore` | `evidence`\n"
                "A role that gets connection / app requirements (Linked Role) is deleted instantly "
                "and whoever made it is punished."))
        mods = (cfg.mods | bit) if value else (cfg.mods & ~bit)
        await store.update(ctx.guild.id, mods=mods)
        await self._send(ctx, ui.toggled("Anti Linked Role", value,
                                         "Linked Roles are now deleted and whoever makes them is punished.",
                                         "Linked Roles are no longer blocked."))

    @antinuke.command(name="integration", help="Anti Bot Nuker: protect my bot role & integration. on | off | status | snapshot")
    async def antinuke_integration(self, ctx, action: str = "status"):
        await self._bg_toggle(ctx, "integration", action, "Anti Bot Nuker")

    @antinuke.command(name="botadd", help="Bot Add Protection: only the owner / extra owners may add bots. on | off | status")
    async def antinuke_botadd(self, ctx, action: str = "status"):
        await self._bg_toggle(ctx, "botadd", action, "Bot Add Protection")

    @antinuke.group(name="extraowner", aliases=["extraowners", "eo"], invoke_without_command=True,
                    help="Manage extra owners who may authorize bot additions. add | remove | list")
    async def antinuke_extraowner(self, ctx):
        view = ui.group_help_view(ctx, ctx.command)
        view.message = await self._send(ctx, view)

    @antinuke_extraowner.command(name="add", help="Authorize a user to add bots (server owner / extra owners only).")
    async def extraowner_add(self, ctx, user: discord.User):
        bg = self._bg()
        if bg is None or not await self._manager_gate(ctx):
            return
        res = await bg.add_extra(ctx.guild, user.id, ctx.author.id, is_bot=user.bot)
        msg = {"added": (ui.ok, "Extra Owner Added", f"{user.mention} can now authorize bot additions."),
               "exists": (ui.fail, "Already Added", f"{user.mention} is already an extra owner."),
               "implicit": (ui.fail, "Not Needed", "The server owner / config-file extra owners are always trusted."),
               "invalid": (ui.fail, "Invalid User", "Bots cannot be extra owners."),
               "limit": (ui.fail, "Limit Reached", "You can have at most 25 extra owners.")}[res]
        await self._send(ctx, msg[0](msg[1], msg[2]))

    @antinuke_extraowner.command(name="remove", help="Remove an extra owner (server owner / extra owners only).")
    async def extraowner_remove(self, ctx, user: discord.User):
        bg = self._bg()
        if bg is None or not await self._manager_gate(ctx):
            return
        res = await bg.remove_extra(ctx.guild.id, user.id, ctx.author.id)
        msg = {"removed": (ui.ok, "Extra Owner Removed", f"{user.mention} can no longer authorize bot additions."),
               "absent": (ui.fail, "Not Found", f"{user.mention} is not an extra owner here."),
               "config": (ui.fail, "Configured Globally", "This extra owner comes from the bot config (EXTRA_OWNER_IDS); remove it there.")}[res]
        await self._send(ctx, msg[0](msg[1], msg[2]))

    @antinuke_extraowner.command(name="list", aliases=["show"], help="List the server owner and extra owners.")
    async def extraowner_list(self, ctx):
        bg = self._bg()
        if bg is None or not await self._gate(ctx):
            return
        lines = [f"{ui.TICK} <@{ctx.guild.owner_id}> {ui.ARROW} **Server Owner** (always trusted)"]
        lines += [f"{ui.TICK} <@{u}> {ui.ARROW} config" for u in sorted(bg.global_extra())]
        lines += [f"{ui.TICK} <@{u}> {ui.ARROW} this server" for u in sorted(bg.extra.get(ctx.guild.id, ()))]
        await self._send(ctx, ui.view_of(ui.text("## Bot Add Authorization\n" + "\n".join(lines))))

    # ---- Anti-Onboarding (same antinuke group / help menu)
    @antinuke.group(name="onboarding", aliases=["onboard", "ob"], invoke_without_command=True,
                    help="Anti-Onboarding: block Administrator roles via onboarding. on | off | status | scan | clean | trust")
    async def antinuke_onboarding(self, ctx, action: str = "status"):
        ob = self._ob()
        if ob is None:
            return await self._send(ctx, ui.fail("Module Not Loaded", "The Anti-Onboarding module is not loaded."))
        action = (action or "status").lower()
        gid = ctx.guild.id
        if action in ("status", "show", "info"):
            if not await self._gate(ctx):
                return
            return await self._send(ctx, await self._ob_status(ctx, ob))
        if action == "scan":
            if not await self._gate(ctx):
                return
            cfg, why, rows = await ob.scan(ctx.guild)
            if cfg is None:
                return await self._send(ctx, ui.fail("Cannot Read Onboarding", "Discord refused: I need **Manage Server** and **Manage Roles**."
                                                      if why == "forbidden" else "Discord returned an error; try again."))
            lines = [f"{ui.TICK} <@&{r}> {ui.ARROW} " + ("**Administrator**" if t == 2 else "dangerous" if t else "safe") for r, _, t, _ in rows]
            bad = sum(1 for _r, _n, t, _p in rows if t)
            body = "\n".join(lines) or "Onboarding does not hand out any role."
            tail = (f"\n{ui.CORNER} **{bad}** dangerous role(s). Run `{ctx.clean_prefix}antinuke onboarding clean` to remove them." if bad else "")
            return await self._send(ctx, ui.view_of(ui.text(f"## Onboarding Scan\n{body}{tail}")))
        if action in ("clean", "sanitize"):
            if not await self._manager_gate(ctx):
                return
            st, detail, roles = await ob.clean_now(ctx.guild, ctx.author.id)
            fn = ui.ok if st == "ok" else ui.fail
            return await self._send(ctx, fn("Onboarding Cleaned" if st == "ok" else "Onboarding Not Cleaned",
                                            detail + (f"\n{ui.CORNER} roles: " + ", ".join(f"<@&{r}>" for r in roles) if roles else "")))
        value = parse_toggle(action)
        if value is None:
            return await self._send(ctx, ui.command_help_view(ctx.clean_prefix, ctx.command))
        if not await self._manager_gate(ctx):
            return
        await ob.set_flag(gid, value)
        body_on = "Protection is now active."
        if value:
            ob._kick_cfg_check(ctx.guild, "enabled")
            if not store.get(gid).enabled:
                body_on += f"\n{ui.CORNER} **Antinuke is not enabled** - run `{ctx.clean_prefix}antinuke enable`, otherwise nothing is checked."
            info = ob.status_info(ctx.guild)
            missing = [n for n, a in (("View Audit Log", info["audit"]), ("Manage Roles", info["manage_roles"]),
                                      ("Manage Server", info["manage_guild"]), ("Ban Members", info["ban"])) if not a]
            if missing:
                body_on += f"\n{ui.CORNER} **Missing permissions:** {', '.join(missing)}"
        await self._send(ctx, ui.toggled("Anti-Onboarding", value, body_on, "Protection is now inactive."))

    async def _ob_status(self, ctx, ob):
        info = ob.status_info(ctx.guild)
        yn = lambda b: ui.OK if b else ui.NO  # noqa: E731
        lines = ["## Anti-Onboarding", f"> `Status` \u2192 {yn(info['on'])}", f"> `Antinuke engine` \u2192 {yn(info['engine'])}",
                 f"> `View Audit Log` \u2192 {yn(info['audit'])}", f"> `Manage Roles` \u2192 {yn(info['manage_roles'])}",
                 f"> `Manage Server` \u2192 {yn(info['manage_guild'])}",
                 f"> `Onboarding baseline` \u2192 {yn(info['baseline'])} ({info['known_roles']} role(s) watched)",
                 f"> `Trusted administrators` \u2192 `{info['trusted']}`"]
        ev = await ob.recent_events(ctx.guild.id, 3)
        if ev:
            lines.append("**Recent events**\n" + "\n".join(f"{ui.TICK} <t:{int(t)}:R> `{k}`" for t, k, *_ in ev))
        return ui.view_of(ui.text("\n".join(lines)))

    @antinuke_onboarding.group(name="trust", aliases=["trusted"], invoke_without_command=True,
                               help="Trusted administrators who may configure dangerous onboarding roles. add | remove | list")
    async def onboarding_trust(self, ctx):
        view = ui.group_help_view(ctx, ctx.command)
        view.message = await self._send(ctx, view)

    @onboarding_trust.command(name="add", help="Trust a user (server owner / extra owners only).")
    async def onboarding_trust_add(self, ctx, user: discord.User):
        ob = self._ob()
        if ob is None or not await self._manager_gate(ctx):
            return
        res = await ob.add_trusted(ctx.guild, user.id, ctx.author.id, is_bot=user.bot)
        msg = {"added": (ui.ok, "Trusted Administrator Added", f"{user.mention} is now exempt from Anti-Onboarding punishment."),
               "exists": (ui.fail, "Already Trusted", f"{user.mention} is already trusted."),
               "implicit": (ui.fail, "Not Needed", "The server owner and extra owners are always exempt."),
               "invalid": (ui.fail, "Invalid User", "Bots cannot be trusted administrators."),
               "limit": (ui.fail, "Limit Reached", "You can trust at most 25 users.")}[res]
        await self._send(ctx, msg[0](msg[1], msg[2]))

    @onboarding_trust.command(name="remove", help="Remove a trusted user (server owner / extra owners only).")
    async def onboarding_trust_remove(self, ctx, user: discord.User):
        ob = self._ob()
        if ob is None or not await self._manager_gate(ctx):
            return
        res = await ob.remove_trusted(ctx.guild.id, user.id, ctx.author.id)
        msg = {"removed": (ui.ok, "Trusted Administrator Removed", f"{user.mention} is no longer exempt."),
               "absent": (ui.fail, "Not Found", f"{user.mention} is not on the trusted list.")}[res]
        await self._send(ctx, msg[0](msg[1], msg[2]))

    @onboarding_trust.command(name="list", aliases=["show"], help="List the exempt users.")
    async def onboarding_trust_list(self, ctx):
        ob = self._ob()
        if ob is None or not await self._gate(ctx):
            return
        lines = [f"{ui.TICK} <@{ctx.guild.owner_id}> {ui.ARROW} **Server Owner** (always exempt)"]
        lines += [f"{ui.TICK} <@{u}> {ui.ARROW} extra owner" for u in sorted(ob.extra_ids(ctx.guild.id))]
        lines += [f"{ui.TICK} <@{u}> {ui.ARROW} trusted" for u in sorted(ob.trusted.get(ctx.guild.id, ()))]
        await self._send(ctx, ui.view_of(ui.text("## Anti-Onboarding Exemptions\n" + "\n".join(lines))))

    # ---- Anti Invite Role (same antinuke group / help menu)
    @antinuke.group(name="inviterole", aliases=["inviteroles", "invrole", "invroles", "roleinvite", "antiinviterole"],
                    invoke_without_command=True,
                    help="Anti Invite Role: stop role-attached invites from unauthorized users. on | off | status | scan | sweep | restore <role_id>")
    async def antinuke_inviterole(self, ctx, action: str = "status", target: Optional[str] = None):
        ig = self._ig()
        if ig is None:
            return await self._send(ctx, ui.fail("Module Not Loaded", "The Anti Invite Role module is not loaded."))
        action = (action or "status").lower()
        gid = ctx.guild.id
        if action in ("status", "show", "info"):
            if not await self._gate(ctx):
                return
            return await self._send(ctx, await self._ig_status(ctx, ig))
        if action == "scan":
            if not await self._gate(ctx):
                return
            rows, why = await ig.scan(ctx.guild)
            if rows is None:
                return await self._send(ctx, ui.fail("Cannot Read Invites", "Discord refused: I need **Manage Server**." if why == "forbidden"
                                                     else "Discord returned an error; try again."))
            lines = [f"{ui.TICK} `{code}` {ui.ARROW} " + (f"<@{inviter}>" if inviter else "unknown creator") + " | roles "
                     + ", ".join(f"<@&{r}>" for r in rids) + (" | **privileged**" if priv else "") for code, inviter, rids, priv in rows[:15]]
            body = "\n".join(lines) or "No invite in this server hands out a role."
            return await self._send(ctx, ui.view_of(ui.text(f"## Invite Role Scan\n{body}\n-# Read only. Invites made while I was offline are listed here but not acted on.")))
        if action == "sweep":
            if not await self._manager_gate(ctx):
                return
            n = await ig.sweep_guild(ctx.guild, force=True)
            return await self._send(ctx, ui.ok("Invite Role Sweep", f"{n} role-attached invite(s) of untrusted creators are being removed and their roles defanged (a sweep never bans)."
                                               if n else "No role-attached invite of an untrusted creator exists."))
        if action == "restore":
            if not await self._manager_gate(ctx):
                return
            digits = "".join(ch for ch in (target or "") if ch.isdigit())
            if not digits:
                return await self._send(ctx, ui.fail("Role Needed", f"Usage: `{ctx.clean_prefix}antinuke inviterole restore <role_id>`"))
            st, detail = await ig.restore_role(ctx.guild, int(digits), ctx.author.id)
            return await self._send(ctx, (ui.ok if st == "ok" else ui.fail)("Role Restored" if st == "ok" else "Role Not Restored", detail))
        value = parse_toggle(action)
        if value is None:
            return await self._send(ctx, ui.command_help_view(ctx.clean_prefix, ctx.command))
        if not await self._manager_gate(ctx):
            return
        await ig.set_flag(gid, value)
        body_on = "Protection is now active."
        if value:
            if not store.get(gid).enabled:
                body_on += f"\n{ui.CORNER} **Antinuke is not enabled** - run `{ctx.clean_prefix}antinuke enable`, otherwise nothing is checked."
            info = ig.status_info(ctx.guild)
            missing = [n for n, a in (("View Audit Log", info["audit"]), ("Manage Roles", info["manage_roles"]),
                                      ("Manage Server", info["manage_guild"]), ("Ban Members", info["ban"])) if not a]
            if missing:
                body_on += f"\n{ui.CORNER} **Missing permissions:** {', '.join(missing)}"
        await self._send(ctx, ui.toggled("Anti Invite Role", value, body_on, "Protection is now inactive."))

    async def _ig_status(self, ctx, ig):
        info = ig.status_info(ctx.guild)
        yn = lambda b: ui.OK if b else ui.NO  # noqa: E731
        lines = ["## Anti Invite Role", f"> `Status` \u2192 {yn(info['on'])}", f"> `Antinuke engine` \u2192 {yn(info['engine'])}",
                 f"> `Raw gateway hook` \u2192 {yn(info['raw_hook'])}", f"> `View Audit Log` \u2192 {yn(info['audit'])}",
                 f"> `Manage Roles` \u2192 {yn(info['manage_roles'])}", f"> `Manage Server` \u2192 {yn(info['manage_guild'])}",
                 f"> `Ban Members` \u2192 {yn(info['ban'])}",
                 f"> `Invite events seen / with roles` \u2192 `{info['invites_seen']}` / `{info['role_invites']}`",
                 f"> `Stripped roles restorable` \u2192 `{info['snapshots']}`"]
        ev = await ig.recent_events(ctx.guild.id, 3)
        if ev:
            lines.append("**Recent events**\n" + "\n".join(f"{ui.TICK} <t:{int(t)}:R> `{k}`" for t, k, *_ in ev))
        return ui.view_of(ui.text("\n".join(lines)))

    # ---- Anti Vanity (same antinuke group / help menu)
    @antinuke.group(name="vanity", aliases=["vanityurl", "antivanity", "vanityguard"], invoke_without_command=True,
                    help="Anti Vanity: protect the server vanity URL. on | off | status | restore | sync | fast on|off")
    async def antinuke_vanity(self, ctx, action: str = "status", target: Optional[str] = None):
        vg = self._vg()
        if vg is None:
            return await self._send(ctx, ui.fail("Module Not Loaded", "The Anti Vanity module is not loaded."))
        action = (action or "status").lower()
        gid = ctx.guild.id
        if action in ("status", "show", "info"):
            if not await self._gate(ctx):
                return
            return await self._send(ctx, await self._vg_status(ctx, vg))
        if action == "restore":
            if not await self._manager_gate(ctx):
                return
            st, detail = await vg.restore_now(ctx.guild, ctx.author.id)
            return await self._send(ctx, (ui.ok if st == "ok" else ui.fail)("Vanity Restored" if st == "ok" else "Vanity Not Restored", detail))
        if action == "fast":
            fv = parse_toggle(target or "")
            if fv is None:
                return await self._send(ctx, ui.fail("Fast Mode", f"Usage: `{ctx.clean_prefix}antinuke vanity fast on` or `off`. Currently: "
                                                      f"{'ON' if vg.is_fast(gid) else 'OFF'}."))
            if not await self._manager_gate(ctx):
                return
            await vg.set_fast(gid, fv)
            return await self._send(ctx, ui.toggled("Vanity Fast Mode", fv,
                                                    "The old code is put back the moment a change is seen, before the audit log answers. A change by the owner "
                                                    "is reverted and applied again within about a second.",
                                                    "The old code is only put back after the audit log confirms who changed it (slower, no revert of the owner)."))
        if action == "sync":
            if not await self._manager_gate(ctx):
                return
            st, detail = await vg.sync_now(ctx.guild, ctx.author.id)
            return await self._send(ctx, (ui.ok if st == "ok" else ui.fail)("Vanity Synced" if st == "ok" else "Vanity Not Synced", detail))
        value = parse_toggle(action)
        if value is None:
            return await self._send(ctx, ui.command_help_view(ctx.clean_prefix, ctx.command))
        if not await self._manager_gate(ctx):
            return
        await vg.set_flag(gid, value, ctx.guild)
        body_on = "Protection is now active."
        if value:
            if not store.get(gid).enabled:
                body_on += f"\n{ui.CORNER} **Antinuke is not enabled** - run `{ctx.clean_prefix}antinuke enable`, otherwise nothing is checked."
            if not getattr(ctx.guild, "vanity_url_code", None):
                body_on += f"\n{ui.CORNER} **This server has no vanity URL right now**, so there is nothing to restore yet."
            info = vg.status_info(ctx.guild)
            missing = [n for n, a in (("View Audit Log", info["audit"]), ("Manage Server", info["manage_guild"]),
                                      ("Ban Members", info["ban"])) if not a]
            if missing:
                body_on += f"\n{ui.CORNER} **Missing permissions:** {', '.join(missing)}"
        await self._send(ctx, ui.toggled("Anti Vanity", value, body_on, "Protection is now inactive."))

    async def _vg_status(self, ctx, vg):
        info = vg.status_info(ctx.guild)
        yn = lambda b: ui.OK if b else ui.NO  # noqa: E731
        shown = lambda c: f"`discord.gg/{c}`" if c else "`none`"  # noqa: E731
        lines = ["## Anti Vanity", f"> `Status` \u2192 {yn(info['on'])}", f"> `Antinuke engine` \u2192 {yn(info['engine'])}",
                 f"> `Raw gateway hook` \u2192 {yn(info['raw_hook'])}", f"> `View Audit Log` \u2192 {yn(info['audit'])}",
                 f"> `Manage Server` \u2192 {yn(info['manage_guild'])}", f"> `Ban Members` \u2192 {yn(info['ban'])}",
                 f"> `Protected code` \u2192 {shown(info['protected']) if info['tracked'] else '`not tracked`'}",
                 f"> `Code right now` \u2192 {shown(info['live'])}",
                 f"> `Fast mode` \u2192 {yn(info['fast'])}", f"> `Direct request path` \u2192 {yn(info['direct'])}",
                 f"> `Changes seen / restored` \u2192 `{info['changes_seen']}` / `{info['restores']}`"]
        if info["pending"]:
            lines.append(f"{ui.CORNER} The code differs from the protected one and was not restored: `antinuke vanity restore` or `antinuke vanity sync`.")
        ev = await vg.recent_events(ctx.guild.id, 3)
        if ev:
            lines.append("**Recent events**\n" + "\n".join(f"{ui.TICK} <t:{int(t)}:R> `{k}`" for t, k, *_ in ev))
        return ui.view_of(ui.text("\n".join(lines)))

    @antinuke.command(name="logging", help="Set the channel for antinuke logs.")
    async def antinuke_logging(self, ctx, channel: discord.TextChannel):
        if not await self._gate(ctx):
            return
        if not channel.permissions_for(ctx.guild.me).send_messages:
            return await self._send(ctx, ui.fail("Missing Permission", f"I can't send messages in {channel.mention}."))
        await store.update(ctx.guild.id, log=channel.id)
        await self.send_test_log(channel)
        await self._send(ctx, ui.ok("Log Channel Set", f"Antinuke logs will be sent to {channel.mention}."))

    @staticmethod
    async def send_test_log(channel: discord.TextChannel) -> None:
        body = (f"## Test Log Message\n"
                f"> **Channel :** {channel.name} ({channel.mention})\n"
                f"> **Channel ID :** `{channel.id}`\n"
                f"-# <t:{int(time.time())}:T>")
        try:
            await channel.send(view=ui.view_of(ui.text(body)), allowed_mentions=ui.NO_PING)
        except (discord.Forbidden, discord.HTTPException):
            pass

    @antinuke.command(name="autorecovery", aliases=["ar"], help="Manage server autorecovery settings.")
    async def antinuke_autorecovery(self, ctx, action: str):
        await self._flag(ctx, action, "autorec", "Autorecovery",
                         "The bot will now attempt to recover from nuke events.",
                         "The bot will no longer attempt to recover from nuke events.")

    @antinuke.command(name="betrayalguard", aliases=["bg"], help="Enable or disable betrayal guard for whitelisted users.")
    async def antinuke_betrayalguard(self, ctx, action: str):
        await self._flag(ctx, action, "betrayal", "Betrayal Guard",
                         "Whitelisted users who exceed their limits will now be punished.",
                         "Whitelisted users are no longer limited.")

    @antinuke.command(name="owneronly", aliases=["oo"], help="Toggle owner only mode for all security commands.")
    async def antinuke_owneronly(self, ctx, action: str):
        await self._flag(ctx, action, "owneronly", "Owner Only Mode",
                         "Only the server owner can use security commands now.",
                         "Whitelisted users can use security commands again.", owner_only=True)

    @antinuke.command(name="whitelist", aliases=["wl"], help="Manage whitelisting for antinuke filters.")
    async def antinuke_whitelist(self, ctx, user: discord.User):
        if not await self._gate(ctx, owner_only=True):
            return
        if user.id == ctx.guild.owner_id:
            return await self._send(ctx, ui.fail("Not Needed", "The server owner is always trusted."))
        if user.id == self.bot.user.id:
            return await self._send(ctx, ui.fail("Not Needed", "I am always trusted."))
        view = WhitelistView(ctx, user)
        view.message = await self._send(ctx, view)

    @antinuke.command(name="whitelisted", help="Show the list of whitelisted users.")
    async def antinuke_whitelisted(self, ctx):
        if not await self._gate(ctx):
            return
        wl = store.get(ctx.guild.id).wl
        if not wl:
            return await self._send(ctx, ui.fail("No Whitelisted Users", "Nobody is whitelisted in this server."))
        total = len(store.MODULES)
        lines = [f"{ui.TICK} <@{uid}> (`{uid}`) {ui.ARROW} " +
                 ("all modules" if mask == store.ALL_MASK else f"`{bin(mask).count('1')}/{total}` modules")
                 for uid, mask in sorted(wl.items())]
        pages = ["\n".join(lines[i:i + 12]) for i in range(0, len(lines), 12)]
        view = ui.PagerView(ctx, f"## Whitelisted Users [{len(wl)}]", pages)
        view.message = await self._send(ctx, view)

    @antinuke.command(name="wizard", help="One-click setup for a powerful antinuke configuration.")
    @commands.max_concurrency(1, per=commands.BucketType.guild, wait=False)
    async def antinuke_wizard(self, ctx):
        if not await self._gate(ctx):
            return
        guild, me = ctx.guild, ctx.guild.me
        lines: list[str] = []
        msg: Optional[discord.Message] = None

        async def step(line: str, flush: bool = True) -> None:
            nonlocal msg
            lines.append(f"{ui.TICK} {line}")
            if not flush:
                return
            view = ui.view_of(ui.text("## Setting up Antinuke!\n" + "\n".join(lines)))
            if msg is None:
                msg = await self._send(ctx, view)
            else:
                await msg.edit(view=view, allowed_mentions=ui.NO_PING)

        cfg = store.get(guild.id)
        await step("Loaded server configs !", flush=False)
        await step("Checking permission and position for my role...", flush=False)
        missing = missing_perms(me)
        if missing:
            return await step(f"{ui.NO} I am missing: {', '.join(missing)}. Give me these (or Administrator) and run the wizard again.")
        above = [r for r in guild.roles if r > me.top_role and not r.managed and is_dangerous(r)]
        if above:
            await step(f"{ui.OK} Permission check passed, but **{len(above)}** powerful role(s) sit above mine and cannot "
                       "be protected. Move my role to the top.", flush=False)
        else:
            await step("Bot's role and position check passed ...", flush=False)
        await step("Enabling server Antinuke ...", flush=False)

        engine = self.bot.get_cog("AntinukeEngine")
        barrier = None
        if engine is not None:
            barrier, problem = await engine.ensure_barrier(guild)
            if barrier is not None and not problem:
                await step(f"Configured {barrier.mention} role (Administrator, just below my top role) ...")
            else:
                await step(f"{ui.NO} Barrier role problem: {problem or 'engine not loaded'}.")
        else:
            await step(f"{ui.NO} Antinuke engine is not loaded.")

        try:
            channel = guild.get_channel(cfg.log) if cfg.log else None
            created = False
            if channel is None:
                overwrites = {
                    guild.default_role: discord.PermissionOverwrite(view_channel=False),
                    me: discord.PermissionOverwrite(view_channel=True, send_messages=True, embed_links=True),
                    ctx.author: discord.PermissionOverwrite(view_channel=True, send_messages=False),
                }
                channel = await guild.create_text_channel("antinuke-logs", overwrites=overwrites,
                                                          reason="Antinuke wizard: log channel")
                created = True
            await step(f"Configured {channel.mention} channel for logging ...")
        except discord.HTTPException:
            channel, created = None, False
            await step(f"{ui.NO} Could not create the log channel (check my Manage Channels permission).")

        await step("Set default trust limits...", flush=False)
        await step("Secured log channel from abuse protection..." if created else
                   "Verified existing channels for abuse protection...", flush=False)
        await step("Saving changes...", flush=False)
        await store.update(guild.id, enabled=True, autorec=True, mods=store.ALL_MASK, limits={},
                           barrier=barrier.id if barrier else cfg.barrier,
                           log=channel.id if channel else cfg.log)
        if self._bg() is not None:
            await self._bg().enable_defaults(guild.id)
        if self._ob() is not None:
            await self._ob().enable_defaults(guild.id)
            self._ob()._kick_cfg_check(guild, "enabled")
        if self._ig() is not None:
            await self._ig().enable_defaults(guild.id)
        if self._vg() is not None:
            await self._vg().enable_defaults(guild.id)
        await step("Antinuke Setup Complete!")
        if channel is not None:
            await self.send_test_log(channel)

    # ---- .mainrole
    @commands.group(name="mainrole", invoke_without_command=True,
                    help="Manage mainrole configuration for your server.")
    @commands.guild_only()
    async def mainrole(self, ctx):
        view = ui.group_help_view(ctx, ctx.command)
        view.message = await self._send(ctx, view)

    @mainrole.command(name="add", help="Add a role to mainrole configuration.")
    async def mainrole_add(self, ctx, role: discord.Role):
        if not await self._gate(ctx, owner_only=True):
            return
        if role.is_default():
            return await self._send(ctx, ui.fail("Invalid Role", "`@everyone` can't be a mainrole."))
        if len(store.get(ctx.guild.id).mainroles) >= 25:
            return await self._send(ctx, ui.fail("Limit Reached", "You can only have 25 mainroles."))
        if not await store.add_mainrole(ctx.guild.id, role.id):
            return await self._send(ctx, ui.fail("Already Added", f"{role.mention} is already a mainrole."))
        await self._send(ctx, ui.ok("Mainrole Added", f"Members with {role.mention} are now trusted by antinuke."))

    @mainrole.command(name="remove", help="Remove a role from mainrole configuration.")
    async def mainrole_remove(self, ctx, role: discord.Role):
        if not await self._gate(ctx, owner_only=True):
            return
        if not await store.remove_mainrole(ctx.guild.id, role.id):
            return await self._send(ctx, ui.fail("Not Found", f"{role.mention} is not a mainrole."))
        await self._send(ctx, ui.ok("Mainrole Removed", f"{role.mention} was removed."))

    @mainrole.command(name="show", aliases=["list"], help="Show the configured mainroles.")
    async def mainrole_show(self, ctx):
        if not await self._gate(ctx):
            return
        ids = sorted(store.get(ctx.guild.id).mainroles)
        if not ids:
            return await self._send(ctx, ui.fail("No Mainroles", "No mainroles are configured."))
        lines = [f"{ui.TICK} <@&{rid}>" if ctx.guild.get_role(rid) else f"{ui.TICK} Deleted role (`{rid}`)" for rid in ids]
        await self._send(ctx, ui.view_of(ui.text(f"## Mainroles [{len(ids)}]\n" + "\n".join(lines))))

    @mainrole.command(name="reset", help="Remove every mainrole.")
    async def mainrole_reset(self, ctx):
        if not await self._gate(ctx, owner_only=True):
            return
        gid = ctx.guild.id

        async def action():
            await store.reset_mainroles(gid)

        view = ConfirmView(ctx, "Reset Mainroles", "Remove **every** mainrole?",
                           action, "Mainroles Reset", "All mainroles were removed.")
        view.message = await self._send(ctx, view)
