"""Automod commands (port of Lune's ``/automod`` dashboard).

``automod`` (= ``automod overview``), ``automod modules``, ``automod rules``, ``automod stats``,
``automod logs``.  Works as prefix command and as slash command.  Every reply is a #ffffff Components V2
dashboard.  Discord's native AutoMod does the scanning; the reactions live in ``cogs/automod/engine.py``.
"""
from __future__ import annotations

import discord
from discord.ext import commands

from utils import automod_ui as ui
from utils.Tools import blacklist_check, ignore_check

from ..automod.store import get_store


class Automod(commands.Cog, name="Automod"):
    """Automod: native Discord AutoMod rules managed from a dashboard."""

    def __init__(self, bot):
        self.bot = bot
        self.store = get_store(bot)

    async def cog_load(self) -> None:
        await self.store.start()

    # ------------------------------------------------------------------ plumbing
    async def cog_check(self, ctx: commands.Context) -> bool:
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        if not await blacklist_check().predicate(ctx):
            return False
        return await ignore_check().predicate(ctx)

    async def _guard(self, ctx: commands.Context) -> bool:
        """Administrator, Server Owner, Extraowner or bot owner."""
        member = ctx.author
        if (member.id == ctx.guild.owner_id or member.id in (self.bot.owner_ids or ())
                or member.guild_permissions.administrator):
            return True
        try:
            from utils.permit_store import store as permit
            if await permit.is_extraowner(ctx.guild.id, member.id):
                return True
        except Exception:
            pass
        await ctx.reply(view=ui.fail("Access Denied",
                                     "Only an **Administrator**, the **Server Owner** or an **Extraowner** "
                                     "can manage automod."),
                        mention_author=False, allowed_mentions=ui.NO_PING)
        return False

    async def _open(self, ctx: commands.Context, page: str) -> None:
        if not await self._guard(ctx):
            return
        await ui.Dashboard(ctx, self.store, page).start()

    # ================================================================== automod
    @commands.hybrid_group(name="automod", invoke_without_command=True, fallback="overview",
                           description="Open the AutoMod dashboard",
                           help="Open the AutoMod dashboard (overview).")
    @commands.guild_only()
    async def automod(self, ctx: commands.Context):
        await self._open(ctx, "overview")

    @automod.command(name="modules", description="Manage protection modules", help="Manage protection modules.")
    @commands.guild_only()
    async def am_modules(self, ctx: commands.Context):
        await self._open(ctx, "modules")

    @automod.command(name="rules", description="List created rules", help="List created Discord AutoMod rules.")
    @commands.guild_only()
    async def am_rules(self, ctx: commands.Context):
        await self._open(ctx, "rules")

    @automod.command(name="stats", description="Show AutoMod statistics", help="Show AutoMod enforcement statistics.")
    @commands.guild_only()
    async def am_stats(self, ctx: commands.Context):
        await self._open(ctx, "stats")

    @automod.command(name="logs", description="Show recent enforcement logs",
                     help="Show recent AutoMod enforcement logs.")
    @commands.guild_only()
    async def am_logs(self, ctx: commands.Context):
        await self._open(ctx, "logs")
