"""Autoresponder category > autoreact commands (in-memory cache, no global locks)."""
from __future__ import annotations

import asyncio
import time

import discord
from discord.ext import commands

from utils import autoresponder_ui as ui
from utils.autoresponder_store import CUSTOM_RE, MAX_EMOJIS, MAX_TRIGGERS, parse_emojis, reactions
from utils.Tools import blacklist_check, ignore_check

_USER_COOLDOWN = 2.0  # seconds between two auto-reactions for the same user


def _guard(func):
    """guild-only + blacklist + ignore + administrator, in that order."""
    func = commands.has_permissions(administrator=True)(func)
    func = ignore_check()(func)
    func = blacklist_check()(func)
    func = commands.guild_only()(func)
    return func


class AutoReaction(commands.Cog, name="Autoreact"):
    """Autoreact commands (Autoresponder category)."""

    def __init__(self, bot):
        self.bot = bot
        self._last: dict[int, float] = {}
        self._tasks: set[asyncio.Task] = set()

    async def cog_load(self) -> None:
        await reactions.load()

    # ------------------------------------------------------------ commands
    @commands.group(name="autoreact", aliases=["react"], invoke_without_command=True,
                    help="Lists all subcommands of autoreact group.",
                    extras={"help_order": ["reset", "list", "remove", "add"]})
    @_guard
    async def autoreact(self, ctx: commands.Context):
        await ui.send_group_help(ctx, ctx.command)

    @autoreact.command(name="add", aliases=["set", "create"], help="Adds a trigger and its emojis to the autoreact.")
    @_guard
    async def autoreact_add(self, ctx: commands.Context, trigger: str, *, emojis: str):
        found = parse_emojis(emojis)
        if not found:
            return await ctx.reply(view=ui.error("Invalid Emojis", "I couldn't find any valid emoji in your message."),
                                   mention_author=False)
        if len(found) > MAX_EMOJIS:
            return await ctx.reply(view=ui.error("Too Many Emojis", f"You can only set up to {MAX_EMOJIS} emojis per trigger."),
                                   mention_author=False)
        unknown = [e for e in found if (m := CUSTOM_RE.fullmatch(e)) and self.bot.get_emoji(int(m.group(1))) is None]
        if unknown:
            return await ctx.reply(view=ui.error(
                "Unknown Emoji", f"I can't use {' '.join(unknown)} because I'm not in the server that owns it."),
                mention_author=False)

        result = await reactions.add(ctx.guild.id, trigger, found)
        if result == "exists":
            view = ui.warning("Trigger Exists", f"The trigger {trigger} already exists. Remove it before adding it again.")
        elif result == "full":
            view = ui.warning("Trigger Limit Reached", f"You can only set up to {MAX_TRIGGERS} triggers for auto-reactions in this guild.")
        else:
            view = ui.success("Trigger Added", f"Successfully added trigger {trigger} with emojis {' '.join(found)}")
        await ctx.reply(view=view, mention_author=False)

    @autoreact.command(name="remove", aliases=["clear", "delete"], help="Removes a trigger and its emojis from the autoreact.")
    @_guard
    async def autoreact_remove(self, ctx: commands.Context, trigger: str):
        if await reactions.remove(ctx.guild.id, trigger):
            view = ui.success("Trigger Removed", f"Successfully removed trigger {trigger}")
        else:
            view = ui.error("Trigger Not Found", f"The trigger {trigger} does not exist.")
        await ctx.reply(view=view, mention_author=False)

    @autoreact.command(name="list", aliases=["show", "config"], help="Lists all the triggers and their emojis in the autoreact module.")
    @_guard
    async def autoreact_list(self, ctx: commands.Context):
        items = reactions.items(ctx.guild.id)
        if not items:
            return await ctx.reply(view=ui.error("No Triggers Set", "There are no auto-reaction triggers set in this guild"),
                                   mention_author=False)
        lines = [f"`{i}.` `{trigger}` ❯ {' '.join(emojis)}" for i, (trigger, emojis) in enumerate(items, 1)]
        lines.append(f"\n-# {len(items)}/{MAX_TRIGGERS} triggers")
        avatar = getattr(getattr(self.bot.user, "display_avatar", None), "url", None)
        await ctx.reply(view=ui.listing("Auto-Reaction Triggers", lines, thumb=avatar and str(avatar)), mention_author=False)

    @autoreact.command(name="reset", help="Resets all the triggers and their emojis in the autoreact module.")
    @_guard
    async def autoreact_reset(self, ctx: commands.Context):
        removed = await reactions.clear(ctx.guild.id)
        if not removed:
            view = ui.error("No Triggers Set", "There are no auto-reaction triggers set to reset.")
        else:
            view = ui.success("All Triggers Reset", "Successfully removed all auto-reaction triggers.")
        await ctx.reply(view=view, mention_author=False)

    # ------------------------------------------------------------ listener
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        guild = message.guild
        if guild is None or message.author.bot or not message.content:
            return
        emojis = reactions.emojis(guild.id, message.content)
        if not emojis:
            return
        me = guild.me
        if me is not None:
            perms = message.channel.permissions_for(me)
            if not (perms.add_reactions and perms.read_message_history):
                return
        now = time.monotonic()
        if now - self._last.get(message.author.id, 0.0) < _USER_COOLDOWN:
            return
        self._last[message.author.id] = now
        if len(self._last) > 5000:
            self._last = {u: t for u, t in self._last.items() if now - t < _USER_COOLDOWN}
        task = asyncio.create_task(self._react(message, emojis))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def _react(self, message: discord.Message, emojis) -> None:
        for emoji in emojis:
            try:
                await message.add_reaction(emoji)
            except discord.NotFound:
                if CUSTOM_RE.fullmatch(emoji):
                    continue  # unknown custom emoji (or message deleted)
                # unicode emoji: Discord can want the other spelling (with / without U+FE0F)
                alt = emoji.replace("️", "") if "️" in emoji else emoji + "️"
                try:
                    await message.add_reaction(alt)
                except discord.HTTPException:
                    continue
            except discord.Forbidden:
                return  # blocked by the author or missing permission: stop here
            except discord.HTTPException:
                continue


async def setup(bot):
    await bot.add_cog(AutoReaction(bot))
