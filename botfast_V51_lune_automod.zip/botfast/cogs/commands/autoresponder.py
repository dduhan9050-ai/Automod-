"""Autoresponder category > autoresponder commands (in-memory cache, no global locks)."""
from __future__ import annotations

import discord
from discord.ext import commands

from utils import autoresponder_ui as ui
from utils.autoresponder_store import MAX_RESPONDERS, responders
from utils.Tools import blacklist_check, ignore_check

_NO_MASS_PING = discord.AllowedMentions(everyone=False, roles=False, users=True, replied_user=False)


def _guard(func):
    """guild-only + blacklist + ignore + administrator, in that order."""
    func = commands.has_permissions(administrator=True)(func)
    func = ignore_check()(func)
    func = blacklist_check()(func)
    func = commands.guild_only()(func)
    return func


def _preview(text: str, limit: int = 45) -> str:
    text = " ".join(text.split())
    return text if len(text) <= limit else text[:limit - 1] + "…"


class AutoResponder(commands.Cog, name="Autoresponder"):
    """Autoresponder commands (Autoresponder category)."""

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self) -> None:
        await responders.load()

    # ------------------------------------------------------------ commands
    @commands.group(name="autoresponder", aliases=["ar"], invoke_without_command=True,
                    help="Manage autoresponders in the server.",
                    extras={"help_order": ["config", "edit", "delete", "create"]})
    @_guard
    async def autoresponder(self, ctx: commands.Context):
        await ui.send_group_help(ctx, ctx.command)

    @autoresponder.command(name="create", aliases=["add"], help="Create a new autoresponder.")
    @_guard
    async def autoresponder_create(self, ctx: commands.Context, name: str, *, message: str):
        result = await responders.add(ctx.guild.id, name, message)
        if result == "exists":
            view = ui.warning("Autoresponder Exists", f"The autoresponder `{name}` already exists. Delete or edit it instead.")
        elif result == "full":
            view = ui.warning("Limit Reached", f"You can only create up to {MAX_RESPONDERS} autoresponders in this guild.")
        else:
            view = ui.success("Autoresponder Created", f"Successfully created autoresponder `{name.lower()}`.")
        await ctx.reply(view=view, mention_author=False)

    @autoresponder.command(name="delete", aliases=["remove"], help="Delete an existing autoresponder.")
    @_guard
    async def autoresponder_delete(self, ctx: commands.Context, name: str):
        if await responders.delete(ctx.guild.id, name):
            view = ui.success("Autoresponder Deleted", f"Successfully deleted autoresponder `{name.lower()}`.")
        else:
            view = ui.error("Autoresponder Not Found", f"No autoresponder found with the name `{name}`.")
        await ctx.reply(view=view, mention_author=False)

    @autoresponder.command(name="edit", help="Edit an existing autoresponder.")
    @_guard
    async def autoresponder_edit(self, ctx: commands.Context, name: str, *, message: str):
        if await responders.edit(ctx.guild.id, name, message):
            view = ui.success("Autoresponder Edited", f"Successfully edited autoresponder `{name.lower()}`.")
        else:
            view = ui.error("Autoresponder Not Found", f"No autoresponder found with the name `{name}`.")
        await ctx.reply(view=view, mention_author=False)

    @autoresponder.command(name="config", aliases=["list", "show"], help="List all autoresponders in the server.")
    @_guard
    async def autoresponder_config(self, ctx: commands.Context):
        items = responders.items(ctx.guild.id)
        if not items:
            return await ctx.reply(view=ui.error(
                "No Autoresponders", f"There are no autoresponders in {ctx.guild.name}"), mention_author=False)
        lines = [f"`{i}.` `{name}` ❯ {_preview(message)}" for i, (name, message) in enumerate(items, 1)]
        lines.append(f"\n-# {len(items)}/{MAX_RESPONDERS} autoresponders")
        avatar = getattr(getattr(self.bot.user, "display_avatar", None), "url", None)
        await ctx.reply(view=ui.listing(f"Autoresponders • {ctx.guild.name}", lines, thumb=avatar and str(avatar)),
                        mention_author=False)

    # ------------------------------------------------------------ listener
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        guild = message.guild
        if guild is None or message.author.bot or not message.content:
            return
        reply = responders.reply(guild.id, message.content)
        if reply is None:
            return
        me = guild.me
        if me is not None and not message.channel.permissions_for(me).send_messages:
            return
        try:
            await message.channel.send(reply, allowed_mentions=_NO_MASS_PING)
        except discord.HTTPException:
            pass


async def setup(bot):
    await bot.add_cog(AutoResponder(bot))
