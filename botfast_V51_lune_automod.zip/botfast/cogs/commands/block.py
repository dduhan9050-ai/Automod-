import asyncio
import discord
from discord.ext import commands
import aiosqlite
import time
from utils import ratelimit
from utils import Paginator, DescriptionEmbedPaginator

class Block(commands.Cog):
  def __init__(self, bot):
    self.bot = bot
    self.bot.loop.create_task(self.set_db())

  #@commands.Cog.listener()
  async def set_db(self):
    async with aiosqlite.connect('db/block.db') as db:
        await db.execute('''
            CREATE TABLE IF NOT EXISTS user_blacklist (
                user_id INTEGER PRIMARY KEY,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        await db.execute('''
            CREATE TABLE IF NOT EXISTS guild_blacklist (
                guild_id INTEGER PRIMARY KEY,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        await db.commit()
      


  @commands.group(name="blacklist", aliases=["bl"], invoke_without_command=True)
  @commands.is_owner()
  async def blacklist(self, ctx):
    if ctx.subcommand_passed is None:
      await ctx.send_help(ctx.command)
      ctx.command.reset_cooldown(ctx)

  @blacklist.group(name="user", help="Add/Remove a user to the blacklist.", invoke_without_command=True)
  @commands.is_owner()
  async def user(self, ctx):
    if ctx.subcommand_passed is None:
      await ctx.send_help(ctx.command)
      ctx.command.reset_cooldown(ctx)

  @user.command(name="add", help="Adds a user to the blacklist.")
  @commands.is_owner()
  async def add_user(self, ctx, user: discord.User):
    async with aiosqlite.connect('db/block.db') as db:
      cursor = await db.execute('SELECT user_id FROM user_blacklist WHERE user_id = ?', (user.id,))
      if await cursor.fetchone():
        embed = discord.Embed(
          title=" User Already Blacklisted",
          description=f"{user.mention} is already blacklisted.",
          color=0x000000
        )
        await ctx.reply(embed=embed)
      else:
        await db.execute('INSERT INTO user_blacklist (user_id) VALUES (?)', (user.id,))
        await db.commit()
        embed = discord.Embed(
          title="<:emoji_4:1566043104551768114> User Blacklisted",
          description=f"{user.mention} has been added to the blacklist.",
          color=0x000000
        )
        await ctx.reply(embed=embed)

  @user.command(name="remove", help="Remove a user from the blacklist.")
  @commands.is_owner()
  async def remove_user(self, ctx, user: discord.User):
    async with aiosqlite.connect('db/block.db') as db:
      cursor = await db.execute('SELECT user_id FROM user_blacklist WHERE user_id = ?', (user.id,))
      if not await cursor.fetchone():
        embed = discord.Embed(
          title="<a:emoji_38:1567096105299214336> User Not Blacklisted",
          description=f"{user.mention} is not in the blacklist.",
          color=0x000000
        )
        await ctx.reply(embed=embed)
      else:
        await db.execute('DELETE FROM user_blacklist WHERE user_id = ?', (user.id,))
        await db.commit()
        embed = discord.Embed(
          title="<:emoji_4:1566043104551768114> User Unblacklisted",
          description=f"{user.mention} has been removed from the blacklist.",
          color=0x000000
        )
        await ctx.reply(embed=embed)

  @user.command(name="show", aliases=["list"], help="Shows all Blacklisted users.")
  @commands.is_owner()
  async def show_users(self, ctx):
    async with aiosqlite.connect('db/block.db') as db:
      cursor = await db.execute('SELECT user_id FROM user_blacklist')
      rows = await cursor.fetchall()
      if not rows:
        embed = discord.Embed(
          title="<:CrossIcon:1327829124894429235> No Blacklisted Users",
          description="There are no users in the blacklist.",
          color=0x000000
        )
        await ctx.reply(embed=embed)
        return

      async def _line(user_id):
        user = self.bot.get_user(user_id)            # cache first, REST only when needed
        try:
          if user is None:
            user = await self.bot.fetch_user(user_id)
          return f"**[{user.name}](https://discord.com/users/{user_id})** - ({user_id})"
        except discord.NotFound:
          return f"User ID: {user_id} (User not found)"
        except discord.HTTPException:
          return f"User ID: {user_id}"

      blacklist = list(await asyncio.gather(*(_line(row[0]) for row in rows)))     # parallel, not one by one
      entries = [f"{index+1}. {user}" for index, user in enumerate(blacklist)]
      paginator = Paginator(source=DescriptionEmbedPaginator(
        entries=entries,
        title=f"List of Blacklisted Users - {len(blacklist)}",
        description="",
        per_page=10,
        color=0x000000),
        ctx=ctx
      )
      await paginator.paginate()

  @blacklist.group(name="guild", help="Add/Remove a guild to the blacklist.", invoke_without_command=True)
  @commands.is_owner()
  async def guild(self, ctx):
    if ctx.subcommand_passed is None:
      await ctx.send_help(ctx.command)
      ctx.command.reset_cooldown(ctx)

  @guild.command(name="add", help="Adds a guild to the blacklist.")
  @commands.is_owner()
  async def add_guild(self, ctx, guild_id: int):
    async with aiosqlite.connect('db/block.db') as db:
      cursor = await db.execute('SELECT guild_id FROM guild_blacklist WHERE guild_id = ?', (guild_id,))
      if await cursor.fetchone():
        embed = discord.Embed(
          title="<:CrossIcon:1327829124894429235> Guild Already Blacklisted",
          description=f"Guild with ID `{guild_id}` is already blacklisted.",
          color=0x000000
        )
        await ctx.reply(embed=embed)
      else:
        await db.execute('INSERT INTO guild_blacklist (guild_id) VALUES (?)', (guild_id,))
        await db.commit()
        embed = discord.Embed(
          title="<:emoji_4:1566043104551768114> Guild Blacklisted",
          description=f"Guild with ID `{guild_id}` has been added to the blacklist.",
          color=0x000000
        )
        await ctx.reply(embed=embed)

  @guild.command(name="remove", help="Remove a guild from the blacklist.")
  @commands.is_owner()
  async def remove_guild(self, ctx, guild_id: int):
    async with aiosqlite.connect('db/block.db') as db:
      cursor = await db.execute('SELECT guild_id FROM guild_blacklist WHERE guild_id = ?', (guild_id,))
      if not await cursor.fetchone():
        embed = discord.Embed(
          title="<:CrossIcon:1327829124894429235> Guild Not Blacklisted",
          description=f"Guild with ID `{guild_id}` is not in the blacklist.",
          color=0x000000
        )
        await ctx.reply(embed=embed)
      else:
        await db.execute('DELETE FROM guild_blacklist WHERE guild_id = ?', (guild_id,))
        await db.commit()
        embed = discord.Embed(
          title="<:emoji_4:1566043104551768114> Guild Unblacklisted",
          description=f"Guild with ID `{guild_id}` has been removed from the blacklist.",
          color=0x000000
        )
        await ctx.reply(embed=embed)
        

  @guild.command(name="show", aliases=["list"], help="Shows the list of blacklisted guilds")
  @commands.is_owner()
  async def show_guilds(self, ctx):
    async with aiosqlite.connect('db/block.db') as db:
      cursor = await db.execute('SELECT guild_id FROM guild_blacklist')
      rows = await cursor.fetchall()
      if not rows:
        embed = discord.Embed(
          title="<:CrossIcon:1327829124894429235> No Blacklisted Guilds",
          description="There are no guilds in the blacklist.",
          color=0x000000
        )
        await ctx.reply(embed=embed)
        return

      blacklist = []
      for row in rows:
        guild_id = row[0]
        try:
          guild = await self.bot.fetch_guild(guild_id)
          guild_name = guild.name
          guild_link = f"https://discord.com/guilds/{guild_id}"
          blacklist.append(f"[{guild_name}]({guild_link}) - ({guild_id})")
        except discord.NotFound:
          blacklist.append(f"Guild ID: {guild_id} (Guild not found)")
      entries = [f"{index+1}. {guild}" for index, guild in enumerate(blacklist)]
      paginator = Paginator(source=DescriptionEmbedPaginator(
        entries=entries,
        title=f"List of Blacklisted Guilds - {len(blacklist)}",
        description="",
        per_page=10,
        color=0x000000),
        ctx=ctx
      )
      await paginator.paginate()

  # ------------------------------------------------------------------ temporary (auto) blacklist
  @commands.group(name="tempblock", aliases=["tbl", "ratelimit"], invoke_without_command=True,
                  help="Owner: manage the automatic temporary blacklist (command spam).")
  @commands.is_owner()
  async def tempblock(self, ctx):
    await ctx.send_help(ctx.command)

  @tempblock.command(name="list", help="Shows everybody who is temporarily blacklisted right now.")
  @commands.is_owner()
  async def tempblock_list(self, ctx):
    rows = ratelimit.active()
    if not rows:
      return await ctx.reply("<:emoji_4:1566043104551768114> Nobody is temporarily blacklisted right now.", mention_author=False)
    now = time.time()
    lines = [f"<@{uid}> (`{uid}`) \u2192 {ratelimit.human(b.until - now)} left \u2022 strike #{b.strikes}"
             for uid, b in rows[:30]]
    await ctx.reply("## Temporary blacklist\n" + "\n".join(lines), mention_author=False)

  @tempblock.command(name="clear", aliases=["remove", "unblock"], help="Unblock a user and reset their strikes.")
  @commands.is_owner()
  async def tempblock_clear(self, ctx, user: discord.User):
    if await ratelimit.clear(user.id):
      await ctx.reply(f"<:emoji_4:1566043104551768114> {user.mention} was unblocked and their strikes were reset.", mention_author=False)
    else:
      await ctx.reply(f"<a:cross:1567096105299214336> {user.mention} has no temporary blacklist entry.", mention_author=False)

  @tempblock.command(name="add", help="Temporarily blacklist a user (minutes optional; default = next strike length).")
  @commands.is_owner()
  async def tempblock_add(self, ctx, user: discord.User, minutes: int = 0):
    b = await ratelimit.punish(user.id)
    if minutes > 0:
      b.until = time.time() + minutes * 60
      await ratelimit.save(user.id)
    await ctx.reply(f"\u26d4 {user.mention} is blacklisted for **{ratelimit.human(b.until - time.time())}** "
                    f"(strike #{b.strikes}).", mention_author=False)


"""
@Author: Sonu Jana
    + Discord: me.sonu
    + Community: https://discord.gg/cfYmz4634n (Death Development)
    + for any queries reach out support or DM me.
"""
