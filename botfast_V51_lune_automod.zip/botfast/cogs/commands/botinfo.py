"""Bot information center + bot-owner team manager.

* ``botinfo`` (``bi``)  - 4 pages: System / General / Team Info / Partner Servers
* ``team``              - bot owners only: add / remove / list the bot team

Team roles (see utils/team_store.py): owner, developer, core, bughunter.
Owners, developers and core team automatically get lifetime server premium and
global no-prefix; removing them from the team removes those perks again.
"""
from __future__ import annotations

import asyncio
import heapq
import importlib.metadata as md
import os
import platform
import sqlite3
import time
from pathlib import Path
from typing import Dict, List, Optional

import discord
import psutil
from discord.ext import commands, tasks

from utils.config import NP_LOG_CHANNEL_ID
from utils.logchan import get_log_channel
from utils.team_store import ROLES, ROLE_TITLES, normalize_role, team

ROOT = Path(__file__).resolve().parents[2]
STATS_DB = ROOT / "db" / "stats.db"
SKIP_DIRS = {".git", "__pycache__", "node_modules", "venv", ".venv", "env", ".local", "site-packages"}

ROLE_ICON = {"owner": "<a:crownn:1567121063194918967>", "developer": "<a:emoji_74:1567132979967299726>", "core": "<a:star_white:1567124664558297180>", "bughunter": "<:bughunter:1567099364160053248>"}
ROLE_LABEL = {"owner": "Owner", "developer": "Developer", "core": "Core Team", "bughunter": "Bug Hunter"}


def _duration(seconds: float) -> str:
    seconds = int(seconds)
    d, rem = divmod(seconds, 86400)
    h, rem = divmod(rem, 3600)
    m, s = divmod(rem, 60)
    parts = []
    if d:
        parts.append(f"{d}d")
    if d or h:
        parts.append(f"{h}h")
    if d or h or m:
        parts.append(f"{m}m")
    parts.append(f"{s}s")
    return " ".join(parts)


def _kv(label: str, value) -> str:
    return f"> **{label}** `{value}`"


def _processor() -> str:
    try:
        with open("/proc/cpuinfo", encoding="utf-8") as fh:
            for line in fh:
                if line.lower().startswith("model name"):
                    return line.split(":", 1)[1].strip()
    except OSError:
        pass
    return platform.processor() or platform.machine() or "Unknown"


def _scan_code(root: Path) -> tuple[int, int, int]:
    """(python files, non-empty lines, words) below ``root`` - runs in a worker thread."""
    files = lines = words = 0
    for base, dirs, names in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for name in names:
            if not name.endswith(".py"):
                continue
            files += 1
            try:
                with open(os.path.join(base, name), encoding="utf-8") as fh:
                    for line in fh:
                        text = line.strip()
                        if text:
                            lines += 1
                            words += len(text.split())
            except (OSError, UnicodeDecodeError):
                continue
    return files, lines, words


class BotInfoView(discord.ui.LayoutView):
    PAGES = (("system", "System"), ("general", "General"),
             ("team", "Team Info"), ("partners", "Partner Servers"))

    def __init__(self, cog: "BotInfo", ctx: commands.Context, page: str = "general"):
        super().__init__(timeout=180)
        self.cog, self.ctx, self.page = cog, ctx, page
        self.message: Optional[discord.Message] = None

    async def build(self) -> "BotInfoView":
        self.clear_items()
        text = await self.cog.render(self.page, self.ctx)
        container = discord.ui.Container()
        if self.page in ("team", "partners"):
            # these two pages carry the bot avatar on the right (like the reference design)
            head, _, rest = text.partition("\n\n")
            container.add_item(discord.ui.Section(discord.ui.TextDisplay(head),
                                                  accessory=discord.ui.Thumbnail(media=self.cog.bot.user.display_avatar.url)))
            container.add_item(discord.ui.TextDisplay(rest))
        else:
            container.add_item(discord.ui.TextDisplay(text))
        self.add_item(container)
        row = discord.ui.ActionRow()
        for key, label in self.PAGES:
            button = discord.ui.Button(label=label, style=discord.ButtonStyle.secondary, disabled=key == self.page)
            button.callback = self._make_callback(key)
            row.add_item(button)
        self.add_item(row)
        return self

    def _make_callback(self, key: str):
        async def callback(interaction: discord.Interaction):
            if interaction.user.id != self.ctx.author.id:
                return await interaction.response.send_message("This menu isn't for you.", ephemeral=True)
            self.page = key
            await self.build()
            await interaction.response.edit_message(view=self)
        return callback

    async def on_timeout(self) -> None:
        for item in self.children:
            if isinstance(item, discord.ui.ActionRow):
                for child in item.children:
                    child.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass


class BotInfo(commands.Cog):
    """Bot information + bot team management."""

    def __init__(self, bot):
        self.bot = bot
        self.proc = psutil.Process()
        self.proc.cpu_percent(None)
        self.commands_used = 0
        self._saved_commands_used = 0
        self._code_cache: tuple[float, tuple[int, int, int]] | None = None
        self._names: Dict[int, tuple[str, str]] = {}          # user id -> (display name, username)
        self._load_counter()
        self._save_loop.start()

    # ------------------------------------------------------------ lifecycle
    def cog_unload(self):
        self._save_loop.cancel()
        self._save_counter()

    def _load_counter(self):
        try:
            STATS_DB.parent.mkdir(parents=True, exist_ok=True)
            with sqlite3.connect(STATS_DB, timeout=5) as db:
                db.execute("CREATE TABLE IF NOT EXISTS stats (key TEXT PRIMARY KEY, value INTEGER)")
                row = db.execute("SELECT value FROM stats WHERE key='commands_used'").fetchone()
                self.commands_used = self._saved_commands_used = int(row[0]) if row else 0
        except sqlite3.Error:
            pass

    def _save_counter(self):
        if self.commands_used == self._saved_commands_used:
            return
        try:
            with sqlite3.connect(STATS_DB, timeout=5) as db:
                db.execute("CREATE TABLE IF NOT EXISTS stats (key TEXT PRIMARY KEY, value INTEGER)")
                db.execute("INSERT OR REPLACE INTO stats (key, value) VALUES ('commands_used', ?)",
                           (self.commands_used,))
            self._saved_commands_used = self.commands_used
        except sqlite3.Error:
            pass

    @tasks.loop(minutes=2)
    async def _save_loop(self):
        await asyncio.to_thread(self._save_counter)

    @commands.Cog.listener()
    async def on_command_completion(self, ctx):
        self.commands_used += 1

    def _songs_played(self) -> int:
        try:
            with sqlite3.connect(STATS_DB, timeout=5) as db:
                row = db.execute("SELECT value FROM stats WHERE key='total_songs_played'").fetchone()
                return int(row[0]) if row else 0
        except sqlite3.Error:
            return 0

    # ------------------------------------------------------------ data
    async def _code_stats(self) -> tuple[int, int, int]:
        if self._code_cache and time.time() - self._code_cache[0] < 600:
            return self._code_cache[1]
        result = await asyncio.to_thread(_scan_code, ROOT)
        self._code_cache = (time.time(), result)
        return result

    async def _resolve(self, user_id: int) -> tuple[str, str]:
        if user_id in self._names:
            return self._names[user_id]
        user = self.bot.get_user(user_id)
        if user is None:
            try:
                user = await self.bot.fetch_user(user_id)
            except discord.HTTPException:
                return (f"Unknown User", str(user_id))
        pair = (user.display_name, user.name)
        self._names[user_id] = pair
        return pair

    async def _team_lines(self, role: str) -> str:
        ids = team.by_role(role)
        if not ids:
            return "`None found`"
        pairs = await asyncio.gather(*(self._resolve(uid) for uid in ids))
        return "\n".join(f"`{i}.` [{name}](https://discord.com/users/{uid}) — `{username}`"
                         for i, (uid, (name, username)) in enumerate(zip(ids, pairs), 1))

    # ------------------------------------------------------------ pages
    async def render(self, page: str, ctx: commands.Context) -> str:
        bot = self.bot
        name = bot.user.display_name
        now = int(time.time())
        foot = f"-# <:emoji_78:1567148180573913098> {name} Information Center | <t:{now}:f>"

        if page == "team":
            parts = ["# <:emoji_81:1567148256260005978> Team Information"]
            for role in ROLES:
                parts.append(f"__**{ROLE_ICON[role]} {ROLE_TITLES[role]}**__\n{await self._team_lines(role)}")
            parts.append(f"-# Requested by {ctx.author.display_name} | <t:{now}:f>")
            # first block (title) sits next to the avatar, the rest below
            return parts[0] + "\n\n" + "\n\n".join(parts[1:])

        if page == "partners":
            top = heapq.nlargest(5, bot.guilds, key=lambda g: g.member_count or 0)
            blocks = ["# <a:emoji_71:1567130056093077665> Trusted By", "__**<a:emoji_234:1567120330386833540> Top Servers**__"]
            lines = []
            for i, g in enumerate(top, 1):
                lines.append(f"`{i}.` **{discord.utils.escape_markdown(g.name)}**\n"
                             f"• Members: `{(g.member_count or 0):,}`")
            blocks_text = "\n\n".join(lines) if lines else "`None found`"
            return (blocks[0] + "\n\n" + blocks[1] + "\n" + blocks_text +
                    f"\n\n-# Requested by {ctx.author.display_name} | <t:{now}:f>")

        if page == "system":
            try:
                freq = psutil.cpu_freq()          # missing on some AWS / ARM (Graviton) hosts
            except Exception:
                freq = None
            vm = psutil.virtual_memory()
            try:
                disk = psutil.disk_usage(str(ROOT)).percent
            except OSError:
                disk = 0
            started = int(self.proc.create_time())
            shard = bot.get_shard(ctx.guild.shard_id) if ctx.guild else None
            ping = round((shard.latency if shard else bot.latency) * 1000)
            songs = await asyncio.to_thread(self._songs_played)
            libs = sum(1 for _ in md.distributions())
            sections = [
                f"**<a:emoji_248:1567112460597469207> {name} Statistics**",
                "**<:563897_computer:1567119790735097908> Hardware**\n" + "\n".join([
                    _kv("CPU Cores", f"{psutil.cpu_count(logical=False) or psutil.cpu_count() or '?'}P / {psutil.cpu_count() or '?'}L"),
                    _kv("Frequency", f"{freq.current:.2f} MHz" if freq else "N/A"),
                    _kv("CPU Usage", f"{psutil.cpu_percent(None):.0f}%"),
                    _kv("Architecture", platform.machine()),
                    _kv("Processor", _processor())]),
                "**<:emoji_16:1566453033771077732> Memory**\n" + "\n".join([
                    _kv("Total RAM", f"{vm.total / 1024 ** 3:.2f} GB"),
                    _kv("Available", f"{vm.available / 1024 ** 3:.1f} GB"),
                    _kv("RAM Usage", f"{vm.percent:.0f}%"),
                    _kv("Disk Usage", f"{disk:.0f}%"),
                    _kv("PID", self.proc.pid)]),
                "**<:server:1567099480602452078> Platform**\n" + "\n".join([
                    _kv("OS", f"{platform.system()} {platform.release()}"),
                    _kv("Python", platform.python_version()),
                    _kv("Discord.py", discord.__version__),
                    _kv("Libraries", libs)]),
                "**<:ping:1567099428660052048> Network**\n" + "\n".join([
                    _kv("Shards", len(bot.shards) or 1),
                    _kv("Ping", f"{ping}ms"),
                    _kv("Voice Clients", len(bot.voice_clients))]),
                "**<a:emoji_40:1567099263513526273> Uptime**\n" + "\n".join([
                    _kv("Duration", _duration(time.time() - started)),
                    f"> **Since** <t:{started}:R>"]),
                "**\u2328\ufe0f Commands**\n" + "\n".join([
                    _kv("Prefix", len(set(bot.walk_commands()))),
                    _kv("Slash", len(bot.tree.get_commands())),
                    _kv("Cogs", len(bot.cogs)),
                    _kv("Extensions", len(bot.extensions)),
                    _kv("Songs Played", f"{songs:,}"),
                    _kv("Commands Used", f"{self.commands_used:,}")]),
                f"-# \u26a1 {name} Performance | <t:{now}:f>",
            ]
            return "\n\n".join(sections)

        # general
        files, lines, words = await self._code_stats()
        users = sum(g.member_count or 0 for g in bot.guilds)
        shard = bot.get_shard(ctx.guild.shard_id) if ctx.guild else None
        ping = round((shard.latency if shard else bot.latency) * 1000)
        flags = bot.user.public_flags
        verified = "Yes" if flags.verified_bot else "No"
        created = bot.user.created_at
        sections = [
            f"**\u2139\ufe0f {name} Information**",
            "**<:521449_bot:1567119077330133122> Bot Core**\n" + "\n".join([
                _kv("Name", name), _kv("ID", bot.user.id),
                f"> **Created** <t:{int(created.timestamp())}:D>", _kv("Verified", verified)]),
            "**<:563897_computer:1567119790735097908> Codebase**\n" + "\n".join([
                _kv("Python Files", f"{files:,}"), _kv("Lines", f"{lines:,}"),
                _kv("Words", f"{words:,}"), _kv("Framework", "discord.py")]),
            "**<:ping:1567099428660052048> Network**\n" + "\n".join([
                _kv("Ping", f"{ping}ms"), _kv("Servers", f"{len(bot.guilds):,}"), _kv("Users", f"{users:,}")]),
            foot,
        ]
        return "\n\n".join(sections)

    # ------------------------------------------------------------ commands
    @commands.command(name="botinfo", aliases=["bi", "about"], help="Shows information about the bot.")
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def botinfo(self, ctx):
        view = await BotInfoView(self, ctx).build()
        view.message = await ctx.reply(view=view, mention_author=False)

    # ---- team management (bot owners only)
    @commands.group(name="team", invoke_without_command=True, hidden=True,
                    help="Manage the bot team (bot owner only).")
    @commands.is_owner()
    async def team_group(self, ctx):
        await self._note(ctx, "## <a:crownn:1567121063194918967> Bot Team\n"
                              f"`{ctx.clean_prefix}team add <user> <owner|developer|core|bughunter>`\n"
                              f"`{ctx.clean_prefix}team remove <user>`\n"
                              f"`{ctx.clean_prefix}team list`\n\n"
                              "Owners, developers and core team get **lifetime server premium** and "
                              "**global no-prefix** automatically.")

    @team_group.command(name="add", aliases=["set"], help="Add a user (or change their role) in the bot team.")
    @commands.is_owner()
    async def team_add(self, ctx, user: discord.User, role: str):
        key = normalize_role(role)
        if key is None:
            return await self._note(ctx, "<a:emoji_38:1567096105299214336> Role must be one of: `owner`, `developer`, `core`, `bughunter`.")
        if user.bot:
            return await self._note(ctx, "<a:emoji_38:1567096105299214336> Bots can't be added to the team.")
        previous = team.set_role(user.id, key, ctx.author.id)
        self._names[user.id] = (user.display_name, user.name)
        self.bot.invalidate_prefix_cache(user_id=user.id)
        perks = ("\n▸ Lifetime **server premium** enabled\n▸ Global **no-prefix** enabled"
                 if key != "bughunter" else "\n▸ No perks (display only)")
        verb = f"moved from **{ROLE_LABEL[previous]}** to" if previous and previous != key else "added as"
        await self._note(ctx, f"<:emoji_4:1566043104551768114> {user.mention} {verb} **{ROLE_LABEL[key]}**.{perks}")
        await self._log(ctx, "Team Member Added" if not previous else "Team Role Changed", user,
                        f"**Role**: {ROLE_LABEL[key]}\n" + ("**Access**: Lifetime Premium + Global No Prefix" if key != "bughunter"
                                                          else "**Access**: None (display only)"))

    @team_group.command(name="remove", aliases=["rm", "delete"], help="Remove a user from the bot team.")
    @commands.is_owner()
    async def team_remove(self, ctx, user: discord.User):
        previous = team.remove(user.id)
        self.bot.invalidate_prefix_cache(user_id=user.id)
        if previous is None:
            return await self._note(ctx, "<a:emoji_38:1567096105299214336> That user is not in the bot team.")
        await self._note(ctx, f"<:emoji_4:1566043104551768114> {user.mention} removed from **{ROLE_LABEL[previous]}**. "
                              "Their team premium / no-prefix access is gone.")
        await self._log(ctx, "Team Member Removed", user, f"**Old Role**: {ROLE_LABEL[previous]}\n**Access**: Removed")

    @team_group.command(name="list", aliases=["show", "all"], help="Show the bot team.")
    @commands.is_owner()
    async def team_list(self, ctx):
        parts = ["## <a:crownn:1567121063194918967> Bot Team"]
        for role in ROLES:
            parts.append(f"__**{ROLE_ICON[role]} {ROLE_TITLES[role]}**__\n{await self._team_lines(role)}")
        await self._note(ctx, "\n\n".join(parts))

    async def _log(self, ctx, title: str, user: discord.User, details: str):
        """Post team changes (they grant / revoke no-prefix) to the no-prefix log channel."""
        channel = await get_log_channel(self.bot, NP_LOG_CHANNEL_ID)
        if channel is None:
            return
        embed = discord.Embed(title=title, color=0x000000, description=(
            f"**User**: [{user}](https://discord.com/users/{user.id})\n**User Mention**: {user.mention}\n"
            f"**ID**: {user.id}\n{details}\n**By**: {ctx.author.mention}"))
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.set_footer(text="Bot Team Log")
        try:
            await channel.send(embed=embed)
        except discord.HTTPException:
            pass

    async def _note(self, ctx, text: str):
        view = discord.ui.LayoutView(timeout=None)
        container = discord.ui.Container()
        container.add_item(discord.ui.TextDisplay(text))
        view.add_item(container)
        await ctx.reply(view=view, mention_author=False)
