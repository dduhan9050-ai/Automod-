"""CustomRole module (ZEON style).

Commands
    customrole create <name> <role>   create a custom role command
    customrole delete <name>          delete a custom role command
    customrole list                   list every custom role command
    customrole reqrole [role]         show / set the role allowed to use the custom commands
    customrole reset                  wipe every customrole setting of the server

Using a custom command:   <prefix><name> <member>   -> gives the role, run again to remove it.

Speed: per-guild data lives in memory (one DB read per guild, invalidated on every write), and the
message listener bails out in a couple of dict/str operations for guilds without custom roles.
Every reply is a white (#ffffff) Components V2 card.
"""
from __future__ import annotations

import re
from typing import Optional

import aiosqlite
import discord
from discord.ext import commands

from core import Cog
from utils import modui
from utils.Tools import blacklist_check, get_ignore_data

DB_PATH = "db/customrole.db"
MAX_COMMANDS = 56
NAME_RE = re.compile(r"^[a-z0-9_\-]{1,32}$")
BRANCH = "╰"
ADMIN = {"administrator": True}


def _card(ok: bool, title: Optional[str], text: str) -> discord.ui.LayoutView:
    """<:emoji_4:1566043104551768114> **Title** + ╰ line (success) or a single <a:cross:1567096105299214336> line (failure). White container."""
    icon = modui.TICK if ok else modui.CROSS
    if title:
        return modui.card(f"{icon} **{title}**\n{BRANCH} {text}")
    return modui.card(f"{icon} {text}")


class CustomRole(Cog, name="CustomRole"):
    """Custom role commands (CustomRole category)."""

    def __init__(self, bot):
        self.bot = bot
        # guild_id -> ({command name: role_id}, reqrole_id | None)
        self._cache: dict[int, tuple[dict[str, int], Optional[int]]] = {}

    # ------------------------------------------------------------------ storage
    async def cog_load(self) -> None:
        async with aiosqlite.connect(DB_PATH) as db:
            # custom_roles + reqrole of existing servers are kept
            await db.execute("CREATE TABLE IF NOT EXISTS roles (guild_id INTEGER PRIMARY KEY, reqrole INTEGER)")
            # drop the leftovers of the removed Death commands (staff / girl / vip / guest / friend roles)
            for legacy in ("staff", "girl", "vip", "guest", "frnd"):
                try:
                    await db.execute(f"ALTER TABLE roles DROP COLUMN {legacy}")
                except aiosqlite.OperationalError:
                    pass  # already gone
            await db.execute(
                "CREATE TABLE IF NOT EXISTS custom_roles (guild_id INTEGER, name TEXT, role_id INTEGER, "
                "PRIMARY KEY (guild_id, name))")
            await db.commit()

    async def _load(self, guild_id: int) -> tuple[dict[str, int], Optional[int]]:
        hit = self._cache.get(guild_id)
        if hit is not None:
            return hit
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT name, role_id FROM custom_roles WHERE guild_id = ?", (guild_id,)) as cur:
                roles = {str(n).lower(): int(r) for n, r in await cur.fetchall() if r}
            async with db.execute("SELECT reqrole FROM roles WHERE guild_id = ?", (guild_id,)) as cur:
                row = await cur.fetchone()
        data = (roles, int(row[0]) if row and row[0] else None)
        self._cache[guild_id] = data
        return data

    def _drop(self, guild_id: int) -> None:
        self._cache.pop(guild_id, None)

    # ------------------------------------------------------------------ group
    @commands.group(name="customrole", invoke_without_command=True,
                    help="Lists all subcommands of customrole group.")
    @modui.guard()
    async def customrole(self, ctx: commands.Context):
        await ctx.send_help(ctx.command)

    @customrole.command(name="create", help="Create a custom role command.")
    @modui.guard(ADMIN)
    async def customrole_create(self, ctx: commands.Context, name: str, role: discord.Role):
        name = name.lower()
        if not NAME_RE.match(name):
            return await modui.send(ctx, _card(False, None, "The name must be 1-32 characters: letters, numbers, `-` or `_`."))
        if self.bot.get_command(name) is not None:
            return await modui.send(ctx, _card(False, None, f"`{name}` is already a bot command, pick another name."))
        problem = modui.role_error(ctx, role)
        if problem:
            return await modui.send(ctx, _card(False, None, problem))
        roles, _ = await self._load(ctx.guild.id)
        if name in roles:
            return await modui.send(ctx, _card(False, None, f"A custom role command named `{name}` already exists."))
        if len(roles) >= MAX_COMMANDS:
            return await modui.send(ctx, _card(False, None, f"This server reached the limit of {MAX_COMMANDS} custom role commands."))
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT INTO custom_roles (guild_id, name, role_id) VALUES (?, ?, ?)",
                             (ctx.guild.id, name, role.id))
            await db.commit()
        self._drop(ctx.guild.id)
        await modui.send(ctx, _card(True, "Customrole Created",
                                    f"Created the custom role command `{name}` for the role {role.mention}."))

    @customrole.command(name="delete", aliases=["remove"], help="Deletes a custom role command.")
    @modui.guard(ADMIN)
    async def customrole_delete(self, ctx: commands.Context, name: str):
        name = name.lower()
        roles, _ = await self._load(ctx.guild.id)
        if name not in roles:
            return await modui.send(ctx, _card(False, None, f"No custom role command named `{name}` exists in this server."))
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM custom_roles WHERE guild_id = ? AND name = ?", (ctx.guild.id, name))
            await db.commit()
        self._drop(ctx.guild.id)
        await modui.send(ctx, _card(True, "Customrole Deleted", f"Deleted the custom role command `{name}`."))

    @customrole.command(name="list", help="Lists all configured roles for this server.")
    @modui.guard(ADMIN)
    async def customrole_list(self, ctx: commands.Context):
        roles, _ = await self._load(ctx.guild.id)
        if not roles:
            return await modui.send(ctx, _card(False, None, "This server has no custom roles configured."))
        prefix = ctx.clean_prefix
        entries = []
        for name in sorted(roles):
            role = ctx.guild.get_role(roles[name])
            entries.append(f"`{prefix}{name}` {modui.ARROW} " + (role.mention if role else "*deleted role*"))
        view = modui.ListPager(ctx, f"Custom Roles [{len(entries)}]", entries, per_page=10, legend=False, sep="\n")
        await modui.send_pager(ctx, view)

    @customrole.command(name="reqrole", help="Sets the reqrole for customroles in this server.")
    @modui.guard(ADMIN)
    async def customrole_reqrole(self, ctx: commands.Context, role: discord.Role = None):
        if role is None:
            _, rid = await self._load(ctx.guild.id)
            current = ctx.guild.get_role(rid) if rid else None
            if current is None:
                return await modui.send(ctx, _card(False, None, "No customrole reqrole is currently set for this server."))
            return await modui.send(ctx, _card(True, "Customrole Reqrole",
                                               f"The customrole reqrole is currently {current.mention}."))
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "INSERT INTO roles (guild_id, reqrole) VALUES (?, ?) "
                "ON CONFLICT(guild_id) DO UPDATE SET reqrole = excluded.reqrole", (ctx.guild.id, role.id))
            await db.commit()
        self._drop(ctx.guild.id)
        await modui.send(ctx, _card(True, "Setup Reqrole Set",
                                    f"The customrole reqrole has been set to {role.mention} for this server."))

    @customrole.command(name="reset", help="Resets all customrole configurations for this server.")
    @modui.guard(ADMIN)
    async def customrole_reset(self, ctx: commands.Context):
        roles, rid = await self._load(ctx.guild.id)
        if not roles and not rid:
            return await modui.send(ctx, _card(False, None, "This server has no customrole configuration to reset."))
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM custom_roles WHERE guild_id = ?", (ctx.guild.id,))
            await db.execute("UPDATE roles SET reqrole = NULL WHERE guild_id = ?", (ctx.guild.id,))
            await db.commit()
        self._drop(ctx.guild.id)
        await modui.send(ctx, _card(True, "Customrole Reset",
                                    f"Removed {len(roles)} custom role command(s) and the reqrole for this server."))

    # --------------------------------------------------------- custom commands
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or message.guild is None or not message.content:
            return
        roles, reqrole_id = await self._load(message.guild.id)
        if not roles:
            return
        lowered = message.content.lower()
        if not any(name in lowered for name in roles):  # cheap pre-filter, no prefix lookup needed
            return

        ctx = await self.bot.get_context(message)
        if ctx.prefix is None or ctx.command is not None or not ctx.invoked_with:
            return
        role_id = roles.get(ctx.invoked_with.lower())
        if role_id is None:
            return
        await self._run_custom(ctx, ctx.invoked_with.lower(), role_id, reqrole_id)

    async def _run_custom(self, ctx: commands.Context, name: str, role_id: int, reqrole_id: Optional[int]) -> None:
        guild, author = ctx.guild, ctx.author

        # blacklist / ignore (same rules as normal commands)
        try:
            if not await blacklist_check().predicate(ctx):
                return
        except commands.CheckFailure:
            return
        data = await get_ignore_data(guild.id)
        if str(author.id) not in data["bypassuser"]:
            if (str(ctx.channel.id) in data["channel"] or str(author.id) in data["user"] or name in data["command"]
                    or (data["role"] and any(str(r.id) in data["role"] for r in author.roles))):
                return

        # who may use it: owner / admin always, otherwise the reqrole (or Manage Roles when no reqrole is set)
        perms = author.guild_permissions
        if author.id != guild.owner_id and not perms.administrator:
            if reqrole_id:
                if not any(r.id == reqrole_id for r in author.roles):
                    reqrole = guild.get_role(reqrole_id)
                    who = reqrole.mention if reqrole else "the customrole reqrole"
                    return await modui.send(ctx, _card(False, None, f"You need {who} to use this command."))
            elif not perms.manage_roles:
                return await modui.send(ctx, _card(False, None, "You need **Manage Roles** permission to use this command."))

        arg = ctx.message.content[len(ctx.prefix) + len(ctx.invoked_with):].strip()
        if not arg:
            return await modui.send(ctx, _card(False, None, f"Usage: `{ctx.clean_prefix}{name} <member>`"))
        try:
            member = await commands.MemberConverter().convert(ctx, arg.split()[0])
        except commands.BadArgument:
            return await modui.send(ctx, _card(False, None, f"Member `{arg.split()[0][:50]}` was not found."))

        role = guild.get_role(role_id)
        if role is None:
            return await modui.send(ctx, _card(False, None, f"The role for `{name}` no longer exists. Delete and create it again."))
        me = guild.me
        if not me.guild_permissions.manage_roles:
            return await modui.send(ctx, _card(False, None, "I need **Manage Roles** permission to do that."))
        if role >= me.top_role or role.managed:
            return await modui.send(ctx, _card(False, None, f"My top role must be higher than {role.mention}."))
        if (author.id != guild.owner_id and not perms.administrator and member.top_role >= author.top_role
                and member.id != author.id):
            return await modui.send(ctx, _card(False, None, f"Your top role must be higher than {member.mention}'s top role."))

        try:
            if role in member.roles:
                await member.remove_roles(role, reason=f"Customrole {name} | by {author} ({author.id})")
                await modui.send(ctx, _card(True, "Role Removed", f"Removed {role.mention} from {member.mention}."))
            else:
                await member.add_roles(role, reason=f"Customrole {name} | by {author} ({author.id})")
                await modui.send(ctx, _card(True, "Role Added", f"Added {role.mention} to {member.mention}."))
        except discord.Forbidden:
            await modui.send(ctx, _card(False, None, "I'm missing permissions for that, or my role is too low."))
        except discord.HTTPException:
            await modui.send(ctx, _card(False, None, "Discord rejected the request, try again."))
