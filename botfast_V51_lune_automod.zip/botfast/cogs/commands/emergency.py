import asyncio
import json
import time

import discord
from utils.config import OWNER_IDS
from discord.ext import commands
import aiosqlite
from utils.Tools import *

# every permission emergency mode removes (names missing in the installed discord.py are skipped)
DANGER_NAMES = ("administrator", "ban_members", "kick_members", "manage_channels", "manage_roles", "manage_guild",
                "manage_webhooks", "mention_everyone", "moderate_members", "manage_expressions",
                "manage_emojis_and_stickers")
DANGEROUS = tuple(n for n in DANGER_NAMES if n in discord.Permissions.VALID_FLAGS)
SEM = 6                      # parallel Discord edits
NO_PING = discord.AllowedMentions.none()
LOCK_TEXT = ("send_messages", "add_reactions", "send_messages_in_threads", "create_public_threads", "create_private_threads")
LOCK_VOICE = ("connect", "speak")

class EmergencyRestoreView(discord.ui.View):
    def __init__(self, ctx):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.value = None

    @discord.ui.button(label="Yes", style=discord.ButtonStyle.green)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Only the Server Owner can use this button.", ephemeral=True)
        self.value = True
        await interaction.response.defer()
        self.stop()

    @discord.ui.button(label="No", style=discord.ButtonStyle.red)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("Only the Server Owner can use this button.", ephemeral=True)
        self.value = False
        await interaction.response.defer()
        self.stop()



class Emergency(commands.Cog):

    def __init__(self, bot):
        self.bot = bot
        self.db_path = "db/emergency.db"
        self.auto_guilds = set()                 # guilds where an antinuke punishment triggers emergency mode
        self._locks = {}
        self._auto_cool = {}
        self.bot.loop.create_task(self.initialize_database())

    async def initialize_database(self):
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS authorised_users (
                    guild_id INTEGER,
                    user_id INTEGER
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS emergency_roles (
                    guild_id INTEGER,
                    role_id INTEGER
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS restore_roles (
                    guild_id INTEGER NOT NULL,
                    role_id INTEGER NOT NULL,
                    disabled_perms TEXT NOT NULL,
                    PRIMARY KEY (guild_id, role_id)
                )
            """)
            await db.execute("""
            CREATE TABLE IF NOT EXISTS role_positions (
    guild_id INTEGER,
    role_id INTEGER,
    previous_position INTEGER
)
""")
            await db.execute("""
                CREATE TABLE IF NOT EXISTS emg_settings (
                    guild_id INTEGER PRIMARY KEY, auto INTEGER DEFAULT 0, inv_disabled INTEGER DEFAULT 0)
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS lockdown_channels (
                    guild_id INTEGER, channel_id INTEGER, prev TEXT, PRIMARY KEY (guild_id, channel_id))
            """)
            await db.commit()
            async with db.execute("SELECT guild_id FROM emg_settings WHERE auto = 1") as cur:
                self.auto_guilds = {r[0] for r in await cur.fetchall()}

    def _lock(self, gid):
        return self._locks.setdefault(gid, asyncio.Lock())

    async def is_guild_owner(self, ctx):
        return ctx.guild and ctx.author.id == ctx.guild.owner_id

    async def is_guild_owner_or_authorised(self, ctx):
        if await self.is_guild_owner(ctx):
            return True
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT 1 FROM authorised_users WHERE guild_id = ? AND user_id = ?", (ctx.guild.id, ctx.author.id)) as cursor:
                return await cursor.fetchone() is not None

    @commands.group(name="emergency", aliases=["emg"], help="Lists all the commands in the emergency group.", invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 4, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    async def emergency(self, ctx):
        embed = discord.Embed(
            title="__Emergency Situation__",
            description="The `emergency` command group is designed to protect your server from malicious activity or accidental damage. It allows server owners and authorized users to disable dangerous permissions from roles by executing `emergencysituation` or `emgs` command and prevent potential risks.\n\n__**The command group has several subcommands**__:",
            color=0x000000
        )
        embed.add_field(name=f"`{ctx.prefix}emergency enable`", value="> Enable emergency mode, it adds all roles with dangerous permissions in the emergency role list.", inline=False)
        embed.add_field(name=f"`{ctx.prefix}emergency disable`", value="> Disable emergency mode and clear the emergency role list.", inline=False)
        embed.add_field(name=f"`{ctx.prefix}emergency authorise`", value="> Manage authorized users for executing `emergencysituation` command.", inline=False)
        embed.add_field(name=f"`{ctx.prefix}emergency role`", value="> Manage roles added to the emergency list. You can add/remove/list roles by emergency role group.", inline=False)
        embed.add_field(name=f"`{ctx.prefix}emergency lockdown` / `unlock`", value="> Lock every channel for @everyone and open them again exactly as they were.", inline=False)
        embed.add_field(name=f"`{ctx.prefix}emergency auto enable|disable`", value="> When antinuke bans a nuker, emergency situation runs by itself (strip perms + delete invites).", inline=False)
        embed.add_field(name=f"`{ctx.prefix}emergency status`", value="> Roles, authorised users, pending restore, locked channels.", inline=False)
        embed.add_field(name=f"`{ctx.prefix}emergency-situation` or `{ctx.prefix}emgs`", value="> Execute emergency situation which disables dangerous permissions from roles in the emergency list & move the role with maximum members under the bot, delete all invites. Undo everything with `emgrestore`.", inline=False)
        embed.set_footer(text="Use \"help emergency <subcommand>\" for more information.", icon_url=self.bot.user.display_avatar.url)
        await ctx.reply(embed=embed)


    @emergency.command(name="enable", help="Enable emergency mode and add all roles with dangerous permissions.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 4, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    async def enable(self, ctx):
        owner_id_strs = [str(i) for i in OWNER_IDS]
        if ctx.author.id != ctx.guild.owner_id and str(ctx.author.id) not in owner_id_strs:
            embed = discord.Embed(title="<:CrossIcon:1327829124894429235> Error", description="Only the server owner can enable emergency mode.", color=0x000000)
            return await ctx.reply(embed=embed)

        dangerous_permissions = DANGEROUS
        roles_added = []

        async with aiosqlite.connect(self.db_path) as db:
            for role in ctx.guild.roles:
                
                if role.managed or role.is_bot_managed():
                    continue

                if role.position >= ctx.guild.me.top_role.position:
                    continue
                
                
                if any(getattr(role.permissions, perm, False) for perm in dangerous_permissions):
                    async with db.execute("SELECT 1 FROM emergency_roles WHERE guild_id = ? AND role_id = ?", (ctx.guild.id, role.id)) as cursor:
                        if not await cursor.fetchone():
                            await db.execute("INSERT INTO emergency_roles (guild_id, role_id) VALUES (?, ?)", (ctx.guild.id, role.id))
                            roles_added.append(role)

            await db.commit()

        
        if roles_added:
            description = "\n".join([f"{role.mention}" for role in roles_added])
            embed = discord.Embed(title="<:emoji_4:1566043104551768114> Success", description=f"The following roles with dangerous permissions have been added to the **emergency list**:\n{description}", color=0x000000)
            embed.set_footer(text="Roles having greater or equal position than my top role is not added in the emergency list.", icon_url=self.bot.user.display_avatar.url)
        else:
            embed = discord.Embed(title="<:CrossIcon:1327829124894429235> Error", description="No new roles with dangerous permissions were found.", color=0x000000)
        
        await ctx.reply(embed=embed)
        

    @emergency.command(name="disable", help="Disable emergency mode and clear the emergency role list.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 4, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    async def disable(self, ctx):
        owner_id_strs = [str(i) for i in OWNER_IDS]
        if ctx.author.id != ctx.guild.owner_id and str(ctx.author.id) not in owner_id_strs:
            embed = discord.Embed(title="<:CrossIcon:1327829124894429235> Error", description="Only the server owner can disable emergency mode.", color=0x000000)
            return await ctx.reply(embed=embed)

        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("DELETE FROM emergency_roles WHERE guild_id = ?", (ctx.guild.id,))
            await db.commit()

        embed = discord.Embed(title="<:emoji_4:1566043104551768114> Success", description="Emergency mode has been disabled, and all emergency roles have been cleared.", color=0x000000)
        await ctx.reply(embed=embed)

    


    @emergency.group(name="authorise", aliases=["ath"], help="Lists all the commands in the emergency authorise group.", invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 4, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    async def authorise(self, ctx):
        if ctx.subcommand_passed is None:
            await ctx.send_help(ctx.command)
            ctx.command.reset_cooldown(ctx)

    @authorise.command(name="add", help="Adds a user to the authorised group.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 4, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    async def authorise_add(self, ctx, member: discord.Member):
        if not await self.is_guild_owner(ctx):
            embed = discord.Embed(title="<:CrossIcon:1327829124894429235> Error", description="Only the server owner can add authorised users for executing emergency situation.", color=0x000000)
            return await ctx.reply(embed=embed)

        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT COUNT(*) FROM authorised_users WHERE guild_id = ?", (ctx.guild.id,)) as cursor:
                count = (await cursor.fetchone())[0]
            if count >= 5:
                embed = discord.Embed(title="<:icons_warning:1327829522573430864> Access Denied", description="Only up to 5 authorised users can be added.", color=0x000000)
                return await ctx.reply(embed=embed)

            async with db.execute("SELECT 1 FROM authorised_users WHERE guild_id = ? AND user_id = ?", (ctx.guild.id, member.id)) as cursor:
                if await cursor.fetchone():
                    embed = discord.Embed(title="<:CrossIcon:1327829124894429235> Error", description="This user is already authorised.", color=0x000000)
                    return await ctx.reply(embed=embed)

            await db.execute("INSERT INTO authorised_users (guild_id, user_id) VALUES (?, ?)", (ctx.guild.id, member.id))
            await db.commit()

        embed = discord.Embed(title="<:emoji_4:1566043104551768114> Success", description=f"**{member.display_name}** has been authorised to use `emergency-situation` command.", color=0x000000)
        await ctx.reply(embed=embed)

    @authorise.command(name="remove", help="Removes a user from the authorised group")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 4, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    async def authorise_remove(self, ctx, member: discord.Member):
        if not await self.is_guild_owner(ctx):
            embed = discord.Embed(title="<:icons_warning:1327829522573430864> Access Denied", description="Only the server owner can remove authorised users for emergency situation.", color=0x000000)
            return await ctx.reply(embed=embed)

        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT 1 FROM authorised_users WHERE guild_id = ? AND user_id = ?", (ctx.guild.id, member.id)) as cursor:
                if not await cursor.fetchone():
                    embed = discord.Embed(title="<:CrossIcon:1327829124894429235> Error", description="This user is not authorised.", color=0x000000)
                    return await ctx.reply(embed=embed)

            await db.execute("DELETE FROM authorised_users WHERE guild_id = ? AND user_id = ?", (ctx.guild.id, member.id))
            await db.commit()

        embed = discord.Embed(title="<:emoji_4:1566043104551768114> Success", description=f"**{member.display_name}** has been removed from the authorised list and can no more use `emergency-situation` command.", color=0x000000)
        await ctx.reply(embed=embed)

    @authorise.command(name="list", aliases=["view", "config"], help="Lists all authorised users for emergency actions.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 4, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    async def list_authorized(self, ctx):
        if not await self.is_guild_owner(ctx):
            embed = discord.Embed(title="<:icons_warning:1327829522573430864> Access Denied", description="Only the server owner can view the list of authorised users for emergency situation.", color=0x000000)
            return await ctx.reply(embed=embed)

        
        async with aiosqlite.connect('db/emergency.db') as db:
            cursor = await db.execute("SELECT user_id FROM authorised_users WHERE guild_id = ?", (ctx.guild.id,))
            authorized_users = await cursor.fetchall()
            
        if not authorized_users:
            await ctx.reply(embed=discord.Embed(
                title="Authorized Users",
                description="No authorized users found.",
                color=0x000000))
            return
                
        description = "\n".join([f"{index + 1}. [{ctx.guild.get_member(user[0]).name}](https://discord.com/users/{user[0]}) - {user[0]}" for index, user in enumerate(authorized_users)])
        await ctx.reply(embed=discord.Embed(
            title="Authorized Users",
            description=description,
            color=0x000000))

    @emergency.group(name="role", help="Lists all the commands in the emergency role group.", invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 4, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    async def role(self, ctx):
        if ctx.subcommand_passed is None:
            await ctx.send_help(ctx.command)
            ctx.command.reset_cooldown(ctx)

    @role.command(name="add", help="Adds a role to the emergency role list")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 4, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    async def role_add(self, ctx, role: discord.Role):
        if not await self.is_guild_owner(ctx):
            embed = discord.Embed(title="<:icons_warning:1327829522573430864> Access Denied", description="Only the server owner can add role for emergency situation.", color=0x000000)
            return await ctx.reply(embed=embed)


        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT COUNT(*) FROM emergency_roles WHERE guild_id = ?", (ctx.guild.id,)) as cursor:
                count = (await cursor.fetchone())[0]
            if count >= 25:
                embed = discord.Embed(title="<:icons_warning:1327829522573430864> Error", description="Only up to 25 roles can be added.", color=0x000000)
                return await ctx.reply(embed=embed)

            async with db.execute("SELECT 1 FROM emergency_roles WHERE guild_id = ? AND role_id = ?", (ctx.guild.id, role.id)) as cursor:
                if await cursor.fetchone():
                    embed = discord.Embed(title="<:CrossIcon:1327829124894429235> Error", description="This role is already in the emergency list.", color=0x000000)
                    return await ctx.reply(embed=embed)

            await db.execute("INSERT INTO emergency_roles (guild_id, role_id) VALUES (?, ?)", (ctx.guild.id, role.id))
            await db.commit()

        embed = discord.Embed(title="<:emoji_4:1566043104551768114> Success", description=f"**{role.name}** has been **added** to the emergency list.", color=0x000000)
        await ctx.reply(embed=embed)

    @role.command(name="remove", help="Removes a role from the emergency role list.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 4, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    async def role_remove(self, ctx, role: discord.Role):
        if not await self.is_guild_owner(ctx):
            embed = discord.Embed(title="<:icons_warning:1327829522573430864> Access Denied", description="Only the server owner can remove roles from emergency list.", color=0x000000)
            return await ctx.reply(embed=embed)

        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT 1 FROM emergency_roles WHERE guild_id = ? AND role_id = ?", (ctx.guild.id, role.id)) as cursor:
                if not await cursor.fetchone():
                    embed = discord.Embed(title="<:CrossIcon:1327829124894429235> Error", description="This role is not in the emergency list.", color=0x000000)
                    return await ctx.reply(embed=embed)

            await db.execute("DELETE FROM emergency_roles WHERE guild_id = ? AND role_id = ?", (ctx.guild.id, role.id))
            await db.commit()

        embed = discord.Embed(title="<:emoji_4:1566043104551768114> Success", description=f"**{role.name}** has been removed from the emergency list.", color=0x000000)
        await ctx.reply(embed=embed)

    @role.command(name="list", aliases=["view", "config"], help="Lists all roles added to the emergency list.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 4, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    async def list_roles(self, ctx):
        if not await self.is_guild_owner_or_authorised(ctx):
            embed = discord.Embed(title="<:icons_warning:1327829522573430864> Access Denied", description="You are not authorised to view list of roles for emergency situation.", color=0x000000)
            return await ctx.reply(embed=embed)

        
        async with aiosqlite.connect('db/emergency.db') as db:
            cursor = await db.execute("SELECT role_id FROM emergency_roles WHERE guild_id = ?", (ctx.guild.id,))
            roles = await cursor.fetchall()

        if not roles:
            
            await ctx.reply(embed=discord.Embed(
                title="Emergency Roles",
                description="No roles added for emergency situation.",
                color=0x000000))
            return

        description = "\n".join([f"{index + 1}. <@&{role[0]}> - {role[0]}" for index, role in enumerate(roles)])

        await ctx.reply(embed=discord.Embed(
            title="Emergency Roles",
            description=description,
            color=0x000000))


    # ------------------------------------------------------------------ core engine
    async def run_situation(self, guild: discord.Guild, reason: str = "Emergency Situation"):
        """Strip dangerous permissions from every emergency role + @everyone (in PARALLEL), move the biggest role
        under the bot, delete every invite and pause new invites.  Safe to run twice: earlier restore data is kept."""
        async with self._lock(guild.id):
            bot_top = guild.me.top_role
            async with aiosqlite.connect(self.db_path) as db:
                async with db.execute("SELECT role_id FROM emergency_roles WHERE guild_id = ?", (guild.id,)) as cur:
                    ids = [r[0] for r in await cur.fetchall()]
            roles = {guild.default_role.id: guild.default_role}
            for rid in ids:
                r = guild.get_role(rid)
                if r is not None:
                    roles[r.id] = r

            modified, unchanged, rows = [], [], []
            sem = asyncio.Semaphore(SEM)

            async def one(role):
                if role.managed or (not role.is_default() and role >= bot_top):
                    if any(getattr(role.permissions, n, False) for n in DANGEROUS):
                        unchanged.append(role)
                    return
                perms = role.permissions
                gone = [n for n in DANGEROUS if getattr(perms, n, False)]
                if not gone:
                    return
                for n in gone:
                    setattr(perms, n, False)
                async with sem:
                    try:
                        await role.edit(permissions=perms, reason=f"{reason}: dangerous permissions removed")
                    except (discord.Forbidden, discord.HTTPException):
                        unchanged.append(role)
                        return
                modified.append(role)
                rows.append((guild.id, role.id, ",".join(gone)))

            move_task = asyncio.create_task(self._move_top_role(guild, reason))
            inv_task = asyncio.create_task(self._kill_invites(guild, reason))
            await asyncio.gather(*(one(r) for r in roles.values()))
            moved, move_err = await move_task
            inv_deleted, inv_off = await inv_task

            async with aiosqlite.connect(self.db_path) as db:
                for gid, rid, names in rows:                      # merge with what an earlier run already stored
                    async with db.execute("SELECT disabled_perms FROM restore_roles WHERE guild_id = ? AND role_id = ?",
                                          (gid, rid)) as cur:
                        old = await cur.fetchone()
                    if old:
                        names = ",".join(dict.fromkeys(old[0].split(",") + names.split(",")))
                    await db.execute("INSERT OR REPLACE INTO restore_roles (guild_id, role_id, disabled_perms) VALUES (?,?,?)",
                                     (gid, rid, names))
                if inv_off:
                    await db.execute("INSERT INTO emg_settings (guild_id, inv_disabled) VALUES (?, 1) "
                                     "ON CONFLICT(guild_id) DO UPDATE SET inv_disabled = 1", (guild.id,))
                await db.commit()
            return {"modified": modified, "unchanged": unchanged, "moved": moved, "move_err": move_err,
                    "inv_deleted": inv_deleted, "inv_off": inv_off}

    async def _move_top_role(self, guild, reason):
        bot_top = guild.me.top_role
        cands = [r for r in guild.roles if not r.managed and not r.is_default() and r < bot_top]
        if not cands:
            return None, ""
        role = max(cands, key=lambda r: len(r.members))
        if role.position >= bot_top.position - 1:
            return None, ""                                          # already right under me
        prev = role.position
        try:
            await role.edit(position=bot_top.position - 1, reason=f"{reason}: role moved for safety")
        except discord.Forbidden:
            return None, "missing permissions"
        except Exception as e:                                       # noqa: BLE001
            return None, str(e)[:80]
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("DELETE FROM role_positions WHERE guild_id = ? AND role_id = ?", (guild.id, role.id))
            await db.execute("INSERT INTO role_positions (guild_id, role_id, previous_position) VALUES (?,?,?)",
                             (guild.id, role.id, prev))
            await db.commit()
        return role, ""

    async def _kill_invites(self, guild, reason):
        deleted, off = 0, False
        try:
            await guild.edit(invites_disabled=True, reason=f"{reason}: invites paused")
            off = True
        except (TypeError, discord.Forbidden, discord.HTTPException):
            pass
        try:
            invites = await guild.invites()
        except (discord.Forbidden, discord.HTTPException):
            return deleted, off
        sem = asyncio.Semaphore(10)

        async def one(inv):
            nonlocal deleted
            async with sem:
                try:
                    await inv.delete(reason=f"{reason}: invite removed")
                    deleted += 1
                except (discord.Forbidden, discord.HTTPException):
                    pass

        await asyncio.gather(*(one(i) for i in invites))
        return deleted, off

    async def run_restore(self, guild: discord.Guild):
        """Give back every removed permission (in PARALLEL), put the moved role back, re-open invites."""
        async with self._lock(guild.id):
            async with aiosqlite.connect(self.db_path) as db:
                async with db.execute("SELECT role_id, disabled_perms FROM restore_roles WHERE guild_id = ?", (guild.id,)) as cur:
                    rows = await cur.fetchall()
                async with db.execute("SELECT role_id, previous_position FROM role_positions WHERE guild_id = ?", (guild.id,)) as cur:
                    positions = await cur.fetchall()
                async with db.execute("SELECT inv_disabled FROM emg_settings WHERE guild_id = ?", (guild.id,)) as cur:
                    inv = await cur.fetchone()
            modified, unchanged = [], []
            sem = asyncio.Semaphore(SEM)

            async def one(rid, names):
                role = guild.get_role(rid)
                if role is None:
                    return
                perms = role.permissions
                for n in names.split(","):
                    if n in discord.Permissions.VALID_FLAGS:
                        setattr(perms, n, True)
                async with sem:
                    try:
                        await role.edit(permissions=perms, reason="Emergency Restore: permissions restored")
                        modified.append(role)
                    except (discord.Forbidden, discord.HTTPException):
                        unchanged.append(role)

            await asyncio.gather(*(one(rid, names) for rid, names in rows))
            moved_back = []
            for rid, pos in positions:
                role = guild.get_role(rid)
                if role is not None:
                    try:
                        await role.edit(position=min(pos, guild.me.top_role.position - 1), reason="Emergency Restore: role position")
                        moved_back.append(role)
                    except Exception:                                     # noqa: BLE001
                        pass
            inv_on = False
            if inv and inv[0]:
                try:
                    await guild.edit(invites_disabled=False, reason="Emergency Restore: invites enabled")
                    inv_on = True
                except (TypeError, discord.Forbidden, discord.HTTPException):
                    pass
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute("DELETE FROM restore_roles WHERE guild_id = ?", (guild.id,))
                await db.execute("DELETE FROM role_positions WHERE guild_id = ?", (guild.id,))
                await db.execute("UPDATE emg_settings SET inv_disabled = 0 WHERE guild_id = ?", (guild.id,))
                await db.commit()
            return modified, unchanged, moved_back, inv_on

    async def auto_trigger(self, guild: discord.Guild, why: str = ""):
        """Called by the antinuke engine after it punished someone (only when `emergency auto enable` is on)."""
        now = time.monotonic()
        if now - self._auto_cool.get(guild.id, -1e9) < 120:
            return
        self._auto_cool[guild.id] = now
        try:
            res = await self.run_situation(guild, "Emergency (auto)")
            from utils import antinuke_store as store
            cfg = store.peek(guild.id)
            ch = guild.get_channel(cfg.log) if cfg and cfg.log else None
            if ch:
                await ch.send(embed=discord.Embed(
                    title="Emergency mode (auto)", color=0x000000,
                    description=f"Triggered by antinuke: *{why}*\nRoles stripped: **{len(res['modified'])}** | "
                                f"Invites deleted: **{res['inv_deleted']}**\nUse `emgrestore` when the server is safe."))
        except Exception:                                                 # noqa: BLE001
            pass

    # ------------------------------------------------------------------ lockdown
    async def _lockdown(self, guild):
        everyone, sem, n = guild.default_role, asyncio.Semaphore(SEM), 0
        rows = []

        async def one(ch):
            nonlocal n
            fields = LOCK_VOICE if isinstance(ch, (discord.VoiceChannel, discord.StageChannel)) else LOCK_TEXT
            ow = ch.overwrites_for(everyone)
            prev = {f: getattr(ow, f) for f in fields}
            if all(v is False for v in prev.values()):
                return
            for f in fields:
                setattr(ow, f, False)
            async with sem:
                try:
                    await ch.set_permissions(everyone, overwrite=ow, reason="Emergency lockdown")
                except (discord.Forbidden, discord.HTTPException):
                    return
            n += 1
            rows.append((guild.id, ch.id, json.dumps(prev)))

        await asyncio.gather(*(one(c) for c in guild.channels if not isinstance(c, discord.CategoryChannel)))
        async with aiosqlite.connect(self.db_path) as db:
            for gid, cid, prev in rows:                                  # keep the ORIGINAL state if locked twice
                await db.execute("INSERT OR IGNORE INTO lockdown_channels (guild_id, channel_id, prev) VALUES (?,?,?)", (gid, cid, prev))
            await db.commit()
        return n

    async def _unlock(self, guild):
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT channel_id, prev FROM lockdown_channels WHERE guild_id = ?", (guild.id,)) as cur:
                rows = await cur.fetchall()
        everyone, sem, n = guild.default_role, asyncio.Semaphore(SEM), 0

        async def one(cid, prev):
            nonlocal n
            ch = guild.get_channel(cid)
            if ch is None:
                return
            ow = ch.overwrites_for(everyone)
            for f, v in json.loads(prev).items():
                setattr(ow, f, v)
            async with sem:
                try:
                    await ch.set_permissions(everyone, overwrite=None if ow.is_empty() else ow, reason="Emergency unlock")
                    n += 1
                except (discord.Forbidden, discord.HTTPException):
                    pass

        await asyncio.gather(*(one(c, p) for c, p in rows))
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("DELETE FROM lockdown_channels WHERE guild_id = ?", (guild.id,))
            await db.commit()
        return n

    # ------------------------------------------------------------------ commands
    @commands.command(name="emergencysituation", help="Disable dangerous permissions from roles in the emergency list.",
                      aliases=["emergency-situation", "emgs"])
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 15, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.guild, wait=False)
    @commands.guild_only()
    @commands.bot_has_permissions(manage_roles=True)
    async def emergencysituation(self, ctx):
        if not await self.is_guild_owner_or_authorised(ctx) and ctx.author.id not in {int(i) for i in OWNER_IDS}:
            return await ctx.reply(embed=discord.Embed(
                title="<:icons_warning:1327829522573430864> Access Denied",
                description="You are not authorised to execute the emergency situation.", color=0x000000))
        t = time.perf_counter()
        msg = await ctx.send(embed=discord.Embed(title="Processing Emergency Situation, wait for a while...", color=0x000000))
        res = await self.run_situation(ctx.guild, "Emergency Situation")
        ok = "<:emoji_4:1566043104551768114>"
        mod = "\n".join(r.mention for r in res["modified"]) or "No roles were modified."
        err = "\n".join(r.mention for r in res["unchanged"]) or "No roles had permission errors."
        parts = [f"**{ok} Roles Modified (Dangerous Permissions Removed)**:\n{mod}"]
        if res["moved"]:
            parts.append(f"**<:icons_warning:1327829522573430864> Role Moved**: {res['moved'].mention} moved right below my top role.\n"
                         f"**Move it back soon after the server is safe** (or use `emgrestore`).")
        elif res["move_err"]:
            parts.append(f"**Role could not be moved**: {res['move_err']}.")
        parts.append(f"**Invites**: `{res['inv_deleted']}` deleted" + (", new invites paused." if res["inv_off"] else "."))
        parts.append(f"**Errors**:\n{err}")
        parts.append(f"-# Done in {time.perf_counter() - t:.1f}s - run `{ctx.clean_prefix}emgrestore` to undo.")
        await msg.edit(embed=discord.Embed(title="Emergency Situation", description="\n\n".join(parts), color=0x000000),
                       allowed_mentions=NO_PING)

    @commands.command(name="emergencyrestore", aliases=["emgrestore", "emgsrestore", "emgbackup"],
                      help="Restore disabled permissions to roles.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 15, commands.BucketType.user)
    @commands.guild_only()
    @commands.bot_has_permissions(manage_roles=True)
    async def emergencyrestore(self, ctx):
        if ctx.author.id != ctx.guild.owner_id and ctx.author.id not in {int(i) for i in OWNER_IDS}:
            return await ctx.reply(embed=discord.Embed(
                title="<:icons_warning:1327829522573430864> Access Denied",
                description="Only the server owner can execute the emergency restore command.", color=0x000000))
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT COUNT(*) FROM restore_roles WHERE guild_id = ?", (ctx.guild.id,)) as cur:
                n = (await cur.fetchone())[0]
        if not n:
            return await ctx.reply(embed=discord.Embed(
                title="<:CrossIcon:1327829124894429235> Error",
                description="No roles were found with disabled permissions for restore.", color=0x000000))
        view = EmergencyRestoreView(ctx)
        await ctx.send(embed=discord.Embed(
            title="Confirm Restoration", color=0x000000,
            description="This will restore previously disabled permissions, move the role back and re-open invites. Proceed?"), view=view)
        await view.wait()
        if view.value is None:
            return await ctx.reply(embed=discord.Embed(title="Restore Cancelled", description="The restore process timed out.", color=0x000000))
        if view.value is False:
            return await ctx.reply(embed=discord.Embed(title="Restore Cancelled", description="Restoring permissions has been cancelled.", color=0x000000))
        modified, unchanged, moved_back, inv_on = await self.run_restore(ctx.guild)
        ok = "\n".join(r.mention for r in modified) or "No roles were restored."
        err = "\n".join(r.mention for r in unchanged) or "No roles had permission errors."
        extra = (f"\n\n**Role positions restored**: {len(moved_back)}" if moved_back else "") + ("\n**Invites** are enabled again." if inv_on else "")
        await ctx.reply(embed=discord.Embed(
            title="Emergency Restore", color=0x000000,
            description=f"**<:emoji_4:1566043104551768114> Permissions Restored**:\n{ok}\n\n**Errors**:\n{err}{extra}"),
            allowed_mentions=NO_PING)

    @emergency.command(name="lockdown", aliases=["lock"], help="Lock every channel for @everyone (restore with `emergency unlock`).")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 15, commands.BucketType.guild)
    @commands.guild_only()
    @commands.bot_has_permissions(manage_channels=True)
    async def lockdown(self, ctx):
        if not await self.is_guild_owner_or_authorised(ctx) and ctx.author.id not in {int(i) for i in OWNER_IDS}:
            return await ctx.reply(embed=discord.Embed(title="<:icons_warning:1327829522573430864> Access Denied",
                                                       description="You are not authorised to lock the server.", color=0x000000))
        t = time.perf_counter()
        n = await self._lockdown(ctx.guild)
        await ctx.reply(embed=discord.Embed(title="<:emoji_4:1566043104551768114> Server Locked", color=0x000000,
                                            description=f"Locked **{n}** channel(s) in `{time.perf_counter() - t:.1f}s`.\n"
                                                        f"Use `{ctx.clean_prefix}emergency unlock` to open them again."))

    @emergency.command(name="unlock", help="Undo `emergency lockdown` exactly as it was.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 15, commands.BucketType.guild)
    @commands.guild_only()
    @commands.bot_has_permissions(manage_channels=True)
    async def unlock(self, ctx):
        if not await self.is_guild_owner_or_authorised(ctx) and ctx.author.id not in {int(i) for i in OWNER_IDS}:
            return await ctx.reply(embed=discord.Embed(title="<:icons_warning:1327829522573430864> Access Denied",
                                                       description="You are not authorised to unlock the server.", color=0x000000))
        n = await self._unlock(ctx.guild)
        await ctx.reply(embed=discord.Embed(title="<:emoji_4:1566043104551768114> Server Unlocked", color=0x000000,
                                            description=f"Restored **{n}** channel(s)." if n else "Nothing was locked."))

    @emergency.command(name="auto", help="Auto emergency: when antinuke punishes someone, strip dangerous perms + delete invites.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def auto(self, ctx, action: str = None):
        if not await self.is_guild_owner(ctx) and ctx.author.id not in {int(i) for i in OWNER_IDS}:
            return await ctx.reply(embed=discord.Embed(title="<:icons_warning:1327829522573430864> Access Denied",
                                                       description="Only the server owner can change this.", color=0x000000))
        if (action or "").lower() not in {"enable", "on", "disable", "off"}:
            state = "ON" if ctx.guild.id in self.auto_guilds else "OFF"
            return await ctx.reply(embed=discord.Embed(
                title="Emergency Auto", color=0x000000,
                description=f"Currently **{state}**.\n`{ctx.clean_prefix}emergency auto enable` / `disable`\n"
                            "When ON and antinuke bans a nuker, emergency situation runs automatically."))
        on = action.lower() in {"enable", "on"}
        (self.auto_guilds.add if on else self.auto_guilds.discard)(ctx.guild.id)
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("INSERT INTO emg_settings (guild_id, auto) VALUES (?, ?) "
                             "ON CONFLICT(guild_id) DO UPDATE SET auto = excluded.auto", (ctx.guild.id, int(on)))
            await db.commit()
        await ctx.reply(embed=discord.Embed(title="<:emoji_4:1566043104551768114> Success", color=0x000000,
                                            description=f"Emergency auto mode is now **{'ON' if on else 'OFF'}**."))

    @emergency.command(name="status", aliases=["info"], help="Show emergency mode status.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def status(self, ctx):
        if not await self.is_guild_owner_or_authorised(ctx) and ctx.author.id not in {int(i) for i in OWNER_IDS}:
            return await ctx.reply(embed=discord.Embed(title="<:icons_warning:1327829522573430864> Access Denied",
                                                       description="You are not authorised to view this.", color=0x000000))
        g = ctx.guild.id
        async with aiosqlite.connect(self.db_path) as db:
            async def count(sql):
                async with db.execute(sql, (g,)) as cur:
                    return (await cur.fetchone())[0]
            roles = await count("SELECT COUNT(*) FROM emergency_roles WHERE guild_id = ?")
            users = await count("SELECT COUNT(*) FROM authorised_users WHERE guild_id = ?")
            pending = await count("SELECT COUNT(*) FROM restore_roles WHERE guild_id = ?")
            locked = await count("SELECT COUNT(*) FROM lockdown_channels WHERE guild_id = ?")
        e = discord.Embed(title="Emergency Status", color=0x000000)
        e.add_field(name="Emergency roles", value=f"`{roles}`")
        e.add_field(name="Authorised users", value=f"`{users}`")
        e.add_field(name="Waiting for restore", value=f"`{pending}` role(s)")
        e.add_field(name="Locked channels", value=f"`{locked}`")
        e.add_field(name="Auto mode", value="ON" if g in self.auto_guilds else "OFF")
        await ctx.reply(embed=e)


"""
@Author: Sonu Jana
    + Discord: me.sonu
    + Community: https://discord.gg/cfYmz4634n (Death Development)
    + for any queries reach out Community or DM me.
"""