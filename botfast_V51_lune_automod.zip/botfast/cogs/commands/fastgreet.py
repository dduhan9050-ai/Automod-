import asyncio
import os

import aiosqlite
import discord
from discord.ext import commands

DB_PATH = "./db/fastgreet.db"


class FastGreet(commands.Cog):
    """Greet new members in configured channels (greeting is deleted after 2s).

    Speed notes: the old version used blocking ``sqlite3`` inside event handlers
    (froze the whole bot on every join) and greeted channels one by one with a
    2s sleep each.  Now: async DB, per-guild in-memory cache, greetings fire in
    parallel and never block the listener.
    """

    def __init__(self, bot):
        self.bot = bot
        os.makedirs("./db", exist_ok=True)
        self._cache: dict[int, list[int]] = {}
        self._ready = False
        self._tasks: set[asyncio.Task] = set()

    async def cog_load(self):
        await self._ensure_table()

    async def _ensure_table(self):
        if self._ready:
            return
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS greet_channels (
                    guild_id INTEGER,
                    channel_id INTEGER,
                    PRIMARY KEY (guild_id, channel_id)
                )
                """
            )
            await db.commit()
        self._ready = True

    async def _channels(self, guild_id: int) -> list[int]:
        cached = self._cache.get(guild_id)
        if cached is not None:
            return cached
        await self._ensure_table()
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute(
                "SELECT channel_id FROM greet_channels WHERE guild_id = ?", (guild_id,)
            ) as cur:
                rows = await cur.fetchall()
        self._cache[guild_id] = channels = [r[0] for r in rows]
        return channels

    @commands.command(name="fastgreet_add")
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def add_greet_channel(self, ctx, channel: discord.TextChannel):
        await self._ensure_table()
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "INSERT OR IGNORE INTO greet_channels (guild_id, channel_id) VALUES (?, ?)",
                (ctx.guild.id, channel.id),
            )
            await db.commit()
        self._cache.pop(ctx.guild.id, None)
        await ctx.send(f"<:emoji_4:1566043104551768114> {channel.mention} added as a greet channel.")

    @commands.command(name="fastgreet_remove")
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def remove_greet_channel(self, ctx, channel: discord.TextChannel):
        await self._ensure_table()
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "DELETE FROM greet_channels WHERE guild_id = ? AND channel_id = ?",
                (ctx.guild.id, channel.id),
            )
            await db.commit()
        self._cache.pop(ctx.guild.id, None)
        await ctx.send(f"<a:emoji_38:1567096105299214336> {channel.mention} removed from greet channels.")

    @commands.command(name="fastgreet_list")
    @commands.guild_only()
    async def list_greet_channels(self, ctx):
        channels = await self._channels(ctx.guild.id)
        if not channels:
            await ctx.send("<a:emoji_250:1567101252712530020> No greet channels configured.")
            return
        await ctx.send("<:emoji_81:1567148256260005978> Greet Channels: " + ", ".join(f"<#{cid}>" for cid in channels))

    async def _greet(self, member: discord.Member, channel_id: int):
        channel = self.bot.get_channel(channel_id)
        if channel is None:
            return
        try:
            msg = await channel.send(f"{member.mention} Welcome!")
            await asyncio.sleep(2)
            await msg.delete()
        except discord.HTTPException:  # Forbidden / NotFound are subclasses
            pass

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        channels = await self._channels(member.guild.id)
        for channel_id in channels:
            # Fire-and-forget so one slow channel never delays the others
            # (and the listener returns immediately).
            task = asyncio.create_task(self._greet(member, channel_id))
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)

    async def cog_unload(self):
        for t in list(self._tasks):
            t.cancel()


async def setup(bot):
    await bot.add_cog(FastGreet(bot))
