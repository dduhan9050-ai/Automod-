from __future__ import annotations

import datetime
import os
import platform
import time

import aiosqlite
import discord
from components_v2 import media_gallery
import psutil
from discord.ext import commands

from utils.Tools import blacklist_check, ignore_check, updateConfig
from utils.config import serverLink
from utils.permit_store import normalize_permission, valid_permission_names
from utils import general_ui as ui
from utils.general_ui import clip, kv, section

_cd = commands.cooldown(1, 2, commands.BucketType.user)

KEY_PERMS = [
    "administrator", "manage_guild", "manage_roles", "manage_channels", "manage_messages",
    "manage_nicknames", "manage_webhooks", "manage_threads", "kick_members", "ban_members",
    "moderate_members", "mention_everyone", "view_audit_log", "move_members", "mute_members", "deafen_members",
]

BADGES = {
    "staff": "Discord Staff", "partner": "Partnered Server Owner", "hypesquad": "HypeSquad Events",
    "bug_hunter": "Bug Hunter", "bug_hunter_level_2": "Bug Hunter Gold", "hypesquad_bravery": "HypeSquad Bravery",
    "hypesquad_brilliance": "HypeSquad Brilliance", "hypesquad_balance": "HypeSquad Balance",
    "early_supporter": "Early Supporter", "verified_bot_developer": "Early Verified Bot Developer",
    "discord_certified_moderator": "Certified Moderator", "active_developer": "Active Developer",
}


CHANNEL_TYPES = {"text": "Text Channel", "voice": "Voice Channel", "stage_voice": "Stage Channel",
                 "news": "Announcement Channel", "forum": "Forum Channel", "category": "Category"}


def pretty(name: str) -> str:
    return name.replace("_", " ").title()


def fmt_uptime(seconds: float) -> str:
    seconds = int(seconds)
    d, r = divmod(seconds, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    parts = [f"{d}d"] if d else []
    if d or h:
        parts.append(f"{h}h")
    parts.append(f"{m}m" if (d or h or m) else f"{s}s")
    return " ".join(parts)


def dt(ts, style="R") -> str:
    return discord.utils.format_dt(ts, style) if ts else "Unknown"


def user_line(m) -> str:
    return f"{m.mention} → `{m.name}`"


def badge_names(user) -> list[str]:
    flags = user.public_flags
    return [label for attr, label in BADGES.items() if getattr(flags, attr, False)]


class General(commands.Cog):
    """General: basic info, bot information and list commands."""

    def __init__(self, bot):
        self.bot = bot
        self.proc = psutil.Process()
        self.proc.cpu_percent(None)  # prime so the first reading is real
        self._db: aiosqlite.Connection | None = None

    async def cog_unload(self):
        if self._db is not None:
            await self._db.close()

    # ------------------------------------------------------------ plumbing
    async def cog_check(self, ctx: commands.Context) -> bool:
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        if not await blacklist_check().predicate(ctx):
            return False
        return await ignore_check().predicate(ctx)

    async def _reply(self, ctx, view):
        return await ctx.reply(view=view, mention_author=False)

    async def _members(self, ctx):
        if not ctx.guild.chunked:
            try:
                await ctx.guild.chunk()
            except Exception:
                pass
        return ctx.guild.members

    def _links(self) -> list[discord.ui.Button]:
        out = []
        for label, env in (("Website", "WEBSITE_URL"), ("Docs", "DOCS_URL"), ("Status", "STATUS_URL")):
            url = os.getenv(env)
            if url:
                out.append(ui.link_button(label, url))
        if serverLink:
            out.append(ui.link_button("Support Server", serverLink))
        return out

    def _invite_url(self) -> str:
        return discord.utils.oauth_url(self.bot.user.id, permissions=discord.Permissions(8),
                                       scopes=("bot", "applications.commands"))

    # ================================================================ BASIC
    @staticmethod
    def _asset_buttons(asset: discord.Asset, extra: list | None = None) -> list[discord.ui.Button]:
        """PNG / JPG / WEBP (+ GIF when animated) link buttons; a bad format never breaks the command."""
        buttons: list[discord.ui.Button] = []
        formats = ["png", "jpg", "webp"] + (["gif"] if asset.is_animated() else [])
        for fmt in formats:
            try:
                buttons.append(ui.link_button(fmt.upper(), asset.with_format(fmt).with_size(1024).url))
            except Exception:
                continue
        buttons.extend(extra or [])
        return buttons[:5]

    @commands.command(name="avatar", aliases=["av"], help="Shows a member's avatar.")
    @_cd
    async def avatar(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        asset = member.display_avatar
        extra = []
        if member.guild_avatar and member.avatar:
            extra.append(ui.link_button("Global Avatar", member.avatar.with_size(1024).url))
        await self._reply(ctx, ui.media_card(f"{member.display_name}'s Avatar", asset.with_size(1024).url,
                                             self._asset_buttons(asset, extra)))

    @commands.command(name="banner", help="Shows a member's banner.")
    @_cd
    async def banner(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        try:
            user = await self.bot.fetch_user(member.id)     # banners are only on the full user object
        except discord.HTTPException:
            return await self._reply(ctx, ui.note("Couldn't fetch that user's profile right now. Try again later."))
        if not user.banner:
            return await self._reply(ctx, ui.note(f"{member.display_name} doesn't have a banner."))
        await self._reply(ctx, ui.media_card(f"{member.display_name}'s Banner", user.banner.with_size(1024).url,
                                             self._asset_buttons(user.banner)))

    @commands.command(name="servericon", aliases=["sicon", "guildicon"], help="Shows the server icon.")
    @_cd
    async def servericon(self, ctx):
        icon = ctx.guild.icon
        if not icon:
            return await self._reply(ctx, ui.note("This server doesn't have an icon."))
        await self._reply(ctx, ui.media_card(f"{ctx.guild.name}'s Icon", icon.with_size(1024).url,
                                             self._asset_buttons(icon)))

    @commands.command(name="serverbanner", aliases=["sbanner", "guildbanner"], help="Shows the server banner.")
    @_cd
    async def serverbanner(self, ctx):
        banner = ctx.guild.banner
        if not banner:
            return await self._reply(ctx, ui.note("This server doesn't have a banner (needs Boost Level 2)."))
        await self._reply(ctx, ui.media_card(f"{ctx.guild.name}'s Banner", banner.with_size(1024).url,
                                             self._asset_buttons(banner)))

    @commands.command(name="membercount", aliases=["mc"], help="Shows the member count of the server.")
    @_cd
    async def membercount(self, ctx):
        g = ctx.guild
        members = g.members
        bots = sum(1 for m in members if m.bot)
        total = g.member_count or len(members)
        status = {s: 0 for s in ("online", "idle", "dnd", "offline")}
        for m in members:
            key = m.status.name
            status[key if key in status else "offline"] += 1
        lines = [section("Count", [kv("Total", total), kv("Humans", total - bots), kv("Bots", bots)]),
                 section("Presence", [kv("Online", status["online"]), kv("Idle", status["idle"]),
                                      kv("Do Not Disturb", status["dnd"]), kv("Offline", status["offline"])])]
        await self._reply(ctx, ui.text_card(f"## {g.name}'s Members\n\n" + "\n\n".join(lines),
                                            thumbnail=g.icon.url if g.icon else None))

    @commands.command(name="boostcount", aliases=["bc"], help="Shows the boost status of the server.")
    @_cd
    async def boostcount(self, ctx):
        g = ctx.guild
        lines = section("Boosts", [kv("Boost Level", f"{g.premium_tier} Level"), kv("Boost Count", g.premium_subscription_count),
                                   kv("Boosters", len(g.premium_subscribers)),
                                   kv("Booster Role", g.premium_subscriber_role.mention if g.premium_subscriber_role else "None")])
        await self._reply(ctx, ui.text_card(f"## {g.name}'s Boosts\n\n{lines}", thumbnail=g.icon.url if g.icon else None))

    @commands.command(name="joinedat", aliases=["joined-at"], help="Shows when a member joined the server.")
    @_cd
    async def joinedat(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        lines = section("Dates", [kv("Joined Server", f"{dt(member.joined_at, 'F')} ({dt(member.joined_at)})"),
                                  kv("Account Created", f"{dt(member.created_at, 'F')} ({dt(member.created_at)})")])
        await self._reply(ctx, ui.text_card(f"## {member.display_name}\n\n{lines}", thumbnail=member.display_avatar.url))

    @commands.command(name="serverinfo", aliases=["si"], help="Shows detailed information about the server.")
    @_cd
    async def serverinfo(self, ctx):
        g = ctx.guild
        total = g.member_count or len(g.members)
        bots = sum(1 for m in g.members if m.bot)
        regular = sum(1 for e in g.emojis if not e.animated)
        animated = len(g.emojis) - regular
        owner = g.owner.mention if g.owner else f"<@{g.owner_id}>"
        mfa = "Enabled" if int(g.mfa_level.value) == 1 else "Disabled"
        cfilter = {"disabled": "Disabled", "no_role": "Members Without Roles", "all_members": "All Members"}.get(
            g.explicit_content_filter.name, pretty(g.explicit_content_filter.name))
        features = [f"<:emoji_4:1566043104551768114> : {pretty(f)}" for f in g.features][:14] or ["None"]
        roles, used = [], 0
        for r in reversed(g.roles[1:]):
            if used + len(r.mention) > 600:
                roles.append(f"+{len(g.roles) - 1 - len(roles)} more")
                break
            roles.append(r.mention)
            used += len(r.mention) + 2
        head = f"### {g.name}'s Info\n\n" + section("About Server", [
            kv("Name", g.name), kv("Server ID", g.id), kv("Owner [<a:crownn:1567121063194918967>]", owner),
            kv("Created At", dt(g.created_at)), kv("Total Members", total)])
        rest = "\n\n".join([
            section("Extras", [kv("Verification Level", pretty(g.verification_level.name)), kv("MFA Level", mfa),
                               kv("Content Filter", cfilter)]),
            section("Features", features),
            section("Members", [kv("Total Members", total), kv("Humans", total - bots), kv("Bots", bots)]),
            section("Channels", [kv("Categories", len(g.categories)), kv("Text Channels", len(g.text_channels)),
                                 kv("Voice Channels", len(g.voice_channels)), kv("Stage Channels", len(g.stage_channels))]),
            section("Emojis", [kv("Regular emojis", regular), kv("Animated emojis", animated),
                               kv("Stickers", len(g.stickers)), kv("Total", len(g.emojis) + len(g.stickers))]),
            section("Boosts", [kv("Boost Level", f"{g.premium_tier} Level"), kv("Boost count", g.premium_subscription_count),
                               kv("Boosters", len(g.premium_subscribers)),
                               kv("Booster Role", g.premium_subscriber_role.mention if g.premium_subscriber_role else "None")]),
            section("Roles", [", ".join(roles) or "None"]),
        ])
        foot = f"Requested by {ctx.author.display_name} | {dt(discord.utils.utcnow(), 'f')}"
        await self._reply(ctx, ui.text_card(head, clip(rest, 3000), thumbnail=g.icon.url if g.icon else None, footer=foot))

    @commands.command(name="userinfo", aliases=["ui", "whois"], help="Shows detailed information about a member.")
    @_cd
    async def userinfo(self, ctx, member: discord.Member = None):
        m = member or ctx.author
        badges = badge_names(m)
        perms = [pretty(p) for p in KEY_PERMS if getattr(m.guild_permissions, p, False)]
        roles = [r.mention for r in reversed(m.roles[1:])]
        shown, used = [], 0
        for r in roles:
            if used + len(r) > 500:
                shown.append(f"+{len(roles) - len(shown)} more")
                break
            shown.append(r)
            used += len(r) + 2
        head = f"### {m.display_name}'s Info\n\n" + section("General", [
            kv("Name", m.name), kv("ID", m.id), kv("Nickname", m.nick or "None"), kv("Bot", "Yes" if m.bot else "No"),
            kv("Created At", dt(m.created_at)), kv("Joined At", dt(m.joined_at))])
        rest = "\n\n".join([
            section("Server", [kv("Top Role", m.top_role.mention if m.top_role.id != ctx.guild.id else "None"),
                               kv("Boosting Since", dt(m.premium_since) if m.premium_since else "Not boosting"),
                               kv("Timed Out", dt(m.timed_out_until) if m.is_timed_out() else "No")]),
            section("Badges", [", ".join(badges) or "None"]),
            section("Key Permissions", [", ".join(perms) or "None"]),
            section(f"Roles [{len(roles)}]", [", ".join(shown) or "None"]),
        ])
        foot = f"Requested by {ctx.author.display_name} | {dt(discord.utils.utcnow(), 'f')}"
        await self._reply(ctx, ui.text_card(head, clip(rest, 3000), thumbnail=m.display_avatar.url, footer=foot))

    @commands.command(name="roleinfo", aliases=["ri"], help="Shows information about a role.")
    @_cd
    async def roleinfo(self, ctx, *, role: discord.Role):
        perms = [pretty(p) for p in KEY_PERMS if getattr(role.permissions, p, False)]
        head = f"### {role.name}\n\n" + section("General", [
            kv("Name", role.name), kv("ID", role.id), kv("Mention", role.mention), kv("Color", str(role.colour)),
            kv("Position", role.position), kv("Members", len(role.members)), kv("Created At", dt(role.created_at))])
        rest = "\n\n".join([
            section("Settings", [kv("Hoisted", "Yes" if role.hoist else "No"),
                                 kv("Mentionable", "Yes" if role.mentionable else "No"),
                                 kv("Managed", "Yes" if role.managed else "No")]),
            section("Key Permissions", [", ".join(perms) or "None"]),
        ])
        await self._reply(ctx, ui.text_card(head, rest, thumbnail=role.icon.url if role.icon else None))

    @commands.command(name="channelinfo", aliases=["ci"], help="Shows information about a channel.")
    @_cd
    async def channelinfo(self, ctx, channel: discord.abc.GuildChannel = None):
        c = channel or ctx.channel
        general = [kv("Name", c.name), kv("ID", c.id), kv("Mention", c.mention), kv("Type", CHANNEL_TYPES.get(c.type.name, pretty(c.type.name))),
                   kv("Category", c.category.name if getattr(c, "category", None) else "None"),
                   kv("Created At", dt(c.created_at)), kv("Position", c.position)]
        settings = []
        if isinstance(c, discord.TextChannel):
            settings += [kv("NSFW", "Yes" if c.is_nsfw() else "No"), kv("Slowmode", f"{c.slowmode_delay}s")]
            if c.topic:
                settings.append(kv("Topic", clip(c.topic, 200)))
        elif isinstance(c, (discord.VoiceChannel, discord.StageChannel)):
            settings += [kv("Bitrate", f"{c.bitrate // 1000} kbps"), kv("User Limit", c.user_limit or "Unlimited")]
        text = f"### {c.name}'s Info\n\n" + section("General", general)
        if settings:
            text += "\n\n" + section("Settings", settings)
        await self._reply(ctx, ui.text_card(text, footer=f"Requested by {ctx.author.display_name} | {dt(discord.utils.utcnow(), 'f')}"))

    @commands.command(name="profile", aliases=["pr"], help="Shows a member's profile card.")
    @_cd
    async def profile(self, ctx, member: discord.Member = None):
        m = member or ctx.author
        user = await self.bot.fetch_user(m.id)
        badges = badge_names(m)
        text = f"## {m.display_name}'s Profile\n\n" + section("About", [
            kv("Username", f"`{m.name}`"), kv("ID", m.id), kv("Created", dt(m.created_at)), kv("Joined", dt(m.joined_at)),
            kv("Top Role", m.top_role.mention if m.top_role.id != ctx.guild.id else "None"),
            kv("Badges", ", ".join(badges) or "None")])
        view = discord.ui.LayoutView(timeout=None)
        container = discord.ui.Container(accent_colour=ui.WHITE)
        container.add_item(discord.ui.Section(discord.ui.TextDisplay(text),
                                              accessory=discord.ui.Thumbnail(media=m.display_avatar.url)))
        if user.banner:
            container.add_item(media_gallery(user.banner.with_size(1024).url))
        view.add_item(container)
        await self._reply(ctx, view)

    async def _votes(self, user_id: int) -> int:
        for path in ("votes.db", "db/votes.db", "top-gg/votes.db"):
            if not os.path.exists(path):
                continue
            try:
                async with aiosqlite.connect(path) as db:
                    async with db.execute("SELECT total_votes FROM votes WHERE user_id = ?", (str(user_id),)) as cur:
                        row = await cur.fetchone()
                return row[0] if row else 0
            except Exception:
                continue
        return 0

    @commands.command(name="vote", help="Vote for the bot.")
    @_cd
    async def vote(self, ctx):
        name = self.bot.user.display_name
        votes = await self._votes(ctx.author.id)
        text = (f"## Vote For {name} !\n"
                f"▸ Click the button below to support {name} on Discord Bot List.\n"
                f"▸ You currently have **{votes}** total votes!")
        buttons = [ui.link_button("Upvote Bot", f"https://top.gg/bot/{self.bot.user.id}/vote")]
        if serverLink:
            buttons.append(ui.link_button("Support Server", serverLink))
        await self._reply(ctx, ui.text_card(text, buttons=buttons))

    # ================================================================ BOT INFORMATION
    @commands.command(name="invite", help="Get the bot invite link.")
    @_cd
    async def invite(self, ctx):
        buttons = [ui.link_button("Invite Me", self._invite_url())]
        if serverLink:
            buttons.append(ui.link_button("Support Server", serverLink))
        await self._reply(ctx, ui.text_card(f"## Invite {self.bot.user.display_name}\nAdd me to your server with the button below.",
                                            thumbnail=self.bot.user.display_avatar.url, buttons=buttons))

    @commands.command(name="ping", aliases=["latency"], help="Shows the bot's latency.")
    @_cd
    async def ping(self, ctx):
        ws = round(self.bot.latency * 1000)
        try:
            if self._db is None:
                self._db = await aiosqlite.connect("db/prefix.db")
            t0 = time.perf_counter()
            await self._db.execute("SELECT 1")
            db_ms = f"{(time.perf_counter() - t0) * 1000:.0f} ms"
        except Exception:
            db_ms = "N/A"
        text = ("## Bot's Latency\n"
                f"{kv('Websocket Latency', f'`{ws} ms`')}\n{kv('SQLite', f'`{db_ms}`')}")
        await self._reply(ctx, ui.text_card(text, thumbnail=self.bot.user.display_avatar.url))

    @commands.command(name="stats", aliases=["statistics", "botstats"], help="Shows the bot's statistics.")
    @_cd
    async def stats(self, ctx):
        bot = self.bot
        guilds = len(bot.guilds)
        users = sum(g.member_count or 0 for g in bot.guilds)
        cpu = self.proc.cpu_percent(None) / max(1, psutil.cpu_count() or 1)
        mem = self.proc.memory_info().rss / 1048576
        shards = sorted(bot.shards)
        shard = ctx.guild.shard_id
        info = bot.get_shard(shard)
        latency = round((info.latency if info else bot.latency) * 1000)
        up = fmt_uptime(time.time() - self.proc.create_time())
        head = (f"## {bot.user.display_name}'s Statistics\n"
                "Real-time overview of the bot's operational status, resource usage and shard distribution.")
        cluster = (f"### Cluster #1 [Host Cluster]\n"
                   f"• **Shard IDs :** `[ {' , '.join(map(str, shards))} ]`\n"
                   f"• **Servers :** `{guilds:,}`\n• **Users :** `{users:,}`\n"
                   f"• **CPU :** `{cpu:.1f}%`\n• **Memory :** `{mem:.1f} MB`")
        foot = (f"Operating across **1** cluster and **{len(shards)}** shards for **{up}** with "
                f"**{len(set(bot.walk_commands()))}** commands loaded. This server is routed through shard **{shard}** ({latency}ms).")
        await self._reply(ctx, ui.text_card(head, cluster, foot, thumbnail=bot.user.display_avatar.url, buttons=self._links()))

    # ================================================================ PREFIX
    @commands.command(name="prefix", aliases=["setprefix", "changeprefix"],
                      help="Shows or changes the prefix of this server.")
    @_cd
    async def prefix_cmd(self, ctx, new_prefix: str = None):
        current = ctx.clean_prefix
        if new_prefix is None:
            return await self._reply(ctx, ui.note(f"The prefix of this server is `{current}`.\n"
                                                  f"Use `{current}prefix <new prefix>` to change it.", ok=True))
        allowed = (ctx.author.id == ctx.guild.owner_id or ctx.author.guild_permissions.administrator
                   or ctx.author.guild_permissions.manage_guild)
        if not allowed:
            return await self._reply(ctx, ui.note("You need the **Manage Server** permission to change the prefix."))
        if len(new_prefix) > 5:
            return await self._reply(ctx, ui.note("The prefix can be at most **5** characters long."))
        if any(ch.isspace() for ch in new_prefix) or "`" in new_prefix or "@" in new_prefix:
            return await self._reply(ctx, ui.note("The prefix can't contain spaces, backticks or `@`."))
        await updateConfig(ctx.guild.id, {"prefix": new_prefix})
        self.bot.invalidate_prefix_cache(guild_id=ctx.guild.id)
        await self._reply(ctx, ui.note(f"The prefix of this server is now `{new_prefix}`.", ok=True))

    # ================================================================ LIST
    @commands.group(name="list", invoke_without_command=True, help="Shows every list command.")
    @_cd
    async def list_cmd(self, ctx):
        cmds = sorted((c for c in ctx.command.commands if not c.hidden), key=lambda c: c.name)
        entries = []
        for c in cmds:
            sig = f" {c.signature}" if c.signature else ""
            entries.append(f"`{ctx.clean_prefix}list {c.name}{sig}`\n> {c.help or ''}")
        view = ui.PagedView(ctx, f"{self.bot.user.display_name} list", entries, per_page=7, numbered=False, nav="long",
                            header="`<..> <required> | [..] [optional]`")
        await view.start()

    @list_cmd.command(name="users", help="Lists all users in the server.")
    @_cd
    async def l_users(self, ctx):
        entries = [user_line(m) for m in await self._members(ctx) if not m.bot]
        await ui.send_list(ctx, "Users list", entries, "There are no users found here.")

    @list_cmd.command(name="emojis", help="Lists all emojis in the server.")
    @_cd
    async def l_emojis(self, ctx):
        entries = [f"{e} → `:{e.name}:`" for e in ctx.guild.emojis]
        await ui.send_list(ctx, "Emojis list", entries, "There are no emojis found here.")

    @list_cmd.command(name="boosters", help="Lists all server boosters.")
    @_cd
    async def l_boosters(self, ctx):
        boosters = sorted(ctx.guild.premium_subscribers, key=lambda m: m.premium_since or discord.utils.utcnow())
        entries = [f"{m.mention} → {dt(m.premium_since)}" for m in boosters]
        await ui.send_list(ctx, "Booster's list", entries, "There are no boosters found here.")

    @list_cmd.command(name="bots", help="Lists all bots in the server.")
    @_cd
    async def l_bots(self, ctx):
        entries = [user_line(m) for m in await self._members(ctx) if m.bot]
        await ui.send_list(ctx, "Bot's list", entries, "There are no bots found here.")

    @list_cmd.command(name="admins", help="Lists all admins in the server.")
    @_cd
    async def l_admins(self, ctx):
        entries = [user_line(m) for m in await self._members(ctx) if not m.bot and m.guild_permissions.administrator]
        await ui.send_list(ctx, "Admin's list", entries, "There are no admins found here.")

    @list_cmd.command(name="mods", aliases=["moderators"], help="Lists moderators.")
    @_cd
    async def l_mods(self, ctx):
        def is_mod(m):
            p = m.guild_permissions
            return not m.bot and not p.administrator and (p.kick_members or p.ban_members or p.manage_messages or p.moderate_members)
        entries = [user_line(m) for m in await self._members(ctx) if is_mod(m)]
        await ui.send_list(ctx, "Moderator's list", entries, "There are no moderators found here.")

    @list_cmd.command(name="roles", help="Lists all roles in the server.")
    @_cd
    async def l_roles(self, ctx):
        entries = [f"{r.mention} → `{len(r.members)} members`" for r in reversed(ctx.guild.roles[1:])]
        await ui.send_list(ctx, "Role's list", entries, "There are no roles found here.")

    @list_cmd.command(name="inrole", help="Lists members that have a role.")
    @_cd
    async def l_inrole(self, ctx, *, role: discord.Role):
        entries = [user_line(m) for m in role.members]
        await ui.send_list(ctx, f"Members in {role.name}", entries, f"There are no members in {role.name}.")

    @list_cmd.command(name="invoice", aliases=["invc"], help="Lists members in voice channels.")
    @_cd
    async def l_invoice(self, ctx, channel: discord.VoiceChannel = None):
        channels = [channel] if channel else ctx.guild.voice_channels + ctx.guild.stage_channels
        entries = [f"{m.mention} → {c.mention}" for c in channels for m in c.members]
        await ui.send_list(ctx, "Voice list", entries, "There is no one in voice channels here.")

    @list_cmd.command(name="joinedat", help="Lists members by their join date.")
    @_cd
    async def l_joinedat(self, ctx):
        members = sorted((m for m in await self._members(ctx) if m.joined_at), key=lambda m: m.joined_at)
        entries = [f"{m.mention} → {dt(m.joined_at, 'd')}" for m in members]
        await ui.send_list(ctx, "Join date list", entries, "There are no members found here.")

    @list_cmd.command(name="createdat", help="Lists members by account creation date.")
    @_cd
    async def l_createdat(self, ctx):
        members = sorted(await self._members(ctx), key=lambda m: m.created_at)
        entries = [f"{m.mention} → {dt(m.created_at, 'd')}" for m in members]
        await ui.send_list(ctx, "Account creation list", entries, "There are no members found here.")

    async def _flag_list(self, ctx, title: str, noun: str, *flags: str):
        entries = [user_line(m) for m in await self._members(ctx) if any(getattr(m.public_flags, f, False) for f in flags)]
        await ui.send_list(ctx, title, entries, f"There is no {noun} found here.")

    @list_cmd.command(name="early", aliases=["sup"], help="Lists members with the Early Supporter badge.")
    @_cd
    async def l_early(self, ctx):
        await self._flag_list(ctx, "Early Supporter list", "early supporter", "early_supporter")

    @list_cmd.command(name="activedeveloper", help="Lists members with the Active Developer badge.")
    @_cd
    async def l_activedev(self, ctx):
        await self._flag_list(ctx, "Active Developer list", "active developer", "active_developer")

    @list_cmd.command(name="bughunters", help="Lists members with a Bug Hunter badge.")
    @_cd
    async def l_bughunters(self, ctx):
        await self._flag_list(ctx, "Bug Hunter list", "bug hunter", "bug_hunter", "bug_hunter_level_2")

    @list_cmd.command(name="hypesquad", help="Lists members with a HypeSquad badge.")
    @_cd
    async def l_hypesquad(self, ctx):
        await self._flag_list(ctx, "HypeSquad list", "HypeSquad member", "hypesquad", "hypesquad_bravery",
                              "hypesquad_brilliance", "hypesquad_balance")

    @list_cmd.command(name="bans", aliases=["ban"], help="Lists all banned users.")
    @_cd
    async def l_bans(self, ctx):
        if not ctx.author.guild_permissions.ban_members:
            return await self._reply(ctx, ui.note("You need the **Ban Members** permission to use this command."))
        try:
            entries = [f"<@{e.user.id}> → `{e.user.name}`" async for e in ctx.guild.bans(limit=None)]
        except discord.Forbidden:
            return await self._reply(ctx, ui.note("I need the **Ban Members** permission to see the ban list."))
        await ui.send_list(ctx, "Ban list", entries, "There are no banned users found here.")

    @list_cmd.command(name="pending", help="Lists members without accepting server rules.")
    @_cd
    async def l_pending(self, ctx):
        entries = [user_line(m) for m in await self._members(ctx) if m.pending]
        await ui.send_list(ctx, "Pending list", entries, "There are no pending members found here.")

    @list_cmd.command(name="channels", help="Lists all channels in the server.")
    @_cd
    async def l_channels(self, ctx):
        icons = {discord.ChannelType.text: "#", discord.ChannelType.voice: "<:emoji_80:1567148233183203369>", discord.ChannelType.stage_voice: "<:emoji_77:1567148151440146533>",
                 discord.ChannelType.forum: "<:emoji_19:1566458847613419591>", discord.ChannelType.news: "<a:emoji_265:1567124692706267216>"}
        chans = [c for c in ctx.guild.channels if not isinstance(c, discord.CategoryChannel)]
        entries = [f"{icons.get(c.type, '•')} {c.mention} → `{CHANNEL_TYPES.get(c.type.name, pretty(c.type.name))}`" for c in chans]
        await ui.send_list(ctx, "Channel's list", entries, "There are no channels found here.")

    @list_cmd.command(name="timeouts", help="Lists all currently timed out members.")
    @_cd
    async def l_timeouts(self, ctx):
        entries = [f"{m.mention} → {dt(m.timed_out_until)}" for m in await self._members(ctx) if m.is_timed_out()]
        await ui.send_list(ctx, "Timeout list", entries, "There are no timed out members found here.")

    @list_cmd.command(name="hasperms", help="Lists members that have a permission.")
    @_cd
    async def l_hasperms(self, ctx, *, permission: str):
        valid = valid_permission_names()
        words = normalize_permission(permission).split("_")
        perm = "_".join(words)
        if perm not in valid:
            return await self._reply(ctx, ui.note(f"`{permission}` is not a valid permission. Example: `manage_messages`"))
        entries = [user_line(m) for m in await self._members(ctx) if getattr(m.guild_permissions, perm)]
        await ui.send_list(ctx, f"{pretty(perm)} list", entries, f"There are no members with {pretty(perm)} here.")
