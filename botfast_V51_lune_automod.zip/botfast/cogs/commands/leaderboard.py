"""Leaderboard category: VoiceLeaderboard, MessageLeaderboard, InviteLeaderboard, LiveLeaderboard, TopLeaderboard.

Fast by design:
  * message / voice counting is done in memory and written in one batch every few seconds
  * settings / blacklists / reward roles are cached in memory (no DB hit per message)
  * ONE shared SQLite connection (WAL) instead of connecting on every command
"""
from __future__ import annotations

import asyncio
import calendar
import re
import time
import traceback
from typing import Optional

import discord
from discord.ext import commands, tasks

from core import Cog
from utils import leaderboard_ui as ui
from utils.leaderboard_store import Store, since_for
from utils.Tools import blacklist_check, ignore_check

MAX_LIVE_PER_GUILD = 5
LIVE_REFRESH_SECONDS = 120
FEATURES = {
    "voice": ("Voice Leaderboard", "voicelb"),
    "msg": ("Message Leaderboard", "msglb"),
    "invite": ("Invite Leaderboard", "invitelb"),
}
EMPTY_TEXT = {
    "voice": "No voice stats recorded yet.",
    "messages": "No message stats recorded yet.",
    "invites": "No invite stats recorded yet.",
}
SUBTITLE = {
    "voice": "The voice activity is being updated in real-time!",
    "messages": "The messages are being updated in real-time!",
    "invites": "The invites are being updated in real-time!",
}
BASE_TITLE = {"voice": "Voice Leaderboard", "messages": "Message Leaderboard", "invites": "Invite Leaderboard"}
PERIOD_PREFIX = {"alltime": "", "daily": "Daily ", "weekly": "Weekly "}


# --------------------------------------------------------------------------
# helpers / converters
# --------------------------------------------------------------------------
def fmt_duration(seconds: int) -> str:
    seconds = int(seconds)
    d, rem = divmod(seconds, 86400)
    h, rem = divmod(rem, 3600)
    m, s = divmod(rem, 60)
    parts = [f"{v}{u}" for v, u in ((d, "d"), (h, "h"), (m, "m")) if v]
    return " ".join(parts[:3]) if parts else f"{s}s"


def parse_duration(text: str) -> int | None:
    """'1h30m', '90m', '2d', '45' (minutes) -> seconds."""
    text = text.strip().lower().replace(" ", "")
    if not re.fullmatch(r"(\d+[smhd]?)+", text):
        return None
    mult = {"s": 1, "m": 60, "h": 3600, "d": 86400, "": 60}
    return sum(int(n) * mult[u] for n, u in re.findall(r"(\d+)([smhd]?)", text))


def since_ts(period: str) -> int:
    day = since_for(period)
    return calendar.timegm(time.strptime(day, "%Y-%m-%d")) if day else 0


class PeriodConv(commands.Converter):
    _MAP = {"daily": "daily", "day": "daily", "today": "daily", "d": "daily",
            "weekly": "weekly", "week": "weekly", "w": "weekly",
            "alltime": "alltime", "all-time": "alltime", "all": "alltime", "total": "alltime", "a": "alltime"}

    async def convert(self, ctx, argument: str) -> str:
        value = self._MAP.get(argument.lower().strip('"\''))
        if value is None:
            raise commands.BadArgument("Period must be daily, weekly or alltime.")
        return value


class KindConv(commands.Converter):
    _MAP = {"messages": "messages", "message": "messages", "msg": "messages", "msgs": "messages",
            "voice": "voice", "vc": "voice", "invites": "invites", "invite": "invites"}

    async def convert(self, ctx, argument: str) -> str:
        value = self._MAP.get(argument.lower())
        if value is None:
            raise commands.BadArgument("Type must be messages, voice or invites.")
        return value


class Leaderboard(Cog):
    """Voice / Message / Invite / Live / Top leaderboards."""

    def __init__(self, bot):
        self.bot = bot
        self.store = Store()
        self.sessions: dict[tuple[int, int], float] = {}                 # (guild, user) -> voice session start
        self.inv_cache: dict[int, dict[str, tuple[int, int, int]]] = {}  # guild -> code -> (uses, max_uses, inviter)
        self._inv_locks: dict[int, asyncio.Lock] = {}
        self._warmed = False

    # ------------------------------------------------------------------ lifecycle
    async def cog_load(self) -> None:
        await self.store.open()
        self.flush_loop.start()
        self.live_loop.start()
        if self.bot.is_ready():
            self._warmed = True
            asyncio.create_task(self._warm())

    async def cog_unload(self) -> None:
        self.flush_loop.cancel()
        self.live_loop.cancel()
        try:
            self._tick_voice()
            await self.store.close()
        except Exception:
            traceback.print_exc()

    async def cog_check(self, ctx) -> bool:
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        return await blacklist_check().predicate(ctx) and await ignore_check().predicate(ctx)

    @commands.Cog.listener()
    async def on_ready(self) -> None:
        if not self._warmed:
            self._warmed = True
            asyncio.create_task(self._warm())

    async def _warm(self) -> None:
        for guild in list(self.bot.guilds):
            cfg = self.store.settings.get(guild.id)
            if not cfg:
                continue
            if cfg.voice:
                self._seed_voice(guild)
            if cfg.invite:
                await self._snapshot_invites(guild)
                await asyncio.sleep(0.25)

    # ------------------------------------------------------------------ flushing
    def _tick_voice(self) -> None:
        now = time.time()
        for key, start in list(self.sessions.items()):
            secs = int(now - start)
            if secs > 0:
                self.store.count_voice(key[0], key[1], secs)
                self.sessions[key] = start + secs

    async def _flush(self) -> None:
        """Make every counter visible in the DB (called before every read, so boards are real-time)."""
        self._tick_voice()
        touched = await self.store.flush()
        if touched:
            await self._message_rewards(touched)

    @tasks.loop(seconds=10)
    async def flush_loop(self) -> None:
        try:
            await self._flush()
        except Exception:
            traceback.print_exc()

    @flush_loop.before_loop
    async def _before_flush(self) -> None:
        await self.bot.wait_until_ready()

    # ------------------------------------------------------------------ reward roles
    async def _message_rewards(self, touched: set[tuple[int, int]]) -> None:
        for guild_id, user_id in touched:
            if (guild_id, "messages") not in self.store.rewards:
                continue
            guild = self.bot.get_guild(guild_id)
            if guild:
                await self._award("messages", guild, user_id, await self.store.total("messages", guild_id, user_id))

    async def _award(self, kind: str, guild: discord.Guild, user_id: int, total: int) -> None:
        rules = self.store.rewards.get((guild.id, kind))
        member = guild.get_member(user_id) if rules else None
        if not member or not guild.me.guild_permissions.manage_roles:
            return
        for threshold, role_id in rules:
            if total < threshold:
                continue
            role = guild.get_role(role_id)
            if role and role not in member.roles and not role.managed and role < guild.me.top_role:
                try:
                    await member.add_roles(role, reason=f"Leaderboard reward ({threshold} {kind})")
                except discord.HTTPException:
                    pass

    async def _can_manage(self, ctx, role: discord.Role) -> bool:
        if role.is_default() or role.managed or role >= ctx.guild.me.top_role:
            await ctx.reply(view=ui.error("I can't give that role. It is managed, or higher than my top role."),
                            mention_author=False)
            return False
        if ctx.author.id != ctx.guild.owner_id and role >= ctx.author.top_role:
            await ctx.reply(view=ui.error("That role is higher than or equal to your top role."),
                            mention_author=False)
            return False
        return True

    # ------------------------------------------------------------------ gating / enable
    async def _gate(self, ctx, feature: str) -> bool:
        if getattr(self.store.cfg(ctx.guild.id), feature):
            return True
        name, cmd = FEATURES[feature]
        await ctx.reply(view=ui.error(f"{name} is disabled. Use `{ctx.clean_prefix}{cmd} on` to enable it."),
                        mention_author=False)
        return False

    async def _toggle(self, ctx, feature: str, value: bool) -> None:
        name = FEATURES[feature][0]
        if getattr(self.store.cfg(ctx.guild.id), feature) == value:
            state = "enabled" if value else "disabled"
            return await ctx.reply(view=ui.error(f"{name} feature is already {state} for this server"),
                                   mention_author=False)
        await self.store.set_flag(ctx.guild.id, feature, value)
        if feature == "voice":
            if value:
                self._seed_voice(ctx.guild)
            else:
                for key in [k for k in self.sessions if k[0] == ctx.guild.id]:
                    del self.sessions[key]
        elif feature == "invite" and value:
            await self._snapshot_invites(ctx.guild)
        state = "enabled" if value else "disabled"
        await ctx.reply(view=ui.success(f"{name} feature has been {state} for this server"), mention_author=False)

    # ------------------------------------------------------------------ row builder
    async def _rows(self, guild: discord.Guild, kind: str, period: str = "alltime", *, role: discord.Role | None = None,
                    mode: str = "regular", limit: int = 100) -> list[str]:
        if kind == "invites":
            data = (await self.store.inv_board(guild.id, mode) if period == "alltime"
                    else await self.store.inv_board_since(guild.id, since_ts(period)))
        else:
            data = await self.store.top(kind, guild.id, period)
        allowed = {m.id for m in role.members} if role else None
        rows: list[str] = []
        for user_id, value in data:
            member = guild.get_member(user_id)
            if member is None or (allowed is not None and user_id not in allowed):
                continue
            rank = len(rows) + 1
            if kind == "voice":
                label = fmt_duration(value)
            else:
                label = f"{value:,} {kind}"
            medal = ui.MEDALS.get(rank, f"`#{rank}`")
            name = discord.utils.escape_markdown(member.display_name)
            rows.append(f"{medal} | **{name}** • {label}")
            if rank >= limit:
                break
        return rows

    def _title(self, kind: str, period: str, mode: str = "regular", role: discord.Role | None = None) -> str:
        title = PERIOD_PREFIX[period] + BASE_TITLE[kind]
        if kind == "invites" and period == "alltime" and mode != "regular":
            title += f" • {mode.title()}"
        if role:
            title += f" • {role.name}"
        return title

    async def _board(self, ctx, kind: str, period: str = "alltime", *, role: discord.Role | None = None,
                     mode: str = "regular") -> None:
        feature = {"voice": "voice", "messages": "msg", "invites": "invite"}[kind]
        if not await self._gate(ctx, feature):
            return
        await self._flush()
        rows = await self._rows(ctx.guild, kind, period, role=role, mode=mode)
        if not rows:
            return await ctx.reply(view=ui.error(EMPTY_TEXT[kind]), mention_author=False)
        await ui.send_board(ctx, self._title(kind, period, mode, role), SUBTITLE[kind], rows)

    # ==================================================================
    #                         VOICE LEADERBOARD
    # ==================================================================
    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after) -> None:
        if member.bot:
            return
        guild = member.guild
        key = (guild.id, member.id)
        cfg = self.store.settings.get(guild.id)
        if cfg is None or not cfg.voice:
            self.sessions.pop(key, None)
            return
        afk_id = guild.afk_channel.id if guild.afk_channel else None
        active = after.channel is not None and after.channel.id != afk_id
        start = self.sessions.get(key)
        if active and start is None:
            self.sessions[key] = time.time()
        elif not active and start is not None:
            self.store.count_voice(guild.id, member.id, int(time.time() - start))
            del self.sessions[key]

    def _seed_voice(self, guild: discord.Guild) -> None:
        now = time.time()
        afk_id = guild.afk_channel.id if guild.afk_channel else None
        for channel in guild.voice_channels + list(guild.stage_channels):
            if channel.id == afk_id:
                continue
            for member in channel.members:
                if not member.bot:
                    self.sessions.setdefault((guild.id, member.id), now)

    @commands.group(name="voicelb", invoke_without_command=True, help="Enable or disable the voice leaderboard.")
    @commands.has_permissions(manage_guild=True)
    async def voicelb(self, ctx):
        await ctx.send_help(ctx.command)

    @voicelb.command(name="on", help="Enable the voice leaderboard for this server.")
    @commands.has_permissions(manage_guild=True)
    async def voicelb_on(self, ctx):
        await self._toggle(ctx, "voice", True)

    @voicelb.command(name="off", help="Disable the voice leaderboard for this server.")
    @commands.has_permissions(manage_guild=True)
    async def voicelb_off(self, ctx):
        await self._toggle(ctx, "voice", False)

    @commands.command(name="vcstats", usage="[member]", help="Shows the voice time of you or another member.")
    async def vcstats(self, ctx, member: Optional[discord.Member] = None):
        member = member or ctx.author
        if not await self._gate(ctx, "voice"):
            return
        await self._flush()
        total, week, today = await self.store.totals("voice", ctx.guild.id, member.id)
        body = (f"**All time** • **{fmt_duration(total)}** in this server\n"
                f"**Weekly** • **{fmt_duration(week)}** in this server\n"
                f"**Today** • **{fmt_duration(today)}** in this server")
        await ctx.reply(view=ui.card(f"{member.display_name}'s Voice Time", member.display_avatar.url, body,
                                     "Voice time is being updated in real-time"), mention_author=False)

    @commands.command(name="voiceleaderboard", aliases=["vlb"], help="Shows the all-time voice leaderboard.")
    async def voiceleaderboard(self, ctx):
        await self._board(ctx, "voice", "alltime")

    @commands.command(name="dailyvoice", help="Shows today's voice leaderboard.")
    async def dailyvoice(self, ctx):
        await self._board(ctx, "voice", "daily")

    @commands.command(name="weeklyvoice", help="Shows the voice leaderboard of the last 7 days.")
    async def weeklyvoice(self, ctx):
        await self._board(ctx, "voice", "weekly")

    @commands.command(name="addvctime", usage="<member> <duration>",
                      help="Adds voice time to a member (e.g. 1h30m, 90m, 2d).")
    @commands.has_permissions(manage_guild=True)
    async def addvctime(self, ctx, member: discord.Member, *, duration: str):
        secs = parse_duration(duration)
        if not secs:
            return await ctx.reply(view=ui.error("Invalid duration. Use something like `1h30m`, `90m` or `2d`."),
                                   mention_author=False)
        self.store.count_voice(ctx.guild.id, member.id, secs)
        await ctx.reply(view=ui.success(f"Added {fmt_duration(secs)} of voice time to {member.display_name}"),
                        mention_author=False)

    @commands.command(name="reducevctime", usage="<member> <duration>",
                      help="Removes voice time from a member (e.g. 1h30m, 90m, 2d).")
    @commands.has_permissions(manage_guild=True)
    async def reducevctime(self, ctx, member: discord.Member, *, duration: str):
        secs = parse_duration(duration)
        if not secs:
            return await ctx.reply(view=ui.error("Invalid duration. Use something like `1h30m`, `90m` or `2d`."),
                                   mention_author=False)
        await self._flush()
        removed = await self.store.deduct("voice", ctx.guild.id, member.id, secs)
        await ctx.reply(view=ui.success(f"Removed {fmt_duration(removed)} of voice time from {member.display_name}"),
                        mention_author=False)

    @commands.command(name="clearvoice", help="Clears the voice stats of the whole server.")
    @commands.has_permissions(administrator=True)
    async def clearvoice(self, ctx):
        async def run() -> str:
            await self._flush()
            await self.store.clear("voice", ctx.guild.id)
            return "All voice stats of this server have been cleared"
        await ui.confirm(ctx, "Clear the voice stats of the whole server? This cannot be undone.", run)

    @commands.command(name="resetmyvoice", help="Resets your own voice stats in this server.")
    async def resetmyvoice(self, ctx):
        await self._flush()
        await self.store.clear("voice", ctx.guild.id, ctx.author.id)
        await ctx.reply(view=ui.success("Your voice stats have been reset"), mention_author=False)

    # ==================================================================
    #                        MESSAGE LEADERBOARD
    # ==================================================================
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        guild = message.guild
        if guild is None or message.author.bot:
            return
        cfg = self.store.settings.get(guild.id)
        if cfg is None or not cfg.msg:
            return
        blocked = self.store.blacklist.get(guild.id)
        if blocked:
            channel = message.channel
            parent = getattr(channel, "parent", None)          # threads count as their parent channel
            ids = (channel.id, getattr(channel, "category_id", None),
                   parent.id if parent else None, getattr(parent, "category_id", None))
            if any(i in blocked for i in ids if i):
                return
        self.store.count_message(guild.id, message.author.id)

    @commands.group(name="msglb", invoke_without_command=True, help="Enable or disable the message leaderboard.")
    @commands.has_permissions(manage_guild=True)
    async def msglb(self, ctx):
        await ctx.send_help(ctx.command)

    @msglb.command(name="on", help="Enable the message leaderboard for this server.")
    @commands.has_permissions(manage_guild=True)
    async def msglb_on(self, ctx):
        await self._toggle(ctx, "msg", True)

    @msglb.command(name="off", help="Disable the message leaderboard for this server.")
    @commands.has_permissions(manage_guild=True)
    async def msglb_off(self, ctx):
        await self._toggle(ctx, "msg", False)

    @commands.command(name="msgstats", usage="[member]", help="Shows the message stats of you or another member.")
    async def msgstats(self, ctx, member: Optional[discord.Member] = None):
        member = member or ctx.author
        if not await self._gate(ctx, "msg"):
            return
        await self._flush()
        total, week, today = await self.store.totals("messages", ctx.guild.id, member.id)
        body = (f"**All time** • **{total:,}** messages in this server\n"
                f"**Weekly** • **{week:,}** messages in this server\n"
                f"**Today** • **{today:,}** messages in this server")
        await ctx.reply(view=ui.card(f"{member.display_name}'s Messages", member.display_avatar.url, body,
                                     "Messages are being updated in real-time"), mention_author=False)

    @commands.group(name="leaderboard", aliases=["lb"], invoke_without_command=True,
                    help="Shows the message leaderboards.")
    async def leaderboard(self, ctx):
        await ctx.send_help(ctx.command)

    @leaderboard.command(name="messages", help="Shows the all-time message leaderboard.")
    async def lb_messages(self, ctx):
        await self._board(ctx, "messages", "alltime")

    @leaderboard.command(name="dailymessages", help="Shows today's message leaderboard.")
    async def lb_daily(self, ctx):
        await self._board(ctx, "messages", "daily")

    @leaderboard.command(name="weeklymessages", help="Shows the message leaderboard of the last 7 days.")
    async def lb_weekly(self, ctx):
        await self._board(ctx, "messages", "weekly")

    @commands.command(name="addmessages", usage="<member> <amount>", help="Adds messages to a member's count.")
    @commands.has_permissions(manage_guild=True)
    async def addmessages(self, ctx, member: discord.Member, amount: int):
        if amount <= 0:
            return await ctx.reply(view=ui.error("Amount must be greater than 0."), mention_author=False)
        self.store.count_message_amount(ctx.guild.id, member.id, amount)
        await ctx.reply(view=ui.success(f"Added {amount:,} messages to {member.display_name}"), mention_author=False)

    @commands.command(name="removemessages", usage="<member> <amount>", help="Removes messages from a member's count.")
    @commands.has_permissions(manage_guild=True)
    async def removemessages(self, ctx, member: discord.Member, amount: int):
        if amount <= 0:
            return await ctx.reply(view=ui.error("Amount must be greater than 0."), mention_author=False)
        await self._flush()
        removed = await self.store.deduct("messages", ctx.guild.id, member.id, amount)
        await ctx.reply(view=ui.success(f"Removed {removed:,} messages from {member.display_name}"),
                        mention_author=False)

    @commands.command(name="clearmsgs", help="Clears the message stats of the whole server.")
    @commands.has_permissions(administrator=True)
    async def clearmsgs(self, ctx):
        async def run() -> str:
            await self._flush()
            await self.store.clear("messages", ctx.guild.id)
            return "All message stats of this server have been cleared"
        await ui.confirm(ctx, "Clear the message stats of the whole server? This cannot be undone.", run)

    @commands.command(name="resetmymessages", help="Resets your own message stats in this server.")
    async def resetmymessages(self, ctx):
        await self._flush()
        await self.store.clear("messages", ctx.guild.id, ctx.author.id)
        await ctx.reply(view=ui.success("Your message stats have been reset"), mention_author=False)

    # ---- blacklists ----------------------------------------------------
    @commands.command(name="blacklistchannel", usage="<channel>",
                      help="Messages in this channel will not be counted.")
    @commands.has_permissions(manage_guild=True)
    async def blacklistchannel(self, ctx, channel: discord.abc.GuildChannel):
        if isinstance(channel, discord.CategoryChannel):
            return await ctx.reply(view=ui.error(f"Use `{ctx.clean_prefix}blacklistcategory` for categories."),
                                   mention_author=False)
        if not await self.store.add_blacklist(ctx.guild.id, channel.id, "channel"):
            return await ctx.reply(view=ui.error(f"{channel.mention} is already blacklisted"), mention_author=False)
        await ctx.reply(view=ui.success(f"{channel.mention} has been blacklisted from the message leaderboard"),
                        mention_author=False)

    @commands.command(name="unblacklistchannel", usage="<channel>", help="Counts messages in this channel again.")
    @commands.has_permissions(manage_guild=True)
    async def unblacklistchannel(self, ctx, channel: discord.abc.GuildChannel):
        if not await self.store.remove_blacklist(ctx.guild.id, channel.id):
            return await ctx.reply(view=ui.error(f"{channel.mention} is not blacklisted"), mention_author=False)
        await ctx.reply(view=ui.success(f"{channel.mention} has been removed from the blacklist"),
                        mention_author=False)

    @commands.command(name="blacklistedchannels", help="Shows the channels that are not counted.")
    async def blacklistedchannels(self, ctx):
        ids = self.store.blacklisted(ctx.guild.id, "channel")
        if not ids:
            return await ctx.reply(view=ui.error("No channels are blacklisted."), mention_author=False)
        await ctx.reply(view=ui.text_panel("Blacklisted Channels", "\n".join(f"• <#{i}>" for i in ids)),
                        mention_author=False)

    @commands.command(name="blacklistcategory", usage="<category>",
                      help="Messages in this category will not be counted.")
    @commands.has_permissions(manage_guild=True)
    async def blacklistcategory(self, ctx, category: discord.CategoryChannel):
        if not await self.store.add_blacklist(ctx.guild.id, category.id, "category"):
            return await ctx.reply(view=ui.error(f"**{category.name}** is already blacklisted"), mention_author=False)
        await ctx.reply(view=ui.success(f"**{category.name}** has been blacklisted from the message leaderboard"),
                        mention_author=False)

    @commands.command(name="unblacklistcategory", usage="<category>", help="Counts messages in this category again.")
    @commands.has_permissions(manage_guild=True)
    async def unblacklistcategory(self, ctx, category: discord.CategoryChannel):
        if not await self.store.remove_blacklist(ctx.guild.id, category.id):
            return await ctx.reply(view=ui.error(f"**{category.name}** is not blacklisted"), mention_author=False)
        await ctx.reply(view=ui.success(f"**{category.name}** has been removed from the blacklist"),
                        mention_author=False)

    @commands.command(name="blacklistedcategories", help="Shows the categories that are not counted.")
    async def blacklistedcategories(self, ctx):
        ids = self.store.blacklisted(ctx.guild.id, "category")
        if not ids:
            return await ctx.reply(view=ui.error("No categories are blacklisted."), mention_author=False)
        lines = []
        for i in ids:
            channel = ctx.guild.get_channel(i)
            lines.append(f"• **{channel.name}**" if channel else f"• Deleted category (`{i}`)")
        await ctx.reply(view=ui.text_panel("Blacklisted Categories", "\n".join(lines)), mention_author=False)

    # ---- reward roles (messages) -----------------------------------------
    async def _set_reward(self, ctx, kind: str, amount: int, role: discord.Role, noun: str) -> None:
        if amount <= 0:
            return await ctx.reply(view=ui.error("Amount must be greater than 0."), mention_author=False)
        if not await self._can_manage(ctx, role):
            return
        await self.store.set_reward(ctx.guild.id, kind, amount, role.id)
        await ctx.reply(view=ui.success(f"{role.name} will be given at {amount:,} {noun}"), mention_author=False)

    async def _unset_reward(self, ctx, kind: str, role: discord.Role) -> None:
        if not await self.store.remove_reward(ctx.guild.id, kind, role.id):
            return await ctx.reply(view=ui.error(f"{role.name} is not a reward role"), mention_author=False)
        await ctx.reply(view=ui.success(f"{role.name} has been removed from the reward roles"), mention_author=False)

    async def _view_rewards(self, ctx, kind: str, title: str, noun: str) -> None:
        rules = self.store.rewards.get((ctx.guild.id, kind), [])
        if not rules:
            return await ctx.reply(view=ui.error("No reward roles are set."), mention_author=False)
        lines = [f"• {amount:,} {noun} → <@&{role_id}>" for amount, role_id in rules]
        await ctx.reply(view=ui.text_panel(title, "\n".join(lines)), mention_author=False)

    @commands.command(name="setmessagerole", usage="<messages> <role>",
                      help="Gives a role when a member reaches the given amount of messages.")
    @commands.has_permissions(manage_guild=True)
    async def setmessagerole(self, ctx, amount: int, role: discord.Role):
        await self._set_reward(ctx, "messages", amount, role, "messages")

    @commands.command(name="unsetmessagerole", usage="<role>", help="Removes a message reward role.")
    @commands.has_permissions(manage_guild=True)
    async def unsetmessagerole(self, ctx, role: discord.Role):
        await self._unset_reward(ctx, "messages", role)

    @commands.command(name="viewmessageroles", help="Shows all message reward roles.")
    async def viewmessageroles(self, ctx):
        await self._view_rewards(ctx, "messages", "Message Reward Roles", "messages")

    # ==================================================================
    #                         INVITE LEADERBOARD
    # ==================================================================
    async def _snapshot_invites(self, guild: discord.Guild) -> dict | None:
        if not guild.me or not guild.me.guild_permissions.manage_guild:
            return None
        try:
            invites = await guild.invites()
        except discord.HTTPException:
            return None
        data = {i.code: (i.uses or 0, i.max_uses or 0, i.inviter.id if i.inviter else 0) for i in invites}
        self.inv_cache[guild.id] = data
        return data

    @staticmethod
    def _find_used(old: dict, new: dict) -> tuple[str, int] | None:
        best = None
        for code, (uses, _mx, inviter) in new.items():
            before = old.get(code)
            gained = uses - (before[0] if before else 0)
            if gained > 0 and (best is None or gained > best[0]):
                best = (gained, code, inviter)
        if best:
            return best[1], best[2]
        # an invite that reached its max uses is deleted by Discord -> it vanished from the list
        gone = [(c, o) for c, o in old.items() if c not in new and o[1] and o[0] + 1 == o[1]]
        if len(gone) == 1:
            return gone[0][0], gone[0][1][2]
        return None

    @commands.Cog.listener()
    async def on_invite_create(self, invite: discord.Invite) -> None:
        if invite.guild and invite.guild.id in self.inv_cache:
            self.inv_cache[invite.guild.id][invite.code] = (
                invite.uses or 0, invite.max_uses or 0, invite.inviter.id if invite.inviter else 0)

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        guild = member.guild
        cfg = self.store.settings.get(guild.id)
        if cfg is None or not cfg.invite or member.bot:
            return
        lock = self._inv_locks.setdefault(guild.id, asyncio.Lock())
        async with lock:
            old = self.inv_cache.get(guild.id)
            new = await self._snapshot_invites(guild)
            if old is None or new is None:
                return
            used = self._find_used(old, new)
        if used is None or not used[1]:
            return
        try:
            await self._record_join(member, used[0], used[1], cfg.alt_days)
        except Exception:
            traceback.print_exc()

    async def _record_join(self, member: discord.Member, code: str, inviter_id: int, alt_days: int) -> None:
        guild = member.guild
        previous = await self.store.inv_member(guild.id, member.id)
        if previous:                                                    # rejoin: no new invite, undo the "left"
            inviter_id = previous["inviter_id"]
            if previous["status"] == "left":
                await self.store.inv_bump(guild.id, inviter_id, left=-1)
            await self.store.inv_bump(guild.id, inviter_id, rejoins=1)
            await self.store.inv_set_status(guild.id, member.id, "fake" if previous["status"] == "fake" else "in")
        else:
            age_days = (discord.utils.utcnow() - member.created_at).total_seconds() / 86400
            fake = inviter_id == member.id or (alt_days > 0 and age_days < alt_days)
            await self.store.inv_add_member(guild.id, member.id, inviter_id, code, "fake" if fake else "in")
            await self.store.inv_bump(guild.id, inviter_id, **({"fake": 1} if fake else {"joins": 1}))
        stats = await self.store.inv_stats(guild.id, inviter_id)
        await self._award("invites", guild, inviter_id, stats["invites"])

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member) -> None:
        guild = member.guild
        cfg = self.store.settings.get(guild.id)
        if cfg is None or not cfg.invite or member.bot:
            return
        row = await self.store.inv_member(guild.id, member.id)
        if row and row["status"] == "in":
            await self.store.inv_set_status(guild.id, member.id, "left")
            await self.store.inv_bump(guild.id, row["inviter_id"], left=1)

    @commands.group(name="invitelb", invoke_without_command=True, help="Enable or disable the invite leaderboard.")
    @commands.has_permissions(manage_guild=True)
    async def invitelb(self, ctx):
        await ctx.send_help(ctx.command)

    @invitelb.command(name="on", help="Enable the invite leaderboard (invite tracking) for this server.")
    @commands.has_permissions(manage_guild=True)
    async def invitelb_on(self, ctx):
        await self._toggle(ctx, "invite", True)

    @invitelb.command(name="off", help="Disable the invite leaderboard (invite tracking) for this server.")
    @commands.has_permissions(manage_guild=True)
    async def invitelb_off(self, ctx):
        await self._toggle(ctx, "invite", False)

    @commands.command(name="invites", usage="[member]", help="Shows the invite stats of you or another member.")
    async def invites(self, ctx, member: Optional[discord.Member] = None):
        member = member or ctx.author
        if not await self._gate(ctx, "invite"):
            return
        s = await self.store.inv_stats(ctx.guild.id, member.id)
        a = ui.ARROW
        body = (f"{member.display_name} currently has **{s['invites']}** invites.\n\n"
                f"**Total:**\n{a} • Joins : {s['joins']}\n{a} • Left : {s['left']}\n{a} • Bonus : {s['bonus']}\n\n"
                f"**Other:**\n{a} • Fake : {s['fake']}\n{a} • Rejoins : {s['rejoins']}")
        await ctx.reply(view=ui.card(f"{member.display_name}'s Invites Stats", member.display_avatar.url, body,
                                     ui.footer_for(ctx)), mention_author=False)

    @commands.command(name="inviter", usage="[member]", help="Shows who invited a member.")
    async def inviter(self, ctx, member: Optional[discord.Member] = None):
        member = member or ctx.author
        if not await self._gate(ctx, "invite"):
            return
        row = await self.store.inv_member(ctx.guild.id, member.id)
        if not row:
            return await ctx.reply(view=ui.error(f"I couldn't find who invited {member.display_name}."),
                                   mention_author=False)
        body = (f"{member.mention} was invited by <@{row['inviter_id']}>\n\n"
                f"{ui.ARROW} • Invite code : `{row['code'] or 'unknown'}`\n"
                f"{ui.ARROW} • Joined : <t:{row['joined_at']}:R>")
        await ctx.reply(view=ui.card(f"{member.display_name}'s Inviter", member.display_avatar.url, body,
                                     ui.footer_for(ctx)), mention_author=False)

    @commands.command(name="invited", usage="[member]", help="Shows the members invited by you or another member.")
    async def invited(self, ctx, member: Optional[discord.Member] = None):
        member = member or ctx.author
        if not await self._gate(ctx, "invite"):
            return
        data = await self.store.inv_invited(ctx.guild.id, member.id)
        if not data:
            return await ctx.reply(view=ui.error(f"{member.display_name} hasn't invited anyone yet."),
                                   mention_author=False)
        label = {"in": "in server", "left": "left", "fake": "fake"}
        rows = [f"• <@{m}> • {label.get(s, s)} • <t:{t}:R>" for m, s, t in data[:300]]
        await ui.send_board(ctx, f"Invited by {member.display_name}", f"**Total invited:** {len(data)}", rows)

    @commands.command(name="inviteinfo", usage="[member]", help="Shows the active invite links of a member.")
    async def inviteinfo(self, ctx, member: Optional[discord.Member] = None):
        member = member or ctx.author
        if not await self._gate(ctx, "invite"):
            return
        if not ctx.guild.me.guild_permissions.manage_guild:
            return await ctx.reply(view=ui.error("I need the `Manage Server` permission to read invite links."),
                                   mention_author=False)
        try:
            invites = [i for i in await ctx.guild.invites() if i.inviter and i.inviter.id == member.id]
        except discord.HTTPException:
            return await ctx.reply(view=ui.error("I couldn't read the invite links of this server."),
                                   mention_author=False)
        if not invites:
            return await ctx.reply(view=ui.error(f"{member.display_name} has no active invite links."),
                                   mention_author=False)
        invites.sort(key=lambda i: i.uses or 0, reverse=True)
        lines = []
        for i in invites[:15]:
            where = i.channel.mention if i.channel else "unknown"
            expires = f"<t:{int(i.expires_at.timestamp())}:R>" if i.expires_at else "never"
            lines.append(f"{ui.ARROW} `{i.code}` • {where} • **{i.uses or 0}** uses • expires {expires}")
        body = f"**{len(invites)}** active links • **{sum(i.uses or 0 for i in invites)}** total uses\n\n" + "\n".join(lines)
        await ctx.reply(view=ui.card(f"{member.display_name}'s Invite Links", member.display_avatar.url, body,
                                     ui.footer_for(ctx)), mention_author=False)

    @commands.group(name="inviteleaderboard", aliases=["invlb"], invoke_without_command=True,
                    help="Shows the invite leaderboard.")
    async def inviteleaderboard(self, ctx):
        await self._board(ctx, "invites", "alltime", mode="regular")

    @inviteleaderboard.command(name="total", help="Leaderboard by total joins (including members who left).")
    async def invlb_total(self, ctx):
        await self._board(ctx, "invites", "alltime", mode="total")

    @inviteleaderboard.command(name="regular", help="Leaderboard by current invites (joins - left + bonus).")
    async def invlb_regular(self, ctx):
        await self._board(ctx, "invites", "alltime", mode="regular")

    @inviteleaderboard.command(name="fake", help="Leaderboard by fake invites.")
    async def invlb_fake(self, ctx):
        await self._board(ctx, "invites", "alltime", mode="fake")

    @inviteleaderboard.command(name="left", help="Leaderboard by invited members who left.")
    async def invlb_left(self, ctx):
        await self._board(ctx, "invites", "alltime", mode="left")

    @commands.command(name="addinvites", usage="<member> <amount>", help="Adds bonus invites to a member.")
    @commands.has_permissions(manage_guild=True)
    async def addinvites(self, ctx, member: discord.Member, amount: int):
        if amount <= 0:
            return await ctx.reply(view=ui.error("Amount must be greater than 0."), mention_author=False)
        await self.store.inv_bump(ctx.guild.id, member.id, bonus=amount)
        stats = await self.store.inv_stats(ctx.guild.id, member.id)
        await self._award("invites", ctx.guild, member.id, stats["invites"])
        await ctx.reply(view=ui.success(f"Added {amount:,} bonus invites to {member.display_name}"),
                        mention_author=False)

    @commands.command(name="removeinvites", usage="<member> <amount>", help="Removes bonus invites from a member.")
    @commands.has_permissions(manage_guild=True)
    async def removeinvites(self, ctx, member: discord.Member, amount: int):
        if amount <= 0:
            return await ctx.reply(view=ui.error("Amount must be greater than 0."), mention_author=False)
        await self.store.inv_bump(ctx.guild.id, member.id, bonus=-amount)
        await ctx.reply(view=ui.success(f"Removed {amount:,} invites from {member.display_name}"),
                        mention_author=False)

    @commands.command(name="clearinvites", help="Clears the invite stats of the whole server.")
    @commands.has_permissions(administrator=True)
    async def clearinvites(self, ctx):
        async def run() -> str:
            await self.store.inv_clear_guild(ctx.guild.id)
            return "All invite stats of this server have been cleared"
        await ui.confirm(ctx, "Clear the invite stats of the whole server? This cannot be undone.", run)

    @commands.command(name="resetmyinvites", help="Resets your own invite stats in this server.")
    async def resetmyinvites(self, ctx):
        await self.store.inv_clear_user(ctx.guild.id, ctx.author.id)
        await ctx.reply(view=ui.success("Your invite stats have been reset"), mention_author=False)

    @commands.command(name="setaltthreshold", usage="<days>",
                      help="Accounts younger than this many days count as fake invites (0 = off).")
    @commands.has_permissions(manage_guild=True)
    async def setaltthreshold(self, ctx, days: int):
        if not 0 <= days <= 365:
            return await ctx.reply(view=ui.error("Days must be between 0 and 365."), mention_author=False)
        await self.store.set_alt_days(ctx.guild.id, days)
        text = "Fake invite detection is now off" if days == 0 else \
            f"Accounts younger than {days} days will count as fake invites"
        await ctx.reply(view=ui.success(text), mention_author=False)

    @commands.command(name="unsetaltthreshold", help="Restores the default alt-account threshold (7 days).")
    @commands.has_permissions(manage_guild=True)
    async def unsetaltthreshold(self, ctx):
        await self.store.set_alt_days(ctx.guild.id, 7)
        await ctx.reply(view=ui.success("Alt threshold has been reset to the default (7 days)"), mention_author=False)

    @commands.command(name="setinviterole", usage="<invites> <role>",
                      help="Gives a role when a member reaches the given amount of invites.")
    @commands.has_permissions(manage_guild=True)
    async def setinviterole(self, ctx, amount: int, role: discord.Role):
        await self._set_reward(ctx, "invites", amount, role, "invites")

    @commands.command(name="unsetinviterole", usage="<role>", help="Removes an invite reward role.")
    @commands.has_permissions(manage_guild=True)
    async def unsetinviterole(self, ctx, role: discord.Role):
        await self._unset_reward(ctx, "invites", role)

    @commands.command(name="viewinviteroles", help="Shows all invite reward roles.")
    async def viewinviteroles(self, ctx):
        await self._view_rewards(ctx, "invites", "Invite Reward Roles", "invites")

    # ==================================================================
    #                          LIVE LEADERBOARD
    # ==================================================================
    async def _live_content(self, guild: discord.Guild, kind: str, period: str):
        await self._flush()
        rows = await self._rows(guild, kind, period, limit=10)
        return ui.live_view(self._title(kind, period), SUBTITLE[kind], rows)

    @tasks.loop(seconds=LIVE_REFRESH_SECONDS)
    async def live_loop(self) -> None:
        try:
            for row in await self.store.live_all():
                guild = self.bot.get_guild(row["guild_id"])
                channel = guild.get_channel_or_thread(row["channel_id"]) if guild else None
                if guild is None or channel is None:
                    await self.store.live_delete(row["id"])
                    continue
                try:
                    view = await self._live_content(guild, row["kind"], row["period"])
                    await channel.get_partial_message(row["message_id"]).edit(view=view)
                except discord.NotFound:
                    await self.store.live_delete(row["id"])
                except discord.HTTPException:
                    pass
                await asyncio.sleep(1)
        except Exception:
            traceback.print_exc()

    @live_loop.before_loop
    async def _before_live(self) -> None:
        await self.bot.wait_until_ready()

    @commands.command(name="createlivelb", usage="<messages|voice|invites> [daily|weekly|alltime] [channel]",
                      help="Creates a leaderboard message that updates itself automatically.")
    @commands.has_permissions(manage_guild=True)
    async def createlivelb(self, ctx, kind: KindConv, period: Optional[PeriodConv] = "alltime",
                           channel: Optional[discord.TextChannel] = None):
        channel = channel or ctx.channel
        feature = {"voice": "voice", "messages": "msg", "invites": "invite"}[kind]
        if not await self._gate(ctx, feature):
            return
        if len(await self.store.live_all(ctx.guild.id)) >= MAX_LIVE_PER_GUILD:
            return await ctx.reply(view=ui.error(f"You can have at most {MAX_LIVE_PER_GUILD} live leaderboards."),
                                   mention_author=False)
        perms = channel.permissions_for(ctx.guild.me)
        if not (perms.view_channel and perms.send_messages):
            return await ctx.reply(view=ui.error(f"I can't send messages in {channel.mention}."), mention_author=False)
        if kind == "invites":
            period = "alltime"
        message = await channel.send(view=await self._live_content(ctx.guild, kind, period))
        live_id = await self.store.live_add(ctx.guild.id, channel.id, message.id, kind, period)
        await ctx.reply(view=ui.success(f"Live {kind} leaderboard created in {channel.mention} (ID: {live_id})"),
                        mention_author=False)

    @commands.command(name="deletelivelb", usage="<id>", help="Deletes a live leaderboard (see showlivelbs for IDs).")
    @commands.has_permissions(manage_guild=True)
    async def deletelivelb(self, ctx, live_id: int):
        row = await self.store.live_get(ctx.guild.id, live_id)
        if not row:
            return await ctx.reply(view=ui.error("No live leaderboard found with that ID."), mention_author=False)
        channel = ctx.guild.get_channel_or_thread(row["channel_id"])
        if channel:
            try:
                await channel.get_partial_message(row["message_id"]).delete()
            except discord.HTTPException:
                pass
        await self.store.live_delete(live_id)
        await ctx.reply(view=ui.success(f"Live leaderboard {live_id} has been deleted"), mention_author=False)

    @commands.command(name="showlivelbs", help="Shows all live leaderboards of this server.")
    async def showlivelbs(self, ctx):
        rows = await self.store.live_all(ctx.guild.id)
        if not rows:
            return await ctx.reply(view=ui.error("This server has no live leaderboards."), mention_author=False)
        lines = [f"`{r['id']}` • **{r['kind']}** ({r['period']}) • <#{r['channel_id']}> • "
                 f"[jump](https://discord.com/channels/{r['guild_id']}/{r['channel_id']}/{r['message_id']})"
                 for r in rows]
        await ctx.reply(view=ui.text_panel("Live Leaderboards", "\n".join(lines)), mention_author=False)

    # ==================================================================
    #                          TOP LEADERBOARD
    # ==================================================================
    @commands.group(name="top", invoke_without_command=True, help="Top leaderboards for a role.")
    async def top(self, ctx):
        await ctx.send_help(ctx.command)

    @top.command(name="messages", aliases=["msg", "message", "msgs"],
                 usage='<role> <"daily"|"weekly"|"alltime">', help="Top messages leaderboard for a role")
    async def top_messages(self, ctx, role: discord.Role, period: PeriodConv = "alltime"):
        await self._board(ctx, "messages", period, role=role)

    @top.command(name="voice", aliases=["vc"], usage='<role> <"daily"|"weekly"|"alltime">',
                 help="Top voice leaderboard for a role")
    async def top_voice(self, ctx, role: discord.Role, period: PeriodConv = "alltime"):
        await self._board(ctx, "voice", period, role=role)

    @top.command(name="invites", aliases=["invite", "inv"], usage='<role> <"daily"|"weekly"|"alltime">',
                 help="Top invites leaderboard for a role")
    async def top_invites(self, ctx, role: discord.Role, period: PeriodConv = "alltime"):
        await self._board(ctx, "invites", period, role=role)


async def setup(bot):
    await bot.add_cog(Leaderboard(bot))
