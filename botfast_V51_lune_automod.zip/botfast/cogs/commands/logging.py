"""Logging commands (``logging ...``).  All replies are #ffffff Components V2 containers.

The event side (what actually gets logged and sent through the webhooks) lives in
``cogs/logsys/engine.py``.
"""
from __future__ import annotations

from typing import Union

import discord
from discord.ext import commands

from utils.Tools import blacklist_check, ignore_check
from utils.logging_setup import SetupError, bind, drop_webhooks, need_perms, setup_logs
from utils.logging_store import IGNORE_LIMIT, LOG_TYPES, TYPE_KEYS, TYPE_LABEL, resolve_type, store
from utils import logging_ui as ui

NO_PING = ui.NO_PING


class LogType(commands.Converter):
    """'system' / 'System Logs' / 'system-logs' -> 'system' (``all`` is kept as 'all')."""

    def __init__(self, allow_all: bool = False):
        self.allow_all = allow_all

    async def convert(self, ctx, argument: str) -> str:
        if self.allow_all and argument.strip().lower() == "all":
            return "all"
        key = resolve_type(argument)
        if key is None:
            raise commands.BadArgument(f"Unknown log type `{argument}`.")
        return key


class _LogTypeAll(LogType):
    def __init__(self):
        super().__init__(allow_all=True)


class Logging(commands.Cog, name="Logging"):
    """Logging: 16 log types delivered through webhooks."""

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self) -> None:
        await store.load_all()

    # ------------------------------------------------------------------ plumbing
    async def cog_check(self, ctx: commands.Context) -> bool:
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        if not await blacklist_check().predicate(ctx):
            return False
        return await ignore_check().predicate(ctx)

    async def _guard(self, ctx: commands.Context) -> bool:
        """Administrator, Server Owner, Extraowner or bot owner."""
        member = ctx.author
        if (member.id == ctx.guild.owner_id or member.id in (self.bot.owner_ids or ())
                or member.guild_permissions.administrator):
            return True
        try:
            from utils.permit_store import store as permit
            if await permit.is_extraowner(ctx.guild.id, member.id):
                return True
        except Exception:
            pass
        await self._reply(ctx, ui.fail("Access Denied",
                                       "Only an **Administrator**, the **Server Owner** or an **Extraowner** "
                                       "can manage logging."))
        return False

    async def _reply(self, ctx, view):
        return await ctx.reply(view=view, mention_author=False, allowed_mentions=NO_PING)

    # ================================================================ group
    @commands.group(name="logging", invoke_without_command=True,
                    help="Advanced logging system with 16 log types.")
    async def logging(self, ctx: commands.Context):
        await ui.send_group_help(ctx, ctx.command)

    @logging.command(name="config", aliases=["settings", "show"],
                     help="Show the current logging config of this server.")
    async def log_config(self, ctx: commands.Context):
        if not await self._guard(ctx):
            return
        me = ctx.guild.me.guild_permissions
        notes = []
        if not me.manage_webhooks:
            notes.append("I am missing `Manage Webhooks`, so logs cannot be delivered.")
        if not me.view_audit_log:
            notes.append("I am missing `View Audit Log`: executors, webhook and application logs are limited.")
        await self._reply(ctx, ui.config_view(ctx, store.get(ctx.guild.id), notes=notes))

    @logging.command(name="enable", help="Enables logging for this server.")
    async def log_enable(self, ctx: commands.Context):
        if not await self._guard(ctx):
            return
        cfg = store.get(ctx.guild.id)
        if cfg is not None and cfg.enabled:
            return await self._reply(ctx, ui.fail("Already Enabled", "Logging is already enabled in this server."))
        await store.set_enabled(ctx.guild.id, True)
        hint = "" if cfg and cfg.targets else f"\nNo log channels yet. Run `{ctx.clean_prefix}logging setup auto`."
        await self._reply(ctx, ui.ok("Logging Enabled", f"Logging is now **enabled** in this server.{hint}"))

    @logging.command(name="disable", help="Disables logging for this server.")
    async def log_disable(self, ctx: commands.Context):
        if not await self._guard(ctx):
            return
        cfg = store.get(ctx.guild.id)
        if cfg is not None and not cfg.enabled:
            return await self._reply(ctx, ui.fail("Already Disabled", "Logging is already disabled in this server."))
        await store.set_enabled(ctx.guild.id, False)
        await self._reply(ctx, ui.ok("Logging Disabled", "Logging is now **disabled**. Your setup is kept."))

    @logging.command(name="remove", usage="<type>", help="Disables logging for a specific log type.")
    async def log_remove(self, ctx: commands.Context, log_type: LogType):
        if not await self._guard(ctx):
            return
        old = await store.remove_target(ctx.guild.id, log_type)
        if old is None:
            return await self._reply(ctx, ui.fail("Not Configured", f"**{TYPE_LABEL[log_type]}** has no channel set."))
        cfg = store.get(ctx.guild.id)
        if old.webhook_id and not any(t.webhook_id == old.webhook_id for t in (cfg.targets.values() if cfg else ())):
            await drop_webhooks(self.bot, [old])
        await self._reply(ctx, ui.ok("Log Type Removed", f"**{TYPE_LABEL[log_type]}** logging is now disabled."))

    @logging.command(name="wizard", help="Runs a wizard and automatically sets up logging.")
    async def log_wizard(self, ctx: commands.Context):
        if not await self._guard(ctx):
            return

        async def runner(types, category):
            return await self._run_setup(ctx, types, category)

        view = ui.WizardView(ctx, runner)
        view.message = await self._reply(ctx, view)

    # ================================================================ setup
    @logging.group(name="setup", invoke_without_command=True, help="Commands to set up logging.")
    async def log_setup(self, ctx: commands.Context):
        await ui.send_group_help(ctx, ctx.command)

    async def _run_setup(self, ctx, types, category=None):
        try:
            result = await setup_logs(ctx.guild, self.bot.user, types, category=category, invoker=ctx.author)
        except SetupError as exc:
            return ui.fail("Setup Failed", str(exc))
        except discord.HTTPException as exc:
            return ui.fail("Setup Failed", f"Discord refused the request: `{exc.text or exc}`")
        lines = [f"**Category :** {result.category.mention if result.category else '`None`'}",
                 f"**Created :** `{len(result.created)}`  |  **Reused :** `{len(result.reused)}`"]
        if result.failed:
            lines.append("**Failed :**\n" + "\n".join(f"• `{n}` → {why[:120]}" for n, why in result.failed[:8]))
        lines.append(f"\nUse `{ctx.clean_prefix}logging config` to see the result.")
        title = "Logging Setup Complete" if not result.failed else "Logging Setup Finished With Errors"
        return (ui.ok if not result.failed else ui.warn)(title, "\n".join(lines))

    @log_setup.command(name="auto", help="Automatically create the log category, channels and webhooks.")
    async def setup_auto(self, ctx: commands.Context):
        if not await self._guard(ctx):
            return
        msg = await self._reply(ctx, ui.working("Setting up logging",
                                                f"Creating `{len(TYPE_KEYS)}` log channels and webhooks..."))
        view = await self._run_setup(ctx, list(TYPE_KEYS))
        await msg.edit(view=view)

    @log_setup.command(name="channel", usage="<type> <channel>", help="Set the channel for a specific log type.")
    async def setup_channel(self, ctx: commands.Context, log_type: _LogTypeAll, channel: discord.TextChannel):
        if not await self._guard(ctx):
            return
        perms = channel.permissions_for(ctx.guild.me)
        if not (perms.view_channel and perms.send_messages and perms.embed_links and perms.manage_webhooks):
            return await self._reply(ctx, ui.fail(
                "Missing Permissions",
                f"In {channel.mention} I need `View Channel`, `Send Messages`, `Embed Links` and `Manage Webhooks`."))
        keys = list(TYPE_KEYS) if log_type == "all" else [log_type]
        try:
            await bind(channel, self.bot.user, keys[0], reason=f"Logging setup by {ctx.author}")
            first = store.get(ctx.guild.id).targets[keys[0]]
            for key in keys[1:]:
                await store.set_target(ctx.guild.id, key, channel.id, first.webhook_id, first.webhook_token)
        except discord.HTTPException as exc:
            return await self._reply(ctx, ui.fail("Setup Failed", f"Discord refused the request: `{exc.text or exc}`"))
        names = "all log types" if log_type == "all" else f"**{TYPE_LABEL[log_type]}**"
        await self._reply(ctx, ui.ok("Log Channel Set", f"{names} will now be sent to {channel.mention}."))

    @log_setup.command(name="clear", help="Clear the logging setup (channels stay, webhooks are removed).")
    async def setup_clear(self, ctx: commands.Context):
        if not await self._guard(ctx):
            return
        cfg = store.get(ctx.guild.id)
        if cfg is None or not cfg.targets:
            return await self._reply(ctx, ui.fail("Nothing To Clear", "No log channels are set up."))
        old = await store.clear_targets(ctx.guild.id)
        unique = {t.webhook_id: t for t in old.values() if t.webhook_id}
        await drop_webhooks(self.bot, list(unique.values()))
        await self._reply(ctx, ui.ok("Logging Setup Cleared",
                                     f"Removed `{len(old)}` log channel setting(s) and their webhooks.\n"
                                     "The Discord channels were not deleted."))

    # ================================================================ ignore
    @logging.group(name="ignore", invoke_without_command=True,
                   help="Commands to ignore certain logging events.")
    async def log_ignore(self, ctx: commands.Context):
        await ui.send_group_help(ctx, ctx.command)

    @log_ignore.command(name="add", usage="<entity>", help="Add a user or role to the ignored list.")
    async def ignore_add(self, ctx: commands.Context, entity: Union[discord.Member, discord.Role, discord.User]):
        if not await self._guard(ctx):
            return
        kind = "role" if isinstance(entity, discord.Role) else "user"
        cfg = store.ensure(ctx.guild.id)
        bucket = cfg.ignored_roles if kind == "role" else cfg.ignored_users
        if len(bucket) >= IGNORE_LIMIT:
            return await self._reply(ctx, ui.fail("Limit Reached", f"You can ignore up to `{IGNORE_LIMIT}` {kind}s."))
        if not await store.ignore_add(ctx.guild.id, kind, entity.id):
            return await self._reply(ctx, ui.fail("Already Ignored", f"{entity.mention} is already ignored."))
        await self._reply(ctx, ui.ok("Added To Ignored List", f"{entity.mention} will no longer be logged."))

    @log_ignore.command(name="remove", usage="<entity>", help="Remove a user or role from the ignored list.")
    async def ignore_remove(self, ctx: commands.Context, entity: Union[discord.Member, discord.Role, discord.User]):
        if not await self._guard(ctx):
            return
        kind = "role" if isinstance(entity, discord.Role) else "user"
        if not await store.ignore_remove(ctx.guild.id, kind, entity.id):
            return await self._reply(ctx, ui.fail("Not Ignored", f"{entity.mention} is not on the ignored list."))
        await self._reply(ctx, ui.ok("Removed From Ignored List", f"{entity.mention} will be logged again."))

    @log_ignore.command(name="embed", aliases=["embeds"], help="Toggle ignoring messages that contain embeds.")
    async def ignore_embed(self, ctx: commands.Context):
        if not await self._guard(ctx):
            return
        new = not (store.get(ctx.guild.id) or store.ensure(ctx.guild.id)).ignore_embeds
        await store.set_flag(ctx.guild.id, "ignore_embeds", new)
        await self._reply(ctx, ui.ok("Ignore Embeds " + ("Enabled" if new else "Disabled"),
                                     "Messages with embeds " + ("will no longer" if new else "will now") + " be logged."))

    @log_ignore.command(name="voice", help="Toggle ignoring voice and stage channels (creation, invites, chat).")
    async def ignore_voice(self, ctx: commands.Context):
        if not await self._guard(ctx):
            return
        new = not (store.get(ctx.guild.id) or store.ensure(ctx.guild.id)).ignore_voice
        await store.set_flag(ctx.guild.id, "ignore_voice", new)
        await self._reply(ctx, ui.ok("Ignore Voice " + ("Enabled" if new else "Disabled"),
                                     "Voice/stage channel creation, updates, invites and chat messages "
                                     + ("will no longer" if new else "will now") + " be logged."))

    # ================================================================ cleanup
    @commands.Cog.listener()
    async def on_guild_remove(self, guild: discord.Guild):
        if store.get(guild.id) is not None:
            await store.delete_guild(guild.id)
