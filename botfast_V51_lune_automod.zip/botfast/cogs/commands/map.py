"""Map command - async geocoding + Components V2 map viewer (white #ffffff container)."""
from __future__ import annotations

import os
import re

import aiohttp
import discord
from components_v2 import media_gallery
from discord.ext import commands

from utils.Tools import blacklist_check, ignore_check

WHITE = discord.Colour(0xFFFFFF)
# Put MAPQUEST_KEY in .env (free key from developer.mapquest.com).
MAPQUEST_KEY = os.getenv("MAPQUEST_KEY", "")
STYLES = {"map": "Map", "sat": "Satellite", "hyb": "Hybrid", "light": "Light", "dark": "Dark"}
SIZES = {"400,300": "400x300", "800,600": "800x600", "1200,900": "1200x900"}
_COORDS = re.compile(r"\s*(-?\d{1,3}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)\s*")


async def geocode(query: str) -> tuple[float, float, str] | None:
    """Address or 'lat, lon' -> (lat, lon, display name). Never blocks the event loop."""
    m = _COORDS.fullmatch(query)
    if m:
        lat, lon = float(m.group(1)), float(m.group(2))
        if -90 <= lat <= 90 and -180 <= lon <= 180:
            return lat, lon, f"{lat:.5f}, {lon:.5f}"
        return None
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=8)) as session:
            async with session.get("https://nominatim.openstreetmap.org/search",
                                   params={"q": query, "format": "json", "limit": 1},
                                   headers={"User-Agent": "DeathDevelopmentBot/1.0"}) as resp:
                if resp.status != 200:
                    return None
                data = await resp.json(content_type=None)
        if not data:
            return None
        return float(data[0]["lat"]), float(data[0]["lon"]), str(data[0].get("display_name") or query)[:120]
    except Exception:
        return None


class GoToModal(discord.ui.Modal, title="Go to location"):
    query = discord.ui.TextInput(label="Address or latitude, longitude", max_length=200)

    def __init__(self, view: "MapView"):
        super().__init__()
        self.map_view = view

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer()
        found = await geocode(str(self.query.value).strip())
        if not found:
            return await interaction.followup.send("<a:emoji_38:1567096105299214336> I couldn't find that location.", ephemeral=True)
        view = self.map_view
        view.lat, view.lon, view.name = found
        view.render()
        await interaction.edit_original_response(view=view)


class MapView(discord.ui.LayoutView):
    def __init__(self, ctx: commands.Context, name: str, lat: float, lon: float):
        super().__init__(timeout=300)
        self.owner_id = ctx.author.id
        self.name, self.lat, self.lon = name, lat, lon
        self.zoom, self.style, self.size = 14, "map", "800,600"
        self.message: discord.Message | None = None
        self.render()

    @property
    def url(self) -> str:
        return (f"https://www.mapquestapi.com/staticmap/v5/map?key={MAPQUEST_KEY}"
                f"&center={self.lat},{self.lon}&zoom={self.zoom}&size={self.size}&type={self.style}")

    def render(self, *, static: bool = False) -> None:
        self.clear_items()
        box = discord.ui.Container(accent_colour=WHITE)
        box.add_item(discord.ui.TextDisplay(
            f"### 🗺️ Map of {self.name}\n"
            f"**Coordinates:** `{self.lat:.5f}, {self.lon:.5f}`  •  **Zoom:** `{self.zoom}`  •  "
            f"**Style:** `{STYLES[self.style]}`  •  **Size:** `{SIZES[self.size]}`\n"
            f"[Open in OpenStreetMap](https://www.openstreetmap.org/?mlat={self.lat}&mlon={self.lon}&zoom={self.zoom})"))
        box.add_item(media_gallery(self.url))
        if not static:
            nav = discord.ui.ActionRow()
            for emoji, dlat, dlon in (("<:left:1567104063240146984>", 0, -1), ("⬆️", 1, 0), ("⬇️", -1, 0), ("➡️", 0, 1)):
                nav.add_item(self._button(emoji, discord.ButtonStyle.secondary, self._mover(dlat, dlon)))
            nav.add_item(self._button("<:bin:1567102784552304640>", discord.ButtonStyle.danger, self._delete))
            box.add_item(nav)
            tools = discord.ui.ActionRow()
            tools.add_item(self._button("<:793645_subtract:1567111722198896660>", discord.ButtonStyle.primary, self._zoomer(-1), label="Zoom Out"))
            tools.add_item(self._button("<:610985_add_symbol:1567111662316552292>", discord.ButtonStyle.primary, self._zoomer(1), label="Zoom In"))
            tools.add_item(self._button("📍", discord.ButtonStyle.success, self._goto, label="Go to"))
            box.add_item(tools)
            style_row = discord.ui.ActionRow()
            style_row.add_item(self._select("Map Style", STYLES, self.style, self._set_style))
            box.add_item(style_row)
            size_row = discord.ui.ActionRow()
            size_row.add_item(self._select("Map Size", SIZES, self.size, self._set_size))
            box.add_item(size_row)
        self.add_item(box)

    # -- builders ---------------------------------------------------------
    @staticmethod
    def _button(emoji, style, callback, label=None) -> discord.ui.Button:
        button = discord.ui.Button(emoji=emoji, style=style, label=label)
        button.callback = callback
        return button

    @staticmethod
    def _select(placeholder, options: dict, current: str, callback) -> discord.ui.Select:
        select = discord.ui.Select(
            placeholder=placeholder,
            options=[discord.SelectOption(label=label, value=value, default=value == current)
                     for value, label in options.items()])
        select.callback = callback
        return select

    async def _refresh(self, interaction: discord.Interaction) -> None:
        self.render()
        await interaction.response.edit_message(view=self)

    # -- callbacks --------------------------------------------------------
    def _mover(self, dlat: int, dlon: int):
        async def callback(interaction: discord.Interaction):
            step = 0.02 * (2 ** (14 - self.zoom))
            self.lat = max(-85.0, min(85.0, self.lat + dlat * step))
            self.lon = ((self.lon + dlon * step + 180) % 360) - 180
            await self._refresh(interaction)
        return callback

    def _zoomer(self, delta: int):
        async def callback(interaction: discord.Interaction):
            self.zoom = max(1, min(18, self.zoom + delta))
            await self._refresh(interaction)
        return callback

    async def _goto(self, interaction: discord.Interaction):
        await interaction.response.send_modal(GoToModal(self))

    async def _set_style(self, interaction: discord.Interaction):
        self.style = interaction.data["values"][0]
        await self._refresh(interaction)

    async def _set_size(self, interaction: discord.Interaction):
        self.size = interaction.data["values"][0]
        await self._refresh(interaction)

    async def _delete(self, interaction: discord.Interaction):
        self.stop()
        await interaction.response.defer()
        try:
            await interaction.delete_original_response()
        except discord.HTTPException:
            pass

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Only the person who ran the command can use this.", ephemeral=True)
            return False
        return True

    async def on_timeout(self) -> None:
        if self.message:
            self.render(static=True)
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass


class Map(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="map", help="Shows a map of a location", usage="<location>",
                             description="Shows a map of a location")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def map(self, ctx: commands.Context, *, location: str):
        if not MAPQUEST_KEY:
            return await ctx.send("<a:emoji_38:1567096105299214336> Map is not configured (set `MAPQUEST_KEY` in `.env`).")
        await ctx.defer()
        found = await geocode(location.strip())
        if not found:
            return await ctx.send("<a:emoji_38:1567096105299214336> Failed to retrieve coordinates for that location. Please try again.")
        view = MapView(ctx, found[2], found[0], found[1])
        view.message = await ctx.send(view=view)
