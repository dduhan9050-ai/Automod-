"""Music cog (Lavalink / wavelink 3.x) - Components V2 UI.

Design goals
* Pretty "Now Playing" card: song thumbnail, title, duration, requester and
  the same button layout as the reference bot.
* Sources: YouTube, YouTube Music, SoundCloud, Spotify, Apple Music, Deezer, JioSaavn, Yandex,
  VK, Tidal, Qobuz (LavaSrc) + Bandcamp / Twitch / Vimeo / direct-stream links.
  Search runs on several sources in parallel and falls back automatically; the bot reads
  the node's real capabilities (/v4/info) and explains *why* something failed.
* A track that fails to load (YouTube blocks, Spotify mirror failure ...) is
  retried on another source instead of making the bot leave the VC.
* Few Discord API calls -> no rate limits:
    - no voice-channel-status edits (heavily rate limited endpoint)
    - no image generation / no per-call aiohttp sessions
    - button replies are ephemeral (one call, nothing left in chat)
    - the card is edited in place when it is still the last message
    - no background polling loops (alone-in-VC uses voice events)
    - 24/7 restore is paced so it does not hit the gateway voice limit
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from collections import defaultdict
from pathlib import Path
from typing import Optional

import discord
import wavelink
from discord.ext import commands

from core import axon
from utils.Tools import blacklist_check, ignore_check
from utils.automation_ui import GroupHelpView, _PagerButton

log = logging.getLogger("deathbot.music")

PINK = discord.Colour(0xF5B7C9)
NO_MENTIONS = discord.AllowedMentions.none()
STAY_FILE = Path("db/247.json")
VOLUME_STEPS = (25, 50, 75, 100, 125, 150)
URL_RE = re.compile(r"^https?://", re.I)

# display name -> Lavalink search prefix.  Every platform Lavalink + youtube-plugin + LavaSrc can
# search.  Which of them really work depends on what the node has enabled (see `platforms`).
SEARCH_SOURCES = {
    "YouTube": "ytsearch",
    "YouTube Music": "ytmsearch",
    "Spotify": "spsearch",
    "SoundCloud": "scsearch",
    "Apple Music": "amsearch",
    "Deezer": "dzsearch",
    "JioSaavn": "jssearch",
    "Yandex Music": "ymsearch",
    "VK Music": "vksearch",
    "Tidal": "tdsearch",
    "Qobuz": "qbsearch",
}
PLATFORM_BY_PREFIX = {v: k for k, v in SEARCH_SOURCES.items()}

# search prefix -> the Lavalink source-manager name that must exist on the node
SEARCH_NEEDS = {
    "ytsearch": "youtube", "ytmsearch": "youtube", "scsearch": "soundcloud",
    "spsearch": "spotify", "amsearch": "applemusic", "dzsearch": "deezer",
    "jssearch": "jiosaavn", "ymsearch": "yandexmusic", "vksearch": "vkmusic",
    "tdsearch": "tidal", "qbsearch": "qobuz",
}

# "play sc: song name" / "play sp: song name" ... forces one platform.
QUERY_PREFIXES = {
    "yt:": "ytsearch", "ytm:": "ytmsearch", "sp:": "spsearch", "sc:": "scsearch",
    "am:": "amsearch", "dz:": "dzsearch", "js:": "jssearch", "ym:": "ymsearch",
    "vk:": "vksearch", "td:": "tdsearch", "qb:": "qbsearch",
}
# (only short prefixes: long ones like "spotify:" would hijack Spotify URIs / song names)

# Links: host regex -> (source-manager name on the node, display name).
# Direct audio files / radio streams (mp3, m3u8 ...) are served by the built-in `http` source.
URL_PLATFORMS = (
    (re.compile(r"(^|\.)(youtube\.com|youtu\.be|youtube-nocookie\.com)$"), "youtube", "YouTube"),
    (re.compile(r"(^|\.)(spotify\.com|spotify\.link)$"), "spotify", "Spotify"),
    (re.compile(r"(^|\.)soundcloud\.com$|^snd\.sc$"), "soundcloud", "SoundCloud"),
    (re.compile(r"(^|\.)music\.apple\.com$"), "applemusic", "Apple Music"),
    (re.compile(r"(^|\.)(deezer\.com|deezer\.page\.link|dzr\.page\.link)$"), "deezer", "Deezer"),
    (re.compile(r"(^|\.)(jiosaavn\.com|saavn\.com)$"), "jiosaavn", "JioSaavn"),
    (re.compile(r"(^|\.)music\.yandex\.[a-z]+$"), "yandexmusic", "Yandex Music"),
    (re.compile(r"(^|\.)(vk\.com|vk\.ru|m\.vk\.com)$"), "vkmusic", "VK Music"),
    (re.compile(r"(^|\.)tidal\.com$"), "tidal", "Tidal"),
    (re.compile(r"(^|\.)qobuz\.com$"), "qobuz", "Qobuz"),
    (re.compile(r"(^|\.)bandcamp\.com$"), "bandcamp", "Bandcamp"),
    (re.compile(r"(^|\.)twitch\.tv$"), "twitch", "Twitch"),
    (re.compile(r"(^|\.)vimeo\.com$"), "vimeo", "Vimeo"),
)

# plain "play <text>" searches these in parallel, first non-empty (in order) wins.
_DEFAULT_FIRST = (os.getenv("MUSIC_DEFAULT_SOURCE") or "ytsearch").strip().lower()
if _DEFAULT_FIRST not in SEARCH_NEEDS:
    _DEFAULT_FIRST = "ytsearch"
DEFAULT_CHAIN = [_DEFAULT_FIRST] + [x for x in ("ytsearch", "scsearch", "ytmsearch") if x != _DEFAULT_FIRST]
DEFAULT_CHAIN = DEFAULT_CHAIN[:3]

# when a track cannot be loaded, try the same song on these (skipping the one that failed;
# platforms the node does not have are skipped automatically)
FALLBACK_ORDER = ("ytmsearch", "ytsearch", "dzsearch", "jssearch")
# wavelink `track.source` -> search prefix of the platform that just failed
TRACK_SOURCE_PREFIX = {
    "youtube": "ytsearch", "youtubemusic": "ytmsearch", "soundcloud": "scsearch",
    "deezer": "dzsearch", "jiosaavn": "jssearch", "yandexmusic": "ymsearch",
    "vkmusic": "vksearch", "qobuz": "qbsearch",
}

SEARCH_TIMEOUT = 7.0       # seconds for one Lavalink search
IDLE_LEAVE_DELAY = 3.0     # seconds after the queue ended before leaving
FAIL_LEAVE_DELAY = 30.0    # seconds after a load failure with nothing left to play
MAX_PLAYLIST = 1000


def split_prefix(query: str):
    """'sc: lofi' -> ('lofi', 'scsearch'); no prefix -> (query, None)."""
    low = query.lower()
    for pre, src in QUERY_PREFIXES.items():
        if low.startswith(pre):
            return query[len(pre):].strip(), src
    return query, None


def platform_of_url(url: str):
    """'https://music.apple.com/...' -> ('applemusic', 'Apple Music'); unknown host -> None."""
    m = re.match(r"^https?://([^/:?#]+)", url.strip(), re.I)
    if not m:
        return None
    host = m.group(1).lower()
    for rx, key, name in URL_PLATFORMS:
        if rx.search(host):
            return key, name
    return None


def explain_load_error(exc: BaseException) -> str:
    """Turn a Lavalink/wavelink load error into one short, useful sentence."""
    raw = " ".join(str(x) for x in (getattr(exc, "error", None), getattr(exc, "cause", None), exc) if x)
    low = raw.lower()
    if "not a bot" in low or "sign in" in low or "confirm you" in low:
        return "YouTube is blocking the node (bot check) - the bot owner should enable OAuth / poToken in the youtube-plugin."
    if "age" in low and "restrict" in low:
        return "This video is age-restricted."
    if "private" in low or "unavailable" in low or "not available" in low:
        return "This track is private, region-locked or unavailable."
    if "no matching" in low or "unknown source" in low or "unsupported" in low:
        return "The Lavalink node has no source for this platform."
    if "token" in low or "401" in low or "403" in low:
        return "The platform rejected the node's credentials (check the API keys in application.yml)."
    if "429" in low or ("rate" in low and "limit" in low):
        return "The platform is rate-limiting the node, try again in a minute."
    cleaned = " ".join(raw.split())
    return (cleaned[:160] + "...") if len(cleaned) > 160 else cleaned


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def fmt_ms(ms: int) -> str:
    s = int(ms // 1000)
    h, rest = divmod(s, 3600)
    m, s = divmod(rest, 60)
    return (f"{h}h " if h else "") + (f"{m}m " if (m or h) else "") + f"{s}s"


def thumb_of(track: wavelink.Playable) -> Optional[str]:
    art = getattr(track, "artwork", None)
    if art and str(art).startswith("http"):
        return str(art)
    source = str(getattr(track, "source", "") or "")
    if "youtube" in source and getattr(track, "identifier", None):
        return f"https://i.ytimg.com/vi/{track.identifier}/hqdefault.jpg"
    return None


def panel(text: str, accent: bool = False) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView(timeout=None)
    box = discord.ui.Container(accent_colour=PINK) if accent else discord.ui.Container()
    box.add_item(discord.ui.TextDisplay(f"> {text}"[:3900]))
    view.add_item(box)
    return view


async def say(ctx: commands.Context, text: str, accent: bool = False):
    try:
        return await ctx.send(view=panel(text, accent), allowed_mentions=NO_MENTIONS)
    except discord.HTTPException:
        return None


async def ireply(interaction: discord.Interaction, text: str, accent: bool = True):
    kwargs = dict(view=panel(text, accent), ephemeral=True, allowed_mentions=NO_MENTIONS)
    if interaction.response.is_done():
        await interaction.followup.send(**kwargs)
    else:
        await interaction.response.send_message(**kwargs)


def is_loop(player: wavelink.Player) -> bool:
    return player.queue.mode == wavelink.QueueMode.loop


def is_autoplay(player: wavelink.Player) -> bool:
    return player.autoplay == wavelink.AutoPlayMode.enabled


# --------------------------------------------------------------------------
# Now Playing card
# --------------------------------------------------------------------------
class _Btn(discord.ui.Button):
    def __init__(self, action: str, **kwargs):
        super().__init__(**kwargs)
        self.action = action

    async def callback(self, interaction: discord.Interaction):
        await self.view.handle(interaction, self.action)


class PlayerView(discord.ui.LayoutView):
    def __init__(self, cog: "Music", track: wavelink.Playable, requester_id: int, *,
                 autoplay: bool = False, loop: bool = False, paused: bool = False,
                 use_thumb: bool = True, ended_by: Optional[str] = None):
        super().__init__(timeout=None)
        self.cog = cog
        self.track = track
        self.requester_id = requester_id
        self.autoplay = autoplay
        self.loop = loop
        self.paused = paused
        self.use_thumb = use_thumb
        self.ended_by = ended_by
        self._build()

    def _build(self) -> None:
        self.clear_items()
        t = self.track
        dead = self.ended_by is not None
        length = "Live" if getattr(t, "is_stream", False) else fmt_ms(t.length)
        flags = []
        if self.paused:
            flags.append("Paused")
        if self.loop:
            flags.append("Loop")
        if self.autoplay:
            flags.append("Autoplay")
        author = f" - [{t.author}]({t.uri})" if t.author and t.uri else (f" - {t.author}" if t.author else "")
        title = t.title.replace("[", "(").replace("]", ")")
        head = f"### [Now Playing]({t.uri})" if t.uri else "### Now Playing"
        text = (f"{head}\n\n**[{title}]({t.uri})**{author}\n" if t.uri else f"{head}\n\n**{title}**{author}\n")
        text += f"Duration: `{length}`\nRequested by ( <@{self.requester_id}> )"
        if flags:
            text += " | " + " | ".join(flags)
        if dead:
            text += f"\n-# Stopped by {self.ended_by}"
        thumb = thumb_of(t) if self.use_thumb else None

        box = discord.ui.Container(accent_colour=PINK)
        body = discord.ui.TextDisplay(text[:3900])
        if thumb:
            box.add_item(discord.ui.Section(body, accessory=discord.ui.Thumbnail(media=thumb)))
        else:
            box.add_item(body)

        row1 = discord.ui.ActionRow()
        row1.add_item(_Btn("prev", emoji="\u23ee\ufe0f", style=discord.ButtonStyle.secondary, disabled=dead))
        row1.add_item(_Btn("pause", emoji="<a:emoji_39:1567099222103294022>" if self.paused else "\u23f8\ufe0f",
                           style=discord.ButtonStyle.secondary, disabled=dead))
        row1.add_item(_Btn("next", emoji="\u23ed\ufe0f", style=discord.ButtonStyle.secondary, disabled=dead))
        row1.add_item(_Btn("vol", emoji="\U0001f509", style=discord.ButtonStyle.secondary, disabled=dead))
        row1.add_item(_Btn("stop", emoji="\u23f9\ufe0f", style=discord.ButtonStyle.danger, disabled=dead))
        row2 = discord.ui.ActionRow()
        row2.add_item(_Btn("loop", label="Loop", emoji="<:loop:1567103059769958431>", style=discord.ButtonStyle.success, disabled=dead))
        row2.add_item(_Btn("shuffle", label="Shuffle", emoji="<:emoji_82:1567148279165100093>", style=discord.ButtonStyle.success, disabled=dead))
        row2.add_item(_Btn("autoplay", label="Autoplay", emoji="<:loop:1567103059769958431>", style=discord.ButtonStyle.success, disabled=dead))
        box.add_item(row1)
        box.add_item(row2)
        self.add_item(box)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        vc = interaction.guild.voice_client if interaction.guild else None
        if not isinstance(vc, wavelink.Player) or not vc.current:
            await ireply(interaction, "Nothing is playing right now.", False)
            return False
        voice = getattr(interaction.user, "voice", None)
        if not voice or voice.channel != vc.channel:
            await ireply(interaction, "Join my voice channel to control the player.", False)
            return False
        return True

    async def handle(self, i: discord.Interaction, action: str) -> None:
        p: wavelink.Player = i.guild.voice_client
        name = i.user.display_name
        try:
            if action == "pause":
                await p.pause(not p.paused)
                self.paused = bool(p.paused)
                self._build()
                await i.response.edit_message(view=self)
            elif action == "next":
                if is_loop(p):
                    p.queue.mode = wavelink.QueueMode.normal
                await p.skip(force=True)
                await ireply(i, f"Skipped by {name}.")
            elif action == "prev":
                hist = self.cog.history.get(i.guild.id, [])
                if len(hist) < 2:
                    return await ireply(i, "No previous track available.", False)
                current = p.current
                hist.pop()
                prev = hist.pop()
                try:
                    if current:
                        p.queue.put_at(0, current)
                except Exception:
                    pass
                await p.play(prev)
                await ireply(i, f"Playing previous track by {name}.")
            elif action == "vol":
                new = next((v for v in VOLUME_STEPS if v > p.volume), VOLUME_STEPS[0])
                await p.set_volume(new)
                await ireply(i, f"Volume set to {new}% by {name}.")
            elif action == "stop":
                self.ended_by = name
                self._build()
                await i.response.edit_message(view=self)
                await self.cog.halt(p)
            elif action == "loop":
                p.queue.mode = wavelink.QueueMode.normal if is_loop(p) else wavelink.QueueMode.loop
                await ireply(i, f"Loop {'enabled' if is_loop(p) else 'disabled'} by {name}.")
            elif action == "shuffle":
                if p.queue.is_empty:
                    return await ireply(i, "Queue is empty.", False)
                p.queue.shuffle()
                await ireply(i, f"Shuffle enabled by {name}.")
            elif action == "autoplay":
                p.autoplay = (wavelink.AutoPlayMode.partial if is_autoplay(p)
                              else wavelink.AutoPlayMode.enabled)
                await ireply(i, f"Autoplay {'enabled' if is_autoplay(p) else 'disabled'} by {name}.")
        except Exception:
            log.exception("player button %s failed", action)
            if not i.response.is_done():
                await ireply(i, "Something went wrong, try again.", False)


# --------------------------------------------------------------------------
# Search
# --------------------------------------------------------------------------
class _NumBtn(discord.ui.Button):
    def __init__(self, index: int):
        super().__init__(label=str(index + 1), style=discord.ButtonStyle.primary)
        self.index = index

    async def callback(self, interaction: discord.Interaction):
        await self.view.pick(interaction, self.index)


class _SourceSelect(discord.ui.Select):
    def __init__(self, current: str, platforms: list[str]):
        names = list(platforms) or list(SEARCH_SOURCES)
        if current not in names:
            names.insert(0, current)
        super().__init__(placeholder="Search on another platform...", options=[
            discord.SelectOption(label=n, value=n, default=(n == current)) for n in names[:25]])

    async def callback(self, interaction: discord.Interaction):
        await self.view.change_source(interaction, self.values[0])


class SearchView(discord.ui.LayoutView):
    def __init__(self, cog: "Music", ctx: commands.Context, query: str, platform: str, results: list):
        super().__init__(timeout=60)
        self.cog, self.ctx, self.query = cog, ctx, query
        self.platform, self.results = platform, results[:5]
        self.message: Optional[discord.Message] = None
        self._build()

    def _build(self) -> None:
        self.clear_items()
        lines = [f"`{n}.` [{t.title[:60]}]({t.uri}) - {t.author[:30]} `{fmt_ms(t.length)}`"
                 for n, t in enumerate(self.results, 1)]
        box = discord.ui.Container(accent_colour=PINK)
        box.add_item(discord.ui.TextDisplay(
            f"### Search results ({self.platform})\n`{self.query[:80]}`\n\n" + "\n".join(lines)))
        row = discord.ui.ActionRow()
        for n in range(len(self.results)):
            row.add_item(_NumBtn(n))
        box.add_item(row)
        sel = discord.ui.ActionRow()
        sel.add_item(_SourceSelect(self.platform, self.cog.available_platforms()))
        box.add_item(sel)
        self.add_item(box)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == self.ctx.author.id:
            return True
        await ireply(interaction, "Only the command author can use this.", False)
        return False

    async def pick(self, i: discord.Interaction, index: int) -> None:
        await i.response.defer()
        self.stop()
        track = self.results[index]
        added = await self.cog.enqueue(self.ctx, [track])
        text = f"Added [{track.title}]({track.uri}) to the queue." if added == "queued" else f"Playing [{track.title}]({track.uri})."
        await i.edit_original_response(view=panel(text, True))

    async def change_source(self, i: discord.Interaction, platform: str) -> None:
        await i.response.defer()
        errs: list[str] = []
        results = await self.cog.search(self.query, SEARCH_SOURCES[platform], errs)
        if not results or isinstance(results, wavelink.Playlist):
            why = f"\n{errs[0]}" if errs else ""
            return await i.edit_original_response(view=panel(f"No results on {platform}.{why}", False))
        self.platform, self.results = platform, list(results)[:5]
        self._build()
        await i.edit_original_response(view=self)

    async def on_timeout(self) -> None:
        if self.message:
            try:
                await self.message.delete()
            except discord.HTTPException:
                pass


# --------------------------------------------------------------------------
# Queue pager (same look as the help pager)
# --------------------------------------------------------------------------
class QueueView(GroupHelpView):
    def _build(self) -> None:
        self.clear_items()
        last = len(self.pages) - 1
        off = self.expired
        row = discord.ui.ActionRow()
        row.add_item(_PagerButton("first", emoji="<:icon_2:1567113746374197318>", disabled=off or self.index == 0))
        row.add_item(_PagerButton("prev", emoji="<:left:1567104063240146984>", disabled=off or self.index == 0))
        row.add_item(_PagerButton("stop", emoji="<:bin:1567102784552304640>", disabled=off))
        row.add_item(_PagerButton("next", emoji="<:right:1567104038284034058>", disabled=off or self.index == last))
        row.add_item(_PagerButton("last", emoji="<:icon_3:1567113772852838410>", disabled=off or self.index == last))
        box = discord.ui.Container(accent_colour=PINK)
        box.add_item(discord.ui.TextDisplay(f"## {self.heading}"))
        box.add_item(discord.ui.Separator())
        box.add_item(discord.ui.TextDisplay("\n".join(self.pages[self.index])[:3900]))
        box.add_item(discord.ui.Separator())
        box.add_item(discord.ui.TextDisplay(
            f"-# Requested by {self.ctx.author.name} | Page {self.index + 1}/{len(self.pages)}"))
        box.add_item(row)
        self.add_item(box)


# --------------------------------------------------------------------------
# Filters
# --------------------------------------------------------------------------
def _filter_preset(name: str) -> wavelink.Filters:
    f = wavelink.Filters()
    if name == "nightcore":
        f.timescale.set(pitch=1.2, speed=1.2, rate=1)
    elif name == "bassboost":
        f.equalizer.set(bands=[{"band": 0, "gain": 0.5}, {"band": 1, "gain": 0.5}, {"band": 2, "gain": 0.5}])
    elif name == "vaporwave":
        f.timescale.set(rate=0.85, pitch=0.85)
    elif name == "karaoke":
        f.karaoke.set(level=1.0, mono_level=1.0, filter_band=220.0, filter_width=100.0)
    elif name == "tremolo":
        f.tremolo.set(depth=0.5, frequency=14.0)
    elif name == "vibrato":
        f.vibrato.set(depth=0.5, frequency=14.0)
    elif name == "rotation":
        f.rotation.set(rotation_hz=5.0)
    elif name == "distortion":
        f.distortion.set(sin_offset=0.0, sin_scale=1.0, cos_offset=0.0, cos_scale=1.0,
                         tan_offset=0.0, tan_scale=1.0, offset=0.0, scale=1.0)
    elif name == "channelmix":
        f.channel_mix.set(left_to_left=0.5, left_to_right=0.5, right_to_left=0.5, right_to_right=0.5)
    return f


FILTER_NAMES = ("vaporwave", "nightcore", "vibrato", "tremolo", "bassboost",
                "karaoke", "rotation", "distortion", "channelmix")


class _FilterSelect(discord.ui.Select):
    def __init__(self, current: Optional[str]):
        super().__init__(placeholder="Choose a filter...", options=[
            discord.SelectOption(label=n.title(), value=n, description=f"Apply {n} effect",
                                 default=(n == current)) for n in FILTER_NAMES])

    async def callback(self, interaction: discord.Interaction):
        await self.view.apply(interaction, self.values[0])


class _CancelBtn(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Cancel", style=discord.ButtonStyle.danger)

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()
        try:
            await interaction.message.delete()
        except discord.HTTPException:
            pass


class FilterView(discord.ui.LayoutView):
    def __init__(self, cog: "Music", ctx: commands.Context):
        super().__init__(timeout=60)
        self.cog, self.ctx = cog, ctx
        current = cog.active_filters.get(ctx.guild.id)
        box = discord.ui.Container(accent_colour=PINK)
        box.add_item(discord.ui.TextDisplay(
            f"### Enable Filter\nChoose a filter to apply.\n**Current filter:** `{current or 'None'}`"))
        sel = discord.ui.ActionRow()
        sel.add_item(_FilterSelect(current))
        box.add_item(sel)
        btn = discord.ui.ActionRow()
        btn.add_item(_CancelBtn())
        box.add_item(btn)
        self.add_item(box)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == self.ctx.author.id:
            return True
        await ireply(interaction, "Only the command author can use this.", False)
        return False

    async def apply(self, i: discord.Interaction, name: str) -> None:
        p = i.guild.voice_client
        if not isinstance(p, wavelink.Player) or not p.playing:
            return await ireply(i, "I'm not playing anything.", False)
        await i.response.defer()
        await p.set_filters(_filter_preset(name), seek=True)
        self.cog.active_filters[i.guild.id] = name
        self.stop()
        await i.edit_original_response(view=panel(f"Filter set to **{name}** by {i.user.display_name}.", True))


# --------------------------------------------------------------------------
# decorators
# --------------------------------------------------------------------------
def guarded(func):
    """blacklist + ignore (both cached) and a soft per-guild flood limit."""
    func = commands.cooldown(5, 5, commands.BucketType.guild)(func)
    func = ignore_check()(func)
    func = blacklist_check()(func)
    return func


# --------------------------------------------------------------------------
# the cog
# --------------------------------------------------------------------------
class Music(commands.Cog):
    def __init__(self, client: axon):
        self.client = client
        self.history: dict[int, list] = {}
        self.cards: dict[int, discord.Message] = {}
        self.last_req: dict[int, int] = {}
        self.active_filters: dict[int, str] = {}
        self.alone_tasks: dict[int, asyncio.Task] = {}
        self.idle_tasks: dict[int, asyncio.Task] = {}
        self.tried: defaultdict[int, set] = defaultdict(set)
        self.last_exc: dict[int, str] = {}
        self.locks: defaultdict[int, asyncio.Lock] = defaultdict(asyncio.Lock)
        self.node_sources: set[str] = set()   # source managers, filled from the node's /v4/info
        self.node_plugins: set[str] = set()
        self.node_version: str = ""
        self.stay: dict[int, dict] = self._load_stay()
        self._node_up = asyncio.Event()      # set while a Lavalink node is connected
        self._poke = asyncio.Event()         # wakes the supervisor for an immediate reconnect
        self._restore_lock = asyncio.Lock()
        self._node_task = client.loop.create_task(self.connect_nodes())

    # ---- lifecycle ---------------------------------------------------------
    async def cog_unload(self) -> None:
        self._node_task.cancel()
        for pool in (self.alone_tasks, self.idle_tasks):
            for task in pool.values():
                task.cancel()
        try:
            await wavelink.Pool.close()
        except Exception:
            pass

    def _load_stay(self) -> dict[int, dict]:
        try:
            raw = json.loads(STAY_FILE.read_text("utf-8"))
            return {int(k): v for k, v in raw.items()}
        except (OSError, ValueError):
            return {}

    def _save_stay(self) -> None:
        try:
            STAY_FILE.parent.mkdir(parents=True, exist_ok=True)
            tmp = STAY_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps({str(k): v for k, v in self.stay.items()}), "utf-8")
            os.replace(tmp, STAY_FILE)
        except OSError:
            log.exception("could not save 24/7 data")

    @staticmethod
    def _node_config() -> tuple[str, str]:
        uri = (os.getenv("LAVALINK_URI") or "").strip()
        # the bundled lavalink/docker-compose.yml defaults to this password, so do the same here:
        # a node started from this repo connects without any extra .env line
        password = os.getenv("LAVALINK_PASSWORD") or "youshallnotpass"
        if not uri:  # also accept HOST / PORT / SECURE style config
            host = (os.getenv("LAVALINK_HOST") or "").strip()
            if host:
                secure = (os.getenv("LAVALINK_SECURE") or "").lower() in ("1", "true", "yes")
                uri = f"{'https' if secure else 'http'}://{host}:{os.getenv('LAVALINK_PORT') or '2333'}"
        if uri and "://" not in uri:
            uri = "http://" + uri
        return uri.rstrip("/"), password

    async def _try_connect(self, uri: str, password: str) -> bool:
        """One connection attempt. Never raises. True when a node is connected afterwards."""
        if self.node_ready():
            return True
        try:
            if not self._pool_nodes():
                node = wavelink.Node(uri=uri, password=password, inactive_player_timeout=None,
                                     retries=None, heartbeat=15.0)
                # wavelink may keep retrying inside connect() until the node is up, so bound it
                await asyncio.wait_for(
                    wavelink.Pool.connect(nodes=[node], client=self.client, cache_capacity=100), 12)
        except asyncio.CancelledError:
            raise
        except asyncio.TimeoutError:
            pass
        except Exception as exc:
            print(f"[Music] Lavalink connection failed: {exc}")
        for _ in range(40):
            if self.node_ready():
                return True
            if not self._pool_nodes():
                break
            await asyncio.sleep(0.25)
        if self.node_ready():
            return True
        await self._drop_dead_nodes()
        return False

    async def connect_nodes(self) -> None:
        """Supervisor: connects to Lavalink as soon as it is reachable and, if the node ever goes
        away (restart / network), notices and reconnects. Music works the moment the node is up."""
        uri, password = self._node_config()
        if not uri:
            print("[Music] Lavalink is not configured. Set LAVALINK_URI (and LAVALINK_PASSWORD) to enable music.")
            return
        await self.client.wait_until_ready()
        print(f"[Music] Connecting to Lavalink at {uri} ...")
        announced = False
        while True:
            try:
                if self.node_ready():
                    if not self._node_up.is_set():
                        self._node_up.set()
                        print("[Music] Connected to Lavalink.")
                        announced = False
                        await self._on_node_up()
                    try:   # healthy: just check again in a few seconds
                        await asyncio.wait_for(self._poke.wait(), 5)
                    except asyncio.TimeoutError:
                        pass
                    self._poke.clear()
                    continue
                self._node_up.clear()
                if await self._try_connect(uri, password):
                    continue
                if not announced:
                    print("[Music] Lavalink is not reachable yet - will connect automatically as soon as it is up.")
                    announced = True
                try:   # unreachable: retry every 3s (a poke from `play` retries immediately)
                    await asyncio.wait_for(self._poke.wait(), 3)
                except asyncio.TimeoutError:
                    pass
                self._poke.clear()
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("node supervisor error")
                await asyncio.sleep(3)

    async def wait_ready(self, timeout: float = 8.0) -> bool:
        """Used by play/join: if the node is not up yet, retry right now instead of failing."""
        if self.node_ready():
            return True
        self._poke.set()
        try:
            await asyncio.wait_for(self._node_up.wait(), timeout)
        except asyncio.TimeoutError:
            pass
        return self.node_ready()

    async def _on_node_up(self) -> None:
        """Runs once each time the node (re)connects: read its info, bring 24/7 VCs back."""
        node = None
        try:
            node = wavelink.Pool.get_node()
        except Exception:
            pass
        if node is not None and not self.node_sources:
            await self._diagnose(node)
        await self.restore_stay()

    @staticmethod
    def _pool_nodes() -> list:
        try:
            nodes = wavelink.Pool.nodes
            if callable(nodes):
                nodes = nodes()
            return list(nodes.values())
        except Exception:
            return []

    async def _drop_dead_nodes(self) -> None:
        """Remove nodes that never connected so the next retry starts from a clean pool."""
        for node in self._pool_nodes():
            try:
                if node.status in (wavelink.NodeStatus.CONNECTED, wavelink.NodeStatus.CONNECTING):
                    continue
            except Exception:
                pass
            try:
                await node.close(eject=True)
            except TypeError:
                try:
                    await node.close()
                except Exception:
                    pass
            except Exception:
                pass

    @staticmethod
    def node_ready() -> bool:
        try:
            wavelink.Pool.get_node()
            return True
        except Exception:
            return False

    # ---- which platforms does the node really have? -----------------------------
    def has_source(self, name: str) -> bool:
        """True if the node has source manager `name`. Unknown (node info not read yet) = True,
        so a failed /v4/info call can never block a platform that would have worked."""
        return not self.node_sources or any(name in m for m in self.node_sources)

    def available_platforms(self) -> list[str]:
        return [n for n, pre in SEARCH_SOURCES.items() if self.has_source(SEARCH_NEEDS[pre])]

    def platform_problem(self, source: Optional[str], query: str) -> Optional[str]:
        """Reason this query can't work on the node (platform missing), or None.
        Only used to *explain* a failed lookup - it never blocks an attempt."""
        if source:
            need = SEARCH_NEEDS.get(source)
            if need and not self.has_source(need):
                return (f"**{PLATFORM_BY_PREFIX.get(source, source)}** is not enabled on the Lavalink node. "
                        f"Use `platforms` to see what is available.")
            return None
        if URL_RE.match(query):
            hit = platform_of_url(query)
            if hit and not self.has_source(hit[0]):
                return f"**{hit[1]}** links are not enabled on the Lavalink node. Use `platforms` to see what is available."
        return None

    async def _diagnose(self, node) -> None:
        """Read the node's real capabilities (version, source managers, plugins)."""
        try:
            info = await node.fetch_info()
        except Exception:
            return
        try:
            managers = {str(m).lower() for m in (getattr(info, "source_managers", None) or [])}
            plugins = {str(getattr(p, "name", p)).lower() for p in (getattr(info, "plugins", None) or [])}
            # only real source managers decide what is searchable; plugin names are kept for the log
            self.node_sources = managers
            self.node_plugins = plugins
            print(f"[Music] Node sources: {', '.join(sorted(managers)) or '-'} | plugins: {', '.join(sorted(plugins)) or '-'}")
            if managers and "youtube" not in managers:
                print("[Music] WARNING: no YouTube source on the node - install/enable youtube-plugin.")
            if managers and not (managers & {"spotify", "applemusic", "deezer", "jiosaavn",
                                             "yandexmusic", "vkmusic", "tidal", "qobuz"}):
                print("[Music] NOTE: no LavaSrc platform is enabled - Spotify/Apple/Deezer/JioSaavn... will not work.")
            version = getattr(info, "version", None)
            self.node_version = str(getattr(version, "semver", version) or "")
            print(f"[Music] Lavalink version: {self.node_version} (4.2.0+ is required for Discord DAVE)")
        except Exception:
            log.debug("could not parse node info", exc_info=True)

    async def restore_stay(self) -> None:
        if self._restore_lock.locked():
            return
        async with self._restore_lock:
            await self._restore_stay()

    async def _restore_stay(self) -> None:
        for gid, info in list(self.stay.items()):
            guild = self.client.get_guild(gid)
            channel = guild.get_channel(info.get("voice", 0)) if guild else None
            if not guild or not channel:
                continue
            if guild.voice_client is None:
                try:
                    player = await channel.connect(cls=wavelink.Player, self_deaf=True)
                    player.autoplay = wavelink.AutoPlayMode.partial
                    player.home = guild.get_channel(info.get("text", 0))
                except Exception:
                    log.warning("24/7 reconnect failed for guild %s", gid)
                await asyncio.sleep(1.0)  # pace voice-state updates

    def cleanup(self, guild_id: int) -> None:
        self.history.pop(guild_id, None)
        self.cards.pop(guild_id, None)
        self.active_filters.pop(guild_id, None)
        self.last_req.pop(guild_id, None)
        self.tried.pop(guild_id, None)
        self.last_exc.pop(guild_id, None)
        for pool in (self.alone_tasks, self.idle_tasks):
            task = pool.pop(guild_id, None)
            if task:
                task.cancel()

    async def halt(self, player: wavelink.Player) -> None:
        """Stop + clear queue. Leaves the VC unless 24/7 mode is on."""
        gid = player.guild.id
        player.queue.clear()
        player.queue.mode = wavelink.QueueMode.normal
        if gid in self.stay:
            self._cancel_idle(gid)
            self.history.pop(gid, None)
            try:
                await player.skip(force=True)
            except Exception:
                pass
        else:
            self.cleanup(gid)
            await player.disconnect()

    # ---- search ------------------------------------------------------------
    async def _lookup(self, query: str, source: Optional[str] = None,
                      errs: Optional[list] = None):
        """One Lavalink search. Never raises; returns None on error/timeout.
        If `errs` is given, a short human-readable reason is appended to it on failure."""
        try:
            if source and not URL_RE.match(query):
                coro = wavelink.Playable.search(query, source=source)
            else:
                coro = wavelink.Playable.search(query)
            return await asyncio.wait_for(coro, SEARCH_TIMEOUT)
        except asyncio.TimeoutError:
            log.warning("search timed out: %r (%s)", query, source)
            if errs is not None:
                errs.append("The search timed out - the Lavalink node or the platform is slow.")
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.warning("search failed: %r (%s): %s", query, source, exc)
            if errs is not None:
                reason = explain_load_error(exc)
                if reason:
                    errs.append(reason)
        return None

    async def search(self, query: str, source: Optional[str] = None, errs: Optional[list] = None):
        return await self._lookup(query, source, errs)

    async def search_chain(self, query: str, errs: Optional[list] = None):
        """Search YouTube / SoundCloud / YT Music in parallel, best-priority hit wins.

        URLs (YouTube, Spotify, Apple Music, Deezer, SoundCloud, direct streams ...) go straight
        to Lavalink. Returns (results, source_prefix_or_None)."""
        if URL_RE.match(query):
            return await self._lookup(query, None, errs), None
        chain = [s for s in DEFAULT_CHAIN if self.has_source(SEARCH_NEEDS[s])] or list(DEFAULT_CHAIN)
        tasks = [asyncio.create_task(self._lookup(query, s, errs)) for s in chain]
        try:
            for src, task in zip(chain, tasks):
                res = await task
                if res:
                    return res, src
            return None, None
        finally:
            for task in tasks:
                task.cancel()

    def failure_text(self, source: Optional[str], query: str, errs: Optional[list] = None) -> str:
        """Message for 'nothing found': names the real reason instead of a bare 'No results'."""
        why = self.platform_problem(source, query)
        if not why and errs:
            why = errs[0]
        return "No results found." + (f"\n{why}" if why else "")

    # kept for old callers
    def source_hint(self, source: Optional[str], query: str = "") -> str:
        why = self.platform_problem(source, query)
        return f"\n{why}" if why else ""

    # ---- core helpers ------------------------------------------------------
    async def ensure_player(self, ctx: commands.Context) -> Optional[wavelink.Player]:
        if not await self.wait_ready():
            await say(ctx, "Music is not available right now (Lavalink is not connected), try again in a few seconds.")
            return None
        target = ctx.author.voice.channel if ctx.author.voice else None
        if not target:
            await say(ctx, "You need to be in a voice channel to use this command.")
            return None
        async with self.locks[ctx.guild.id]:  # two quick /play calls must not connect twice
            vc = ctx.guild.voice_client
            if vc and vc.channel != target:
                await say(ctx, f"You must be connected to {vc.channel.mention} to use this.")
                return None
            if not vc:
                perms = target.permissions_for(ctx.guild.me)
                if not (perms.connect and perms.speak):
                    await say(ctx, f"I need `Connect` and `Speak` permissions in {target.mention}.")
                    return None
                try:
                    vc = await target.connect(cls=wavelink.Player, self_deaf=True)
                except (discord.ClientException, asyncio.TimeoutError):
                    await say(ctx, "I couldn't join that voice channel.")
                    return None
                except Exception:
                    log.exception("voice connect failed")
                    await say(ctx, "I couldn't join that voice channel.")
                    return None
                vc.autoplay = wavelink.AutoPlayMode.partial
            if not isinstance(vc, wavelink.Player):
                await say(ctx, "I'm already connected to voice with another module.")
                return None
            vc.home = ctx.channel
            return vc

    async def need_player(self, ctx: commands.Context, *, playing: bool = True) -> Optional[wavelink.Player]:
        vc = ctx.guild.voice_client
        if not isinstance(vc, wavelink.Player) or (playing and not vc.current):
            await say(ctx, "No song is currently playing." if playing else "I'm not connected to a voice channel.")
            return None
        if not ctx.author.voice or ctx.author.voice.channel != vc.channel:
            await say(ctx, "You need to be in the same voice channel as me to use this command.")
            return None
        return vc

    @staticmethod
    def _tag(track: wavelink.Playable, user_id: int) -> None:
        try:
            track.extras = {"requester": user_id}
        except Exception:
            pass

    async def enqueue(self, ctx: commands.Context, tracks: list,
                      player: Optional[wavelink.Player] = None) -> Optional[str]:
        """Queue tracks; start playback if idle. Returns 'started' | 'queued' | None."""
        player = player or await self.ensure_player(ctx)
        if not player:
            return None
        gid = ctx.guild.id
        async with self.locks[gid]:
            self._cancel_idle(gid)
            self.last_req[gid] = ctx.author.id
            for t in tracks:
                self._tag(t, ctx.author.id)
            await player.queue.put_wait(tracks)
            # never `get_wait()` here: it blocks forever (holding the lock) if
            # wavelink's autoplay already took the track from the queue.
            if not player.current and not player.queue.is_empty:
                await player.play(player.queue.get())
                return "started"
            return "queued"

    async def show_card(self, player: wavelink.Player, track: wavelink.Playable) -> None:
        channel = getattr(player, "home", None)
        if channel is None:
            return
        gid = player.guild.id
        uid = (getattr(getattr(track, "extras", None), "requester", None)
               or self.last_req.get(gid) or self.client.user.id)
        self.last_req[gid] = uid
        view = PlayerView(self, track, uid, autoplay=is_autoplay(player), loop=is_loop(player))
        old = self.cards.get(gid)
        if old is not None and channel.last_message_id == old.id:
            try:
                self.cards[gid] = await old.edit(view=view, allowed_mentions=NO_MENTIONS)
                return
            except discord.HTTPException:
                pass
        if old is not None:
            self.client.loop.create_task(self._safe_delete(old))
        for use_thumb in (True, False):
            view = PlayerView(self, track, uid, autoplay=is_autoplay(player),
                              loop=is_loop(player), use_thumb=use_thumb)
            try:
                self.cards[gid] = await channel.send(view=view, allowed_mentions=NO_MENTIONS)
                return
            except discord.Forbidden:
                return
            except discord.HTTPException:
                continue

    @staticmethod
    async def _safe_delete(message: discord.Message) -> None:
        try:
            await message.delete()
        except discord.HTTPException:
            pass

    async def notify(self, player: wavelink.Player, text: str, accent: bool = False) -> None:
        home = getattr(player, "home", None)
        if home is not None:
            try:
                await home.send(view=panel(text, accent), allowed_mentions=NO_MENTIONS)
            except discord.HTTPException:
                pass

    async def leave(self, player: wavelink.Player, text: str) -> None:
        self.cleanup(player.guild.id)
        try:
            await player.disconnect()
        except Exception:
            pass
        await self.notify(player, text, True)

    # ---- idle handling (debounced, replaces the old fixed sleep) -----------
    def _cancel_idle(self, gid: int) -> None:
        task = self.idle_tasks.pop(gid, None)
        if task:
            task.cancel()

    def _schedule_idle(self, player: wavelink.Player, delay: float,
                       text: str = "All tracks have been played, leaving the voice channel.") -> None:
        gid = player.guild.id
        self._cancel_idle(gid)
        self.idle_tasks[gid] = self.client.loop.create_task(self._idle_leave(player, delay, text))

    async def _idle_leave(self, player: wavelink.Player, delay: float, text: str) -> None:
        gid = player.guild.id
        try:
            await asyncio.sleep(delay)
        except asyncio.CancelledError:
            return
        self.idle_tasks.pop(gid, None)
        if player.guild.voice_client is not player or not player.connected:
            return
        if player.current or player.playing or not player.queue.is_empty:
            return
        if is_autoplay(player) or gid in self.stay:
            return
        await self.leave(player, text)

    # ---- failed-track fallback ---------------------------------------------
    @staticmethod
    def _similar(orig: wavelink.Playable, cand: wavelink.Playable) -> bool:
        if not orig.length or getattr(orig, "is_stream", False) or not cand.length:
            return True
        return abs(orig.length - cand.length) <= max(15_000, orig.length * 0.2)

    async def _try_fallback(self, player: wavelink.Player, track: wavelink.Playable) -> bool:
        gid = player.guild.id
        key = track.identifier or track.uri or track.title
        tried = self.tried[gid]
        if key in tried:
            return False
        if len(tried) > 200:
            tried.clear()
        tried.add(key)
        failed = TRACK_SOURCE_PREFIX.get(str(track.source or "").lower())
        query = f"{track.title} {track.author or ''}".strip()
        for src in FALLBACK_ORDER:
            if src == failed or not self.has_source(SEARCH_NEEDS[src]):
                continue
            res = await self._lookup(query, src)
            if not res or isinstance(res, wavelink.Playlist):
                continue
            cand = next((t for t in list(res)[:5] if self._similar(track, t)), None)
            if cand is None:
                continue
            requester = getattr(getattr(track, "extras", None), "requester", None) or self.last_req.get(gid)
            if requester:
                self._tag(cand, requester)
            async with self.locks[gid]:
                if player.current:
                    player.queue.put_at(0, cand)
                else:
                    await player.play(cand)
            name = PLATFORM_BY_PREFIX.get(src, src)
            await self.notify(player, f"Couldn't load **{track.title}**, playing it from {name} instead.", True)
            return True
        return False

    # ---- events ------------------------------------------------------------
    @commands.Cog.listener()
    async def on_wavelink_node_ready(self, payload: wavelink.NodeReadyEventPayload):
        log.info("Lavalink node %s ready (resumed=%s)", payload.node.identifier, payload.resumed)
        self._node_up.set()
        await self._diagnose(payload.node)
        if not payload.resumed:
            # fresh session (first start or Lavalink restarted): players the bot still holds have
            # no matching player on the node -> drop them, then bring 24/7 channels back
            for guild in list(self.client.guilds):
                vc = guild.voice_client
                if isinstance(vc, wavelink.Player) and guild.id in self.stay:
                    try:
                        self.cleanup(guild.id)
                        await vc.disconnect()
                    except Exception:
                        pass
            self.client.loop.create_task(self.restore_stay())

    @commands.Cog.listener()
    async def on_wavelink_track_start(self, payload: wavelink.TrackStartEventPayload):
        player = payload.player
        if not player or not player.guild:
            return
        self._cancel_idle(player.guild.id)
        track = payload.track
        # wavelink rebuilds `payload.track` from Lavalink's answer, which drops our `extras`
        # (requester). The object we queued is kept in `payload.original`.
        original = getattr(payload, "original", None)
        if original is not None and getattr(getattr(original, "extras", None), "requester", None):
            try:
                track.extras = {"requester": original.extras.requester}
            except Exception:
                pass
        hist = self.history.setdefault(player.guild.id, [])
        if not hist or hist[-1] != track:
            hist.append(track)
            del hist[:-15]
        await self.show_card(player, track)

    @commands.Cog.listener()
    async def on_wavelink_track_exception(self, payload: wavelink.TrackExceptionEventPayload):
        track = getattr(payload, "track", None)
        exc = getattr(payload, "exception", "")
        log.warning("track exception: %s - %s", getattr(track, "title", "?"), exc)
        player = getattr(payload, "player", None)
        if player is not None and getattr(player, "guild", None) is not None:
            if isinstance(exc, dict):  # {"message": ..., "severity": ..., "cause": ...}
                exc = f"{exc.get('message') or ''} {exc.get('cause') or ''}"
            self.last_exc[player.guild.id] = explain_load_error(Exception(str(exc)))

    @commands.Cog.listener()
    async def on_wavelink_track_end(self, payload: wavelink.TrackEndEventPayload):
        player = payload.player
        if not player or not player.guild or player.guild.voice_client is not player:
            return
        reason = str(getattr(payload, "reason", "") or "").replace("_", "").lower()
        track = payload.track
        if reason == "loadfailed" and track is not None:
            try:
                if await self._try_fallback(player, track):
                    return
            except Exception:
                log.exception("fallback failed")
            if player.current or not player.queue.is_empty:
                return  # something else is already playing / queued
            why = self.last_exc.pop(player.guild.id, None) or "the source refused or failed to load it"
            await self.notify(player, f"Couldn't play **{track.title}** ({why})")
            self._schedule_idle(player, FAIL_LEAVE_DELAY,
                                "Nothing more to play, leaving the voice channel.")
            return
        if reason in ("replaced", "stopped", "cleanup") and (player.current or reason == "replaced"):
            return
        # natural end: give wavelink a moment to start the next queued/autoplay track
        self._schedule_idle(player, IDLE_LEAVE_DELAY)

    @commands.Cog.listener()
    async def on_wavelink_track_stuck(self, payload: wavelink.TrackStuckEventPayload):
        try:
            await payload.player.skip(force=True)
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_wavelink_websocket_closed(self, payload: wavelink.WebsocketClosedEventPayload):
        player = payload.player
        code = getattr(payload, "code", None)
        log.warning("voice websocket closed: code=%s reason=%s", code, getattr(payload, "reason", ""))
        if not player or not player.guild:
            return
        if code == 4017:  # Discord requires DAVE (E2EE); node is too old
            await self.notify(player, "Discord rejected the voice connection (DAVE / E2EE required). "
                                      "The Lavalink node must be **v4.2.0 or newer**.")
            self.cleanup(player.guild.id)
            try:
                await player.disconnect()
            except Exception:
                pass
        elif code == 4014:  # kicked / channel deleted
            self.cleanup(player.guild.id)

    @commands.Cog.listener()
    async def on_voice_state_update(self, member: discord.Member, before, after):
        guild = member.guild
        vc = guild.voice_client
        if not isinstance(vc, wavelink.Player) or not vc.channel:
            if member.id == self.client.user.id and after.channel is None:
                self.cleanup(guild.id)
            return
        if any(not m.bot for m in vc.channel.members):
            task = self.alone_tasks.pop(guild.id, None)
            if task:
                task.cancel()
            return
        if guild.id in self.stay or guild.id in self.alone_tasks:
            return
        self.alone_tasks[guild.id] = self.client.loop.create_task(self._alone_leave(guild.id))

    async def _alone_leave(self, guild_id: int) -> None:
        try:
            await asyncio.sleep(120)
        except asyncio.CancelledError:
            return
        self.alone_tasks.pop(guild_id, None)
        guild = self.client.get_guild(guild_id)
        vc = guild.voice_client if guild else None
        if isinstance(vc, wavelink.Player) and vc.channel and not any(not m.bot for m in vc.channel.members):
            await self.leave(vc, "Left the voice channel because nobody was listening for 2 minutes.")

    # ---- commands ----------------------------------------------------------
    @commands.hybrid_command(name="247", help="Keeps the bot in your voice channel 24/7.")
    @guarded
    async def twenty_four_seven(self, ctx: commands.Context):
        gid = ctx.guild.id
        if gid in self.stay:
            self.stay.pop(gid)
            self._save_stay()
            return await say(ctx, f"24/7 mode disabled by {ctx.author.mention}.", True)
        player = await self.ensure_player(ctx)
        if not player:
            return
        self.stay[gid] = {"voice": player.channel.id, "text": ctx.channel.id}
        self._save_stay()
        await say(ctx, f"24/7 mode enabled by {ctx.author.mention}. I will stay in {player.channel.mention}.", True)

    @commands.hybrid_command(name="play", aliases=["p"], usage="play <query | url>",
                             help='Play a song or playlist.')
    @guarded
    async def play(self, ctx: commands.Context, *, query: str):
        if ctx.interaction:
            await ctx.defer()
        if not ctx.author.voice:
            return await say(ctx, "You need to be in a voice channel to use this command.")
        text, source = split_prefix(query.strip().strip("<>"))
        text = re.sub(r'^(https?://)(?:music|m)\.youtube\.com', r'\1www.youtube.com', text)
        if not text:
            return await say(ctx, "Please tell me what to play.")
        if not await self.wait_ready():
            return await say(ctx, "Music is not available right now (Lavalink is not connected), try again in a few seconds.")
        had_vc = ctx.guild.voice_client is not None
        errs: list[str] = []
        # join the VC and search at the same time (the slowest two steps run in parallel)
        join = asyncio.create_task(self.ensure_player(ctx))
        try:
            if source:
                results, used = await self._lookup(text, source, errs), source
            else:
                results, used = await self.search_chain(text, errs)
        except BaseException:
            join.cancel()
            raise
        player = await join
        if not player:
            return
        if not results:
            if not had_vc and not player.current and player.queue.is_empty and ctx.guild.id not in self.stay:
                self.cleanup(ctx.guild.id)
                try:
                    await player.disconnect()
                except Exception:
                    pass
            return await say(ctx, self.failure_text(used, text, errs))
        if isinstance(results, wavelink.Playlist):
            tracks = list(results.tracks)[:MAX_PLAYLIST]
            if not await self.enqueue(ctx, tracks, player):
                return
            return await say(ctx, f"Added playlist **{results.name}** with **{len(tracks)} songs** to the queue.", True)
        track = results[0]
        state = await self.enqueue(ctx, [track], player)
        if state == "queued":
            await say(ctx, f"Added [{track.title}]({track.uri}) to the queue.", True)

    @commands.hybrid_command(name="search", usage="search <query>", help="Searches music from multiple platforms.")
    @guarded
    async def search_cmd(self, ctx: commands.Context, *, query: str):
        if ctx.interaction:
            await ctx.defer()
        if not ctx.author.voice:
            return await say(ctx, "You need to be in a voice channel to use this command.")
        text, source = split_prefix(query.strip())
        errs: list[str] = []
        if source:
            results, used = await self._lookup(text, source, errs), source
        else:
            results, used = await self.search_chain(text, errs)
        if not results or isinstance(results, wavelink.Playlist):
            return await say(ctx, self.failure_text(used, text, errs))
        platform = PLATFORM_BY_PREFIX.get(used or "ytsearch", "YouTube")
        view = SearchView(self, ctx, text, platform, list(results))
        view.message = await ctx.send(view=view, allowed_mentions=NO_MENTIONS)

    @commands.hybrid_command(name="platforms", aliases=["sources"], usage="platforms",
                             help="Shows which music platforms the Lavalink node supports right now.")
    @guarded
    async def platforms(self, ctx: commands.Context):
        if not self.node_ready():
            return await say(ctx, "Music is not available right now, try again later.")
        if not self.node_sources:
            return await say(ctx, "The node did not report its sources yet; every platform will be tried.")
        yes, no = "<:emoji_4:1566043104551768114>", "<a:emoji_38:1567096105299214336>"
        short = {v: k for k, v in QUERY_PREFIXES.items()}   # 'spsearch' -> 'sp:'
        lines = []
        for name, pre in SEARCH_SOURCES.items():
            mark = yes if self.has_source(SEARCH_NEEDS[pre]) else no
            lines.append(f"{mark} **{name}** (`{short.get(pre, pre)}`)")
        extra = [n for n, k in (("Bandcamp", "bandcamp"), ("Twitch", "twitch"), ("Vimeo", "vimeo"),
                                ("Direct links / radio", "http")) if self.has_source(k)]
        text = "### Music platforms\n" + "\n".join(lines)
        if extra:
            text += f"\n{yes} " + ", ".join(extra) + " (links only)"
        text += f"\n-# Lavalink {self.node_version or '?'} | `play <name>` or `play <prefix> <name>` or paste a link"
        await say(ctx, text, True)

    @commands.hybrid_command(name="loop", usage="loop", help="Toggles loop mode.")
    @guarded
    async def loop(self, ctx: commands.Context):
        p = await self.need_player(ctx)
        if not p:
            return
        p.queue.mode = wavelink.QueueMode.normal if is_loop(p) else wavelink.QueueMode.loop
        await say(ctx, f"Loop {'enabled' if is_loop(p) else 'disabled'} by {ctx.author.mention}.", True)

    @commands.hybrid_command(name="autoplay", usage="autoplay", help="Toggles autoplay mode.")
    @guarded
    async def autoplay(self, ctx: commands.Context):
        p = await self.need_player(ctx)
        if not p:
            return
        p.autoplay = wavelink.AutoPlayMode.partial if is_autoplay(p) else wavelink.AutoPlayMode.enabled
        await say(ctx, f"Autoplay {'enabled' if is_autoplay(p) else 'disabled'} by {ctx.author.mention}.", True)

    @commands.hybrid_command(name="nowplaying", aliases=["nop"], usage="nowplaying", help="Shows the info about the current song.")
    @guarded
    async def nowplaying(self, ctx: commands.Context):
        p = await self.need_player(ctx)
        if not p:
            return
        t = p.current
        total = max(t.length, 1)
        filled = min(10, int(10 * p.position / total))
        bar = "\u25ac" * filled + "\U0001f518" + "\u25ac" * (10 - filled)
        thumb = thumb_of(t)
        text = (f"### [Now Playing]({t.uri})\n\n**[{t.title}]({t.uri})** - {t.author}\n"
                f"`{fmt_ms(p.position)}` {bar} `{fmt_ms(t.length)}`\n"
                f"Queue: `{len(p.queue)}` song(s)")
        box = discord.ui.Container(accent_colour=PINK)
        body = discord.ui.TextDisplay(text[:3900])
        box.add_item(discord.ui.Section(body, accessory=discord.ui.Thumbnail(media=thumb)) if thumb else body)
        view = discord.ui.LayoutView(timeout=None)
        view.add_item(box)
        try:
            await ctx.send(view=view, allowed_mentions=NO_MENTIONS)
        except discord.HTTPException:
            await say(ctx, f"Now playing: [{t.title}]({t.uri})", True)

    @commands.hybrid_command(name="shuffle", usage="shuffle", help="Shuffles the queue.")
    @guarded
    async def shuffle(self, ctx: commands.Context):
        p = await self.need_player(ctx)
        if not p:
            return
        if p.queue.is_empty:
            return await say(ctx, "Queue is empty.")
        p.queue.shuffle()
        await say(ctx, f"Queue shuffled by {ctx.author.mention}.", True)

    @commands.hybrid_command(name="stop", usage="stop", help="Stops the music, clears the queue and leaves.")
    @guarded
    async def stop(self, ctx: commands.Context):
        p = await self.need_player(ctx, playing=False)
        if not p:
            return
        await self.halt(p)
        await say(ctx, f"Stopped and queue cleared by {ctx.author.mention}.", True)

    @commands.hybrid_command(name="skip", usage="skip", help="Skips the current song.")
    @guarded
    async def skip(self, ctx: commands.Context):
        p = await self.need_player(ctx)
        if not p:
            return
        if is_loop(p):
            p.queue.mode = wavelink.QueueMode.normal
        await p.skip(force=True)
        await say(ctx, f"Skipped by {ctx.author.mention}.", True)

    @commands.hybrid_command(name="seek", usage="seek <percentage>", help="Seeks to a percentage of the song.")
    @guarded
    async def seek(self, ctx: commands.Context, percentage: int):
        if not 1 <= percentage <= 100:
            return await say(ctx, "Please provide a percentage between 1 and 100.")
        p = await self.need_player(ctx)
        if not p:
            return
        if getattr(p.current, "is_stream", False) or not getattr(p.current, "is_seekable", True):
            return await say(ctx, "This track can't be seeked.")
        await p.seek(int(p.current.length * percentage / 100))
        await say(ctx, f"Seeked to {percentage}% of the current track.", True)

    @commands.hybrid_command(name="join", aliases=["connect"], usage="join", help="Joins your voice channel.")
    @guarded
    async def join(self, ctx: commands.Context):
        p = await self.ensure_player(ctx)
        if p:
            await say(ctx, f"Joined {p.channel.mention}.", True)

    @commands.hybrid_command(name="disconnect", aliases=["dc", "leave"], usage="disconnect", help="Disconnects the bot from the voice channel.")
    @guarded
    async def disconnect(self, ctx: commands.Context):
        p = await self.need_player(ctx, playing=False)
        if not p:
            return
        self.stay.pop(ctx.guild.id, None)
        self._save_stay()
        self.cleanup(ctx.guild.id)
        await p.disconnect()
        await say(ctx, "Disconnected from the voice channel.", True)

    @commands.hybrid_command(name="replay", usage="replay", help="Replays the current song.")
    @guarded
    async def replay(self, ctx: commands.Context):
        p = await self.need_player(ctx)
        if not p:
            return
        if not getattr(p.current, "is_seekable", True):
            return await say(ctx, "This track can't be replayed.")
        await p.seek(0)
        await say(ctx, "Replaying the current track.", True)

    @commands.hybrid_command(name="queue", usage="queue", help="Shows the current queue.")
    @guarded
    async def queue(self, ctx: commands.Context):
        p = await self.need_player(ctx, playing=False)
        if not p:
            return
        if p.queue.is_empty:
            return await say(ctx, "The queue is currently empty.")
        entries = [f"`{n}.` [{t.title[:70]}]({t.uri}) - {t.author[:30]}" for n, t in enumerate(p.queue, 1)]
        view = QueueView(ctx, f"Queue ({len(entries)} songs)", entries, per_page=10, accent=PINK.value)
        view.message = await ctx.send(view=view, allowed_mentions=NO_MENTIONS)

    @commands.hybrid_command(name="clearqueue", usage="clearqueue", help="Clears the queue.")
    @guarded
    async def clearqueue(self, ctx: commands.Context):
        p = await self.need_player(ctx, playing=False)
        if not p:
            return
        if p.queue.is_empty:
            return await say(ctx, "No queue to clear.")
        p.queue.clear()
        await say(ctx, "Queue has been cleared.", True)

    @commands.hybrid_command(name="pause", usage="pause", help="Pauses the current song.")
    @guarded
    async def pause(self, ctx: commands.Context):
        p = await self.need_player(ctx)
        if not p:
            return
        if p.paused:
            return await say(ctx, "The player is already paused.")
        await p.pause(True)
        await say(ctx, f"Paused by {ctx.author.mention}.", True)

    @commands.hybrid_command(name="resume", usage="resume", help="Resumes the paused song.")
    @guarded
    async def resume(self, ctx: commands.Context):
        p = await self.need_player(ctx)
        if not p:
            return
        if not p.paused:
            return await say(ctx, "The player is not paused.")
        await p.pause(False)
        await say(ctx, f"Resumed by {ctx.author.mention}.", True)

    @commands.hybrid_command(name="volume", aliases=["vol"], usage="volume [level]", help="Sets the volume (1-150).")
    @guarded
    async def volume(self, ctx: commands.Context, level: Optional[int] = None):
        p = await self.need_player(ctx, playing=False)
        if not p:
            return
        if level is None:
            return await say(ctx, f"Current volume is {p.volume}%.")
        if not 1 <= level <= 150:
            return await say(ctx, "Volume must be between 1 and 150.")
        await p.set_volume(level)
        await say(ctx, f"Volume set to {level}% by {ctx.author.mention}.", True)

    # ---- filters -----------------------------------------------------------
    @commands.hybrid_group(name="filter", invoke_without_command=True, help="Audio filters for the player.")
    @guarded
    async def filter(self, ctx: commands.Context):
        await say(ctx, f"Use `{ctx.clean_prefix}filter enable` to pick a filter or "
                       f"`{ctx.clean_prefix}filter disable` to remove it.")

    @filter.command(name="enable", help="Enable a filter.")
    @guarded
    async def filter_enable(self, ctx: commands.Context):
        if not await self.need_player(ctx):
            return
        view = FilterView(self, ctx)
        await ctx.send(view=view, allowed_mentions=NO_MENTIONS)

    @filter.command(name="disable", help="Disable the current filter.")
    @guarded
    async def filter_disable(self, ctx: commands.Context):
        p = await self.need_player(ctx)
        if not p:
            return
        await p.set_filters(wavelink.Filters(), seek=True)
        self.active_filters.pop(ctx.guild.id, None)
        await say(ctx, "Filter disabled.", True)
