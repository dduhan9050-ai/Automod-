"""Nightmode (V40) - strips dangerous permissions from every role below the bot, restores them exactly.

  * enable [30m|8h|1d]   strip dangerous perms from all manageable roles (incl. @everyone) - edits run in PARALLEL
  * disable              give back exactly the bits that were stripped (changes made meanwhile are kept)
  * status               state, timer, schedule, stripped / exempt roles
  * exempt add/remove/list <role>
  * schedule set <start> <end> [utc offset] / off / view   (daily automatic nightmode)
  * while ON: a role that gets (or is created with) a dangerous permission is stripped again instantly
The bot's own edits are ignored by antinuke, so nothing has to be paused while this runs.
"""
import asyncio
import os
import re
import time
from datetime import datetime, timedelta, timezone

import aiosqlite
import discord
from discord.ext import commands, tasks

from utils.Tools import *
from utils.config import OWNER_IDS

DB_PATH = os.path.join("db", "anti.db")

DANGER_NAMES = ("administrator", "manage_guild", "manage_roles", "manage_channels", "ban_members", "kick_members",
                "manage_webhooks", "mention_everyone", "moderate_members", "manage_expressions",
                "manage_emojis_and_stickers")


def _danger_mask() -> int:
    bits, seen = 0, set()
    for name in DANGER_NAMES:
        if name in discord.Permissions.VALID_FLAGS:
            v = discord.Permissions(**{name: True}).value
            if v not in seen:
                seen.add(v)
                bits |= v
    return bits


DANGER = _danger_mask()
SEM = 6          # parallel role edits


def parse_duration(text):
    m = re.fullmatch(r"(\d+)\s*([smhd])", (text or "").strip().lower())
    if not m:
        return None
    secs = int(m.group(1)) * {"s": 1, "m": 60, "h": 3600, "d": 86400}[m.group(2)]
    return secs if 60 <= secs <= 30 * 86400 else None


def parse_clock(text):
    m = re.fullmatch(r"([01]?\d|2[0-3]):([0-5]\d)", (text or "").strip())
    return (int(m.group(1)) * 60 + int(m.group(2))) if m else None


def parse_offset(text):
    m = re.fullmatch(r"(?:utc|gmt)?\s*([+-])(\d{1,2})(?::?([0-5]\d))?", (text or "").strip().lower())
    if not m:
        return None
    mins = int(m.group(2)) * 60 + int(m.group(3) or 0)
    return -mins if m.group(1) == "-" else mins


def fmt_clock(mins):
    return f"{mins // 60:02d}:{mins % 60:02d}"


NO_PING = discord.AllowedMentions.none()


class Nightmode(commands.Cog):

    def __init__(self, bot):
        self.bot = bot
        self.db = None
        self.color = 0x000000
        self.bot_owners = list(OWNER_IDS)
        self.active = {}      # guild -> {"until": ts|None, "sched": bool}
        self.exempt = {}      # guild -> set(role ids)
        self.sched = {}       # guild -> (start_min, end_min, utc_offset_min)
        self._locks = {}
        self._ready = asyncio.Event()

    # ------------------------------------------------------------------ storage
    async def cog_load(self):
        self.db = await aiosqlite.connect(DB_PATH)
        await self.db.executescript('''
            CREATE TABLE IF NOT EXISTS Nightmode (guildId TEXT, roleId TEXT, adminPermissions INTEGER);
            CREATE TABLE IF NOT EXISTS extraowners (guild_id INTEGER, owner_id INTEGER, PRIMARY KEY (guild_id, owner_id));
            CREATE TABLE IF NOT EXISTS nm_roles (guildId INTEGER, roleId INTEGER, stripped INTEGER,
                                                 PRIMARY KEY (guildId, roleId));
            CREATE TABLE IF NOT EXISTS nm_state (guildId INTEGER PRIMARY KEY, active INTEGER DEFAULT 0,
                                                 until REAL, by_sched INTEGER DEFAULT 0,
                                                 s_start INTEGER, s_end INTEGER, s_off INTEGER DEFAULT 0);
            CREATE TABLE IF NOT EXISTS nm_exempt (guildId INTEGER, roleId INTEGER, PRIMARY KEY (guildId, roleId));
        ''')
        await self.db.commit()
        async with self.db.execute("SELECT guildId, active, until, by_sched, s_start, s_end, s_off FROM nm_state") as c:
            for gid, act, until, bs, s1, s2, off in await c.fetchall():
                if act:
                    self.active[gid] = {"until": until, "sched": bool(bs)}
                if s1 is not None and s2 is not None:
                    self.sched[gid] = (s1, s2, off or 0)
        async with self.db.execute("SELECT guildId, roleId FROM nm_exempt") as c:
            for gid, rid in await c.fetchall():
                self.exempt.setdefault(gid, set()).add(rid)
        async with self.db.execute("SELECT DISTINCT guildId FROM Nightmode") as c:     # servers using the OLD nightmode
            for (gid,) in await c.fetchall():
                self.active.setdefault(int(gid), {"until": None, "sched": False})
        self._ready.set()
        self.clock.start()

    async def cog_unload(self):
        self.clock.cancel()
        if self.db:
            await self.db.close()

    async def _save_state(self, gid):
        st, sc = self.active.get(gid), self.sched.get(gid)
        await self.db.execute(
            "INSERT OR REPLACE INTO nm_state (guildId, active, until, by_sched, s_start, s_end, s_off) VALUES (?,?,?,?,?,?,?)",
            (gid, 1 if st else 0, st["until"] if st else None, 1 if st and st["sched"] else 0,
             sc[0] if sc else None, sc[1] if sc else None, sc[2] if sc else 0))
        await self.db.commit()

    def _lock(self, gid):
        return self._locks.setdefault(gid, asyncio.Lock())

    # ------------------------------------------------------------------ helpers
    async def is_extra_owner(self, user, guild):
        from utils.permit_store import store
        return await store.is_extraowner(guild.id, user.id)

    async def _allowed(self, ctx):
        if ctx.author.id == ctx.guild.owner_id or ctx.author.id in self.bot_owners:
            return True
        if await self.is_extra_owner(ctx.author, ctx.guild):
            return True
        await ctx.send(embed=discord.Embed(title="<:icons_warning:1327829522573430864> Access Denied", color=self.color,
                                           description="Only the **Server Owner** or an **Extraowner** can use this command."))
        return False

    def _ok(self, text, title="<:emoji_4:1566043104551768114> Success"):
        return discord.Embed(title=title, description=text, color=self.color)

    def _err(self, text, title="<:CrossIcon:1327829124894429235> Error"):
        return discord.Embed(title=title, description=text, color=self.color)

    # ------------------------------------------------------------------ core
    def _targets(self, guild):
        top, ex = guild.me.top_role, self.exempt.get(guild.id, ())
        out = []
        for r in guild.roles:
            if r.managed or r.id in ex:
                continue
            if not r.is_default() and r >= top:
                continue
            if r.permissions.value & DANGER:
                out.append(r)
        return out

    async def activate(self, guild, *, until=None, by_sched=False, reason="Nightmode ENABLED"):
        """-> (stripped roles, failed roles); every edit runs in parallel."""
        async with self._lock(guild.id):
            sem, done, failed = asyncio.Semaphore(SEM), [], []

            async def one(role):
                bits = role.permissions.value & DANGER
                async with sem:
                    try:
                        await role.edit(permissions=discord.Permissions(role.permissions.value & ~DANGER), reason=reason)
                        done.append((role, bits))
                    except (discord.Forbidden, discord.HTTPException):
                        failed.append(role)

            await asyncio.gather(*(one(r) for r in self._targets(guild)))
            if done:
                await self.db.executemany(
                    "INSERT INTO nm_roles (guildId, roleId, stripped) VALUES (?,?,?) "
                    "ON CONFLICT(guildId, roleId) DO UPDATE SET stripped = stripped | excluded.stripped",
                    [(guild.id, r.id, bits) for r, bits in done])
            self.active[guild.id] = {"until": until, "sched": by_sched}
            await self._save_state(guild.id)
            return [r for r, _ in done], failed

    async def deactivate(self, guild, reason="Nightmode DISABLED"):
        """-> (restored roles, failed roles); gives back exactly the stripped bits."""
        async with self._lock(guild.id):
            async with self.db.execute("SELECT roleId, stripped FROM nm_roles WHERE guildId = ?", (guild.id,)) as c:
                rows = await c.fetchall()
            async with self.db.execute("SELECT roleId FROM Nightmode WHERE guildId = ?", (str(guild.id),)) as c:
                legacy = [int(r[0]) for r in await c.fetchall()]
            sem, done, failed = asyncio.Semaphore(SEM), [], []

            async def one(rid, bits):
                role = guild.get_role(rid)
                if role is None:
                    return
                async with sem:
                    try:
                        await role.edit(permissions=discord.Permissions(role.permissions.value | bits), reason=reason)
                        done.append(role)
                    except (discord.Forbidden, discord.HTTPException):
                        failed.append(role)

            admin_bit = discord.Permissions(administrator=True).value
            known = {r for r, _ in rows}
            await asyncio.gather(*([one(rid, bits) for rid, bits in rows] +
                                   [one(rid, admin_bit) for rid in legacy if rid not in known]))
            await self.db.execute("DELETE FROM nm_roles WHERE guildId = ?", (guild.id,))
            await self.db.execute("DELETE FROM Nightmode WHERE guildId = ?", (str(guild.id),))
            self.active.pop(guild.id, None)
            await self._save_state(guild.id)
            return done, failed

    async def _announce(self, guild, text):
        try:
            from utils import antinuke_store as store
            cfg = store.peek(guild.id)
            ch = guild.get_channel(cfg.log) if cfg and cfg.log else None
            if ch:
                await ch.send(embed=discord.Embed(description=text, color=self.color))
        except Exception:
            pass

    # ------------------------------------------------------------------ keep it on
    @commands.Cog.listener()
    async def on_guild_role_update(self, before, after):
        if after.guild.id not in self.active or after.managed:
            return
        if not after.permissions.value & DANGER or after.id in self.exempt.get(after.guild.id, ()):
            return
        me = after.guild.me
        if me is None or (not after.is_default() and after >= me.top_role):
            return
        try:
            await after.edit(permissions=discord.Permissions(after.permissions.value & ~DANGER),
                             reason="Nightmode: dangerous permission blocked")
        except (discord.Forbidden, discord.HTTPException):
            pass

    @commands.Cog.listener()
    async def on_guild_role_create(self, role):
        if role.guild.id in self.active:
            await self.on_guild_role_update(role, role)

    # ------------------------------------------------------------------ timer + schedule
    @tasks.loop(seconds=20)
    async def clock(self):
        now = time.time()
        for gid, st in list(self.active.items()):
            if st["until"] and now >= st["until"]:
                guild = self.bot.get_guild(gid)
                if guild:
                    try:
                        await self.deactivate(guild, "Nightmode timer ended")
                        await self._announce(guild, "Nightmode timer ended - permissions restored.")
                    except Exception:
                        pass
        for gid, (s1, s2, off) in list(self.sched.items()):
            guild = self.bot.get_guild(gid)
            if guild is None:
                continue
            local = datetime.now(timezone.utc) + timedelta(minutes=off)
            m = local.hour * 60 + local.minute
            inside = (s1 <= m < s2) if s1 < s2 else (m >= s1 or m < s2)
            st = self.active.get(gid)
            try:
                if inside and st is None:
                    await self.activate(guild, by_sched=True, reason="Nightmode schedule started")
                    await self._announce(guild, "Scheduled nightmode started.")
                elif not inside and st is not None and st["sched"]:
                    await self.deactivate(guild, "Nightmode schedule ended")
                    await self._announce(guild, "Scheduled nightmode ended - permissions restored.")
            except Exception:
                pass

    @clock.before_loop
    async def _before_clock(self):
        await self.bot.wait_until_ready()
        await self._ready.wait()

    # ------------------------------------------------------------------ commands
    @commands.hybrid_group(name="nightmode", aliases=["nm"], help="Manages Nightmode feature", invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.guild_only()
    async def nightmode(self, ctx):
        p = ctx.clean_prefix
        e = discord.Embed(
            title='__**Nightmode**__', color=self.color,
            description=('Nightmode instantly strips dangerous permissions (Administrator, Manage Roles/Channels/Server/Webhooks, '
                         'Ban, Kick, Timeout, @everyone ...) from every role below me and gives them back **exactly** on disable.\n\n'
                         '**Keep my ROLE above all roles you want to protect.**'))
        e.add_field(name="Usage", inline=False, value=(
            f"`{p}nightmode enable [30m|8h|1d]`\n`{p}nightmode disable`\n`{p}nightmode status`\n"
            f"`{p}nightmode exempt add/remove/list <role>`\n"
            f"`{p}nightmode schedule set <start> <end> [utc offset]`\n`{p}nightmode schedule off` / `view`"))
        e.set_thumbnail(url=self.bot.user.display_avatar.url)
        await ctx.send(embed=e)

    @nightmode.command(name="enable", help="Enable nightmode (optional timer like 30m, 8h, 1d)")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 10, commands.BucketType.guild)
    @commands.bot_has_permissions(manage_roles=True)
    @commands.guild_only()
    async def enable_nightmode(self, ctx, duration: str = None):
        if not await self._allowed(ctx):
            return
        until = None
        if duration:
            secs = parse_duration(duration)
            if secs is None:
                return await ctx.send(embed=self._err("Invalid time. Use `30m`, `8h` or `1d` (1 minute - 30 days)."))
            until = time.time() + secs
        if ctx.guild.id in self.active:
            return await ctx.send(embed=self._err("Nightmode is already enabled."))
        if not self._targets(ctx.guild):
            return await ctx.send(embed=self._err("No manageable roles with dangerous permissions were found."))
        msg = await ctx.send(embed=self._ok("Enabling nightmode ...", "Please wait"))
        t = time.perf_counter()
        done, failed = await self.activate(ctx.guild, until=until)
        text = f"Stripped dangerous permissions from **{len(done)}** role(s) in `{time.perf_counter() - t:.1f}s`."
        if until:
            text += f"\nAuto-disable: <t:{int(until)}:R>"
        if failed:
            text += f"\n\n<:icons_warning:1327829522573430864> Could not edit: {' '.join(r.mention for r in failed[:15])}"
        await msg.edit(embed=self._ok(text))

    @nightmode.command(name="disable", help="Disable nightmode and restore permissions")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 10, commands.BucketType.guild)
    @commands.bot_has_permissions(manage_roles=True)
    @commands.guild_only()
    async def disable_nightmode(self, ctx):
        if not await self._allowed(ctx):
            return
        if ctx.guild.id not in self.active:
            return await ctx.send(embed=self._err("Nightmode is not enabled."))
        msg = await ctx.send(embed=self._ok("Restoring permissions ...", "Please wait"))
        done, failed = await self.deactivate(ctx.guild)
        text = f"Restored permissions on **{len(done)}** role(s)."
        if failed:
            text += f"\n\n<:icons_warning:1327829522573430864> Could not edit: {' '.join(r.mention for r in failed[:15])}"
        await msg.edit(embed=self._ok(text))

    @nightmode.command(name="status", aliases=["config", "info"], help="Show nightmode status")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def status_nightmode(self, ctx):
        gid = ctx.guild.id
        st = self.active.get(gid)
        e = discord.Embed(title="Nightmode Status", color=self.color)
        e.add_field(name="State", value="<:emoji_4:1566043104551768114> **ON**" if st else "<a:cross:1567096105299214336> **OFF**")
        if st and st["until"]:
            e.add_field(name="Auto disable", value=f"<t:{int(st['until'])}:R>")
        if st and st["sched"]:
            e.add_field(name="Started by", value="Schedule")
        async with self.db.execute("SELECT COUNT(*) FROM nm_roles WHERE guildId = ?", (gid,)) as c:
            n = (await c.fetchone())[0]
        e.add_field(name="Roles stripped", value=f"`{n}`")
        sc = self.sched.get(gid)
        e.add_field(name="Schedule", inline=False,
                    value=(f"`{fmt_clock(sc[0])}` -> `{fmt_clock(sc[1])}` (UTC{sc[2] / 60:+g})" if sc else "Off"))
        ex = self.exempt.get(gid)
        e.add_field(name="Exempt roles", inline=False, value=(" ".join(f"<@&{r}>" for r in ex) if ex else "None"))
        await ctx.send(embed=e, allowed_mentions=NO_PING)

    # ---- exempt roles
    @nightmode.group(name="exempt", aliases=["ignore", "whitelist"], help="Roles that nightmode never touches",
                     invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def nm_exempt(self, ctx):
        await ctx.send(embed=self._err(f"Use `{ctx.clean_prefix}nightmode exempt add/remove/list <role>`", "Exempt roles"))

    @nm_exempt.command(name="add", help="Never touch this role")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def nm_exempt_add(self, ctx, role: discord.Role):
        if not await self._allowed(ctx):
            return
        self.exempt.setdefault(ctx.guild.id, set()).add(role.id)
        await self.db.execute("INSERT OR IGNORE INTO nm_exempt (guildId, roleId) VALUES (?,?)", (ctx.guild.id, role.id))
        await self.db.commit()
        await ctx.send(embed=self._ok(f"{role.mention} is now exempt from nightmode."), allowed_mentions=NO_PING)

    @nm_exempt.command(name="remove", help="Protect this role again")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def nm_exempt_remove(self, ctx, role: discord.Role):
        if not await self._allowed(ctx):
            return
        self.exempt.get(ctx.guild.id, set()).discard(role.id)
        await self.db.execute("DELETE FROM nm_exempt WHERE guildId = ? AND roleId = ?", (ctx.guild.id, role.id))
        await self.db.commit()
        await ctx.send(embed=self._ok(f"{role.mention} is no longer exempt."), allowed_mentions=NO_PING)

    @nm_exempt.command(name="list", aliases=["show"], help="Show exempt roles")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def nm_exempt_list(self, ctx):
        ex = self.exempt.get(ctx.guild.id)
        await ctx.send(embed=self._ok("\n".join(f"<@&{r}>" for r in ex) if ex else "No exempt roles.", "Exempt roles"),
                       allowed_mentions=NO_PING)

    # ---- schedule
    @nightmode.group(name="schedule", aliases=["timer", "auto"], help="Daily automatic nightmode", invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def nm_schedule(self, ctx):
        await ctx.invoke(self.nm_schedule_view)

    @nm_schedule.command(name="set", help="nightmode schedule set 23:00 07:00 +5:30")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def nm_schedule_set(self, ctx, start: str, end: str, utc_offset: str = "+0"):
        if not await self._allowed(ctx):
            return
        s1, s2, off = parse_clock(start), parse_clock(end), parse_offset(utc_offset)
        if s1 is None or s2 is None or off is None or s1 == s2:
            return await ctx.send(embed=self._err(
                f"Example: `{ctx.clean_prefix}nightmode schedule set 23:00 07:00 +5:30` (24h clock, UTC offset)."))
        self.sched[ctx.guild.id] = (s1, s2, off)
        await self._save_state(ctx.guild.id)
        await ctx.send(embed=self._ok(f"Nightmode will run daily from `{fmt_clock(s1)}` to `{fmt_clock(s2)}` (UTC{off / 60:+g})."))

    @nm_schedule.command(name="off", aliases=["disable", "remove"], help="Turn the schedule off")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def nm_schedule_off(self, ctx):
        if not await self._allowed(ctx):
            return
        self.sched.pop(ctx.guild.id, None)
        await self._save_state(ctx.guild.id)
        await ctx.send(embed=self._ok("Nightmode schedule removed."))

    @nm_schedule.command(name="view", aliases=["show"], help="Show the schedule")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def nm_schedule_view(self, ctx):
        sc = self.sched.get(ctx.guild.id)
        await ctx.send(embed=self._ok(
            f"`{fmt_clock(sc[0])}` -> `{fmt_clock(sc[1])}` (UTC{sc[2] / 60:+g})" if sc else "No schedule set.", "Nightmode schedule"))


"""
@Author: Sonu Jana
    + Discord: me.sonu
    + Community: https://discord.gg/cfYmz4634n (Death Development)
    + for any queries reach out Community or DM me.
"""
