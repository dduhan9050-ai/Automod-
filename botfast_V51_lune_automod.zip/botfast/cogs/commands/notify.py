import discord
from discord.ext import commands
import aiosqlite
from utils.Tools import *

class NotifCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db_path = "db/notify.db"
        self.loop_task = self.bot.loop.create_task(self.setup_db())

    async def setup_db(self):
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute('''CREATE TABLE IF NOT EXISTS notifications (
                                id INTEGER PRIMARY KEY AUTOINCREMENT,
                                type TEXT NOT NULL UNIQUE,
                                role_id INTEGER NOT NULL,
                                channel_id INTEGER NOT NULL)''')
            await db.commit()

    @commands.group(invoke_without_command=True)
    async def setnotif(self, ctx):
        embed = discord.Embed(title="Notification Commands", color=0x000000)
        embed.add_field(name="Subcommands", value="twitch, youtube, list, reset")
        await ctx.send(embed=embed)

    @setnotif.command()
    @blacklist_check()
    @ignore_check()
    @commands.has_permissions(administrator=True)
    async def twitch(self, ctx, role: discord.Role, channel: discord.TextChannel):
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute('SELECT * FROM notifications WHERE type = ?', ('twitch',)) as existing:
                row = await existing.fetchone()
                if row:
                    await ctx.reply(embed=discord.Embed(title="<:icons_warning:1327829522573430864>Access Denied", description="Twitch notification already set. Remove it first.", color=0x000000))
                    return

            await db.execute('INSERT INTO notifications (type, role_id, channel_id) VALUES (?, ?, ?)', ('twitch', role.id, channel.id))
            await db.commit()
            self._notif_cache = {}
            await ctx.reply(embed=discord.Embed(title="<:emoji_4:1566043104551768114> Success", description=f"Twitch notifications set for {role.mention} in {channel.mention}.", color=0x000000))

    @setnotif.command()
    @blacklist_check()
    @ignore_check()
    @commands.has_permissions(administrator=True)
    async def youtube(self, ctx, role: discord.Role, channel: discord.TextChannel):
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute('SELECT * FROM notifications WHERE type = ?', ('youtube',)) as existing:
                row = await existing.fetchone()
                if row:
                    await ctx.reply(embed=discord.Embed(title="<:icons_warning:1327829522573430864> Access Denied", description="YouTube notification already set. Remove it first.", color=0x000000))
                    return

            await db.execute('INSERT INTO notifications (type, role_id, channel_id) VALUES (?, ?, ?)', ('youtube', role.id, channel.id))
            await db.commit()
            self._notif_cache = {}
            await ctx.reply(embed=discord.Embed(title="<:emoji_4:1566043104551768114> Success", description=f"YouTube notifications set for {role.mention} in {channel.mention}.", color=0x000000))

    @setnotif.command()
    async def list(self, ctx):
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute('SELECT * FROM notifications') as cursor:
                rows = await cursor.fetchall()
                if not rows:
                    await ctx.reply(embed=discord.Embed(description="No Twitch and YouTube notification channels set.", color=0xFF0000))
                    return

            embed = discord.Embed(title="Current Notification Settings", color=0x000000)
            for row in rows:
                notif_type = row[1].capitalize() 
                role = ctx.guild.get_role(row[2])
                channel = ctx.guild.get_channel(row[3])
                if role and channel:
                    embed.add_field(name=f"{notif_type} Notifications", value=f"Role: {role.mention} | Channel: {channel.mention}", inline=False)
                else:
                    embed.add_field(name=f"{notif_type} Notifications", value="Role or Channel not found", inline=False)

            await ctx.reply(embed=embed)

    @setnotif.command()
    async def reset(self, ctx):
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute('DELETE FROM notifications WHERE type IN (?, ?)', ('twitch', 'youtube'))
            await db.commit()
            self._notif_cache = {}
            await ctx.send(embed=discord.Embed(title="<:emoji_4:1566043104551768114> Success", description="Twitch and YouTube notifications have been reset.", color=0x00FF00))


    async def _notif_config(self, stream_type: str):
        """(role_id, channel_id) for twitch/youtube, cached 60s (presence updates are the busiest event)."""
        import time as _t
        cache = getattr(self, "_notif_cache", None)
        if cache is None:
            cache = self._notif_cache = {}
        hit = cache.get(stream_type)
        now = _t.monotonic()
        if hit and hit[0] > now:
            return hit[1]
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute('SELECT role_id, channel_id FROM notifications WHERE type = ?', (stream_type,)) as cursor:
                row = await cursor.fetchone()
        cache[stream_type] = (now + 60, row)
        return row

    @staticmethod
    def _stream_of(member):
        for activity in member.activities:
            if isinstance(activity, discord.Streaming):
                return activity
        return None

    @commands.Cog.listener()
    async def on_presence_update(self, before, after):
        # Cheapest checks first - this fires for every presence change in every guild.
        streaming = self._stream_of(after)
        if streaming is None:
            return
        # Only announce when the stream STARTS (used to re-announce on every presence tick).
        if self._stream_of(before) is not None:
            return

        url = (streaming.url or "").lower()   # url can be None -> used to raise AttributeError
        stream_type = "twitch" if "twitch" in url else "youtube" if "youtube" in url else None
        if not stream_type:
            return

        row = await self._notif_config(stream_type)
        if not row:
            return
        role_id, channel_id = row
        role = after.guild.get_role(role_id)
        channel = after.guild.get_channel(channel_id)
        if not (role and channel):
            return

        embed = discord.Embed(
            title=f"{after.display_name} is now live!",
            description=f"{after.mention} is now streaming on {stream_type.capitalize()}.",
            color=0x000000
        )
        embed.add_field(name="Stream Title", value=streaming.name or "Live", inline=False)
        embed.add_field(name="Watch here", value=streaming.url, inline=False)
        try:
            await channel.send(content=role.mention, embed=embed)
        except discord.HTTPException:
            pass

"""
@Author: Sonu Jana
    + Discord: me.sonu
    + Community: https://discord.gg/cfYmz4634n (Death Development)
    + for any queries reach out Community or DM me.
"""