from __future__ import annotations

import discord
from discord.ext import commands

from utils.Tools import blacklist_check, ignore_check
from utils.permit_store import store, normalize_permission, valid_permission_names
from utils import permit_ui as ui

# Access levels
OWNER, EXTRA, TRUSTED = 3, 2, 1

KEY_PERMS = [
    "administrator", "manage_guild", "manage_roles", "manage_channels", "manage_messages",
    "manage_nicknames", "manage_webhooks", "manage_threads", "manage_expressions", "kick_members",
    "ban_members", "moderate_members", "mention_everyone", "view_audit_log", "create_instant_invite",
    "move_members", "mute_members", "deafen_members", "priority_speaker", "stream",
    "manage_events", "manage_permissions", "view_guild_insights", "send_messages", "embed_links",
]


def pretty(perm: str) -> str:
    return perm.replace("_", " ").title()


class Permit(commands.Cog):
    """Permit: extraowner, trusted, fake permissions and ignore."""

    def __init__(self, bot):
        self.bot = bot

    # ------------------------------------------------------------ plumbing
    async def cog_check(self, ctx: commands.Context) -> bool:
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        if not await blacklist_check().predicate(ctx):
            return False
        root = ctx.command.root_parent or ctx.command
        if root.name != "ignore":  # ignore group stays usable so admins can never lock themselves out
            return await ignore_check().predicate(ctx)
        return True

    async def _level(self, ctx) -> int:
        uid, gid = ctx.author.id, ctx.guild.id
        if uid == ctx.guild.owner_id or uid in (self.bot.owner_ids or ()):
            return OWNER
        if await store.is_extraowner(gid, uid):
            return EXTRA
        if await store.is_trusted(gid, uid) or ctx.author.guild_permissions.administrator:
            return TRUSTED
        return 0

    async def _need(self, ctx, level: int) -> bool:
        if await self._level(ctx) >= level:
            return True
        who = {OWNER: "the Server Owner", EXTRA: "the Server Owner or an Extraowner",
               TRUSTED: "an Administrator, Trusted user, Extraowner or the Server Owner"}[level]
        await ctx.reply(view=ui.fail("Access Denied", f"Only {who} can use this command."), mention_author=False)
        return False

    async def _usage(self, ctx, group: commands.Group, title: str, about: str):
        lines = []
        for cmd in group.walk_commands():
            if cmd.hidden:
                continue
            sig = f" {cmd.signature}" if cmd.signature else ""
            lines.append(f"`{ctx.clean_prefix}{cmd.qualified_name}{sig}`\n-# {cmd.short_doc or cmd.help or ''}")
        body = about + "\n\n" + "\n".join(lines)
        await ctx.reply(view=ui.card(title, body), mention_author=False)

    @staticmethod
    def _fmt_users(ids) -> list[str]:
        return [f"• <@{i}> (`{i}`)" for i in sorted(ids)]

    # ================================================================ EXTRAOWNER
    @commands.group(name="extraowner", aliases=["extraowners", "eo"], invoke_without_command=True,
                    help="Manage extra owners of this server.")
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def extraowner(self, ctx):
        await self._usage(ctx, ctx.command, "Extra Owner",
                          "Extraowners can manage antinuke, trusted users and fake permissions. "
                          "Only the Server Owner can add or remove them.")

    @extraowner.command(name="add", help="Add an extra owner.")
    async def eo_add(self, ctx, member: discord.Member):
        if not await self._need(ctx, OWNER):
            return
        if member.bot:
            return await ctx.reply(view=ui.fail("Invalid User", "Bots cannot be extra owners."), mention_author=False)
        if member.id == ctx.guild.owner_id:
            return await ctx.reply(view=ui.fail("Not Needed", "The Server Owner already has full access."), mention_author=False)
        added = await store.extraowner_add(ctx.guild.id, member.id)
        view = ui.ok("Extraowner Added", f"{member.mention} is now an extra owner.") if added \
            else ui.fail("Already Added", f"{member.mention} is already an extra owner.")
        await ctx.reply(view=view, mention_author=False)

    @extraowner.command(name="remove", help="Remove an extra owner.")
    async def eo_remove(self, ctx, member: discord.Member):
        if not await self._need(ctx, OWNER):
            return
        removed = await store.extraowner_remove(ctx.guild.id, member.id)
        view = ui.ok("Extraowner Removed", f"{member.mention} is no longer an extra owner.") if removed \
            else ui.fail("Not Found", f"{member.mention} is not an extra owner.")
        await ctx.reply(view=view, mention_author=False)

    @extraowner.command(name="show", aliases=["list", "view"], help="Show all extra owners.")
    async def eo_show(self, ctx):
        if not await self._need(ctx, EXTRA):
            return
        ids = await store.extraowners(ctx.guild.id)
        await ctx.reply(view=ui.listing("Extra Owners", self._fmt_users(ids), empty="No extra owners set."),
                        mention_author=False)

    @extraowner.command(name="reset", help="Remove every extra owner.")
    async def eo_reset(self, ctx):
        if not await self._need(ctx, OWNER):
            return
        count = await store.extraowner_reset(ctx.guild.id)
        await ctx.reply(view=ui.ok("Extraowners Reset", f"Removed `{count}` extra owner(s).") if count
                        else ui.fail("Nothing To Reset", "No extra owners set."), mention_author=False)

    # ================================================================ TRUSTED
    @commands.group(name="trusted", invoke_without_command=True, help="Manage trusted users of this server.")
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def trusted(self, ctx):
        await self._usage(ctx, ctx.command, "Trusted Users",
                          "Trusted users can manage the ignore settings without needing Administrator.")

    @trusted.command(name="add", help="Add a trusted user.")
    async def tr_add(self, ctx, member: discord.Member):
        if not await self._need(ctx, EXTRA):
            return
        if member.bot:
            return await ctx.reply(view=ui.fail("Invalid User", "Bots cannot be trusted users."), mention_author=False)
        added = await store.trusted_add(ctx.guild.id, member.id)
        await ctx.reply(view=ui.ok("Trusted Added", f"{member.mention} is now trusted.") if added
                        else ui.fail("Already Added", f"{member.mention} is already trusted."), mention_author=False)

    @trusted.command(name="remove", help="Remove a trusted user.")
    async def tr_remove(self, ctx, member: discord.Member):
        if not await self._need(ctx, EXTRA):
            return
        removed = await store.trusted_remove(ctx.guild.id, member.id)
        await ctx.reply(view=ui.ok("Trusted Removed", f"{member.mention} is no longer trusted.") if removed
                        else ui.fail("Not Found", f"{member.mention} is not trusted."), mention_author=False)

    @trusted.command(name="show", aliases=["list"], help="Show all trusted users.")
    async def tr_show(self, ctx):
        if not await self._need(ctx, EXTRA):
            return
        ids = await store.trusted(ctx.guild.id)
        await ctx.reply(view=ui.listing("Trusted Users", self._fmt_users(ids), empty="No trusted users set."),
                        mention_author=False)

    @trusted.command(name="reset", help="Remove every trusted user.")
    async def tr_reset(self, ctx):
        if not await self._need(ctx, EXTRA):
            return
        count = await store.trusted_reset(ctx.guild.id)
        await ctx.reply(view=ui.ok("Trusted Reset", f"Removed `{count}` trusted user(s).") if count
                        else ui.fail("Nothing To Reset", "No trusted users set."), mention_author=False)

    # ================================================================ FAKE PERMISSIONS
    @commands.group(name="permissions", aliases=["perms", "fakeperms"], invoke_without_command=True,
                    help="Fake permissions for roles, or check a member's key permissions.")
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def permissions(self, ctx, member: discord.Member = None):
        if member is None:
            return await self._usage(
                ctx, ctx.command, "Fake Permissions",
                "Give a role bot-level permissions (they work only on my commands, Discord permissions stay "
                f"unchanged). Use `{ctx.clean_prefix}permissions <member>` to check someone's key permissions.")
        perms = member.guild_permissions
        have = [pretty(p) for p in KEY_PERMS if getattr(perms, p, False)]
        fake = sorted(pretty(p) for p in await store.member_fake_perms(member))
        body = f"**Key Permissions**\n{', '.join(have) if have else 'None'}"
        if fake:
            body += f"\n\n**Fake Permissions**\n{', '.join(fake)}"
        await ctx.reply(view=ui.card(f"Permissions of {member.display_name}", body,
                                     thumbnail=member.display_avatar.url), mention_author=False)

    @staticmethod
    def _parse_perms(raw: str):
        valid = valid_permission_names()
        wanted = [normalize_permission(p) for p in raw.replace(",", " ").split() if p.strip()]
        # allow "manage messages" typed with spaces: join pairs if the single word is not valid
        names, bad, i = [], [], 0
        while i < len(wanted):
            word = wanted[i]
            if word not in valid and i + 1 < len(wanted) and f"{word}_{wanted[i + 1]}" in valid:
                word = f"{word}_{wanted[i + 1]}"
                i += 1
            (names if word in valid else bad).append(word)
            i += 1
        return names, bad

    @permissions.command(name="grant", aliases=["give", "add"], help="Grant fake permission(s) to a role.")
    async def p_grant(self, ctx, role: discord.Role, *, permissions: str):
        if not await self._need(ctx, EXTRA):
            return
        names, bad = self._parse_perms(permissions)
        if bad or not names:
            return await ctx.reply(view=ui.fail("Invalid Permission", "Unknown: " + (", ".join(f"`{b}`" for b in bad) or "none given")
                                                + "\nExample: `manage_messages kick_members`"), mention_author=False)
        new = await store.fake_grant(ctx.guild.id, role.id, names)
        await ctx.reply(view=ui.ok("Permissions Granted", f"{role.mention} → " + ", ".join(f"`{pretty(p)}`" for p in sorted(new)))
                        if new else ui.fail("Already Granted", f"{role.mention} already has these fake permissions."),
                        mention_author=False)

    @permissions.command(name="revoke", aliases=["remove"], help="Revoke fake permission(s) from a role.")
    async def p_revoke(self, ctx, role: discord.Role, *, permissions: str):
        if not await self._need(ctx, EXTRA):
            return
        names, bad = self._parse_perms(permissions)
        if bad or not names:
            return await ctx.reply(view=ui.fail("Invalid Permission", "Unknown: " + (", ".join(f"`{b}`" for b in bad) or "none given")),
                                   mention_author=False)
        gone = await store.fake_revoke(ctx.guild.id, role.id, names)
        await ctx.reply(view=ui.ok("Permissions Revoked", f"{role.mention} ✕ " + ", ".join(f"`{pretty(p)}`" for p in sorted(gone)))
                        if gone else ui.fail("Not Found", f"{role.mention} had none of these fake permissions."),
                        mention_author=False)

    @permissions.command(name="list", aliases=["show"], help="List roles that have fake permissions.")
    async def p_list(self, ctx, role: discord.Role = None):
        if not await self._need(ctx, EXTRA):
            return
        data = await store.fake_perms(ctx.guild.id)
        if role is not None:
            data = {role.id: data.get(role.id, set())} if data.get(role.id) else {}
        lines = []
        for rid, perms in data.items():
            r = ctx.guild.get_role(rid)
            lines.append(f"{r.mention if r else f'`{rid}`'}\n-# {', '.join(pretty(p) for p in sorted(perms))}")
        await ctx.reply(view=ui.listing("Fake Permissions", lines, empty="No fake permissions set."), mention_author=False)

    @permissions.command(name="resetall", help="Remove all fake permissions from every role.")
    async def p_resetall(self, ctx):
        if not await self._need(ctx, EXTRA):
            return
        count = await store.fake_resetall(ctx.guild.id)
        await ctx.reply(view=ui.ok("Fake Permissions Reset", f"Cleared `{count}` role(s).") if count
                        else ui.fail("Nothing To Reset", "No fake permissions set."), mention_author=False)

    @permissions.command(name="manage", help="Open the interactive fake permission manager.")
    async def p_manage(self, ctx):
        if not await self._need(ctx, EXTRA):
            return
        view = ManageView(ctx)
        await view.refresh()
        view.message = await ctx.reply(view=view, mention_author=False)

    # ================================================================ IGNORE
    @commands.group(name="ignore", invoke_without_command=True,
                    help="Manage ignored commands, channels, roles, users and bypass users.")
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def ignore(self, ctx):
        if not await self._need(ctx, TRUSTED):
            return
        await self._usage(ctx, ctx.command, "Ignore", "Stop me from responding to chosen commands, channels, roles or users.")

    async def _ig_group(self, ctx, title, about):
        if not await self._need(ctx, TRUSTED):
            return
        await self._usage(ctx, ctx.command, title, about)

    async def _ig_add(self, ctx, kind: str, value, shown: str, label: str):
        if not await self._need(ctx, TRUSTED):
            return
        res = await store.ignore_add(ctx.guild.id, kind, value)
        if res == "added":
            view = ui.ok(f"{label} Ignored", f"{shown} added to the ignore {kind} list.")
        elif res == "exists":
            view = ui.fail("Already Added", f"{shown} is already in the ignore {kind} list.")
        else:
            view = ui.fail("Limit Reached", f"The ignore {kind} list is full.")
        await ctx.reply(view=view, mention_author=False)

    async def _ig_remove(self, ctx, kind: str, value, shown: str, label: str):
        if not await self._need(ctx, TRUSTED):
            return
        ok = await store.ignore_remove(ctx.guild.id, kind, value)
        await ctx.reply(view=ui.ok(f"{label} Removed", f"{shown} removed from the ignore {kind} list.") if ok
                        else ui.fail("Not Found", f"{shown} is not in the ignore {kind} list."), mention_author=False)

    async def _ig_show(self, ctx, kind: str, title: str, fmt):
        if not await self._need(ctx, TRUSTED):
            return
        items = await store.ignore_list(ctx.guild.id, kind)
        await ctx.reply(view=ui.listing(title, [f"• {fmt(i)}" for i in items], empty=f"No {kind} entries are ignored."),
                        mention_author=False)

    async def _ig_reset(self, ctx, kind: str, label: str):
        if not await self._need(ctx, TRUSTED):
            return
        count = await store.ignore_reset(ctx.guild.id, kind)
        await ctx.reply(view=ui.ok(f"{label} Reset", f"Cleared `{count}` entr{'y' if count == 1 else 'ies'}.") if count
                        else ui.fail("Nothing To Reset", f"The ignore {kind} list is already empty."), mention_author=False)

    # ---- ignore command
    @ignore.group(name="command", invoke_without_command=True, help="Manage ignored commands.")
    async def ig_command(self, ctx):
        await self._ig_group(ctx, "Ignore Command", "Ignored commands stop working for everyone except bypass users.")

    @ig_command.command(name="add", help="Ignore a command.")
    async def igc_add(self, ctx, *, command_name: str):
        cmd = self.bot.get_command(command_name.strip().lower())
        if cmd is None:
            return await ctx.reply(view=ui.fail("Invalid Command", f"`{command_name}` is not a valid command."), mention_author=False)
        if (cmd.root_parent or cmd).name in ("ignore", "help"):
            return await ctx.reply(view=ui.fail("Not Allowed", "That command can't be ignored."), mention_author=False)
        await self._ig_add(ctx, "command", cmd.name.lower(), f"`{cmd.name}`", "Command")

    @ig_command.command(name="remove", help="Stop ignoring a command.")
    async def igc_remove(self, ctx, *, command_name: str):
        name = command_name.strip().lower()
        cmd = self.bot.get_command(name)
        await self._ig_remove(ctx, "command", cmd.name.lower() if cmd else name, f"`{command_name}`", "Command")

    @ig_command.command(name="show", help="Show ignored commands.")
    async def igc_show(self, ctx):
        await self._ig_show(ctx, "command", "Ignored Commands", lambda n: f"`{n}`")

    @ig_command.command(name="reset", help="Clear the ignored commands list.")
    async def igc_reset(self, ctx):
        await self._ig_reset(ctx, "command", "Commands")

    # ---- ignore role
    @ignore.group(name="role", invoke_without_command=True, help="Manage ignored roles.")
    async def ig_role(self, ctx):
        await self._ig_group(ctx, "Ignore Role", "Members with an ignored role can't use my commands (bypass users excepted).")

    @ig_role.command(name="add", help="Ignore a role.")
    async def igr_add(self, ctx, role: discord.Role):
        await self._ig_add(ctx, "role", role.id, role.mention, "Role")

    @ig_role.command(name="remove", help="Stop ignoring a role.")
    async def igr_remove(self, ctx, role: discord.Role):
        await self._ig_remove(ctx, "role", role.id, role.mention, "Role")

    @ig_role.command(name="show", help="Show ignored roles.")
    async def igr_show(self, ctx):
        await self._ig_show(ctx, "role", "Ignored Roles", lambda i: f"<@&{i}>")

    @ig_role.command(name="reset", help="Clear the ignored roles list.")
    async def igr_reset(self, ctx):
        await self._ig_reset(ctx, "role", "Roles")

    # ---- ignore channel
    @ignore.group(name="channel", invoke_without_command=True, help="Manage ignored channels.")
    async def ig_channel(self, ctx):
        await self._ig_group(ctx, "Ignore Channel", "I won't respond to commands in ignored channels.")

    @ig_channel.command(name="add", help="Ignore a channel.")
    async def igch_add(self, ctx, channel: discord.TextChannel):
        await self._ig_add(ctx, "channel", channel.id, channel.mention, "Channel")

    @ig_channel.command(name="remove", help="Stop ignoring a channel.")
    async def igch_remove(self, ctx, channel: discord.TextChannel):
        await self._ig_remove(ctx, "channel", channel.id, channel.mention, "Channel")

    @ig_channel.command(name="show", help="Show ignored channels.")
    async def igch_show(self, ctx):
        await self._ig_show(ctx, "channel", "Ignored Channels", lambda i: f"<#{i}>")

    @ig_channel.command(name="reset", help="Clear the ignored channels list.")
    async def igch_reset(self, ctx):
        await self._ig_reset(ctx, "channel", "Channels")

    # ---- ignore user
    @ignore.group(name="user", invoke_without_command=True, help="Manage ignored users.")
    async def ig_user(self, ctx):
        await self._ig_group(ctx, "Ignore User", "I won't respond to ignored users.")

    @ig_user.command(name="add", help="Ignore a user.")
    async def igu_add(self, ctx, member: discord.Member):
        await self._ig_add(ctx, "user", member.id, member.mention, "User")

    @ig_user.command(name="remove", help="Stop ignoring a user.")
    async def igu_remove(self, ctx, member: discord.Member):
        await self._ig_remove(ctx, "user", member.id, member.mention, "User")

    @ig_user.command(name="show", help="Show ignored users.")
    async def igu_show(self, ctx):
        await self._ig_show(ctx, "user", "Ignored Users", lambda i: f"<@{i}>")

    @ig_user.command(name="reset", help="Clear the ignored users list.")
    async def igu_reset(self, ctx):
        await self._ig_reset(ctx, "user", "Users")

    # ---- ignore bypass
    @ignore.group(name="bypass", invoke_without_command=True, help="Manage users who bypass every ignore rule.")
    async def ig_bypass(self, ctx):
        await self._ig_group(ctx, "Ignore Bypass", "Bypass users can use my commands even in ignored channels/commands.")

    @ig_bypass.command(name="add", help="Add a bypass user.")
    async def igb_add(self, ctx, member: discord.Member):
        await self._ig_add(ctx, "bypass", member.id, member.mention, "Bypass User")

    @ig_bypass.command(name="remove", help="Remove a bypass user.")
    async def igb_remove(self, ctx, member: discord.Member):
        await self._ig_remove(ctx, "bypass", member.id, member.mention, "Bypass User")

    @ig_bypass.command(name="show", aliases=["list"], help="Show bypass users.")
    async def igb_show(self, ctx):
        await self._ig_show(ctx, "bypass", "Bypass Users", lambda i: f"<@{i}>")

    @ig_bypass.command(name="reset", help="Clear the bypass users list.")
    async def igb_reset(self, ctx):
        await self._ig_reset(ctx, "bypass", "Bypass Users")


# ====================================================================== manage UI
class _RoleSelect(discord.ui.RoleSelect):
    def __init__(self, pview: "ManageView"):
        super().__init__(placeholder="1. Pick a role", min_values=1, max_values=1)
        self.pview = pview

    async def callback(self, interaction: discord.Interaction):
        self.pview.role = self.values[0]
        await self.pview.refresh()
        await interaction.response.edit_message(view=self.pview)


class _PermSelect(discord.ui.Select):
    def __init__(self, pview: "ManageView", current: set):
        options = [discord.SelectOption(label=pretty(p), value=p, default=p in current) for p in KEY_PERMS[:25]]
        super().__init__(placeholder="2. Choose fake permissions", min_values=0, max_values=len(options), options=options)
        self.pview = pview

    async def callback(self, interaction: discord.Interaction):
        role = self.pview.role
        await store.fake_set(interaction.guild.id, role.id, self.values)
        await self.pview.refresh()
        await interaction.response.edit_message(view=self.pview)


class ManageView(discord.ui.LayoutView):
    def __init__(self, ctx: commands.Context):
        super().__init__(timeout=120)
        self.ctx = ctx
        self.role: discord.Role | None = None
        self.message = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.ctx.author.id:
            await interaction.response.send_message("Only the command author can use this.", ephemeral=True)
            return False
        return True

    async def refresh(self):
        self.clear_items()
        container = discord.ui.Container(accent_colour=ui.WHITE)
        if self.role is None:
            container.add_item(discord.ui.TextDisplay("## Fake Permissions Manager\nPick a role to edit its fake permissions."))
        else:
            current = (await store.fake_perms(self.ctx.guild.id)).get(self.role.id, set())
            shown = ", ".join(pretty(p) for p in sorted(current)) or "None"
            container.add_item(discord.ui.TextDisplay(f"## Fake Permissions Manager\n{self.role.mention}\n**Current:** {shown}"))
        container.add_item(discord.ui.Separator())
        row = discord.ui.ActionRow()
        row.add_item(_RoleSelect(self))
        container.add_item(row)
        if self.role is not None:
            current = (await store.fake_perms(self.ctx.guild.id)).get(self.role.id, set())
            row2 = discord.ui.ActionRow()
            row2.add_item(_PermSelect(self, current))
            container.add_item(row2)
        self.add_item(container)

    async def on_timeout(self):
        for child in self.walk_children():
            if hasattr(child, "disabled"):
                child.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except Exception:
                pass
