"""Premium category.

Commands (same names / aliases / descriptions as the reference bot):
    activate, botavatar, botbanner, botbio, botname, botreset, customise,
    customisereset, deactivate, premium, premiumstats, servernoprefix
Extra premium command:
    cmdalias  -> give ANY command your own custom alias in this server
Owner-only group `premium`: list, add, activate, revoke, remove, status (listed under Bot Owner in help)

Speed: all premium data lives in memory (utils/premium_store.py); the bot's
``get_prefix`` / ``get_context`` read it without touching the disk.
"""
from __future__ import annotations

import asyncio
import base64
import re
import time
from typing import Optional

import aiohttp
import discord
from discord.ext import commands, tasks
from discord.http import Route

from utils.config import OWNER_IDS, serverLink
from utils.Tools import blacklist_check, ignore_check
from utils.grouphelp import GroupHelpView
from utils.premium_store import store, MAX_SERVER_NP, MAX_ALIASES

MAX_IMAGE_BYTES = 8 * 1024 * 1024
ALIAS_RE = re.compile(r"^[\w-]{1,32}$", re.UNICODE)
URL_RE = re.compile(r"https?://\S+")
RESET_WORDS = {"reset", "default", "remove", "clear"}
PREMIUM_ORDER = ["list", "add", "activate", "revoke", "remove", "status"]
RESET_ALL = {"nick": None, "avatar": None, "banner": None, "bio": None}
RESET_LOOK = {"avatar": None, "banner": None, "bio": None}

_DUR = re.compile(r"^(\d+)(mo|y|w|d|h|m)$")
_UNITS = {"m": 60, "h": 3600, "d": 86400, "w": 604800, "mo": 2592000, "y": 31536000}


# --------------------------------------------------------------------------- helpers
def _embed(title: str, description: str) -> discord.Embed:
    return discord.Embed(title=title, description=description, color=0x000000)


def _ok(text: str) -> discord.Embed:
    return _embed("<:emoji_4:1566043104551768114> Done", text)


def _err(text: str) -> discord.Embed:
    return _embed("<a:emoji_38:1567096105299214336> Error", text)


def _data_uri(raw: bytes) -> Optional[str]:
    if raw.startswith(b"\x89PNG\r\n\x1a\n"):
        mime = "image/png"
    elif raw[:3] == b"\xff\xd8\xff":
        mime = "image/jpeg"
    elif raw[:6] in (b"GIF87a", b"GIF89a"):
        mime = "image/gif"
    elif raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        mime = "image/webp"
    else:
        return None
    return f"data:{mime};base64,{base64.b64encode(raw).decode()}"


def _parse_duration(text: str) -> Optional[float] | str:
    """'lifetime' -> None (never expires), '30d' -> timestamp, bad input -> 'error'."""
    text = text.lower().strip()
    if text in ("lifetime", "life", "perm", "permanent", "forever"):
        return None
    match = _DUR.match(text)
    if not match:
        return "error"
    return time.time() + int(match.group(1)) * _UNITS[match.group(2)]


def _can_manage(guild: discord.Guild, member: discord.abc.User) -> bool:
    if member.id in OWNER_IDS or member.id == guild.owner_id:
        return True
    perms = getattr(member, "guild_permissions", None)
    if perms is not None and perms.administrator:
        return True
    return store.activations.get(guild.id) == member.id


async def _read_image(message: discord.Message, url: Optional[str] = None):
    """Return (bytes, None) | (None, error) | (None, None) when no image was supplied."""
    attachment = None
    if message.attachments:
        attachment = message.attachments[0]
    else:
        ref = message.reference.resolved if message.reference else None
        if isinstance(ref, discord.Message) and ref.attachments:
            attachment = ref.attachments[0]
    try:
        if attachment is not None:
            if attachment.size > MAX_IMAGE_BYTES:
                return None, "That image is too big (max **8 MB**)."
            return await attachment.read(), None
        if not url:
            found = URL_RE.search(message.content or "")
            url = found.group(0) if found else None
        if not url:
            return None, None
        if not url.lower().startswith(("http://", "https://")):
            return None, None
        timeout = aiohttp.ClientTimeout(total=20)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url) as resp:
                if resp.status != 200:
                    return None, f"Couldn't download that image (HTTP {resp.status})."
                data = await resp.content.read(MAX_IMAGE_BYTES + 1)
                if len(data) > MAX_IMAGE_BYTES:
                    return None, "That image is too big (max **8 MB**)."
                return data, None
    except (aiohttp.ClientError, asyncio.TimeoutError, discord.HTTPException):
        return None, "Couldn't download that image. Try uploading it directly."


# --------------------------------------------------------------------------- UI
class _TextModal(discord.ui.Modal):
    def __init__(self, cog: "Premium", field: str, title: str, label: str, maxlen: int,
                 style: discord.TextStyle, placeholder: str):
        super().__init__(title=title, timeout=300)
        self.cog = cog
        self.field = field
        self.input = discord.ui.TextInput(label=label, style=style, max_length=maxlen,
                                          required=False, placeholder=placeholder)
        self.add_item(self.input)

    async def on_submit(self, interaction: discord.Interaction):
        guild = interaction.guild
        if guild is None or not _can_manage(guild, interaction.user) or not store.is_active(guild.id):
            await interaction.response.send_message(embed=_err("You can't do that here."), ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        value = (self.input.value or "").strip() or None
        problem = await self.cog.patch_profile(guild.id, {self.field: value}, f"By {interaction.user}")
        if problem:
            await interaction.followup.send(embed=_err(problem), ephemeral=True)
        else:
            what = "reset to default" if value is None else "updated"
            await interaction.followup.send(embed=_ok(f"Bot {self.title.lower()} {what} in this server."),
                                            ephemeral=True)

    async def on_error(self, interaction: discord.Interaction, error: Exception):
        try:
            if interaction.response.is_done():
                await interaction.followup.send(embed=_err("Something went wrong."), ephemeral=True)
            else:
                await interaction.response.send_message(embed=_err("Something went wrong."), ephemeral=True)
        except discord.HTTPException:
            pass


class CustomiseView(discord.ui.LayoutView):
    """Customise panel: Name / Avatar / Banner / Bio / Reset buttons."""

    def __init__(self, cog: "Premium", ctx: commands.Context):
        super().__init__(timeout=300)
        self.cog = cog
        self.author_id = ctx.author.id
        self.message: Optional[discord.Message] = None

        container = discord.ui.Container()
        container.add_item(discord.ui.TextDisplay(
            "# <a:z_exo_mobile:1567139775721377792> Customise Bot\n"
            "Change how the bot looks **in this server only**.\n\n"
            "• **Name** – bot nickname\n• **Avatar** – profile picture\n"
            "• **Banner** – profile banner\n• **Bio** – About Me text"))
        container.add_item(discord.ui.Separator())
        self.row = discord.ui.ActionRow()
        for label, style, handler in (
            ("Name", discord.ButtonStyle.primary, self.on_name),
            ("Avatar", discord.ButtonStyle.primary, self.on_avatar),
            ("Banner", discord.ButtonStyle.primary, self.on_banner),
            ("Bio", discord.ButtonStyle.primary, self.on_bio),
            ("Reset", discord.ButtonStyle.danger, self.on_reset),
        ):
            button = discord.ui.Button(label=label, style=style)
            button.callback = handler
            self.row.add_item(button)
        container.add_item(self.row)
        self.add_item(container)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message("This panel isn't yours. Run the command yourself.",
                                                    ephemeral=True)
            return False
        if interaction.guild is None or not store.is_active(interaction.guild.id):
            await interaction.response.send_message("Premium is not active in this server.", ephemeral=True)
            return False
        return True

    async def on_timeout(self):
        for item in self.row.children:
            item.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass

    async def on_name(self, interaction: discord.Interaction):
        await interaction.response.send_modal(_TextModal(
            self.cog, "nick", "Nickname", "New bot nickname (empty = default)", 32,
            discord.TextStyle.short, "Type a nickname"))

    async def on_bio(self, interaction: discord.Interaction):
        await interaction.response.send_modal(_TextModal(
            self.cog, "bio", "Bio", "New bot bio (empty = default)", 190,
            discord.TextStyle.paragraph, "Type the About Me text"))

    async def _ask_image(self, interaction: discord.Interaction, field: str, label: str):
        await interaction.response.send_message(
            f"Send the new **{label}** image in this channel within **60 seconds** "
            "(attach it, or paste an image link). Type `cancel` to stop.", ephemeral=True)

        def check(m: discord.Message) -> bool:
            return m.author.id == interaction.user.id and m.channel.id == interaction.channel_id

        try:
            msg = await interaction.client.wait_for("message", check=check, timeout=60)
        except asyncio.TimeoutError:
            await interaction.followup.send("<a:time:1567099263513526273> Timed out. Press the button again to retry.", ephemeral=True)
            return
        if (msg.content or "").strip().lower() == "cancel":
            await interaction.followup.send("Cancelled.", ephemeral=True)
            return
        raw, problem = await _read_image(msg)
        if problem or not raw:
            await interaction.followup.send(embed=_err(problem or "I couldn't find an image in that message."),
                                            ephemeral=True)
            return
        uri = _data_uri(raw)
        if not uri:
            await interaction.followup.send(embed=_err("Only **PNG, JPG, GIF or WEBP** images are supported."),
                                            ephemeral=True)
            return
        problem = await self.cog.patch_profile(interaction.guild.id, {field: uri}, f"By {interaction.user}")
        if problem:
            await interaction.followup.send(embed=_err(problem), ephemeral=True)
        else:
            await interaction.followup.send(embed=_ok(f"Bot {label} updated in this server."), ephemeral=True)

    async def on_avatar(self, interaction: discord.Interaction):
        await self._ask_image(interaction, "avatar", "avatar")

    async def on_banner(self, interaction: discord.Interaction):
        await self._ask_image(interaction, "banner", "banner")

    async def on_reset(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        problem = await self.cog.patch_profile(interaction.guild.id, RESET_ALL, f"Reset by {interaction.user}")
        if problem:
            await interaction.followup.send(embed=_err(problem), ephemeral=True)
        else:
            await interaction.followup.send(embed=_ok("Nickname, avatar, banner and bio were reset to default."),
                                            ephemeral=True)


# --------------------------------------------------------------------------- cog
class Premium(commands.Cog, name="Premium"):
    """Premium commands."""

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        await store.load()
        self._expiry_loop.start()

    async def cog_unload(self):
        self._expiry_loop.cancel()

    # ------------------------------------------------------------- internals
    async def patch_profile(self, guild_id: int, payload: dict, reason: str) -> Optional[str]:
        """Edit the bot's per-server profile. Returns an error text, or None on success."""
        route = Route("PATCH", "/guilds/{guild_id}/members/@me", guild_id=guild_id)
        try:
            await self.bot.http.request(route, json=payload, reason=reason[:480])
        except discord.Forbidden:
            return ("I don't have permission to do that. Give me the **Change Nickname** permission "
                    "and make sure my role is allowed to edit my profile.")
        except discord.HTTPException as exc:
            text = (getattr(exc, "text", "") or str(exc))[:300]
            if exc.status == 429:
                return "Discord is rate-limiting profile changes. Please try again in a minute."
            return f"Discord rejected this change: {text}"
        return None

    async def _gate(self, ctx: commands.Context, premium: bool = True, manage: bool = True) -> bool:
        if manage and not _can_manage(ctx.guild, ctx.author):
            await ctx.reply(embed=_err("Only the **server owner**, an **Administrator** or the member who "
                                       "**activated premium** can use this command."), mention_author=False)
            return False
        if premium and not store.is_active(ctx.guild.id):
            await ctx.reply(embed=_err(f"Premium is **not active** in this server.\n"
                                       f"Use `{ctx.clean_prefix}activate` (needs a premium plan) first."),
                            mention_author=False)
            return False
        return True

    @tasks.loop(minutes=10)
    async def _expiry_loop(self):
        try:
            for guild_id, user_id in list(store.activations.items()):
                if store.plan_of(user_id) is None:
                    await store.deactivate(guild_id)
                    await self.patch_profile(guild_id, RESET_ALL, "Premium expired")
        except Exception as exc:  # never let the loop die
            print(f"[premium] expiry loop error: {exc}")

    @_expiry_loop.before_loop
    async def _before_expiry(self):
        await self.bot.wait_until_ready()

    # ------------------------------------------------------------- activate / deactivate
    @commands.command(name="activate", aliases=["premactivate", "premiumactivate"],
                      help="Activate premium for this server using your premium access.")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def activate(self, ctx: commands.Context):
        guild_id, user_id = ctx.guild.id, ctx.author.id
        if user_id not in OWNER_IDS and not ctx.author.guild_permissions.manage_guild:
            return await ctx.reply(embed=_err("You need the **Manage Server** permission to activate premium here."),
                                   mention_author=False)
        plan = store.plan_of(user_id)
        if not plan:
            return await ctx.reply(embed=_err(f"You don't have a premium plan.\nJoin the [support server]({serverLink}) "
                                              "to get premium access."), mention_author=False)
        if store.is_active(guild_id):
            who = store.activations[guild_id]
            return await ctx.reply(embed=_embed("<a:pinfloat:1567124641347145809> Already Active",
                                                f"Premium is already active in this server (activated by <@{who}>)."),
                                   mention_author=False)
        slots, _ = plan
        used = store.used_slots(user_id)
        if len(used) >= slots:
            return await ctx.reply(embed=_err(f"All your premium slots are used (**{len(used)}/{slots}**).\n"
                                              f"Run `{ctx.clean_prefix}deactivate` in another server to free a slot."),
                                   mention_author=False)
        await store.activate(guild_id, user_id)
        await ctx.reply(embed=_embed(
            "<a:pinfloat:1567124641347145809> Premium Activated",
            f"Premium is now active in **{ctx.guild.name}**.\n\n"
            f"• Slots used: **{len(used) + 1}/{slots if slots < 999 else '∞'}**\n"
            f"• Customise the bot: `{ctx.clean_prefix}customise`\n"
            f"• Server no-prefix: `{ctx.clean_prefix}servernoprefix`\n"
            f"• Custom aliases: `{ctx.clean_prefix}cmdalias`"), mention_author=False)

    @commands.command(name="deactivate", aliases=["premdeactivate"],
                      help="Deactivate premium for this server that you activated.")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def deactivate(self, ctx: commands.Context):
        guild_id = ctx.guild.id
        owner = store.activations.get(guild_id)
        if owner is None:
            return await ctx.reply(embed=_err("Premium is not activated in this server."), mention_author=False)
        if ctx.author.id != owner and ctx.author.id not in OWNER_IDS:
            return await ctx.reply(embed=_err(f"Only <@{owner}> (who activated premium) can deactivate it."),
                                   mention_author=False)
        await store.deactivate(guild_id)
        await self.patch_profile(guild_id, RESET_ALL, f"Premium deactivated by {ctx.author}")
        await ctx.reply(embed=_embed("<a:pinfloat:1567124641347145809> Premium Deactivated",
                                     "Premium was removed from this server and the bot's look was reset to default.\n"
                                     "Your slot is free again."), mention_author=False)

    # ------------------------------------------------------------- branding commands
    async def _image_command(self, ctx: commands.Context, field: str, label: str, url: Optional[str]):
        if not await self._gate(ctx):
            return
        prefix = ctx.clean_prefix
        command = ctx.invoked_with or f"bot{label}"
        if url and url.lower() in RESET_WORDS:
            problem = await self.patch_profile(ctx.guild.id, {field: None}, f"Reset by {ctx.author}")
            if problem:
                return await ctx.reply(embed=_err(problem), mention_author=False)
            return await ctx.reply(embed=_ok(f"Bot {label} reset to default in this server."), mention_author=False)
        async with ctx.typing():
            raw, problem = await _read_image(ctx.message, url)
        if problem:
            return await ctx.reply(embed=_err(problem), mention_author=False)
        if not raw:
            return await ctx.reply(embed=_embed(
                f"Bot {label.title()}",
                f"Attach an image, reply to a message with an image, or give an image link.\n\n"
                f"**Usage:** `{prefix}{command} [image link]`\n**Reset:** `{prefix}{command} reset`"),
                mention_author=False)
        uri = _data_uri(raw)
        if not uri:
            return await ctx.reply(embed=_err("Only **PNG, JPG, GIF or WEBP** images are supported."),
                                   mention_author=False)
        problem = await self.patch_profile(ctx.guild.id, {field: uri}, f"By {ctx.author}")
        if problem:
            return await ctx.reply(embed=_err(problem), mention_author=False)
        await ctx.reply(embed=_ok(f"Bot {label} updated in this server."), mention_author=False)

    @commands.command(name="botavatar", aliases=["setbotavatar", "avatarbot"],
                      help="Change the bot avatar in this (premium) server.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.guild)
    @blacklist_check()
    @ignore_check()
    async def botavatar(self, ctx: commands.Context, url: Optional[str] = None):
        await self._image_command(ctx, "avatar", "avatar", url)

    @commands.command(name="botbanner", aliases=["setbotbanner", "bannerbot"],
                      help="Change the bot banner in this (premium) server.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.guild)
    @blacklist_check()
    @ignore_check()
    async def botbanner(self, ctx: commands.Context, url: Optional[str] = None):
        await self._image_command(ctx, "banner", "banner", url)

    @commands.command(name="botbio", aliases=["setbotbio", "biobot"],
                      help="Change the bot bio (About Me) in this (premium) server.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.guild)
    @blacklist_check()
    @ignore_check()
    async def botbio(self, ctx: commands.Context, *, text: Optional[str] = None):
        if not await self._gate(ctx):
            return
        if not text:
            return await ctx.reply(embed=_embed(
                "Bot Bio", f"**Usage:** `{ctx.clean_prefix}botbio <text>`\n"
                           f"**Reset:** `{ctx.clean_prefix}botbio reset`\nMax **190** characters."),
                mention_author=False)
        text = text.strip()
        if text.lower() in RESET_WORDS:
            value = None
        elif len(text) > 190:
            return await ctx.reply(embed=_err(f"The bio is too long (**{len(text)}/190**)."), mention_author=False)
        else:
            value = text
        problem = await self.patch_profile(ctx.guild.id, {"bio": value}, f"By {ctx.author}")
        if problem:
            return await ctx.reply(embed=_err(problem), mention_author=False)
        await ctx.reply(embed=_ok("Bot bio reset to default." if value is None else "Bot bio updated in this server."),
                        mention_author=False)

    @commands.command(name="botname", aliases=["setbotname", "namebot", "botnick"],
                      help="Change the bot nickname in this (premium) server.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.guild)
    @blacklist_check()
    @ignore_check()
    async def botname(self, ctx: commands.Context, *, name: Optional[str] = None):
        if not await self._gate(ctx):
            return
        if not name:
            return await ctx.reply(embed=_embed(
                "Bot Name", f"**Usage:** `{ctx.clean_prefix}botname <name>`\n"
                            f"**Reset:** `{ctx.clean_prefix}botname reset`\nMax **32** characters."),
                mention_author=False)
        name = name.strip()
        if name.lower() in RESET_WORDS:
            value = None
        elif len(name) > 32:
            return await ctx.reply(embed=_err(f"The name is too long (**{len(name)}/32**)."), mention_author=False)
        else:
            value = name
        problem = await self.patch_profile(ctx.guild.id, {"nick": value}, f"By {ctx.author}")
        if problem:
            return await ctx.reply(embed=_err(problem), mention_author=False)
        await ctx.reply(embed=_ok("Bot nickname reset to default." if value is None
                                  else f"Bot nickname changed to **{discord.utils.escape_markdown(value)}**."),
                        mention_author=False)

    @commands.command(name="botreset", aliases=["resetbotbranding", "premreset", "brandingreset"],
                      help="Reset the bot nickname, avatar, banner and bio in this server to default.")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.guild)
    @blacklist_check()
    @ignore_check()
    async def botreset(self, ctx: commands.Context):
        if not await self._gate(ctx, premium=False):
            return
        problem = await self.patch_profile(ctx.guild.id, RESET_ALL, f"Reset by {ctx.author}")
        if problem:
            return await ctx.reply(embed=_err(problem), mention_author=False)
        await ctx.reply(embed=_ok("Nickname, avatar, banner and bio were reset to default."), mention_author=False)

    @commands.command(name="customise", aliases=["customize", "custom"],
                      help="Customise the bot's appearance in your server")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def customise(self, ctx: commands.Context):
        if not await self._gate(ctx):
            return
        view = CustomiseView(self, ctx)
        view.message = await ctx.reply(view=view, mention_author=False)

    @commands.command(name="customisereset", aliases=["customizereset", "customreset", "creset"],
                      help="Reset the bot's customized avatar, banner, and bio in this server to default")
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.guild)
    @blacklist_check()
    @ignore_check()
    async def customisereset(self, ctx: commands.Context):
        if not await self._gate(ctx, premium=False):
            return
        problem = await self.patch_profile(ctx.guild.id, RESET_LOOK, f"Reset by {ctx.author}")
        if problem:
            return await ctx.reply(embed=_err(problem), mention_author=False)
        await ctx.reply(embed=_ok("Avatar, banner and bio were reset to default."), mention_author=False)

    # ------------------------------------------------------------- info
    @commands.group(name="premium", aliases=["premiuminfo", "premiumhelp"], invoke_without_command=True,
                    help="See what premium gives you and whether it is active here.")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def premium(self, ctx: commands.Context):
        if ctx.author.id in self.bot.owner_ids:          # bot owners get the management group help
            return await GroupHelpView(ctx, ctx.command, order=PREMIUM_ORDER).start()
        p = ctx.clean_prefix
        plan = store.plan_of(ctx.author.id)
        if plan:
            slots, exp = plan
            used = len(store.used_slots(ctx.author.id))
            you = (f"<:emoji_4:1566043104551768114> Premium ({used}/{slots if slots < 999 else '∞'} servers, "
                   f"{'lifetime' if exp is None else f'expires <t:{int(exp)}:R>'})")
        else:
            you = "<a:cross:1567096105299214336> No premium"
        if store.is_active(ctx.guild.id):
            server = f"<:emoji_4:1566043104551768114> Activated (by <@{store.activations[ctx.guild.id]}>)"
        else:
            server = "<a:cross:1567096105299214336> Not activated"
        dot = "\u25cf"
        box = discord.ui.Container()
        box.add_item(discord.ui.TextDisplay(f"## <a:pinfloat:1567124641347145809> {self.bot.user.name} Premium"))
        box.add_item(discord.ui.Separator())
        box.add_item(discord.ui.TextDisplay(f"> {dot} **You:** {you}\n> {dot} **This server:** {server}"))
        box.add_item(discord.ui.Separator())
        box.add_item(discord.ui.TextDisplay(
            "**What you get**\n"
            f"> {dot} Custom bot **name, avatar, banner & bio** in your server\n"
            f"> {dot} **Server no-prefix** for up to {MAX_SERVER_NP} members\n"
            f"> {dot} Your own **aliases** for any command\n"
            f"> {dot} Premium-only commands & profile extras"))
        box.add_item(discord.ui.Separator())
        box.add_item(discord.ui.TextDisplay(
            "**Commands**\n"
            f"> `{p}activate` / `{p}deactivate` \u2022 turn premium on or off for this server\n"
            f"> `{p}premiumstats` \u2022 your plans and active servers\n"
            f"> `{p}customise` \u2022 customise the bot's look in this server\n"
            f"> `{p}botname` `{p}botavatar` `{p}botbanner` `{p}botbio` `{p}botreset`\n"
            f"> `{p}servernp` \u2022 manage server no-prefix members\n"
            f"> `{p}cmdalias` \u2022 create custom command aliases"))
        view = discord.ui.LayoutView(timeout=None)
        view.add_item(box)
        row = discord.ui.ActionRow()
        row.add_item(discord.ui.Button(label="Get Premium", url=serverLink, style=discord.ButtonStyle.link,
                                       emoji="<:link:1566470776851529769>"))
        view.add_item(row)
        await ctx.reply(view=view, mention_author=False)

    @commands.command(name="premiumstats", aliases=["premstats", "pstats"],
                      help="View your premium plan, used slots and the servers you activated.")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def premiumstats(self, ctx: commands.Context):
        plan = store.plan_of(ctx.author.id)
        if not plan:
            return await ctx.reply(embed=_embed("<a:pinfloat:1567124641347145809> Premium Stats",
                                                f"You don't have a premium plan.\nGet one in the [support server]({serverLink})."),
                                   mention_author=False)
        slots, exp = plan
        used = store.used_slots(ctx.author.id)
        lines = []
        for gid in used:
            guild = self.bot.get_guild(gid)
            lines.append(f"• **{discord.utils.escape_markdown(guild.name) if guild else 'Unknown server'}** (`{gid}`)")
        servers = "\n".join(lines) if lines else "None yet – use `activate` in a server."
        await ctx.reply(embed=_embed("<a:pinfloat:1567124641347145809> Premium Stats", (
            f"**Plan:** {'Lifetime' if exp is None else f'expires <t:{int(exp)}:R> (<t:{int(exp)}:f>)'}\n"
            f"**Slots:** {len(used)}/{slots if slots < 999 else '∞'} used\n\n"
            f"**Servers you activated**\n{servers[:3000]}")), mention_author=False)

    # ------------------------------------------------------------- server no-prefix
    @commands.group(name="servernoprefix", aliases=["servernp", "npserver", "premiumnp"],
                    invoke_without_command=True,
                    help="Give up to 10 members of this server no-prefix access (premium).")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def servernoprefix(self, ctx: commands.Context):
        await self._np_list(ctx)

    async def _np_list(self, ctx: commands.Context):
        p = ctx.clean_prefix
        members = sorted(store.server_np.get(ctx.guild.id, ()))
        listing = "\n".join(f"`{i}.` <@{uid}> (`{uid}`)" for i, uid in enumerate(members, 1)) or "No members yet."
        await ctx.reply(embed=_embed(f"Server No-Prefix [{len(members)}/{MAX_SERVER_NP}]", (
            f"{listing}\n\n**Commands**\n"
            f"`{p}servernoprefix add <member>`\n`{p}servernoprefix remove <member>`\n"
            f"`{p}servernoprefix list`\n`{p}servernoprefix reset`")), mention_author=False)

    @servernoprefix.command(name="list", help="Show members with server no-prefix.")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def servernp_list(self, ctx: commands.Context):
        await self._np_list(ctx)

    @servernoprefix.command(name="add", help="Give a member no-prefix access in this server.")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def servernp_add(self, ctx: commands.Context, member: discord.Member):
        if not await self._gate(ctx):
            return
        current = store.server_np.get(ctx.guild.id, set())
        if member.bot:
            return await ctx.reply(embed=_err("Bots can't have no-prefix access."), mention_author=False)
        if member.id in current:
            return await ctx.reply(embed=_err(f"{member.mention} already has no-prefix access here."),
                                   mention_author=False)
        if len(current) >= MAX_SERVER_NP:
            return await ctx.reply(embed=_err(f"This server reached the limit of **{MAX_SERVER_NP}** no-prefix members."),
                                   mention_author=False)
        await store.add_server_np(ctx.guild.id, member.id)
        await ctx.reply(embed=_ok(f"{member.mention} can now use my commands **without a prefix** in this server "
                                  f"(**{len(current) + 1}/{MAX_SERVER_NP}**)."), mention_author=False)

    @servernoprefix.command(name="remove", aliases=["delete"], help="Remove a member's server no-prefix access.")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def servernp_remove(self, ctx: commands.Context, member: discord.User):
        if not await self._gate(ctx, premium=False):
            return
        if member.id not in store.server_np.get(ctx.guild.id, set()):
            return await ctx.reply(embed=_err(f"{member.mention} doesn't have server no-prefix access."),
                                   mention_author=False)
        await store.remove_server_np(ctx.guild.id, member.id)
        await ctx.reply(embed=_ok(f"Removed no-prefix access from {member.mention}."), mention_author=False)

    @servernoprefix.command(name="reset", aliases=["clear"], help="Remove everyone's server no-prefix access.")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def servernp_reset(self, ctx: commands.Context):
        if not await self._gate(ctx, premium=False):
            return
        count = len(store.server_np.get(ctx.guild.id, ()))
        await store.clear_server_np(ctx.guild.id)
        await ctx.reply(embed=_ok(f"Removed no-prefix access from **{count}** member(s)."), mention_author=False)

    # ------------------------------------------------------------- custom command aliases
    @commands.group(name="cmdalias", aliases=["customalias", "setalias", "commandalias", "calias"],
                    invoke_without_command=True,
                    help="Create your own custom aliases for any command in this (premium) server.")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def cmdalias(self, ctx: commands.Context):
        p = ctx.clean_prefix
        await ctx.reply(embed=_embed("<:link:1566470776851529769> Custom Command Aliases", (
            "Give any command your own short name in this server.\n\n"
            f"`{p}cmdalias add <alias> <command>` – e.g. `{p}cmdalias add b ban`\n"
            f"`{p}cmdalias remove <alias>`\n`{p}cmdalias list`\n`{p}cmdalias reset`\n\n"
            f"Limit: **{MAX_ALIASES}** aliases per server.")), mention_author=False)

    @cmdalias.command(name="add", aliases=["create", "set"], help="Create an alias for a command.")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def cmdalias_add(self, ctx: commands.Context, alias: str, *, command: str):
        if not await self._gate(ctx):
            return
        alias = alias.lower().strip()
        if not ALIAS_RE.match(alias):
            return await ctx.reply(embed=_err("An alias must be **1-32** letters, numbers, `_` or `-` (no spaces)."),
                                   mention_author=False)
        if self.bot.get_command(alias) is not None:
            return await ctx.reply(embed=_err(f"`{alias}` is already a command or alias of the bot."),
                                   mention_author=False)
        target = self.bot.get_command(command.strip().lower())
        if target is None or target.hidden:
            return await ctx.reply(embed=_err(f"I couldn't find a command called `{command.strip()[:50]}`."),
                                   mention_author=False)
        if target.parent is not None:
            return await ctx.reply(embed=_err("You can only alias **main** commands, not subcommands.\n"
                                              f"Alias `{target.root_parent.qualified_name}` instead and add the subcommand "
                                              "when you use it."), mention_author=False)
        table = store.aliases.get(ctx.guild.id, {})
        if alias not in table and len(table) >= MAX_ALIASES:
            return await ctx.reply(embed=_err(f"You reached the limit of **{MAX_ALIASES}** aliases."),
                                   mention_author=False)
        updated = alias in table
        await store.add_alias(ctx.guild.id, alias, target.qualified_name)
        await ctx.reply(embed=_ok(f"Alias `{alias}` {'updated' if updated else 'created'} → "
                                  f"`{target.qualified_name}`\nTry it: `{ctx.clean_prefix}{alias}`"),
                        mention_author=False)

    @cmdalias.command(name="remove", aliases=["delete", "del"], help="Remove one of your aliases.")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def cmdalias_remove(self, ctx: commands.Context, alias: str):
        if not await self._gate(ctx, premium=False):
            return
        if await store.remove_alias(ctx.guild.id, alias.lower().strip()):
            await ctx.reply(embed=_ok(f"Alias `{alias.lower()}` removed."), mention_author=False)
        else:
            await ctx.reply(embed=_err(f"`{alias}` isn't one of this server's aliases."), mention_author=False)

    @cmdalias.command(name="list", aliases=["all", "show"], help="Show this server's custom aliases.")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def cmdalias_list(self, ctx: commands.Context):
        table = store.aliases.get(ctx.guild.id, {})
        if not table:
            return await ctx.reply(embed=_embed("<:link:1566470776851529769> Custom Aliases", "No custom aliases yet."), mention_author=False)
        lines = [f"`{a}` → `{c}`" for a, c in sorted(table.items())]
        state = "" if store.is_active(ctx.guild.id) else "\n\n<a:emoji_250:1567101252712530020> Premium is not active, so aliases are paused."
        await ctx.reply(embed=_embed(f"<:link:1566470776851529769> Custom Aliases [{len(table)}/{MAX_ALIASES}]",
                                     "\n".join(lines)[:3500] + state), mention_author=False)

    @cmdalias.command(name="reset", aliases=["clear"], help="Remove all custom aliases of this server.")
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    async def cmdalias_reset(self, ctx: commands.Context):
        if not await self._gate(ctx, premium=False):
            return
        count = await store.clear_aliases(ctx.guild.id)
        await ctx.reply(embed=_ok(f"Removed **{count}** alias(es)."), mention_author=False)

    # ------------------------------------------------------------- owner tools: `premium <sub>`
    @premium.command(name="list", help="List all premium users and servers")
    @commands.is_owner()
    async def premium_list(self, ctx: commands.Context):
        lines = []
        for uid, (slots, exp) in store.plans.items():
            when = "lifetime" if exp is None else f"<t:{int(exp)}:R>"
            lines.append(f"<@{uid}> – {len(store.used_slots(uid))}/{slots} slots – {when}")
        servers = []
        for gid, uid in store.activations.items():
            guild = self.bot.get_guild(gid)
            name = discord.utils.escape_markdown(guild.name) if guild else "Unknown server"
            servers.append(f"**{name}** (`{gid}`) – by <@{uid}>")
        if not lines and not servers:
            return await ctx.reply(embed=_embed("Premium", "No premium users or servers."), mention_author=False)
        text = (f"**Users [{len(lines)}]**\n" + ("\n".join(lines) or "None") +
                f"\n\n**Servers [{len(servers)}]**\n" + ("\n".join(servers) or "None"))
        await ctx.reply(embed=_embed("<a:pinfloat:1567124641347145809> Premium List", text[:3900]), mention_author=False)

    @premium.command(name="add", help="Add premium to a user")
    @commands.is_owner()
    async def premium_add(self, ctx: commands.Context, user: discord.User, duration: str = "30d",
                          guild_limit: int = 1, *, reason: str = "No reason provided"):
        if not 1 <= guild_limit <= 50:
            return await ctx.reply(embed=_err("`guild_limit` must be between **1** and **50**."), mention_author=False)
        expires = _parse_duration(duration)
        if expires == "error":
            return await ctx.reply(embed=_err("Duration examples: `30d`, `2w`, `1mo`, `1y`, `lifetime`."),
                                   mention_author=False)
        await store.grant(user.id, guild_limit, expires)
        when = "Lifetime" if expires is None else f"expires <t:{int(expires)}:R>"
        await ctx.reply(embed=_ok(f"{user.mention} now has premium: **{guild_limit}** server slot(s), {when}.\n"
                                  f"Reason: {reason[:200]}"), mention_author=False)

    @premium.command(name="activate", help="Activate premium in the current server")
    @commands.is_owner()
    @commands.guild_only()
    async def premium_activate(self, ctx: commands.Context):
        await ctx.invoke(self.activate)

    @premium.command(name="revoke", help="Revoke premium from the current server")
    @commands.is_owner()
    @commands.guild_only()
    async def premium_revoke(self, ctx: commands.Context):
        await ctx.invoke(self.deactivate)

    @premium.command(name="remove", help="Remove premium from a user")
    @commands.is_owner()
    async def premium_remove(self, ctx: commands.Context, user: discord.User, *, reason: str = "No reason provided"):
        if user.id not in store.plans:
            return await ctx.reply(embed=_err(f"{user.mention} has no premium plan."), mention_author=False)
        freed = await store.revoke(user.id)
        for guild_id in freed:
            await self.patch_profile(guild_id, RESET_ALL, f"Premium plan removed: {reason[:200]}")
        await ctx.reply(embed=_ok(f"Premium removed from {user.mention} ({len(freed)} server(s) deactivated).\n"
                                  f"Reason: {reason[:200]}"), mention_author=False)

    @premium.command(name="status", help="Check premium status of a user")
    @commands.is_owner()
    async def premium_status(self, ctx: commands.Context, user: discord.User = None):
        user = user or ctx.author
        plan = store.plan_of(user.id)
        if not plan:
            return await ctx.reply(embed=_embed("<a:pinfloat:1567124641347145809> Premium Status", f"{user.mention} has **no** premium plan."),
                                   mention_author=False)
        slots, exp = plan
        used = store.used_slots(user.id)
        names = []
        for gid in used:
            guild = self.bot.get_guild(gid)
            names.append(f"• **{discord.utils.escape_markdown(guild.name) if guild else 'Unknown server'}** (`{gid}`)")
        await ctx.reply(embed=_embed("<a:pinfloat:1567124641347145809> Premium Status", (
            f"**User:** {user.mention}\n"
            f"**Plan:** {'Lifetime' if exp is None else f'expires <t:{int(exp)}:R> (<t:{int(exp)}:f>)'}\n"
            f"**Slots:** {len(used)}/{slots if slots < 999 else '∞'} used\n\n"
            f"**Servers**\n" + ("\n".join(names) or "None")[:2500])), mention_author=False)
