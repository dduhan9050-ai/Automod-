"""Ticket system (rewritten).

* `?ticket` group with the same 12 sub-commands as the reference bot.
* Panel + ticket message are native Components V2 containers, fully customisable
  (`?ticket setup`), with subcategories (each can ask its own questions).
* `?ticketvariables` lists every placeholder usable in the ticket texts.
* Buttons / menus use fixed `zticket:*` custom ids handled in `on_interaction`, so they
  keep working after a restart - ticket state lives in db/ticket.db, not in memory.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Optional

import aiosqlite
import discord
from discord.ext import commands

from utils import automation_ui as base
from utils import leaderboard_ui
from utils import ticket_ui as ui
from utils.Tools import blacklist_check, ignore_check
from utils.ticket_setup import SetupView, panel_problem, send_panel
from utils.ticket_store import store
from utils.ticket_vars import build_values

log = logging.getLogger("tickets")
NO_PINGS = discord.AllowedMentions.none()

HELP_ORDER = ["delete", "transcript", "staff", "adduser", "reset",
              "close", "edit", "setcategory", "removeuser", "config",
              "panel", "setup"]


def _guard(func):
    """guild-only + blacklist + ignore (used by every command)."""
    func = ignore_check()(func)
    func = blacklist_check()(func)
    return commands.guild_only()(func)


def _admin(func):
    return commands.has_permissions(administrator=True)(_guard(func))


class TicketSystem(commands.Cog, name="Tickets"):
    """Ticket commands."""

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self) -> None:
        await store.load()

    # ====================================================================
    # shared helpers
    # ====================================================================
    async def _owner_of(self, guild: discord.Guild, owner_id: int):
        return guild.get_member(owner_id) or await self.bot.fetch_user(owner_id)

    @staticmethod
    def _claimer_of(guild: discord.Guild, row: dict):
        cid = row.get("claimed_by")
        return guild.get_member(cid) if cid else None

    async def _update_welcome(self, channel: discord.TextChannel, *, disabled: bool = False) -> None:
        """Re-render the first message of a ticket (claim state / enabled state)."""
        row = await store.get_ticket(channel.id)
        if not row or not row.get("message_id"):
            return
        guild = channel.guild
        cfg = store.get(guild.id)
        try:
            message = await channel.fetch_message(row["message_id"])
            owner = await self._owner_of(guild, row["owner_id"])
            view = ui.ticket_view(guild, cfg, row, owner=owner, sub=store.find_sub(cfg, row["subcategory"]),
                                  channel=channel, claimer=self._claimer_of(guild, row), disabled=disabled)
            await message.edit(view=view, allowed_mentions=NO_PINGS)
        except (discord.NotFound, discord.Forbidden, discord.HTTPException):
            pass

    async def _log_transcript(self, guild: discord.Guild, channel: discord.TextChannel, row: dict,
                              actor, reason: Optional[str]) -> None:
        """Build the HTML transcript, post it to the transcript channel and DM it to the owner."""
        cfg = store.get(guild.id)
        owner = await self._owner_of(guild, row["owner_id"])
        sub = store.find_sub(cfg, row["subcategory"])
        try:
            data, filename, count = await ui.build_transcript(channel, f"{guild.name} • Ticket #{row['number']}")
        except discord.HTTPException:
            return
        claimer = self._claimer_of(guild, row)
        lines = [
            base.label("Ticket", f"`#{channel.name}` (`{row['number']}`)"),
            base.label("Opened By", f"{owner.mention} (`{owner.id}`)"),
            base.label("Subcategory", sub["label"] if sub else "`General`"),
            base.label("Claimed By", claimer.mention if claimer else "`Nobody`"),
            base.label("Closed By", actor.mention),
            base.label("Reason", ui.cut(reason or "No reason provided", 300)),
            base.label("Messages", f"`{count}`"),
        ]
        log_channel = guild.get_channel(cfg.get("transcript_id") or 0)
        if isinstance(log_channel, discord.TextChannel) and log_channel.permissions_for(guild.me).send_messages:
            try:
                await log_channel.send(view=ui.log_view("📄 Ticket Transcript", lines, filename),
                                       file=ui.make_file(data, filename), allowed_mentions=NO_PINGS)
            except discord.HTTPException as exc:
                log.warning("could not post transcript: %s", exc)
        if cfg["settings"].get("dm_transcript", True):
            try:
                await owner.send(view=ui.log_view(f"📄 Your ticket transcript • {guild.name}", lines, filename),
                                 file=ui.make_file(data, filename))
            except (discord.Forbidden, discord.HTTPException):
                pass

    # ---------------------------------------------------------- actions
    async def do_close(self, guild: discord.Guild, channel: discord.TextChannel, actor,
                       reason: Optional[str] = None) -> bool:
        row = await store.get_ticket(channel.id)
        if row is None or row["status"] == "closed":
            return False
        cfg = store.get(guild.id)
        sub = store.find_sub(cfg, row["subcategory"])
        await store.close_ticket(channel.id, actor.id, reason)
        row = await store.get_ticket(channel.id)
        owner = await self._owner_of(guild, row["owner_id"])
        if isinstance(owner, discord.Member):
            try:
                await channel.set_permissions(owner, view_channel=True, send_messages=False,
                                              read_message_history=True, reason="Ticket closed")
            except discord.HTTPException:
                pass
        await self._update_welcome(channel, disabled=True)
        await channel.send(view=ui.closed_view(guild, cfg, row, owner=owner, sub=sub, channel=channel,
                                               closer=actor, reason=reason), allowed_mentions=NO_PINGS)
        await self._log_transcript(guild, channel, row, actor, reason)
        return True

    async def do_reopen(self, guild: discord.Guild, channel: discord.TextChannel, actor) -> bool:
        row = await store.get_ticket(channel.id)
        if row is None or row["status"] != "closed":
            return False
        await store.reopen_ticket(channel.id)
        owner = await self._owner_of(guild, row["owner_id"])
        if isinstance(owner, discord.Member):
            try:
                await channel.set_permissions(owner, view_channel=True, send_messages=True,
                                              read_message_history=True, attach_files=True, embed_links=True,
                                              reason="Ticket reopened")
            except discord.HTTPException:
                pass
        await self._update_welcome(channel, disabled=False)
        await channel.send(view=ui.success("Ticket Reopened", ui.note(f"Reopened by {actor.mention}.")),
                           allowed_mentions=NO_PINGS)
        return True

    async def do_delete(self, guild: discord.Guild, channel: discord.TextChannel, actor) -> bool:
        row = await store.get_ticket(channel.id)
        if row is None:
            return False
        cfg = store.get(guild.id)
        if row["status"] != "closed":  # never lose a transcript
            reason = f"Deleted by {actor}"
            await store.close_ticket(channel.id, actor.id, reason)
            await self._log_transcript(guild, channel, await store.get_ticket(channel.id), actor, reason)
        delay = int(cfg["settings"].get("delete_delay", 5))
        if delay > 0:
            await channel.send(view=ui.warning(
                "Deleting Ticket", ui.note(f"This channel will be deleted in `{delay}` seconds.")))
            await asyncio.sleep(delay)
        await store.delete_ticket(channel.id)
        try:
            await channel.delete(reason=f"Ticket deleted by {actor}")
        except discord.HTTPException:
            return False
        return True

    # ---------------------------------------------------------- opening
    async def _blacklisted(self, user_id: int, guild_id: int) -> bool:
        try:
            async with aiosqlite.connect("db/block.db") as db:
                cur = await db.execute("SELECT 1 FROM user_blacklist WHERE user_id = ?", (str(user_id),))
                if await cur.fetchone():
                    return True
                cur = await db.execute("SELECT 1 FROM guild_blacklist WHERE guild_id = ?", (str(guild_id),))
                return await cur.fetchone() is not None
        except Exception:
            return False

    async def _begin_open(self, interaction: discord.Interaction, sub_id: str) -> None:
        guild, user = interaction.guild, interaction.user
        cfg = store.get(guild.id)

        if await self._blacklisted(user.id, guild.id):
            return await interaction.response.send_message(
                view=ui.error("Blacklisted", ui.note("You can't use this bot.")), ephemeral=True)

        sub = None
        if sub_id != "_":
            sub = store.find_sub(cfg, sub_id)
            if sub is None:
                return await interaction.response.send_message(view=ui.error(
                    "Option Unavailable", ui.note("This option no longer exists. Ask an admin to update the panel.")),
                    ephemeral=True)
        elif cfg["subcategories"]:
            return await interaction.response.send_message(view=ui.error(
                "Panel Outdated", ui.note("This panel is outdated. Ask an admin to update it.")), ephemeral=True)

        if panel_problem(guild, cfg):
            return await interaction.response.send_message(view=ui.error(
                "Tickets Not Ready", ui.note("The ticket system isn't fully set up yet. Please tell an admin.")),
                ephemeral=True)

        existing = [r for r in await store.open_tickets_of(guild.id, user.id) if guild.get_channel(r["channel_id"])]
        limit = int(cfg["settings"].get("max_open", 1))
        if len(existing) >= limit:
            links = "\n".join(f"{base.DOT} <#{r['channel_id']}>" for r in existing[:5])
            return await interaction.response.send_message(view=ui.warning(
                "Ticket Limit Reached", ui.note(f"You can only have `{limit}` open ticket(s)."), links), ephemeral=True)

        questions = list((sub or {}).get("questions") or [])
        if not questions and cfg["settings"].get("ask_reason"):
            questions = ["Why are you opening this ticket?"]
        if questions:
            return await interaction.response.send_modal(_AnswerModal(self, sub, questions[:5]))
        await interaction.response.defer(ephemeral=True)
        await self._create_ticket(interaction, sub, [])

    async def _create_ticket(self, interaction: discord.Interaction, sub: Optional[dict], answers: list) -> None:
        guild, user = interaction.guild, interaction.user
        cfg = store.get(guild.id)
        role = guild.get_role(cfg.get("staff_role_id") or 0)
        me = guild.me

        number = await store.next_number(guild.id)
        values = build_values(guild=guild, user=user, cfg=cfg, subcategory=sub,
                              ticket={"number": number, "answers": answers})
        name = ui.channel_name(cfg["settings"].get("name_format", "ticket-{ticket_number}"), values)

        category_id = (sub or {}).get("category_id") or cfg.get("category_id")
        category = guild.get_channel(category_id) if category_id else None
        if not isinstance(category, discord.CategoryChannel):
            category = None

        member_perms = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True,
                                                   attach_files=True, embed_links=True)
        staff_perms = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True,
                                                  attach_files=True, embed_links=True, manage_messages=True)
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True,
                                            manage_messages=True, embed_links=True, attach_files=True,
                                            read_message_history=True),
            user: member_perms,
        }
        staff_roles = [role] if role else []
        for rid in (sub or {}).get("roles", []):
            extra = guild.get_role(rid)
            if extra and extra not in staff_roles:
                staff_roles.append(extra)
        for r in staff_roles:
            overwrites[r] = staff_perms

        try:
            channel = await guild.create_text_channel(
                name=name, category=category, overwrites=overwrites,
                topic=f"Ticket #{number} • owner: {user.id} • {(sub or {}).get('label', 'General')}",
                reason=f"Ticket #{number} opened by {user}")
        except discord.HTTPException as exc:
            return await interaction.followup.send(view=ui.error(
                "Couldn't Create Ticket", ui.note(f"Discord refused: {str(exc)[:180]}"),
                ui.note("Check my permissions and that the category isn't full.")), ephemeral=True)

        await store.add_ticket(channel_id=channel.id, guild_id=guild.id, owner_id=user.id, number=number,
                               subcategory=(sub or {}).get("id"), answers=answers)
        row = await store.get_ticket(channel.id)

        ping_staff = cfg["settings"].get("ping_staff", True)
        pings = [user.mention] + ([r.mention for r in staff_roles] if ping_staff else [])
        view = ui.ticket_view(guild, cfg, row, owner=user, sub=sub, channel=channel, mention_line=" ".join(pings))
        message = await channel.send(view=view, allowed_mentions=discord.AllowedMentions(
            users=[user], roles=staff_roles if ping_staff else []))
        await store.set_message(channel.id, message.id)
        await interaction.followup.send(view=ui.created_view(channel), ephemeral=True)

    # ====================================================================
    # component routing
    # ====================================================================
    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type is not discord.InteractionType.component or interaction.guild is None:
            return
        cid = (interaction.data or {}).get("custom_id", "")
        if not cid.startswith("zticket:"):
            return
        try:
            await self._route(interaction, cid)
        except Exception:
            log.exception("ticket interaction failed (%s)", cid)
            try:
                view = ui.error("Something went wrong", ui.note("Please try again in a moment."))
                if interaction.response.is_done():
                    await interaction.followup.send(view=view, ephemeral=True)
                else:
                    await interaction.response.send_message(view=view, ephemeral=True)
            except discord.HTTPException:
                pass

    async def _ticket_context(self, interaction: discord.Interaction, *, staff_only: bool = False,
                              owner_or_staff: bool = False):
        """Return (cfg, row, sub) for the ticket this button belongs to, or None after replying."""
        cfg = store.get(interaction.guild.id)
        row = await store.get_ticket(interaction.channel_id)
        if row is None:
            await interaction.response.send_message(
                view=ui.error("Not a Ticket", ui.note("This ticket is no longer tracked.")), ephemeral=True)
            return None
        sub = store.find_sub(cfg, row["subcategory"])
        staff = ui.is_staff(interaction.user, cfg, sub)
        if (staff_only and not staff) or (owner_or_staff and not (staff or interaction.user.id == row["owner_id"])):
            await interaction.response.send_message(view=ui.error(
                "Not Allowed", ui.note("Only ticket staff can do that." if staff_only
                                       else "Only the ticket owner or staff can do that.")), ephemeral=True)
            return None
        return cfg, row, sub

    async def _route(self, interaction: discord.Interaction, cid: str) -> None:
        guild, channel = interaction.guild, interaction.channel

        if cid == ui.CID_SELECT:
            await self._begin_open(interaction, interaction.data["values"][0])
            # reset the menu so the same option can be picked again
            try:
                await interaction.message.edit(view=ui.panel_view(guild, store.get(guild.id)))
            except discord.HTTPException:
                pass
            return
        if cid.startswith(ui.CID_CREATE + ":"):
            return await self._begin_open(interaction, cid.split(":", 2)[2])

        if cid == ui.CID_CLAIM:
            ctx = await self._ticket_context(interaction, staff_only=True)
            if ctx is None:
                return
            _, row, _ = ctx
            if row["claimed_by"]:
                return await interaction.response.send_message(view=ui.warning(
                    "Already Claimed", ui.note(f"This ticket is claimed by <@{row['claimed_by']}>.")), ephemeral=True)
            await store.set_claim(channel.id, interaction.user.id)
            await interaction.response.defer()
            await self._update_welcome(channel)
            return await channel.send(view=ui.success("Ticket Claimed", ui.note(
                f"{interaction.user.mention} claimed this ticket and will help you.")), allowed_mentions=NO_PINGS)

        if cid == ui.CID_UNCLAIM:
            ctx = await self._ticket_context(interaction, staff_only=True)
            if ctx is None:
                return
            _, row, _ = ctx
            if row["claimed_by"] not in (None, interaction.user.id) and not interaction.user.guild_permissions.administrator:
                return await interaction.response.send_message(view=ui.error(
                    "Not Allowed", ui.note("Only the claimer or an admin can unclaim.")), ephemeral=True)
            await store.set_claim(channel.id, None)
            await interaction.response.defer()
            await self._update_welcome(channel)
            return await channel.send(view=ui.warning("Ticket Unclaimed", ui.note(
                f"{interaction.user.mention} released this ticket.")), allowed_mentions=NO_PINGS)

        if cid == ui.CID_CLOSE:
            ctx = await self._ticket_context(interaction, owner_or_staff=True)
            if ctx is None:
                return
            cfg, row, _ = ctx
            if row["status"] == "closed":
                return await interaction.response.send_message(
                    view=ui.warning("Already Closed", ui.note("This ticket is already closed.")), ephemeral=True)
            if cfg["settings"].get("confirm_close", True):
                return await interaction.response.send_message(view=ui.confirm_close_view(), ephemeral=True)
            await interaction.response.defer(ephemeral=True)
            await self.do_close(guild, channel, interaction.user)
            return await interaction.followup.send(view=ui.success("Ticket Closed"), ephemeral=True)

        if cid == ui.CID_CLOSE_NO:
            return await interaction.response.edit_message(
                view=ui.error("Cancelled", ui.note("The ticket stays open.")))

        if cid == ui.CID_CLOSE_YES:
            ctx = await self._ticket_context(interaction, owner_or_staff=True)
            if ctx is None:
                return
            await interaction.response.edit_message(view=ui.success("Closing Ticket", ui.note("One moment…")))
            await self.do_close(guild, channel, interaction.user)
            return

        if cid == ui.CID_REOPEN:
            if await self._ticket_context(interaction, staff_only=True) is None:
                return
            await interaction.response.defer()
            await self.do_reopen(guild, channel, interaction.user)
            return

        if cid == ui.CID_DELETE:
            if await self._ticket_context(interaction, staff_only=True) is None:
                return
            await interaction.response.defer()
            await self.do_delete(guild, channel, interaction.user)
            return

        if cid == ui.CID_TRANSCRIPT:
            if await self._ticket_context(interaction, staff_only=True) is None:
                return
            await interaction.response.defer(ephemeral=True, thinking=True)
            data, filename, count = await ui.build_transcript(channel, f"{guild.name} • {channel.name}")
            await interaction.followup.send(
                view=ui.log_view("📄 Transcript", [base.label("Messages", f"`{count}`")], filename),
                file=ui.make_file(data, filename), ephemeral=True)

    # ====================================================================
    # commands
    # ====================================================================
    async def _need_ticket(self, ctx: commands.Context, *, staff_only: bool = True):
        cfg = store.get(ctx.guild.id)
        row = await store.get_ticket(ctx.channel.id)
        if row is None:
            await ctx.reply(view=ui.error("Not a Ticket", ui.note("Use this command inside a ticket channel.")),
                            mention_author=False)
            return None
        sub = store.find_sub(cfg, row["subcategory"])
        staff = ui.is_staff(ctx.author, cfg, sub)
        if not staff and (staff_only or ctx.author.id != row["owner_id"]):
            await ctx.reply(view=ui.error("Not Allowed", ui.note(
                "Only ticket staff can use this command." if staff_only
                else "Only the ticket owner or staff can use this command.")), mention_author=False)
            return None
        return cfg, row, sub

    @commands.group(name="ticket", invoke_without_command=True, help="Ticket system commands",
                    extras={"help_order": HELP_ORDER})
    @_guard
    async def ticket(self, ctx: commands.Context):
        await ui.send_group_help(ctx, ctx.command)

    # ---- page 1 -----------------------------------------------------------
    @ticket.command(name="delete", help="Delete the ticket channel")
    @_guard
    async def ticket_delete(self, ctx: commands.Context):
        if await self._need_ticket(ctx) is None:
            return
        await self.do_delete(ctx.guild, ctx.channel, ctx.author)

    @ticket.command(name="transcript", help="Set the transcript channel")
    @_admin
    async def ticket_transcript(self, ctx: commands.Context, channel: discord.TextChannel):
        if not channel.permissions_for(ctx.guild.me).send_messages:
            return await ctx.reply(view=ui.error("Missing Permissions", ui.note(
                f"I can't send messages in {channel.mention}.")), mention_author=False)
        store.get(ctx.guild.id)["transcript_id"] = channel.id
        await store.save(ctx.guild.id)
        await ctx.reply(view=ui.success("Transcript Channel Set", base.label(
            "Channel", f"Ticket transcripts will be sent to {channel.mention}")), mention_author=False)

    @ticket.command(name="staff", help="Set the staff role")
    @_admin
    async def ticket_staff(self, ctx: commands.Context, role: discord.Role):
        if role.is_default() or role.managed:
            return await ctx.reply(view=ui.error("Invalid Role", ui.note(
                "Choose a normal role (not @everyone or a bot role).")), mention_author=False)
        store.get(ctx.guild.id)["staff_role_id"] = role.id
        await store.save(ctx.guild.id)
        await ctx.reply(view=ui.success("Staff Role Set", base.label(
            "Role", f"{role.mention} will manage tickets")), mention_author=False)

    @ticket.command(name="adduser", help="Add a user to the ticket")
    @_guard
    async def ticket_adduser(self, ctx: commands.Context, member: discord.Member):
        if await self._need_ticket(ctx) is None:
            return
        await ctx.channel.set_permissions(member, view_channel=True, send_messages=True, read_message_history=True,
                                          attach_files=True, embed_links=True, reason=f"Added by {ctx.author}")
        await ctx.reply(view=ui.success("User Added", base.label("Member", f"{member.mention} can now see this ticket")),
                        mention_author=False)

    @ticket.command(name="reset", help="Resets ticket system")
    @_admin
    async def ticket_reset(self, ctx: commands.Context):
        async def go() -> str:
            await store.reset(ctx.guild.id)
            return "Ticket settings were reset. Open tickets keep working."

        await leaderboard_ui.confirm(
            ctx, "Reset the whole ticket system (settings, panel design and subcategories)?", go)

    # ---- page 2 -----------------------------------------------------------
    @ticket.command(name="close", help="Close the current ticket")
    @_guard
    async def ticket_close(self, ctx: commands.Context):
        if await self._need_ticket(ctx, staff_only=False) is None:
            return
        if not await self.do_close(ctx.guild, ctx.channel, ctx.author):
            await ctx.reply(view=ui.warning("Already Closed", ui.note("This ticket is already closed.")),
                            mention_author=False)

    @ticket.command(name="edit", help="Edits ticket settings (Dashboard Only).")
    @_admin
    async def ticket_edit(self, ctx: commands.Context):
        await self._open_setup(ctx)

    @ticket.command(name="setcategory", help="Set the category channel for tickets")
    @_admin
    async def ticket_setcategory(self, ctx: commands.Context, category: discord.CategoryChannel):
        store.get(ctx.guild.id)["category_id"] = category.id
        await store.save(ctx.guild.id)
        await ctx.reply(view=ui.success("Ticket Category Set", base.label(
            "Category", f"New tickets will be created in **{category.name}**")), mention_author=False)

    @ticket.command(name="removeuser", help="Remove a user from the ticket")
    @_guard
    async def ticket_removeuser(self, ctx: commands.Context, member: discord.Member):
        found = await self._need_ticket(ctx)
        if found is None:
            return
        cfg, row, sub = found
        if member.id == row["owner_id"] or ui.is_staff(member, cfg, sub):
            return await ctx.reply(view=ui.error("Can't Remove", ui.note(
                "You can't remove the ticket owner or staff.")), mention_author=False)
        await ctx.channel.set_permissions(member, overwrite=None, reason=f"Removed by {ctx.author}")
        await ctx.reply(view=ui.success("User Removed", base.label("Member", f"{member.mention} was removed")),
                        mention_author=False)

    @ticket.command(name="config", help="Shows current ticket configuration")
    @_admin
    async def ticket_config(self, ctx: commands.Context):
        cfg = store.get(ctx.guild.id)
        await ctx.reply(view=ui.config_view(self.bot.user, ctx.guild, cfg, await store.open_count(ctx.guild.id)),
                        mention_author=False)

    # ---- page 3 -----------------------------------------------------------
    @ticket.command(name="panel", help="Send the ticket panel to a channel")
    @_admin
    async def ticket_panel(self, ctx: commands.Context, channel: Optional[discord.TextChannel] = None):
        channel = channel or ctx.channel
        cfg = store.get(ctx.guild.id)
        problem = panel_problem(ctx.guild, cfg)
        if problem:
            return await ctx.reply(view=ui.error("Can't Send Panel", ui.note(problem)), mention_author=False)
        if not channel.permissions_for(ctx.guild.me).send_messages:
            return await ctx.reply(view=ui.error("Missing Permissions", ui.note(
                f"I can't send messages in {channel.mention}.")), mention_author=False)
        await send_panel(ctx.guild, channel)
        if channel.id != ctx.channel.id:
            await ctx.reply(view=ui.success("Panel Sent", ui.note(f"The ticket panel was sent to {channel.mention}.")),
                            mention_author=False)

    @ticket.command(name="setup", help="Directs you to the dashboard to configure ticket system.")
    @_admin
    async def ticket_setup(self, ctx: commands.Context):
        await self._open_setup(ctx)

    async def _open_setup(self, ctx: commands.Context) -> None:
        view = SetupView(ctx.guild, ctx.author.id, ctx.clean_prefix)
        view.message = await ctx.reply(view=view, mention_author=False)

    # ---- variables ----------------------------------------------------------
    @commands.command(name="ticketvariables", aliases=["ticketvars", "ticketvariable", "tvars"],
                      help="Shows every variable you can use in the ticket system")
    @_guard
    async def ticketvariables(self, ctx: commands.Context):
        await ui.send_variables(ctx)


class _AnswerModal(discord.ui.Modal):
    """Questions of a subcategory (or the single 'reason' question)."""

    def __init__(self, cog: TicketSystem, sub: Optional[dict], questions: list[str]):
        super().__init__(title=ui.cut((sub or {}).get("label") or "Open a Ticket", 45), timeout=600)
        self.cog, self.sub, self.questions = cog, sub, questions
        self.inputs = []
        for i, question in enumerate(questions):
            item = discord.ui.TextInput(label=ui.cut(question, 45), required=(i == 0),
                                        style=discord.TextStyle.paragraph, max_length=800)
            self.add_item(item)
            self.inputs.append(item)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        answers = [[q, (i.value or "").strip()] for q, i in zip(self.questions, self.inputs)]
        await self.cog._create_ticket(interaction, self.sub, answers)

    async def on_error(self, interaction: discord.Interaction, error: Exception):
        log.exception("ticket answer modal failed", exc_info=error)
        try:
            view = ui.error("Something went wrong", ui.note("Please try again in a moment."))
            if interaction.response.is_done():
                await interaction.followup.send(view=view, ephemeral=True)
            else:
                await interaction.response.send_message(view=view, ephemeral=True)
        except discord.HTTPException:
            pass


async def setup(bot):
    await bot.add_cog(TicketSystem(bot))
