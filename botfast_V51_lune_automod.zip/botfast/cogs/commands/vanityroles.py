"""Vanity Roles.

Members who put the server vanity (e.g. ``.gg/amongusindia``) in their custom status get the
configured role automatically; it is taken away again when they remove it.

Fast by design:
  * event driven (``on_presence_update``) - no polling, no invite API calls
  * config cached in memory, DB is touched only on setup / reset
  * roles are added / removed with a single request (``atomic=False``)
  * every reply is a Components V2 container with the #ffffff accent
"""
from __future__ import annotations

import asyncio
import os
import re
import time

import aiosqlite
import discord
from discord.ext import commands

from core import Cog
from utils.Tools import blacklist_check, ignore_check

DB_PATH = "db/vanity.db"
WHITE = discord.Colour(0xFFFFFF)          # container accent  #ffffff
OK, BAD, BULLET = "<:emoji_4:1566043104551768114>", "<a:emoji_38:1567096105299214336>", "<a:whitearrow:1567140354833129472>"
BRAND = "Powered by Death Development™"

# A vanity role must never grant any of these.
DANGEROUS = (
    "administrator", "manage_guild", "manage_roles", "manage_channels", "manage_webhooks",
    "manage_messages", "manage_nicknames", "manage_expressions", "manage_threads", "manage_events",
    "kick_members", "ban_members", "moderate_members", "mention_everyone", "view_audit_log",
)

_PREFIX_RE = re.compile(r"^(?:https?://)?(?:www\.)?(?:discord(?:app)?\.(?:gg|com/invite)/|\.?gg/|/)", re.I)


def normalize(text: str) -> str | None:
    """'.gg/Code' | 'discord.gg/code' | 'https://discord.gg/code' | 'code'  ->  'code'."""
    text = _PREFIX_RE.sub("", text.strip().strip("`<>").lower())
    text = text.split("?")[0].strip("/ ")
    return text if re.fullmatch(r"[a-z0-9_-]{2,32}", text) else None


class Cfg:
    __slots__ = ("guild_id", "code", "role_id", "channel_id", "rx")

    def __init__(self, guild_id: int, code: str, role_id: int, channel_id: int) -> None:
        self.guild_id, self.code, self.role_id, self.channel_id = guild_id, code, role_id, channel_id
        self.rx = re.compile(rf"gg/{re.escape(code)}(?![a-z0-9_-])", re.I)

    @property
    def display(self) -> str:
        return f".gg/{self.code}"

    def matches(self, member: discord.Member) -> bool:
        for act in member.activities:
            if act.type is discord.ActivityType.custom:
                text = getattr(act, "state", None) or getattr(act, "name", None)
                if text and self.rx.search(text):
                    return True
        return False


# --------------------------------------------------------------------------
# Components V2 cards (white container)
# --------------------------------------------------------------------------
def card(title: str, body: str, *, thumb: str | None = None, footer: str | None = None) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView(timeout=None)
    box = discord.ui.Container(accent_colour=WHITE)
    text = discord.ui.TextDisplay(f"### {title}\n\n{body}")
    if thumb:
        box.add_item(discord.ui.Section(text, accessory=discord.ui.Thumbnail(media=thumb)))
    else:
        box.add_item(text)
    if footer:
        box.add_item(discord.ui.TextDisplay(f"-# {footer}"))
    view.add_item(box)
    return view


def err(title: str, message: str) -> discord.ui.LayoutView:
    return card(f"{BAD} {title}", f"> {message}")


def ok(title: str, body: str) -> discord.ui.LayoutView:
    return card(f"{OK} {title}", body)


class VanityRoles(Cog):
    """Vanity role system."""

    def __init__(self, bot):
        self.bot = bot
        self.cache: dict[int, Cfg] = {}
        self._busy: set[tuple[int, int]] = set()
        self._last: dict[tuple[int, int], tuple[bool, float]] = {}
        self._tasks: set[asyncio.Task] = set()

    # ------------------------------------------------------------------ lifecycle
    async def cog_load(self) -> None:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "CREATE TABLE IF NOT EXISTS vanity_config ("
                "guild_id INTEGER PRIMARY KEY, vanity TEXT NOT NULL, "
                "role_id INTEGER NOT NULL, channel_id INTEGER NOT NULL)"
            )
            # carry over setups made with the old module
            async with db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='vanity_roles'") as cur:
                if await cur.fetchone():
                    await db.execute(
                        "INSERT OR IGNORE INTO vanity_config (guild_id, vanity, role_id, channel_id) "
                        "SELECT guild_id, vanity, role_id, log_channel_id FROM vanity_roles"
                    )
            await db.commit()
            async with db.execute("SELECT guild_id, vanity, role_id, channel_id FROM vanity_config") as cur:
                rows = await cur.fetchall()
        for guild_id, vanity, role_id, channel_id in rows:
            code = normalize(vanity)
            if code:
                self.cache[guild_id] = Cfg(guild_id, code, role_id, channel_id)
        if self.bot.is_ready():
            self._spawn(self._sync_all())

    async def cog_unload(self) -> None:
        for task in list(self._tasks):
            task.cancel()

    async def cog_check(self, ctx) -> bool:
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        return await blacklist_check().predicate(ctx) and await ignore_check().predicate(ctx)

    def _spawn(self, coro) -> None:
        task = asyncio.create_task(coro)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    @staticmethod
    async def _send(ctx, view) -> None:
        try:
            await ctx.reply(view=view, mention_author=False)
        except discord.HTTPException:
            await ctx.send(view=view)

    @staticmethod
    def _can_manage(member: discord.Member) -> bool:
        perms = member.guild_permissions
        return member.id == member.guild.owner_id or perms.administrator or perms.manage_guild

    # ------------------------------------------------------------------ core logic
    async def _apply(self, member: discord.Member, cfg: Cfg, role: discord.Role, *, log: bool = True) -> bool:
        """Make the member's role match their status. Returns True when something changed."""
        if member.bot or member.status is discord.Status.offline:   # offline = presence unknown, never strip
            return False
        has = cfg.matches(member)
        if has == (member.get_role(role.id) is not None):
            return False
        key = (member.guild.id, member.id)
        last = self._last.get(key)
        if key in self._busy or (last and last[0] == has and time.monotonic() - last[1] < 10):
            return False
        self._busy.add(key)
        try:
            if has:
                await member.add_roles(role, reason=f"Vanity {cfg.display} in status", atomic=False)
            else:
                await member.remove_roles(role, reason=f"Vanity {cfg.display} removed from status", atomic=False)
        except (discord.Forbidden, discord.HTTPException):
            return False
        finally:
            self._busy.discard(key)
        self._last[key] = (has, time.monotonic())
        if len(self._last) > 5000:
            self._last.clear()
        if log:
            await self._log(member, cfg, role, has)
        return True

    async def _log(self, member: discord.Member, cfg: Cfg, role: discord.Role, added: bool) -> None:
        channel = member.guild.get_channel(cfg.channel_id)
        if channel is None or not channel.permissions_for(member.guild.me).send_messages:
            return
        if added:
            title = "Vanity Added"
            body = (f"{member.mention} has been given the **{role.name}** role for repping our vanity "
                    f"`{cfg.display}` in their status. Thanks for the Support!")
        else:
            title = "Vanity Removed"
            body = (f"{member.mention} has been removed from the **{role.name}** role for no longer repping our "
                    f"vanity `{cfg.display}` in their status. Thanks for your previous Support!")
        try:
            await channel.send(view=card(title, body, thumb=member.display_avatar.url),
                               allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException:
            pass

    async def _sync_guild(self, guild: discord.Guild) -> None:
        cfg = self.cache.get(guild.id)
        role = guild.get_role(cfg.role_id) if cfg else None
        if not cfg or not role:
            return
        for member in list(guild.members):
            if await self._apply(member, cfg, role, log=False):
                await asyncio.sleep(0.3)        # stay well under the role-edit rate limit

    async def _sync_all(self) -> None:
        for guild_id in list(self.cache):
            guild = self.bot.get_guild(guild_id)
            if guild:
                await self._sync_guild(guild)

    # ------------------------------------------------------------------ listeners
    @commands.Cog.listener()
    async def on_ready(self) -> None:
        self._spawn(self._sync_all())

    @commands.Cog.listener()
    async def on_presence_update(self, before: discord.Member, after: discord.Member) -> None:
        cfg = self.cache.get(after.guild.id)
        if cfg is None:
            return
        role = after.guild.get_role(cfg.role_id)
        if role is not None:
            await self._apply(after, cfg, role)

    @commands.Cog.listener()
    async def on_guild_remove(self, guild: discord.Guild) -> None:
        if self.cache.pop(guild.id, None):
            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute("DELETE FROM vanity_config WHERE guild_id = ?", (guild.id,))
                await db.commit()

    # ------------------------------------------------------------------ commands
    @commands.group(name="vanityroles", aliases=["vanityrole"], invoke_without_command=True)
    async def vanityroles(self, ctx: commands.Context):
        p = ctx.clean_prefix
        await self._send(ctx, card("Vanity Roles", (
            f"{BULLET} `{p}vanityroles setup <.gg/vanity> <@role> <#channel>`\n"
            f"{BULLET} `{p}vanityroles config`\n"
            f"{BULLET} `{p}vanityroles reset`\n\n"
            "> Members repping the vanity in their status get the role automatically")))

    @vanityroles.command(name="setup")
    async def vanityroles_setup(self, ctx: commands.Context, vanity: str = None, role: str = None, channel: str = None):
        if not self._can_manage(ctx.author):
            return await self._send(ctx, err("Missing Permissions", "You need the **Manage Server** permission to use this."))
        if not (vanity and role and channel):
            return await self._send(ctx, err(
                "Invalid Usage", f"`{ctx.clean_prefix}vanityroles setup <.gg/vanity> <@role> <#channel>`"))

        code = normalize(vanity)
        if not code:
            return await self._send(ctx, err("Invalid Vanity", "Give a valid vanity, e.g. `.gg/yourvanity`."))
        try:
            role_obj = await commands.RoleConverter().convert(ctx, role)
        except commands.BadArgument:
            return await self._send(ctx, err("Invalid Role", "I couldn't find that role."))
        try:
            chan = await commands.TextChannelConverter().convert(ctx, channel)
        except commands.BadArgument:
            return await self._send(ctx, err("Invalid Channel", "I couldn't find that text channel."))

        if role_obj.is_default() or role_obj.managed:
            return await self._send(ctx, err("Invalid Role", "That role can't be assigned manually."))
        for perm in DANGEROUS:
            if getattr(role_obj.permissions, perm, False):
                return await self._send(ctx, err(
                    "Dangerous Permission", f"Role {role_obj.mention} has restricted permission: `{perm}`"))
        me = ctx.guild.me
        if not me.guild_permissions.manage_roles:
            return await self._send(ctx, err("Missing Permissions", "I need the **Manage Roles** permission."))
        if role_obj >= me.top_role:
            return await self._send(ctx, err("Role Hierarchy", f"{role_obj.mention} is higher than my top role."))
        if ctx.author.id != ctx.guild.owner_id and role_obj >= ctx.author.top_role:
            return await self._send(ctx, err("Role Hierarchy", f"{role_obj.mention} is higher than your top role."))
        if not chan.permissions_for(me).send_messages:
            return await self._send(ctx, err("Missing Access", f"I can't send messages in {chan.mention}."))

        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "INSERT OR REPLACE INTO vanity_config (guild_id, vanity, role_id, channel_id) VALUES (?, ?, ?, ?)",
                (ctx.guild.id, code, role_obj.id, chan.id))
            await db.commit()
        cfg = Cfg(ctx.guild.id, code, role_obj.id, chan.id)
        self.cache[ctx.guild.id] = cfg

        await self._send(ctx, ok("Vanity Role Setup Complete", (
            f"{BULLET} __**Vanity Status:**__ `{cfg.display}`\n"
            f"{BULLET} __**Role:**__ {role_obj.mention}\n"
            f"{BULLET} __**Channel:**__ {chan.mention}\n\n"
            "> Users with this status will receive the role automatically")))
        self._spawn(self._sync_guild(ctx.guild))      # give the role to people already repping it

    @vanityroles.command(name="config", aliases=["show"])
    async def vanityroles_config(self, ctx: commands.Context):
        cfg = self.cache.get(ctx.guild.id)
        if cfg is None:
            return await self._send(ctx, err("No Configuration", "No vanity role configuration found in this server."))
        role = ctx.guild.get_role(cfg.role_id)
        chan = ctx.guild.get_channel(cfg.channel_id)
        thumb = (ctx.guild.icon or self.bot.user.display_avatar).url
        await self._send(ctx, card(f"{OK} Vanity Role Configuration", (
            f"{BULLET} __**Vanity Status:**__ `{cfg.display}`\n"
            f"{BULLET} __**Role:**__ {role.mention if role else '`Deleted role`'}\n"
            f"{BULLET} __**Channel:**__ {chan.mention if chan else '`Deleted channel`'}\n\n"
            "> Users with this status will receive the role."),
            thumb=thumb, footer=f"{BRAND} | <t:{int(time.time())}:t>"))

    @vanityroles.command(name="reset")
    async def vanityroles_reset(self, ctx: commands.Context):
        if not self._can_manage(ctx.author):
            return await self._send(ctx, err("Missing Permissions", "You need the **Manage Server** permission to use this."))
        if self.cache.pop(ctx.guild.id, None) is None:
            return await self._send(ctx, err("No Configuration", "No vanity role configuration found in this server."))
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM vanity_config WHERE guild_id = ?", (ctx.guild.id,))
            await db.commit()
        await self._send(ctx, ok("Vanity Roles Reset", "> The vanity role configuration has been removed."))
