"""Voice module (ZEON style): ``voice`` commands + ``vcrole`` (VC auto role).

* Every reply is a white (#ffffff) Components V2 card (one ``<:emoji_4:1566043104551768114> | text`` / ``<a:cross:1567096105299214336> | text`` line).
* Bulk commands (kickall, muteall, ...) run with 8 parallel workers.
* vcrole keeps its data in ``db/invc.db`` (table ``vcroles``, an ``enabled`` column is added on load),
  held in memory per guild, so the voice-state listener never touches SQLite on the hot path.
"""
from __future__ import annotations

from typing import Optional

import aiosqlite
import discord
from discord.ext import commands

from core import Cog
from utils import modui

VC_DB = "db/invc.db"

# permissions a VC auto role must NOT have (it is handed out automatically to everyone who joins a VC)
DANGEROUS = (
    "administrator", "manage_guild", "manage_roles", "manage_channels", "manage_messages", "manage_webhooks",
    "manage_nicknames", "manage_expressions", "manage_threads", "manage_events", "kick_members", "ban_members",
    "moderate_members", "mention_everyone", "view_audit_log", "mute_members", "deafen_members", "move_members",
)

MOVE = {"move_members": True}
MUTE = {"mute_members": True}
DEAF = {"deafen_members": True}
CHAN = {"manage_channels": True}


def _vc(ctx: commands.Context) -> Optional[discord.VoiceChannel]:
    state = ctx.author.voice
    return state.channel if state and state.channel else None


class Voice(Cog, name="Voice"):
    """Voice commands."""

    def __init__(self, bot):
        self.bot = bot

    # ------------------------------------------------------------- helpers
    async def _target(self, ctx, member: discord.Member) -> Optional[discord.VoiceChannel]:
        """The voice channel of ``member`` or an error reply (None)."""
        state = member.voice
        if state is None or state.channel is None:
            await modui.fail(ctx, f"{modui.who(member)} is not connected to any voice channel.")
            return None
        return state.channel

    async def _mine(self, ctx) -> Optional[discord.VoiceChannel]:
        channel = _vc(ctx)
        if channel is None:
            await modui.fail(ctx, "You are not connected to any voice channel.")
        return channel

    async def _bulk(self, ctx, members: list, fn, done: str, *, empty: str = "There is nobody to apply this to.") -> None:
        if not members:
            return await modui.fail(ctx, empty)
        progress = await modui.run_bulk(
            ctx, members, fn, start=f"Working on {len(members)} members...",
            done=lambda p: done.format(ok=p.ok, bad=p.bad, total=p.total) + (f" ({p.bad} failed)" if p.bad else ""))
        return progress

    # --------------------------------------------------------------- group
    @commands.group(name="voice", aliases=["vc"], invoke_without_command=True,
                    help="Lists all subcommands of voice group.")
    @modui.guard()
    async def voice(self, ctx: commands.Context):
        await ctx.send_help(ctx.command)

    # ---- single member
    @voice.command(name="kick", help="Kicks a user from their voice channel.")
    @modui.guard(MOVE, MOVE)
    async def voice_kick(self, ctx, member: discord.Member):
        channel = await self._target(ctx, member)
        if channel is None:
            return
        await member.move_to(None, reason=f"Voice kick by {ctx.author} ({ctx.author.id})")
        await modui.ok(ctx, f"Kicked {modui.who(member)} from {channel.mention}.")

    @voice.command(name="mute", help="Mutes a user in their voice channel.")
    @modui.guard(MUTE, MUTE)
    async def voice_mute(self, ctx, member: discord.Member):
        channel = await self._target(ctx, member)
        if channel is None:
            return
        if member.voice.mute:
            return await modui.fail(ctx, f"{modui.who(member)} is already muted.")
        await member.edit(mute=True, reason=f"Voice mute by {ctx.author} ({ctx.author.id})")
        await modui.ok(ctx, f"Muted {modui.who(member)} in {channel.mention}.")

    @voice.command(name="unmute", help="Unmutes a user in their voice channel.")
    @modui.guard(MUTE, MUTE)
    async def voice_unmute(self, ctx, member: discord.Member):
        channel = await self._target(ctx, member)
        if channel is None:
            return
        if not member.voice.mute:
            return await modui.fail(ctx, f"{modui.who(member)} is not muted.")
        await member.edit(mute=False, reason=f"Voice unmute by {ctx.author} ({ctx.author.id})")
        await modui.ok(ctx, f"Unmuted {modui.who(member)} in {channel.mention}.")

    @voice.command(name="deafen", help="Deafens a user in their voice channel.")
    @modui.guard(DEAF, DEAF)
    async def voice_deafen(self, ctx, member: discord.Member):
        channel = await self._target(ctx, member)
        if channel is None:
            return
        if member.voice.deaf:
            return await modui.fail(ctx, f"{modui.who(member)} is already deafened.")
        await member.edit(deafen=True, reason=f"Voice deafen by {ctx.author} ({ctx.author.id})")
        await modui.ok(ctx, f"Deafened {modui.who(member)} in {channel.mention}.")

    @voice.command(name="undeafen", help="Undeafens a user in their voice channel.")
    @modui.guard(DEAF, DEAF)
    async def voice_undeafen(self, ctx, member: discord.Member):
        channel = await self._target(ctx, member)
        if channel is None:
            return
        if not member.voice.deaf:
            return await modui.fail(ctx, f"{modui.who(member)} is not deafened.")
        await member.edit(deafen=False, reason=f"Voice undeafen by {ctx.author} ({ctx.author.id})")
        await modui.ok(ctx, f"Undeafened {modui.who(member)} in {channel.mention}.")

    @voice.command(name="move", help="Moves a specific user to another voice channel.")
    @modui.guard(MOVE, MOVE)
    async def voice_move(self, ctx, member: discord.Member, channel: discord.VoiceChannel):
        current = await self._target(ctx, member)
        if current is None:
            return
        if current.id == channel.id:
            return await modui.fail(ctx, f"{modui.who(member)} is already in {channel.mention}.")
        await member.move_to(channel, reason=f"Voice move by {ctx.author} ({ctx.author.id})")
        await modui.ok(ctx, f"Moved {modui.who(member)} from {current.mention} to {channel.mention}.")

    @voice.command(name="pull", help="Pulls a user into your current voice channel.")
    @modui.guard(MOVE, MOVE)
    async def voice_pull(self, ctx, member: discord.Member):
        mine = await self._mine(ctx)
        if mine is None:
            return
        current = await self._target(ctx, member)
        if current is None:
            return
        if current.id == mine.id:
            return await modui.fail(ctx, f"{modui.who(member)} is already in your voice channel.")
        await member.move_to(mine, reason=f"Voice pull by {ctx.author} ({ctx.author.id})")
        await modui.ok(ctx, f"Pulled {modui.who(member)} from {current.mention} to {mine.mention}.")

    # ---- everyone in the author's channel
    @voice.command(name="kickall", help="Kicks all users from the current voice channel.")
    @modui.guard(MOVE, MOVE)
    async def voice_kickall(self, ctx):
        mine = await self._mine(ctx)
        if mine is None:
            return
        members = [m for m in mine.members if m.id != ctx.author.id]
        reason = f"Voice kickall by {ctx.author} ({ctx.author.id})"
        await self._bulk(ctx, members, lambda m: m.move_to(None, reason=reason),
                         f"Kicked {{ok}} members from {mine.mention}.", empty="Nobody else is in your voice channel.")

    @voice.command(name="muteall", help="Mutes all users in your current voice channel.")
    @modui.guard(MUTE, MUTE)
    async def voice_muteall(self, ctx):
        mine = await self._mine(ctx)
        if mine is None:
            return
        members = [m for m in mine.members if m.id != ctx.author.id and not m.voice.mute]
        reason = f"Voice muteall by {ctx.author} ({ctx.author.id})"
        await self._bulk(ctx, members, lambda m: m.edit(mute=True, reason=reason),
                         f"Muted {{ok}} members in {mine.mention}.", empty="Everyone else is already muted.")

    @voice.command(name="unmuteall", help="Unmutes all users in your current voice channel.")
    @modui.guard(MUTE, MUTE)
    async def voice_unmuteall(self, ctx):
        mine = await self._mine(ctx)
        if mine is None:
            return
        members = [m for m in mine.members if m.voice.mute]
        reason = f"Voice unmuteall by {ctx.author} ({ctx.author.id})"
        await self._bulk(ctx, members, lambda m: m.edit(mute=False, reason=reason),
                         f"Unmuted {{ok}} members in {mine.mention}.", empty="Nobody is muted in your voice channel.")

    @voice.command(name="deafenall", help="Deafens all users in your current voice channel.")
    @modui.guard(DEAF, DEAF)
    async def voice_deafenall(self, ctx):
        mine = await self._mine(ctx)
        if mine is None:
            return
        members = [m for m in mine.members if m.id != ctx.author.id and not m.voice.deaf]
        reason = f"Voice deafenall by {ctx.author} ({ctx.author.id})"
        await self._bulk(ctx, members, lambda m: m.edit(deafen=True, reason=reason),
                         f"Deafened {{ok}} members in {mine.mention}.", empty="Everyone else is already deafened.")

    @voice.command(name="undeafenall", help="Undeafens all users in your current voice channel.")
    @modui.guard(DEAF, DEAF)
    async def voice_undeafenall(self, ctx):
        mine = await self._mine(ctx)
        if mine is None:
            return
        members = [m for m in mine.members if m.voice.deaf]
        reason = f"Voice undeafenall by {ctx.author} ({ctx.author.id})"
        await self._bulk(ctx, members, lambda m: m.edit(deafen=False, reason=reason),
                         f"Undeafened {{ok}} members in {mine.mention}.", empty="Nobody is deafened in your voice channel.")

    @voice.command(name="moveall", help="Moves users from the current channel to another.")
    @modui.guard(MOVE, MOVE)
    async def voice_moveall(self, ctx, channel: discord.VoiceChannel):
        mine = await self._mine(ctx)
        if mine is None:
            return
        if mine.id == channel.id:
            return await modui.fail(ctx, "You are already in that voice channel.")
        reason = f"Voice moveall by {ctx.author} ({ctx.author.id})"
        await self._bulk(ctx, list(mine.members), lambda m: m.move_to(channel, reason=reason),
                         f"Moved {{ok}} members from {mine.mention} to {channel.mention}.")

    @voice.command(name="pullall", help="Pulls all users from a specified voice channel.")
    @modui.guard(MOVE, MOVE)
    async def voice_pullall(self, ctx, channel: discord.VoiceChannel):
        mine = await self._mine(ctx)
        if mine is None:
            return
        if mine.id == channel.id:
            return await modui.fail(ctx, "That is already your voice channel.")
        reason = f"Voice pullall by {ctx.author} ({ctx.author.id})"
        await self._bulk(ctx, list(channel.members), lambda m: m.move_to(mine, reason=reason),
                         f"Pulled {{ok}} members from {channel.mention} to {mine.mention}.",
                         empty=f"Nobody is in {channel.mention}.")

    # ---- channel permissions
    async def _perm(self, ctx, reason: str, text: str, **perms) -> None:
        mine = await self._mine(ctx)
        if mine is None:
            return
        await mine.set_permissions(ctx.guild.default_role, reason=f"{reason} by {ctx.author} ({ctx.author.id})", **perms)
        await modui.ok(ctx, text.format(ch=mine.mention))

    @voice.command(name="lock", help="Locks the current voice channel.")
    @modui.guard(CHAN, CHAN)
    async def voice_lock(self, ctx):
        await self._perm(ctx, "Voice lock", "Locked {ch}.", connect=False)

    @voice.command(name="unlock", help="Unlocks the current voice channel.")
    @modui.guard(CHAN, CHAN)
    async def voice_unlock(self, ctx):
        await self._perm(ctx, "Voice unlock", "Unlocked {ch}.", connect=True)

    @voice.command(name="private", help="Makes the current voice channel private.")
    @modui.guard(CHAN, CHAN)
    async def voice_private(self, ctx):
        await self._perm(ctx, "Voice private", "{ch} is now private.", connect=False, view_channel=False)

    @voice.command(name="unprivate", help="Makes the current voice channel public.")
    @modui.guard(CHAN, CHAN)
    async def voice_unprivate(self, ctx):
        await self._perm(ctx, "Voice unprivate", "{ch} is now public.", connect=True, view_channel=True)


class VcRole(Cog, name="VcRole"):
    """VC auto role: members get the role while they are in a voice channel."""

    def __init__(self, bot):
        self.bot = bot
        self._cache: dict[int, tuple[Optional[int], bool]] = {}  # guild -> (role_id, enabled)

    async def cog_load(self) -> None:
        async with aiosqlite.connect(VC_DB) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS vcroles (guild_id INTEGER PRIMARY KEY, role_id INTEGER NOT NULL)")
            try:
                await db.execute("ALTER TABLE vcroles ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1")
            except aiosqlite.OperationalError:
                pass  # column already there
            await db.commit()

    async def _get(self, guild_id: int) -> tuple[Optional[int], bool]:
        hit = self._cache.get(guild_id)
        if hit is not None:
            return hit
        async with aiosqlite.connect(VC_DB) as db:
            async with db.execute("SELECT role_id, enabled FROM vcroles WHERE guild_id = ?", (guild_id,)) as cur:
                row = await cur.fetchone()
        data = (int(row[0]), bool(row[1])) if row else (None, False)
        self._cache[guild_id] = data
        return data

    async def _write(self, sql: str, args: tuple, guild_id: int) -> None:
        async with aiosqlite.connect(VC_DB) as db:
            await db.execute(sql, args)
            await db.commit()
        self._cache.pop(guild_id, None)

    @commands.group(name="vcrole", invoke_without_command=True, help="Lists all subcommands of vcrole group.")
    @modui.guard()
    async def vcrole(self, ctx: commands.Context):
        await ctx.send_help(ctx.command)

    @vcrole.command(name="set", help="Sets the role given to members while they are in a voice channel.")
    @modui.guard({"administrator": True})
    async def vcrole_set(self, ctx, role: discord.Role):
        problem = modui.role_error(ctx, role)
        if problem:
            return await modui.fail(ctx, problem)
        if any(getattr(role.permissions, p, False) for p in DANGEROUS):
            return await modui.fail(ctx, "It has dangerous permissions and cannot be used as a VC role.")
        await self._write(
            "INSERT INTO vcroles (guild_id, role_id, enabled) VALUES (?, ?, 1) "
            "ON CONFLICT(guild_id) DO UPDATE SET role_id = excluded.role_id, enabled = 1",
            (ctx.guild.id, role.id), ctx.guild.id)
        await modui.ok(ctx, f"The VC role has been set to {role.mention} and enabled.")

    @vcrole.command(name="enable", help="Enables the VC role system.")
    @modui.guard({"administrator": True})
    async def vcrole_enable(self, ctx):
        role_id, enabled = await self._get(ctx.guild.id)
        if not role_id:
            return await modui.fail(ctx, "No voice role is configured in this server.")
        if enabled:
            return await modui.fail(ctx, "The voice role system is already enabled.")
        await self._write("UPDATE vcroles SET enabled = 1 WHERE guild_id = ?", (ctx.guild.id,), ctx.guild.id)
        await modui.ok(ctx, "The voice role system has been enabled.")

    @vcrole.command(name="disable", help="Disables the VC role system.")
    @modui.guard({"administrator": True})
    async def vcrole_disable(self, ctx):
        role_id, enabled = await self._get(ctx.guild.id)
        if not role_id:
            return await modui.fail(ctx, "No voice role is configured in this server.")
        if not enabled:
            return await modui.fail(ctx, "The voice role system is already disabled.")
        await self._write("UPDATE vcroles SET enabled = 0 WHERE guild_id = ?", (ctx.guild.id,), ctx.guild.id)
        await modui.ok(ctx, "The voice role system has been disabled.")

    @vcrole.command(name="show", help="Shows the current VC role configuration.")
    @modui.guard({"administrator": True})
    async def vcrole_show(self, ctx):
        role_id, enabled = await self._get(ctx.guild.id)
        if not role_id:
            return await modui.fail(ctx, "No voice role system is configured for this server.")
        role = ctx.guild.get_role(role_id)
        shown = role.mention if role else "*deleted role*"
        await modui.ok(ctx, f"VC role: {shown} | Status: **{'Enabled' if enabled else 'Disabled'}**")

    @vcrole.command(name="reset", help="Resets the VC role configuration.")
    @modui.guard({"administrator": True})
    async def vcrole_reset(self, ctx):
        role_id, _ = await self._get(ctx.guild.id)
        if not role_id:
            return await modui.fail(ctx, "No voice role system is configured for this server.")
        await self._write("DELETE FROM vcroles WHERE guild_id = ?", (ctx.guild.id,), ctx.guild.id)
        await modui.ok(ctx, "The voice role configuration has been reset.")

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if before.channel == after.channel:  # mute / deafen / stream toggles fire this too
            return
        role_id, enabled = await self._get(member.guild.id)
        if not role_id or not enabled:
            return
        role = member.guild.get_role(role_id)
        if role is None:
            return
        try:
            if after.channel and role not in member.roles:
                await member.add_roles(role, reason="Member joined VC | VC role")
            elif not after.channel and role in member.roles:
                await member.remove_roles(role, reason="Member left VC | VC role")
        except discord.HTTPException:
            pass  # missing permission / role above mine: nothing useful to do per event
