import discord
import json
import time as _time
import aiosqlite
from discord.ext import commands
from utils.config import serverLink
from core import axon, Cog, Context
from utils.Tools import get_ignore_data
from utils import antinuke_ui as anti_ui
from utils import modui
from utils import ratelimit
from utils.ratelimit import TempBlacklisted

class Errors(Cog):
  def __init__(self, client: axon):
    self.client = client

  async def _fake_perm_bypass(self, ctx: Context, error) -> bool:
    try:
      from utils.permit_store import store
      from utils.Tools import blacklist_check, ignore_check
      if not await store.fake_covers(ctx.author, error.missing_permissions):
        return False
      # keep blacklist / ignore rules in force, reinvoke only skips the permission check
      if not await blacklist_check().predicate(ctx) or not await ignore_check().predicate(ctx):
        return False
      await ctx.command.reinvoke(ctx)
      return True
    except commands.CommandError as exc:
      self.client.dispatch("command_error", ctx, exc)
      return True
    except Exception as exc:
      self.client.dispatch("command_error", ctx, commands.CommandInvokeError(exc))
      return True

  @commands.Cog.listener()
  async def on_command_error(self, ctx: Context, error):
    if ctx.command is None:
      return
    

    if isinstance(error, commands.CommandNotFound):
      return

    # Rate-limit protection: temporary blacklist (see utils/ratelimit.py)
    if isinstance(error, TempBlacklisted):
      left = ratelimit.human(error.until - _time.time())
      if error.first:
        text = (f"{ctx.author.mention} <a:emoji_250:1567101252712530020> **Slow down!** You were sending commands too fast, so you are "
                f"**temporarily blacklisted for {left}** (ends <t:{int(error.until)}:R>).\n"
                f"-# Strike **#{error.strikes}** \u2022 every repeat doubles the time "
                f"(10m \u2192 20m \u2192 40m \u2192 ...).")
      elif ratelimit.should_notify(error.user_id):
        text = (f"{ctx.author.mention} \u26d4 You are temporarily blacklisted. "
                f"You can use my commands again <t:{int(error.until)}:R>.")
      else:
        return                       # already told them recently - stay silent, no reply spam
      try:
        await ctx.send(text, delete_after=30)
      except discord.HTTPException:
        pass
      return

    # Moderation module: white V2 cards with <:emoji_4:1566043104551768114> / <a:cross:1567096105299214336> / <a:warn:1567101252712530020> (permission errors are handled below, after the Permit bypass)
    if ctx.command.cog_name in modui.MOD_COGS and not isinstance(error, commands.MissingPermissions):
      if await modui.handle_error(ctx, error):
        return

    if isinstance(error, (commands.MissingRequiredArgument, commands.BadArgument)) and ctx.command.cog_name == "Antinuke":
      await ctx.send(view=anti_ui.usage_notice(ctx.clean_prefix, ctx.command))
      ctx.command.reset_cooldown(ctx)
      return

    if isinstance(error, commands.MissingRequiredArgument):
      await ctx.send_help(ctx.command)
      ctx.command.reset_cooldown(ctx)
      return

    if isinstance(error, commands.CheckFailure) and ctx.guild is not None:
      data = await get_ignore_data(ctx.guild.id)
      ch = data["channel"]
      iuser = data["user"]
      cmd = data["command"]
      buser = data["bypassuser"]

      if str(ctx.author.id) in buser:
        return

      if str(ctx.channel.id) in ch:
        await ctx.reply(f"{ctx.author.mention} This **channel** is on the **ignored** list. Please try my commands in another channel.",
                        delete_after=8)
        return

      if str(ctx.author.id) in iuser:
        await ctx.reply(f"{ctx.author.mention} You are set as an **ignored user** for this guild. Please try my commands or modules in a different guild.", delete_after=8)
        return

      if data.get("role") and any(str(r.id) in data["role"] for r in getattr(ctx.author, "roles", ())):
        await ctx.reply(f"{ctx.author.mention} One of your **roles** is on the **ignored** list for this guild.", delete_after=8)
        return

      if ctx.command.name in cmd or any(alias in cmd for alias in ctx.command.aliases):
        await ctx.reply(f"{ctx.author.mention} This **command is ignored** in this guild. Please use other commands or try this command in a different guild", delete_after=8)
        return

    if isinstance(error, commands.NoPrivateMessage):
      embed = discord.Embed(color=0x000000, description="You can't use my commands in DMs.")
      embed.set_author(name=ctx.author, icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
      embed.set_thumbnail(url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
      await ctx.reply(embed=embed, delete_after=20)
      return

    if isinstance(error, commands.TooManyArguments):
      await ctx.send_help(ctx.command)
      ctx.command.reset_cooldown(ctx)
      return

    if isinstance(error, commands.CommandOnCooldown):
      embed = discord.Embed(color=0x000000, description=f"{ctx.author.mention} Whoa, slow down there! You can run the command again in **{error.retry_after:.2f}** seconds.")
      embed.set_author(name="Cooldown", icon_url=self.client.user.display_avatar.url)
      
      embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
      await ctx.reply(embed=embed, delete_after=10)
      return

    if isinstance(error, commands.MaxConcurrencyReached):
      embed = discord.Embed(color=0x000000, description=f"{ctx.author.mention} This command is already in progress. Please let it finish and try again afterward.")
      embed.set_author(name="Command in Progress.", icon_url=self.client.user.display_avatar.url)
      
      embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
      await ctx.reply(embed=embed, delete_after=10)
      ctx.command.reset_cooldown(ctx)
      return

    if isinstance(error, commands.MissingPermissions):
      # Fake permissions (Permit module): roles granted these perms may run the command.
      if ctx.guild and await self._fake_perm_bypass(ctx, error):
        return
      if ctx.command.cog_name in modui.MOD_COGS:
        await modui.missing_perms(ctx, error)
        return
      missing = [perm.replace("_", " ").replace("guild", "server").title() for perm in error.missing_permissions]
      fmt = "{}, and {}".format(", ".join(missing[:-1]), missing[-1]) if len(missing) > 2 else " and ".join(missing)
      embed = discord.Embed(color=0x000000, description=f"You lack the **{fmt}** Permission to run the **{ctx.command.name}** command!")
      embed.set_author(name="Missing Permissions", icon_url=self.client.user.display_avatar.url)
      
      embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
      await ctx.reply(embed=embed, delete_after=7)
      ctx.command.reset_cooldown(ctx)
      return

    if isinstance(error, commands.BadArgument):
      await ctx.send_help(ctx.command)
      ctx.command.reset_cooldown(ctx)
      return

    if isinstance(error, commands.BotMissingPermissions):
      missing = ", ".join(error.missing_permissions)
      await ctx.reply(f' I need **{missing}** Permission to run the **{ctx.command.qualified_name}** command!', delete_after=7)
      return

    if isinstance(error, discord.HTTPException):
      return

    if isinstance(error, commands.CommandInvokeError):
      orig = error.original
      # Previously every crash inside a command was swallowed silently - log it and tell the user.
      if isinstance(orig, discord.Forbidden):
        try:
          await ctx.reply("<a:emoji_38:1567096105299214336> I don't have permission to do that here. Please check my role / channel permissions.", delete_after=8)
        except discord.HTTPException:
          pass
        return
      if isinstance(orig, discord.NotFound):
        return
      import traceback
      print(f"[command error] {ctx.command.qualified_name}: {orig!r}")
      traceback.print_exception(type(orig), orig, orig.__traceback__)
      try:
        await ctx.reply(f"<a:emoji_38:1567096105299214336> Something went wrong while running `{ctx.command.qualified_name}`. Please try again.", delete_after=10)
      except discord.HTTPException:
        pass
      return

