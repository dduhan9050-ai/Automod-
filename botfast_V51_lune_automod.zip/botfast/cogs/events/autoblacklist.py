import discord
from core import axon, Cog
from discord.ext import commands
import aiosqlite
import time
from collections import deque
from datetime import datetime, timedelta
from utils import ratelimit

class AutoBlacklist(Cog):
    def __init__(self, client: axon):
        self.client = client
        self.spam_cd_mapping = commands.CooldownMapping.from_cooldown(5, 5, commands.BucketType.member)
        self.spam_command_mapping = commands.CooldownMapping.from_cooldown(6, 10, commands.BucketType.member)
        self.last_spam = {}
        self.spam_threshold = 5
        self.spam_window = timedelta(minutes=10)
        self.db_path = 'db/block.db'
        self.bot_user_id = self.client.user.id if self.client.user else None
        self.guild_command_tracking: dict[int, deque] = {}

    async def add_to_blacklist(self, user_id=None, guild_id=None, channel=None):
        try:
            async with aiosqlite.connect(self.db_path) as db:
                timestamp = datetime.utcnow()
                if guild_id:
                    await db.execute('''
                        INSERT OR IGNORE INTO guild_blacklist (guild_id, timestamp) VALUES (?, ?)
                    ''', (guild_id, timestamp))
                    if channel:
                        embed = discord.Embed(
                            title="<:icons_warning:1327829522573430864> Guild Blacklisted",
                            description=(
                                f"This guild has been blacklisted due to spamming or automation. "
                                f"If you believe this is a mistake, please contact our [Support Server](https://discord.gg/cfYmz4634n) with any proof if possible."
                            ),
                            color=0x000000
                        )
                        await channel.send(embed=embed)
                elif user_id:
                    await db.execute('''
                        INSERT OR IGNORE INTO user_blacklist (user_id, timestamp) VALUES (?, ?)
                    ''', (user_id, timestamp))
                await db.commit()
            try:
                from utils.Tools import invalidate_check_caches
                invalidate_check_caches()
            except Exception:
                pass
        except aiosqlite.Error as e:
            print(f"Database error: {e}")

    async def check_and_blacklist_guild(self, guild_id):
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                '''
                SELECT COUNT(DISTINCT user_id) FROM user_blacklist 
                WHERE timestamp >= ?
                ''', 
                (datetime.utcnow() - self.spam_window,)
            ) as cursor:
                count = await cursor.fetchone()
                if count[0] >= self.spam_threshold:
                    try:
                        async with db.execute('SELECT channel_id FROM guild_settings WHERE guild_id = ?', (guild_id,)) as cursor:
                            channel_id = await cursor.fetchone()
                    except aiosqlite.Error:
                        channel_id = None  # table is optional / may not exist
                    if channel_id:
                        channel = self.client.get_channel(channel_id[0])
                        if channel:
                            await self.add_to_blacklist(None, guild_id, channel)

    @commands.Cog.listener()
    async def on_message(self, message):
        # NOTE: the old version counted EVERY chat message per guild here and blacklisted
        # the whole server when >8 messages arrived in 2s (any active server!).
        # That rate check now lives in on_command and only counts real command runs.
        if message.author.bot:
            return

        bucket = self.spam_cd_mapping.get_bucket(message)
        if not bucket.update_rate_limit():
            return  # fast path: nothing to do for 99% of messages

        bot_id = self.bot_user_id or (self.client.user.id if self.client.user else None)
        if bot_id and message.content in (f'<@{bot_id}>', f'<@!{bot_id}>'):
            if ratelimit.blocked_until(message.author.id):
                return
            async with aiosqlite.connect(self.db_path) as db:
                async with db.execute('SELECT 1 FROM user_blacklist WHERE user_id = ?', (message.author.id,)) as cursor:
                    if await cursor.fetchone():
                        return
            block = await ratelimit.punish(message.author.id)      # temporary, escalating (10m, 20m, 40m...)
            embed = discord.Embed(
                title="<:icons_warning:1327829522573430864> Temporarily Blacklisted",
                description=(f"{message.author.mention} has been blacklisted for "
                             f"**{ratelimit.human(block.until - time.time())}** for repeatedly mentioning me "
                             f"(strike #{block.strikes}, every repeat doubles the time)."),
                color=0x000000
            )
            try:
                await message.channel.send(embed=embed)
            except discord.HTTPException:
                pass
            return

        if message.guild:
            now = datetime.utcnow()
            cutoff = now - self.spam_window
            recent_spam = [t for t in self.last_spam.get(message.author.id, ()) if t >= cutoff]
            recent_spam.append(now)
            self.last_spam[message.author.id] = recent_spam
            if len(self.last_spam) > 5000:  # bound memory
                self.last_spam = {k: v for k, v in self.last_spam.items() if v and v[-1] >= cutoff}
            if len(recent_spam) >= self.spam_threshold:
                await self.check_and_blacklist_guild(message.guild.id)

    @commands.Cog.listener()
    async def on_command(self, ctx):
        if ctx.author.bot:
            return

        # ---- guild-wide command flood (real commands only) ----
        if ctx.guild is not None:
            now = time.monotonic()
            dq = self.guild_command_tracking.setdefault(ctx.guild.id, deque())
            dq.append(now)
            while dq and dq[0] < now - 2:
                dq.popleft()
            if len(dq) > 8:
                dq.clear()
                await self.add_to_blacklist(guild_id=ctx.guild.id, channel=ctx.channel)
                return

        # ---- per-user command flood: handled by utils.ratelimit.global_check (temporary, escalating block) ----
