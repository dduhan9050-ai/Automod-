import discord
from discord.ext import commands
import asyncio

class React(commands.Cog):

    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or "<@" not in message.content:
            return
        for owner in self.bot.owner_ids:
            if f"<@{owner}>" in message.content:
                try:
                    if owner == 931137196130443344:
                        
                        emojis = [
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468>",
                            "<a:king:1234399917792034846>",
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468> ",
                            "<a:king:1419197264680718468>",
                            "<a:king:1419197264680718468>"
                        ]
                        for emoji in emojis:
                            await message.add_reaction(emoji)
                    else:
                        
                        await message.add_reaction("<a:king:1419197264680718468>")
                except discord.errors.RateLimited as e:
                    await asyncio.sleep(e.retry_after)
                    await message.add_reaction("<a:king:1419197264680718468>")
                except Exception as e:
                    print(f"An unexpected error occurred Auto react owner mention: {e}")
