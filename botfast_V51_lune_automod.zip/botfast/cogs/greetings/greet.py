"""Greetings module (replaces the old Welcomer module).

Commands
    greet                       list the greet commands
    greet setup [channel]       set the welcome channel + open the configuration menu
    greet channel [channel]     show / set the welcome channel
    greet enable | disable      turn the welcome module on / off
    greet autodelete [seconds]  seconds before the welcome message is deleted (0 = never)
    greet config                show the current configuration
    greet test                  send a test welcome message to the welcome channel
    greet reset                 remove the welcome configuration of the server
    greet edit                  open the configuration menu again
    welcomesetup                hidden shortcut for `greet setup`

Configuration menu (dropdown + Save): Message, Author, Title, Description, Thumbnail (toggle),
Main Image, Footer, Color, Auto Delete.

Speed
    * every guild config lives in memory (the whole table is preloaded once) - a member join never
      touches SQLite;
    * the welcome message is built and sent in its own task, so the listener returns immediately and
      a burst of joins is greeted in parallel;
    * database writes only happen when somebody saves a setting.

Every command reply is a white (#ffffff) Components V2 card. The help-menu page of this module has no
accent colour (``help_plain``). The welcome message itself uses the colour picked in the menu
(white by default).
"""
from __future__ import annotations

import asyncio
import json
import os
from typing import Optional

import aiosqlite
import discord
from components_v2 import media_gallery
from discord.ext import commands

from core import Cog
from utils.Tools import blacklist_check, ignore_check
from utils.utilkit import (CORNER, CROSS, TICK, WHITE, apply_vars, card, check_url, parse_color)

DB_PATH = "db/greetings.db"
OLD_DB = "db/welcome.db"          # database of the removed Welcomer module (imported once)
MAX_AUTODELETE = 86400

COLUMNS = ("guild_id", "enabled", "channel_id", "message", "author", "title", "description",
           "thumbnail", "image", "footer", "color", "autodelete")

DEFAULTS: dict = {
    "enabled": 1,
    "channel_id": None,
    "message": "{user}",
    "author": "",
    "title": "Welcome to {server_name}!",
    "description": "Hey {user}, glad to have you here!\nYou are member #{server_membercount}.",
    "thumbnail": 1,
    "image": "",
    "footer": "",
    "color": None,                 # None = white (#ffffff)
    "autodelete": 0,
}

COMMAND_NAMES = ("greet", "greet setup", "greet channel", "greet enable", "greet disable",
                 "greet autodelete", "greet config", "greet test", "greet reset", "greet edit")

COMMAND_HELP = (
    ("greet setup [channel]", "Opens the welcome configuration menu."),
    ("greet channel [channel]", "Shows / sets the welcome message channel."),
    ("greet enable", "Enables the welcome module for this server."),
    ("greet disable", "Disables the welcome module for this server."),
    ("greet autodelete [seconds]", "Sets auto-delete duration in seconds. Use 0 to disable."),
    ("greet config", "Shows current welcome configuration."),
    ("greet test", "Sends a test welcome message to preview the setup."),
    ("greet reset", "Resets and removes the welcome configuration for this server."),
    ("greet edit", "Edits welcome settings."),
)

# (key, label, description) - exactly the entries of the configuration dropdown
MENU = (
    ("message", "Message", "Set the message that appears above the welcome embed"),
    ("author", "Author", "Set the author text of the welcome embed"),
    ("title", "Title", "Set the title of the welcome embed"),
    ("description", "Description", "Set the description of the welcome embed"),
    ("thumbnail", "Thumbnail", "Toggle member avatar thumbnail"),
    ("image", "Main Image", "Set the main image of the welcome embed"),
    ("footer", "Footer", "Set the footer text of the welcome embed"),
    ("color", "Color", "Set the color of the welcome embed"),
    ("autodelete", "Auto Delete", "Set how long before welcome message is deleted"),
)

# key -> (modal title, input label, max length, paragraph?, placeholder)
MODALS = {
    "message": ("Welcome Message", "Message above the embed", 1900, True, "Welcome {user}!"),
    "author": ("Welcome Author", "Author text", 256, False, "{server_name}"),
    "title": ("Welcome Title", "Embed title", 256, False, "Welcome to {server_name}!"),
    "description": ("Welcome Description", "Embed description", 4000, True,
                    "Hey {user}, you are member #{server_membercount}."),
    "image": ("Welcome Main Image", "Image link (https://...)", 500, False, "https://..."),
    "footer": ("Welcome Footer", "Footer text", 500, False, "{server_name}"),
    "color": ("Welcome Color", "Hex colour", 7, False, "#ffffff"),
    "autodelete": ("Welcome Auto Delete", "Seconds (0 = never delete)", 5, False, "0"),
}


def _ok(text: str) -> discord.ui.LayoutView:
    return card(f"{TICK} {text}")


def _err(text: str) -> discord.ui.LayoutView:
    return card(f"{CROSS} {text}")


def _done(title: str, text: str) -> discord.ui.LayoutView:
    return card(f"{TICK} **{title}**\n{CORNER} {text}")


def _short(text: Optional[str], limit: int = 120) -> str:
    text = (text or "").replace("\n", " ").strip()
    if not text:
        return "`Not set`"
    return f"`{text[:limit]}{'…' if len(text) > limit else ''}`"


# --------------------------------------------------------------------------- welcome message
def _http(url: Optional[str]) -> str:
    return url if url and url.startswith(("http://", "https://")) else ""


def build_welcome(cfg: dict, member: discord.Member) -> Optional[discord.ui.LayoutView]:
    """Welcome message as a Components V2 view (message above, embed-like container below)."""
    guild = member.guild

    def fmt(text: Optional[str]) -> str:
        return (apply_vars(text, member, guild) or "").strip()

    view = discord.ui.LayoutView(timeout=None)
    message = fmt(cfg.get("message"))[:1900]
    if message:
        view.add_item(discord.ui.TextDisplay(message))

    lines = []
    if fmt(cfg.get("author")):
        lines.append(f"**{fmt(cfg['author'])[:256]}**")
    if fmt(cfg.get("title")):
        lines.append(f"# {fmt(cfg['title'])[:256]}")
    if fmt(cfg.get("description")):
        lines.append(fmt(cfg["description"])[:3500])
    if fmt(cfg.get("footer")):
        lines.append(f"-# {fmt(cfg['footer'])[:500]}")
    image = _http(fmt(cfg.get("image")))
    thumb = member.display_avatar.url if cfg.get("thumbnail") else None

    if lines or image or thumb:
        color = cfg.get("color")
        box = discord.ui.Container(accent_colour=discord.Colour(color) if color is not None else WHITE)
        if thumb:
            box.add_item(discord.ui.Section(discord.ui.TextDisplay("\n".join(lines) or "\u200b"),
                                            accessory=discord.ui.Thumbnail(media=thumb)))
        elif lines:
            box.add_item(discord.ui.TextDisplay("\n".join(lines)))
        if image:
            box.add_item(media_gallery(image))
        view.add_item(box)
    return view if view.children else None


# --------------------------------------------------------------------------- config menu
class FieldModal(discord.ui.Modal):
    def __init__(self, menu: "ConfigView", key: str):
        title, label, max_len, paragraph, placeholder = MODALS[key]
        super().__init__(title=title, timeout=300)
        self.menu = menu
        self.key = key
        current = menu.draft.get(key)
        if key == "color":
            current = f"#{current:06x}" if current is not None else "#ffffff"
        elif key == "autodelete":
            current = str(current or 0)
        self.field = discord.ui.TextInput(
            label=label, required=False, max_length=max_len, placeholder=placeholder[:100],
            style=discord.TextStyle.paragraph if paragraph else discord.TextStyle.short,
            default=(str(current)[:max_len] if current else None))
        self.add_item(self.field)

    def convert(self, value: str):
        if self.key == "color":
            return parse_color(value)
        if self.key == "autodelete":
            if not value:
                return 0
            if not value.isdigit() or int(value) > MAX_AUTODELETE:
                raise ValueError(f"Auto delete must be a number of seconds between `0` and `{MAX_AUTODELETE}`.")
            return int(value)
        if self.key == "image" and value and "{" not in value:
            return check_url(value, "Main image")
        return value

    async def on_submit(self, interaction: discord.Interaction):
        try:
            stored = self.convert(self.field.value.strip())
        except ValueError as exc:
            await interaction.response.send_message(view=_err(str(exc)), ephemeral=True)
            return
        self.menu.draft[self.key] = stored
        label = next(l for k, l, _ in MENU if k == self.key)
        self.menu.render(f"{label} updated. Press **Save** when you are done.")
        await interaction.response.edit_message(view=self.menu)


class OptionSelect(discord.ui.Select):
    def __init__(self, menu: "ConfigView"):
        super().__init__(
            placeholder="Select an option to configure", min_values=1, max_values=1,
            options=[discord.SelectOption(label=label, value=key, description=desc)
                     for key, label, desc in MENU])
        self.menu = menu

    async def callback(self, interaction: discord.Interaction):
        key = self.values[0]
        if key == "thumbnail":
            self.menu.draft["thumbnail"] = 0 if self.menu.draft.get("thumbnail") else 1
            state = "enabled" if self.menu.draft["thumbnail"] else "disabled"
            self.menu.render(f"Thumbnail {state}. Press **Save** when you are done.")
            await interaction.response.edit_message(view=self.menu)
            return
        await interaction.response.send_modal(FieldModal(self.menu, key))


class SaveButton(discord.ui.Button):
    def __init__(self, menu: "ConfigView"):
        super().__init__(label="Save", style=discord.ButtonStyle.success)
        self.menu = menu

    async def callback(self, interaction: discord.Interaction):
        await self.menu.cog._save(self.menu.guild_id, self.menu.draft)
        self.menu.finish()
        await interaction.response.edit_message(view=_ok("Welcome configuration updated."))


class ConfigView(discord.ui.LayoutView):
    def __init__(self, cog: "Greetings", ctx: commands.Context, draft: dict, note: str):
        super().__init__(timeout=300)
        self.cog = cog
        self.author_id = ctx.author.id
        self.guild_id = ctx.guild.id
        self.key = (ctx.guild.id, ctx.channel.id)
        self.draft = draft
        self.message: Optional[discord.Message] = None
        self.render(note)

    def render(self, note: str) -> None:
        self.clear_items()
        box = discord.ui.Container(accent_colour=WHITE)
        box.add_item(discord.ui.TextDisplay(
            f"{TICK} {note}\nSelect an option from the dropdown below to configure the welcome message settings."))
        select_row = discord.ui.ActionRow()
        select_row.add_item(OptionSelect(self))
        box.add_item(select_row)
        save_row = discord.ui.ActionRow()
        save_row.add_item(SaveButton(self))
        box.add_item(save_row)
        self.add_item(box)

    def finish(self) -> None:
        self.cog._sessions.pop(self.key, None)
        self.stop()

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(view=_err("Only the command author can use this menu."),
                                                    ephemeral=True)
            return False
        return True

    async def on_timeout(self) -> None:
        self.cog._sessions.pop(self.key, None)
        if self.message:
            try:
                await self.message.edit(view=_err("The welcome configuration menu timed out."))
            except discord.HTTPException:
                pass


class ConfirmReset(discord.ui.LayoutView):
    def __init__(self, cog: "Greetings", ctx: commands.Context):
        super().__init__(timeout=60)
        self.cog = cog
        self.author_id = ctx.author.id
        self.guild_id = ctx.guild.id
        self.message: Optional[discord.Message] = None
        box = discord.ui.Container(accent_colour=WHITE)
        box.add_item(discord.ui.TextDisplay("<a:emoji_250:1567101252712530020> **Reset the welcome configuration?**\n"
                                            f"{CORNER} This removes every welcome setting of this server."))
        row = discord.ui.ActionRow()
        yes = discord.ui.Button(label="Reset", style=discord.ButtonStyle.danger)
        no = discord.ui.Button(label="Cancel", style=discord.ButtonStyle.secondary)
        yes.callback = self._yes
        no.callback = self._no
        row.add_item(yes)
        row.add_item(no)
        box.add_item(row)
        self.add_item(box)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(view=_err("Only the command author can use this."),
                                                    ephemeral=True)
            return False
        return True

    async def _yes(self, interaction: discord.Interaction):
        await self.cog._delete(self.guild_id)
        self.stop()
        await interaction.response.edit_message(view=_done("Welcome Reset", "The welcome configuration was removed."))

    async def _no(self, interaction: discord.Interaction):
        self.stop()
        await interaction.response.edit_message(view=_err("Reset cancelled."))

    async def on_timeout(self) -> None:
        if self.message:
            try:
                await self.message.edit(view=_err("Reset cancelled (timed out)."))
            except discord.HTTPException:
                pass


# --------------------------------------------------------------------------- cog
class Greetings(Cog, name="Greetings"):
    """Welcome messages for new members."""

    help_plain = True   # no accent colour on this module's help-menu container

    def __init__(self, bot):
        self.bot = bot
        self._cfg: dict[int, dict] = {}
        self._sessions: dict[tuple[int, int], ConfigView] = {}
        self._tasks: set[asyncio.Task] = set()

    # ------------------------------------------------------------ help menu
    def help_custom(self):
        return "👋", "Greetings", "Show you Commands of Greetings"

    def help_body(self, prefix: str = "") -> str:
        names = [n for n in COMMAND_NAMES if self.bot.get_command(n)]
        return "__**Greetings**__\n" + " , ".join(f"`{n}`" for n in names)

    # ------------------------------------------------------------ storage
    async def cog_load(self) -> None:
        os.makedirs("db", exist_ok=True)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "CREATE TABLE IF NOT EXISTS greetings (guild_id INTEGER PRIMARY KEY, enabled INTEGER, "
                "channel_id INTEGER, message TEXT, author TEXT, title TEXT, description TEXT, "
                "thumbnail INTEGER, image TEXT, footer TEXT, color INTEGER, autodelete INTEGER)")
            await self._import_old(db)
            await db.commit()
            async with db.execute(f"SELECT {', '.join(COLUMNS)} FROM greetings") as cur:
                async for row in cur:
                    data = dict(zip(COLUMNS, row))
                    self._cfg[data.pop("guild_id")] = data

    @staticmethod
    async def _import_old(db: aiosqlite.Connection) -> None:
        """One-time import of db/welcome.db (old Welcomer module); the file is renamed afterwards."""
        if not os.path.exists(OLD_DB):
            return
        try:
            async with aiosqlite.connect(OLD_DB) as old:
                async with old.execute("SELECT guild_id, welcome_type, welcome_message, channel_id, "
                                       "embed_data, auto_delete_duration FROM welcome") as cur:
                    rows = await cur.fetchall()
            for gid, wtype, wmsg, chid, edata, auto in rows:
                cfg = dict(DEFAULTS, enabled=1, channel_id=chid, autodelete=int(auto or 0),
                           title="", description="", thumbnail=0, message=wmsg or "")
                if wtype == "embed" and edata:
                    info = json.loads(edata)
                    color = info.get("color")
                    if isinstance(color, str) and color.startswith("#"):
                        color = int(color[1:], 16)
                    cfg.update(
                        message=info.get("message") or "", author=info.get("author_name") or "",
                        title=info.get("title") or "", description=info.get("description") or "",
                        thumbnail=1 if info.get("thumbnail") else 0, image=info.get("image") or "",
                        footer=info.get("footer_text") or "", color=color if isinstance(color, int) else None)
                await db.execute(
                    f"INSERT OR IGNORE INTO greetings ({', '.join(COLUMNS)}) VALUES ({', '.join('?' * len(COLUMNS))})",
                    (gid, *(cfg[c] for c in COLUMNS[1:])))
            os.replace(OLD_DB, OLD_DB + ".migrated")
        except Exception as exc:  # never block the cog from loading
            print(f"[greetings] old welcome.db import skipped: {type(exc).__name__}: {exc}")

    async def _save(self, guild_id: int, cfg: dict) -> None:
        cfg = {c: cfg.get(c) for c in COLUMNS[1:]}
        self._cfg[guild_id] = cfg                       # cache first: the new settings are live instantly
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                f"INSERT OR REPLACE INTO greetings ({', '.join(COLUMNS)}) VALUES ({', '.join('?' * len(COLUMNS))})",
                (guild_id, *(cfg[c] for c in COLUMNS[1:])))
            await db.commit()

    async def _delete(self, guild_id: int) -> None:
        self._cfg.pop(guild_id, None)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM greetings WHERE guild_id = ?", (guild_id,))
            await db.commit()

    def _get(self, guild_id: int) -> dict:
        return dict(self._cfg.get(guild_id) or DEFAULTS)

    # ------------------------------------------------------------ welcome listener
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        cfg = self._cfg.get(member.guild.id)
        if not cfg or not cfg["enabled"] or not cfg["channel_id"]:
            return
        channel = member.guild.get_channel(cfg["channel_id"])
        if channel is None:
            return
        task = asyncio.create_task(self._welcome(cfg, member, channel))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    @commands.Cog.listener()
    async def on_guild_remove(self, guild: discord.Guild) -> None:
        if guild.id in self._cfg:
            await self._delete(guild.id)

    @staticmethod
    async def _welcome(cfg: dict, member: discord.Member, channel) -> None:
        view = build_welcome(cfg, member)
        if view is None:
            return
        try:
            await channel.send(view=view, delete_after=cfg.get("autodelete") or None)
        except discord.HTTPException:       # Forbidden / NotFound are subclasses
            pass

    async def cog_unload(self) -> None:
        for task in list(self._tasks):
            task.cancel()
        for menu in list(self._sessions.values()):
            menu.stop()

    # ------------------------------------------------------------ helpers
    @staticmethod
    async def _reply(ctx: commands.Context, view: discord.ui.LayoutView) -> discord.Message:
        return await ctx.reply(view=view, mention_author=False)

    async def _open_menu(self, ctx: commands.Context, note: str) -> None:
        key = (ctx.guild.id, ctx.channel.id)
        session = self._sessions.get(key)
        if session and not session.is_finished():
            await self._reply(ctx, _err("You already have an active welcome configuration menu in this channel. "
                                        "Please finish it before starting a new one."))
            return
        menu = ConfigView(self, ctx, self._get(ctx.guild.id), note)
        self._sessions[key] = menu
        menu.message = await self._reply(ctx, menu)

    async def _setup(self, ctx: commands.Context, channel: Optional[discord.TextChannel]) -> None:
        cfg = self._get(ctx.guild.id)
        if channel is None:
            existing = ctx.guild.get_channel(cfg["channel_id"]) if cfg["channel_id"] else None
            channel = existing or ctx.channel
        if not channel.permissions_for(ctx.guild.me).send_messages:
            await self._reply(ctx, _err(f"I can't send messages in {channel.mention}."))
            return
        if cfg["channel_id"] != channel.id or ctx.guild.id not in self._cfg:
            cfg["channel_id"] = channel.id
            await self._save(ctx.guild.id, cfg)
        await self._open_menu(ctx, f"Welcome channel set to {channel.mention}.")

    # ------------------------------------------------------------ commands
    @commands.hybrid_group(name="greet", invoke_without_command=True, help="Shows all the greet commands.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def greet(self, ctx: commands.Context):
        prefix = ctx.clean_prefix
        lines = "\n".join(f"`{prefix}{name}`\n{CORNER} {desc}" for name, desc in COMMAND_HELP)
        await self._reply(ctx, card(f"# GREETINGS\n{lines}"))

    @greet.command(name="setup", help="Sets the welcome channel and opens the welcome configuration menu.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def greet_setup(self, ctx: commands.Context, channel: Optional[discord.TextChannel] = None):
        await self._setup(ctx, channel)

    @commands.command(name="welcomesetup", hidden=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def welcomesetup(self, ctx: commands.Context, channel: Optional[discord.TextChannel] = None):
        await self._setup(ctx, channel)

    @greet.command(name="channel", help="Sets the welcome message channel.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def greet_channel(self, ctx: commands.Context, channel: Optional[discord.TextChannel] = None):
        cfg = self._get(ctx.guild.id)
        if channel is None:
            current = ctx.guild.get_channel(cfg["channel_id"]) if cfg["channel_id"] else None
            await self._reply(ctx, _ok(f"Welcome channel is {current.mention}.") if current else
                              _err(f"No welcome channel set. Use `{ctx.clean_prefix}greet channel <channel>`."))
            return
        if not channel.permissions_for(ctx.guild.me).send_messages:
            await self._reply(ctx, _err(f"I can't send messages in {channel.mention}."))
            return
        cfg["channel_id"] = channel.id
        await self._save(ctx.guild.id, cfg)
        await self._reply(ctx, _ok(f"Welcome channel set to {channel.mention}."))

    @greet.command(name="enable", help="Enables the welcome module for this server.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def greet_enable(self, ctx: commands.Context):
        cfg = self._get(ctx.guild.id)
        if not cfg["channel_id"]:
            await self._reply(ctx, _err(f"Set a welcome channel first with `{ctx.clean_prefix}greet setup`."))
            return
        cfg["enabled"] = 1
        await self._save(ctx.guild.id, cfg)
        await self._reply(ctx, _ok("Welcome module enabled."))

    @greet.command(name="disable", help="Disables the welcome module for this server.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def greet_disable(self, ctx: commands.Context):
        if ctx.guild.id not in self._cfg:
            await self._reply(ctx, _err("The welcome module is not configured."))
            return
        cfg = self._get(ctx.guild.id)
        cfg["enabled"] = 0
        await self._save(ctx.guild.id, cfg)
        await self._reply(ctx, _ok("Welcome module disabled."))

    @greet.command(name="autodelete", help="Sets auto-delete duration in seconds. Use 0 to disable.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def greet_autodelete(self, ctx: commands.Context, seconds: Optional[int] = None):
        cfg = self._get(ctx.guild.id)
        if seconds is None:
            current = cfg["autodelete"]
            await self._reply(ctx, _ok(f"Auto delete is set to `{current}s`." if current else "Auto delete is disabled."))
            return
        if not 0 <= seconds <= MAX_AUTODELETE:
            await self._reply(ctx, _err(f"Seconds must be between `0` and `{MAX_AUTODELETE}`."))
            return
        cfg["autodelete"] = seconds
        await self._save(ctx.guild.id, cfg)
        await self._reply(ctx, _ok(f"Welcome message will be deleted after `{seconds}s`." if seconds
                                   else "Auto delete disabled."))

    @greet.command(name="config", help="Shows current welcome configuration.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def greet_config(self, ctx: commands.Context):
        if ctx.guild.id not in self._cfg:
            await self._reply(ctx, _err(f"The welcome module is not configured. Use `{ctx.clean_prefix}greet setup`."))
            return
        cfg = self._get(ctx.guild.id)
        channel = ctx.guild.get_channel(cfg["channel_id"]) if cfg["channel_id"] else None
        color = f"#{cfg['color']:06x}" if cfg["color"] is not None else "#ffffff"
        auto = f"`{cfg['autodelete']}s`" if cfg["autodelete"] else "`Off`"
        text = (
            "# WELCOME CONFIGURATION\n"
            f"**Status:** {'Enabled' if cfg['enabled'] else 'Disabled'}\n"
            f"**Channel:** {channel.mention if channel else '`Not set`'}\n"
            f"**Auto Delete:** {auto}\n"
            f"**Thumbnail:** {'On' if cfg['thumbnail'] else 'Off'}\n"
            f"**Color:** `{color}`\n"
            f"**Message:** {_short(cfg['message'])}\n"
            f"**Author:** {_short(cfg['author'])}\n"
            f"**Title:** {_short(cfg['title'])}\n"
            f"**Description:** {_short(cfg['description'])}\n"
            f"**Main Image:** {_short(cfg['image'])}\n"
            f"**Footer:** {_short(cfg['footer'])}")
        await self._reply(ctx, card(text))

    @greet.command(name="test", help="Sends a test welcome message to preview the setup.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def greet_test(self, ctx: commands.Context):
        if ctx.guild.id not in self._cfg:
            await self._reply(ctx, _err(f"The welcome module is not configured. Use `{ctx.clean_prefix}greet setup`."))
            return
        cfg = self._get(ctx.guild.id)
        channel = ctx.guild.get_channel(cfg["channel_id"]) if cfg["channel_id"] else None
        if channel is None:
            await self._reply(ctx, _err("The welcome channel no longer exists. Set a new one with `greet channel`."))
            return
        view = build_welcome(cfg, ctx.author)
        if view is None:
            await self._reply(ctx, _err("The welcome message is empty. Configure it with `greet edit`."))
            return
        try:
            await channel.send(view=view, delete_after=cfg["autodelete"] or None)
        except discord.HTTPException:
            await self._reply(ctx, _err(f"I can't send messages in {channel.mention}."))
            return
        await self._reply(ctx, _ok(f"Test welcome message sent in {channel.mention}."))

    @greet.command(name="reset", help="Resets and removes the welcome configuration for this server.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def greet_reset(self, ctx: commands.Context):
        if ctx.guild.id not in self._cfg:
            await self._reply(ctx, _err("The welcome module is not configured."))
            return
        view = ConfirmReset(self, ctx)
        view.message = await self._reply(ctx, view)

    @greet.command(name="edit", help="Edits welcome settings.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def greet_edit(self, ctx: commands.Context):
        if ctx.guild.id not in self._cfg:
            await self._reply(ctx, _err(f"The welcome module is not configured. Use `{ctx.clean_prefix}greet setup`."))
            return
        await self._open_menu(ctx, "Editing the welcome configuration.")
