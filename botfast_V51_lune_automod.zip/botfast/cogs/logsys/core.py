"""Building blocks of the logging engine: embed helpers, audit-log buffer, webhook dispatcher."""
from __future__ import annotations

import asyncio
import logging
import time
from collections import deque
from typing import Any, Iterable, Optional, Sequence

import aiohttp
import discord

from utils.logging_store import Target, store

log = logging.getLogger("deathbot.logging")

# --------------------------------------------------------------------------- colours
GREEN = 0x2ECC71
RED = 0xE74C3C
GREY = 0x99AAB5
BLUE = 0x3498DB
TEAL = 0x1ABC9C
ORANGE = 0xE67E22
BLURPLE = 0x5865F2

HIGH_RISK = ("administrator", "manage_guild", "manage_roles", "manage_channels", "manage_webhooks",
             "ban_members", "kick_members", "mention_everyone")


# --------------------------------------------------------------------------- formatting helpers
def esc(text: Any) -> str:
    return discord.utils.escape_markdown(str(text))


def code(value: Any) -> str:
    return f"`{str(value).replace('`', '')}`" if str(value) else "`None`"


def user_line(user) -> str:
    """@name (<@id>)"""
    return f"@{esc(user.name)} ({user.mention})"


def when(dt, style: str = "R") -> str:
    return f"<t:{int(dt.timestamp())}:{style}>"


def perm_name(flag: str) -> str:
    return flag.removeprefix("use_").replace("_", " ").title()


def perm_list(flags: Iterable[str]) -> str:
    return ", ".join(perm_name(f) for f in flags)


def high_risk_of(perms: discord.Permissions) -> list[str]:
    if perms.administrator:
        return ["administrator"]
    return [name for name in HIGH_RISK if getattr(perms, name)]


def trim(text: Optional[str], limit: int = 1000) -> str:
    text = text or ""
    return text if len(text) <= limit else text[: limit - 1] + "…"


def make(title: str, color: int, rows: Sequence[tuple[str, Any]], *, extra: str | None = None,
         thumb: str | None = None, actor=None) -> discord.Embed:
    """Embed in the style of the reference logs: quoted ``**Label :** value`` lines + actor footer."""
    lines = []
    for label, value in rows:
        if value is None or value == "":
            continue
        value = str(value).replace("\n", "\n> ")
        lines.append(f"> **{label} :** {value}")
    description = "\n".join(lines)
    if extra:
        description += ("\n\n" if description else "") + extra
    embed = discord.Embed(title=title, description=description[:4090] or None, color=color,
                          timestamp=discord.utils.utcnow())
    if thumb:
        embed.set_thumbnail(url=thumb)
    if actor is not None:
        name = getattr(actor, "name", None)
        if name:
            avatar = getattr(getattr(actor, "display_avatar", None), "url", None)
            embed.set_footer(text=str(name)[:2000], icon_url=avatar)
    return embed


def avatar_of(user) -> Optional[str]:
    asset = getattr(user, "display_avatar", None)
    return str(asset.url) if asset else None


# --------------------------------------------------------------------------- audit-log buffer
class AuditBuffer:
    """Remembers recent audit-log entries (from the gateway, no REST calls) so the
    event handlers can name the person who did something.

    ``find`` consumes the entry it returns, so two quick actions on the same target
    never get the same executor.  If the entry has not arrived yet (it normally
    follows the event by a few ms) we wait for it for a short time.
    """

    TTL = 6.0

    def __init__(self) -> None:
        self._recent: dict[tuple[int, int, int], tuple[float, discord.AuditLogEntry]] = {}
        self._waiters: dict[tuple[int, int, int], list[asyncio.Future]] = {}

    def push(self, entry: discord.AuditLogEntry) -> None:
        target_id = getattr(entry, "_target_id", None) or 0
        key = (entry.guild.id, entry.action.value, target_id)
        waiters = self._waiters.get(key)
        while waiters:
            fut = waiters.pop(0)
            if not fut.done():
                fut.set_result(entry)
                return  # consumed by a waiting handler
        now = time.monotonic()
        self._recent[key] = (now, entry)
        if len(self._recent) > 1500:
            for k in [k for k, (t, _) in self._recent.items() if now - t > self.TTL]:
                self._recent.pop(k, None)

    async def find(self, guild: discord.Guild, actions: Sequence[discord.AuditLogAction],
                   target_id: int, wait: float = 0.6) -> Optional[discord.AuditLogEntry]:
        if not guild.me or not guild.me.guild_permissions.view_audit_log:
            return None
        now = time.monotonic()
        keys = [(guild.id, a.value, target_id) for a in actions]
        for key in keys:
            hit = self._recent.pop(key, None)
            if hit and now - hit[0] <= self.TTL:
                return hit[1]
        loop = asyncio.get_running_loop()
        fut: asyncio.Future = loop.create_future()
        for key in keys:
            self._waiters.setdefault(key, []).append(fut)
        try:
            return await asyncio.wait_for(fut, wait)
        except asyncio.TimeoutError:
            return None
        finally:
            for key in keys:
                lst = self._waiters.get(key)
                if lst is not None:
                    try:
                        lst.remove(fut)
                    except ValueError:
                        pass
                    if not lst:
                        self._waiters.pop(key, None)


# --------------------------------------------------------------------------- webhook dispatcher
class _Item:
    __slots__ = ("guild_id", "log_type", "target", "embed")

    def __init__(self, guild_id: int, log_type: str, target: Target, embed: discord.Embed):
        self.guild_id, self.log_type, self.target, self.embed = guild_id, log_type, target, embed


class Dispatcher:
    """Sends embeds through the log webhooks.

    * the first embed of a burst is sent immediately (no artificial delay);
    * embeds that arrive while a request is in flight are merged into one message
      (up to 10 embeds / 5500 characters) - far fewer requests under load;
    * every channel has its own queue, so a slow channel never delays another one;
    * a deleted webhook is re-created automatically.
    """

    def __init__(self, bot) -> None:
        self.bot = bot
        self.session: aiohttp.ClientSession | None = None
        self._queues: dict[int, deque[_Item]] = {}
        self._tasks: dict[int, asyncio.Task] = {}
        self._hooks: dict[int, discord.Webhook] = {}
        self._repairing: set[int] = set()
        self._pass_flag = bool(getattr(discord.Webhook.send, "_deathbot_v2_patched", False))

    async def start(self) -> None:
        self.session = aiohttp.ClientSession()

    async def close(self) -> None:
        for task in list(self._tasks.values()):
            task.cancel()
        self._tasks.clear()
        if self.session is not None:
            await self.session.close()
            self.session = None

    def put(self, guild_id: int, log_type: str, target: Target, embed: discord.Embed) -> None:
        key = target.channel_id
        queue = self._queues.get(key)
        if queue is None:
            queue = self._queues[key] = deque()
        if len(queue) > 500:  # never let one stuck channel eat memory
            queue.popleft()
        queue.append(_Item(guild_id, log_type, target, embed))
        if key not in self._tasks:
            self._tasks[key] = asyncio.get_running_loop().create_task(self._drain(key))

    async def _drain(self, key: int) -> None:
        queue = self._queues[key]
        try:
            while queue:
                batch = [queue.popleft()]
                size = len(batch[0].embed)
                while queue and len(batch) < 10 and size + len(queue[0].embed) <= 5500:
                    item = queue.popleft()
                    size += len(item.embed)
                    batch.append(item)
                try:
                    await self._send(batch)
                except asyncio.CancelledError:
                    raise
                except Exception:  # never kill the drain loop
                    log.exception("log delivery failed")
        finally:
            self._tasks.pop(key, None)
            if not queue:
                self._queues.pop(key, None)

    def _hook(self, target: Target) -> discord.Webhook:
        hook = self._hooks.get(target.webhook_id)
        if hook is None:
            hook = discord.Webhook.partial(target.webhook_id, target.webhook_token, session=self.session)
            self._hooks[target.webhook_id] = hook
        return hook

    async def _post(self, target: Target, embeds: list[discord.Embed]) -> None:
        kwargs: dict[str, Any] = dict(
            embeds=embeds, username=self.bot.user.name[:80],
            avatar_url=str(self.bot.user.display_avatar.url),
            allowed_mentions=discord.AllowedMentions.none())
        if self._pass_flag:
            kwargs["legacy_embed"] = True  # keep real embeds: skip the V2 conversion layer
        await self._hook(target).send(**kwargs)

    async def _send(self, batch: list[_Item]) -> None:
        first = batch[0]
        target = first.target
        embeds = [i.embed for i in batch]
        if not target.webhook_id or not target.webhook_token:
            target = await self._repair(first) or target
            if not target.webhook_id:
                return
        try:
            await self._post(target, embeds)
        except discord.HTTPException as exc:
            if exc.status not in (401, 403, 404):
                log.warning("log webhook error %s in guild %s: %s", exc.status, first.guild_id, exc.text)
                return
            self._hooks.pop(target.webhook_id, None)
            fresh = await self._repair(first)
            if fresh is not None:
                try:
                    await self._post(fresh, embeds)
                except discord.HTTPException as exc2:
                    log.warning("log webhook retry failed %s in guild %s", exc2.status, first.guild_id)

    async def _repair(self, item: _Item) -> Optional[Target]:
        """Webhook missing/deleted: create a new one for the same channel."""
        channel_id = item.target.channel_id
        if channel_id in self._repairing:
            return None
        self._repairing.add(channel_id)
        try:
            guild = self.bot.get_guild(item.guild_id)
            channel = guild.get_channel(channel_id) if guild else None
            if not isinstance(channel, discord.TextChannel):
                return None
            if not channel.permissions_for(guild.me).manage_webhooks:
                return None
            from utils.logging_setup import ensure_webhook
            hook = await ensure_webhook(channel, self.bot.user, reason="Logging webhook repaired")
            cfg = store.get(item.guild_id)
            # every log type that pointed to this channel gets the new webhook
            for key, tgt in list((cfg.targets if cfg else {}).items()):
                if tgt.channel_id == channel_id:
                    await store.set_target(item.guild_id, key, channel_id, hook.id, hook.token or "")
            return Target(channel_id, hook.id, hook.token or "")
        except discord.HTTPException:
            return None
        finally:
            self._repairing.discard(channel_id)
