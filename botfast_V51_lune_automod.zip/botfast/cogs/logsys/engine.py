"""Logging engine: listens to Discord events and ships them to the log webhooks.

Design for speed
----------------
* Every handler starts with ONE dict lookup (``store.get``); servers without logging cost nothing.
* Embeds are only built after we know a log channel exists for that log type.
* Delivery goes through ``Dispatcher`` (instant first send, merged bursts, per-channel queues).
* Executors ("who did it") come from the audit-log gateway event via ``AuditBuffer`` - no REST calls.
"""
from __future__ import annotations

from typing import Optional

import discord
from discord import AuditLogAction as A
from discord.ext import commands

from utils.logging_store import store
from .core import (AuditBuffer, BLUE, BLURPLE, Dispatcher, GREEN, GREY, HIGH_RISK, ORANGE, RED, TEAL, avatar_of, code,
                   esc, high_risk_of, make, perm_list, trim, user_line, when)

VOICE_TYPES = (discord.VoiceChannel, discord.StageChannel)
WEBHOOK_KIND = {1: "Incoming", 2: "Channel Follower", 3: "Application"}

GUILD_FIELDS = (
    ("name", "Name"), ("owner_id", "Owner"), ("description", "Description"),
    ("afk_channel", "AFK Channel"), ("afk_timeout", "AFK Timeout"), ("system_channel", "System Channel"),
    ("rules_channel", "Rules Channel"), ("public_updates_channel", "Updates Channel"),
    ("verification_level", "Verification Level"), ("default_notifications", "Default Notifications"),
    ("explicit_content_filter", "Content Filter"), ("mfa_level", "2FA Level"),
    ("preferred_locale", "Locale"), ("premium_progress_bar_enabled", "Boost Bar"),
)
VOICE_FLAGS = (("self_mute", "Self Mute"), ("self_deaf", "Self Deaf"), ("mute", "Server Mute"),
               ("deaf", "Server Deaf"), ("self_stream", "Streaming"), ("self_video", "Camera"),
               ("suppress", "Suppressed"))


def _val(value) -> str:
    """Readable value for before/after diffs."""
    if value is None:
        return "`None`"
    if isinstance(value, (discord.abc.GuildChannel, discord.Role)):
        return value.mention
    if hasattr(value, "name") and not isinstance(value, str):
        return code(str(value.name).replace("_", " ").title())
    if isinstance(value, bool):
        return "<:emoji_4:1566043104551768114>" if value else "<a:emoji_38:1567096105299214336>"
    return code(trim(str(value), 200))


INF = "\u221e"


def _channel_text(ch) -> str:
    if ch is None:
        return "`unknown`"
    name = getattr(ch, "name", None)
    return f"{esc(name)} ({ch.mention})" if name else ch.mention


def _guild_val(attr: str, value) -> str:
    return f"<@{value}>" if attr == "owner_id" else _val(value)


def _is_voice(ch) -> bool:
    return isinstance(ch, VOICE_TYPES)


class LoggingEngine(commands.Cog, name="LoggingEngine"):
    """Event side of the logging module (no commands)."""

    def __init__(self, bot):
        self.bot = bot
        self.out = Dispatcher(bot)
        self.audit = AuditBuffer()

    async def cog_load(self) -> None:
        await store.load_all()
        await self.out.start()

    async def cog_unload(self) -> None:
        await self.out.close()

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _on(guild_id: int, log_type: str):
        cfg = store.get(guild_id)
        if cfg is None:
            return None
        target = cfg.target(log_type)
        return (cfg, target) if target else None

    @staticmethod
    def _ignored(cfg, member) -> bool:
        if member is None or not (cfg.ignored_users or cfg.ignored_roles):
            return False
        if member.id in cfg.ignored_users:
            return True
        roles = getattr(member, "roles", None)
        return bool(roles and cfg.ignored_roles and any(r.id in cfg.ignored_roles for r in roles))

    def _send(self, guild_id: int, log_type: str, target, embed: discord.Embed) -> None:
        self.out.put(guild_id, log_type, target, embed)

    def _who(self, entry):
        if entry is None:
            return None
        return entry.user or (self.bot.get_user(entry.user_id) if entry.user_id else None)

    async def _entry(self, guild: discord.Guild, actions, target_id: int, wait: float = 0.6):
        return await self.audit.find(guild, actions, target_id, wait)

    # ================================================================== SYSTEM
    @commands.Cog.listener()
    async def on_command(self, ctx: commands.Context):
        if ctx.guild is None:
            return
        pair = self._on(ctx.guild.id, "system")
        if not pair or self._ignored(pair[0], ctx.author):
            return
        m = ctx.message
        embed = make("Command Executed", RED, [
            ("Channel", _channel_text(ctx.channel)),
            ("Message ID", f"[{m.id}]({m.jump_url})"),
            ("Message author", user_line(ctx.author)),
            ("Message created", when(m.created_at)),
        ], extra=f"**Command**\n{trim(m.content, 900)}")
        self._send(ctx.guild.id, "system", pair[1], embed)

    # ================================================================== JOIN / LEAVE
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        pair = self._on(member.guild.id, "join")
        if not pair or self._ignored(pair[0], member):
            return
        embed = make("User Joined", GREY, [
            ("Member", user_line(member)),
            ("User ID", code(member.id)),
            ("Bot", "<:emoji_4:1566043104551768114>" if member.bot else None),
            ("Account created", when(member.created_at)),
            ("Total members", member.guild.member_count),
        ], thumb=avatar_of(member))
        self._send(member.guild.id, "join", pair[1], embed)

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        pair = self._on(member.guild.id, "leave")
        if not pair or self._ignored(pair[0], member):
            return
        roles = [r.mention for r in reversed(member.roles) if not r.is_default()]
        embed = make("User left", RED, [
            ("Member", user_line(member)),
            ("Joined", when(member.joined_at) if member.joined_at else None),
            ("Total members", member.guild.member_count),
            ("Roles", ", ".join(roles[:25]) + (f" (+{len(roles) - 25})" if len(roles) > 25 else "") if roles else None),
        ], thumb=avatar_of(member))
        self._send(member.guild.id, "leave", pair[1], embed)

    # ================================================================== MEMBER / ALERT / MODERATION(timeout)
    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        guild = after.guild
        cfg = store.get(guild.id)
        if cfg is None or not cfg.enabled or not cfg.targets or self._ignored(cfg, after):
            return

        if before.roles != after.roles:
            old_ids = {r.id for r in before.roles}
            new_ids = {r.id for r in after.roles}
            added = [r for r in after.roles if r.id not in old_ids]
            removed = [r for r in before.roles if r.id not in new_ids]
            member_t, alert_t = cfg.target("member"), cfg.target("alert")
            if (added or removed) and (member_t or alert_t):
                entry = await self._entry(guild, (A.member_role_update,), after.id)
                actor = self._who(entry)
                if member_t:
                    self._send(guild.id, "member", member_t, make("Member Roles Updated", GREY, [
                        ("Member", user_line(after)),
                        ("Role added", ", ".join(r.mention for r in added) if added else None),
                        ("Role removed", ", ".join(r.mention for r in removed) if removed else None),
                    ], thumb=avatar_of(after), actor=actor))
                if alert_t:
                    for role in added:
                        risky = high_risk_of(role.permissions)
                        if risky:
                            self._send(guild.id, "alert", alert_t, make("High-risk role granted", RED, [
                                ("Member", user_line(after)),
                                ("Role Assigned", role.mention),
                                ("Grants Permissions", code(perm_list(risky))),
                            ], actor=actor))

        nick_changed = before.nick != after.nick
        timeout_changed = before.timed_out_until != after.timed_out_until
        if not (nick_changed or timeout_changed):
            return
        entry = None
        member_t, mod_t = cfg.target("member"), cfg.target("moderation")
        if (nick_changed and member_t) or (timeout_changed and mod_t):
            entry = await self._entry(guild, (A.member_update,), after.id)
        actor = self._who(entry)
        if nick_changed and member_t:
            self._send(guild.id, "member", member_t, make("Member Updated", GREY, [
                ("Member", user_line(after)),
                ("Nickname before", _val(before.nick)),
                ("Nickname after", _val(after.nick)),
            ], thumb=avatar_of(after), actor=actor))
        if timeout_changed and mod_t:
            until = after.timed_out_until
            if until:
                embed = make("Member Timed Out", ORANGE, [
                    ("Member", user_line(after)),
                    ("Until", f"{when(until, 'F')} ({when(until)})"),
                    ("Reason", esc(entry.reason) if entry and entry.reason else None),
                ], thumb=avatar_of(after), actor=actor)
            else:
                embed = make("Timeout Removed", GREEN, [
                    ("Member", user_line(after)),
                    ("Reason", esc(entry.reason) if entry and entry.reason else None),
                ], thumb=avatar_of(after), actor=actor)
            self._send(guild.id, "moderation", mod_t, embed)

    @commands.Cog.listener()
    async def on_user_update(self, before: discord.User, after: discord.User):
        changes = []
        if before.name != after.name:
            changes.append(("Username before", code(before.name)))
            changes.append(("Username after", code(after.name)))
        if before.global_name != after.global_name:
            changes.append(("Display name before", _val(before.global_name)))
            changes.append(("Display name after", _val(after.global_name)))
        if before.avatar != after.avatar:
            changes.append(("Avatar", "Changed"))
        if not changes:
            return
        for gid in store.configured_guild_ids():
            pair = self._on(gid, "member")
            guild = self.bot.get_guild(gid)
            member = guild.get_member(after.id) if guild else None
            if pair and member and not self._ignored(pair[0], member):
                self._send(gid, "member", pair[1], make(
                    "User Updated", GREY, [("Member", user_line(after)), *changes], thumb=avatar_of(after)))

    # ================================================================== MESSAGE
    def _skip_message(self, cfg, msg: discord.Message) -> bool:
        author = msg.author
        if author is not None and author.id == self.bot.user.id:
            return True
        if cfg.ignore_embeds and (msg.embeds or getattr(msg.flags, "components_v2", False)):
            return True
        if cfg.ignore_voice and _is_voice(getattr(msg, "channel", None)):
            return True
        return self._ignored(cfg, author)

    @commands.Cog.listener()
    async def on_raw_message_delete(self, payload: discord.RawMessageDeleteEvent):
        if payload.guild_id is None:
            return
        pair = self._on(payload.guild_id, "message")
        if not pair:
            return
        cfg, target = pair
        msg = payload.cached_message
        guild = self.bot.get_guild(payload.guild_id)
        if msg is not None:
            if self._skip_message(cfg, msg):
                return
            files = ", ".join(f"[{esc(a.filename)}]({a.url})" for a in msg.attachments[:5])
            embed = make("Message deleted", RED, [
                ("Author", user_line(msg.author)),
                ("Channel", _channel_text(msg.channel)),
                ("Message ID", code(msg.id)),
                ("Created", when(msg.created_at)),
                ("Attachments", files or None),
            ], extra=f"**Content**\n{trim(msg.content)}" if msg.content else None, thumb=avatar_of(msg.author))
        else:
            channel = guild.get_channel_or_thread(payload.channel_id) if guild else None
            if cfg.ignore_voice and _is_voice(channel):
                return
            embed = make("Message deleted", RED, [
                ("Channel", _channel_text(channel) if channel else f"<#{payload.channel_id}>"),
                ("Message ID", code(payload.message_id)),
                ("Created", when(discord.utils.snowflake_time(payload.message_id))),
            ], extra="-# Message was not cached, so its content is unknown.")
        self._send(payload.guild_id, "message", target, embed)

    @commands.Cog.listener()
    async def on_raw_bulk_message_delete(self, payload: discord.RawBulkMessageDeleteEvent):
        if payload.guild_id is None:
            return
        pair = self._on(payload.guild_id, "message")
        if not pair:
            return
        guild = self.bot.get_guild(payload.guild_id)
        channel = guild.get_channel_or_thread(payload.channel_id) if guild else None
        if pair[0].ignore_voice and _is_voice(channel):
            return
        entry = await self._entry(guild, (A.message_bulk_delete,), payload.channel_id, 0.8) if guild else None
        self._send(payload.guild_id, "message", pair[1], make("Messages bulk deleted", RED, [
            ("Channel", _channel_text(channel) if channel else f"<#{payload.channel_id}>"),
            ("Messages", code(len(payload.message_ids))),
            ("Cached", code(len(payload.cached_messages))),
        ], actor=self._who(entry)))

    @commands.Cog.listener()
    async def on_raw_message_edit(self, payload: discord.RawMessageUpdateEvent):
        if payload.guild_id is None:
            return
        pair = self._on(payload.guild_id, "message")
        if not pair:
            return
        cfg, target = pair
        before = payload.cached_message
        after = payload.message
        if "content" not in payload.data:
            return
        if before is not None:
            if before.content == after.content:
                return
        elif not payload.data.get("edited_timestamp"):
            return  # embed/link-preview refresh, not a user edit
        if self._skip_message(cfg, after):
            return
        embed = make("Message edited", GREY, [
            ("Author", user_line(after.author)),
            ("Channel", _channel_text(after.channel)),
            ("Message ID", f"[{after.id}]({after.jump_url})"),
        ], extra=(f"**Before**\n{trim(before.content, 900) or '`empty`'}\n\n" if before is not None else
                  "**Before**\n`not cached`\n\n") + f"**After**\n{trim(after.content, 900) or '`empty`'}",
            thumb=avatar_of(after.author))
        self._send(payload.guild_id, "message", target, embed)

    # ================================================================== THREAD
    @commands.Cog.listener()
    async def on_thread_create(self, thread: discord.Thread):
        pair = self._on(thread.guild.id, "thread")
        if not pair:
            return
        owner = thread.owner or (self.bot.get_user(thread.owner_id) if thread.owner_id else None)
        self._send(thread.guild.id, "thread", pair[1], make("Thread Created", GREEN, [
            ("Thread", f"{esc(thread.name)} ({thread.mention})"),
            ("Thread ID", code(thread.id)),
            ("Parent", thread.parent.mention if thread.parent else None),
            ("Owner", f"<@{thread.owner_id}>" if thread.owner_id else None),
            ("Auto archive", code(f"{thread.auto_archive_duration} minutes")),
        ], actor=owner))

    @commands.Cog.listener()
    async def on_raw_thread_delete(self, payload: discord.RawThreadDeleteEvent):
        pair = self._on(payload.guild_id, "thread")
        if not pair:
            return
        thread = payload.thread
        self._send(payload.guild_id, "thread", pair[1], make("Thread Deleted", RED, [
            ("Thread", esc(thread.name) if thread else "`unknown`"),
            ("Thread ID", code(payload.thread_id)),
            ("Parent", f"<#{payload.parent_id}>" if payload.parent_id else None),
        ]))

    @commands.Cog.listener()
    async def on_thread_update(self, before: discord.Thread, after: discord.Thread):
        pair = self._on(after.guild.id, "thread")
        if not pair:
            return
        rows = []
        if before.name != after.name:
            rows += [("Previous Name", esc(before.name)), ("New Name", esc(after.name))]
        if before.archived != after.archived:
            rows.append(("Archived", _val(after.archived)))
        if before.locked != after.locked:
            rows.append(("Locked", _val(after.locked)))
        if before.slowmode_delay != after.slowmode_delay:
            rows.append(("Slowmode", code(f"{before.slowmode_delay}s -> {after.slowmode_delay}s")))
        if before.auto_archive_duration != after.auto_archive_duration:
            rows.append(("Auto archive", code(f"{before.auto_archive_duration} -> {after.auto_archive_duration} min")))
        if not rows:
            return
        self._send(after.guild.id, "thread", pair[1], make("Thread Updated", GREY, [
            ("Thread", f"{esc(after.name)} ({after.mention})"), ("Thread ID", code(after.id)), *rows]))

    @commands.Cog.listener()
    async def on_thread_member_join(self, member: discord.ThreadMember):
        pair = self._on(member.thread.guild.id, "thread")
        if pair:
            self._send(member.thread.guild.id, "thread", pair[1], make("Thread Member Joined", GREEN, [
                ("Member", f"<@{member.id}>"), ("Thread", member.thread.mention)]))

    @commands.Cog.listener()
    async def on_thread_member_remove(self, member: discord.ThreadMember):
        pair = self._on(member.thread.guild.id, "thread")
        if pair:
            self._send(member.thread.guild.id, "thread", pair[1], make("Thread Member Left", RED, [
                ("Member", f"<@{member.id}>"), ("Thread", member.thread.mention)]))

    # ================================================================== VOICE / STAGE
    @commands.Cog.listener()
    async def on_voice_state_update(self, member: discord.Member, before: discord.VoiceState,
                                    after: discord.VoiceState):
        gid = member.guild.id
        cfg = store.get(gid)
        if cfg is None or not cfg.enabled or not cfg.targets:
            return
        old, new = before.channel, after.channel
        stage = isinstance(old, discord.StageChannel) or isinstance(new, discord.StageChannel)
        log_type = "stage" if stage else "voice"
        target = cfg.target(log_type)
        if target is None or self._ignored(cfg, member):
            return
        thumb = avatar_of(member)

        def users(ch) -> str:
            return f"{len(ch.members)}/{ch.user_limit or '∞'}"

        if old is None and new is not None:
            title = "User joined stage" if stage else "User joined channel"
            embed = make(title, GREY, [("Member", user_line(member)), ("Channel", new.mention),
                                       ("Users", users(new))], thumb=thumb)
        elif old is not None and new is None:
            title = "User left stage" if stage else "User left channel"
            embed = make(title, RED, [("Member", user_line(member)), ("Channel", old.mention),
                                      ("Users", users(old))], thumb=thumb)
        elif old is not None and new is not None and old.id != new.id:
            title = "User moved stage" if stage else "User moved channel"
            embed = make(title, BLUE, [("Member", user_line(member)), ("Channel", new.mention),
                                       ("Previous Channel", old.mention), ("Users", users(new))], thumb=thumb)
        else:
            diff = [f"{label} -> {getattr(after, attr)}" for attr, label in VOICE_FLAGS
                    if getattr(before, attr) != getattr(after, attr)]
            if before.requested_to_speak_at != after.requested_to_speak_at:
                diff.append(f"Requested To Speak -> {after.requested_to_speak_at is not None}")
            if not diff or new is None:
                return
            title = "Stage state update" if stage else "Voice state update"
            embed = make(title, GREY, [("Member", user_line(member)), ("Channel", new.mention)],
                         extra="```\n" + "\n".join(diff) + "\n```", thumb=thumb)
        self._send(gid, log_type, target, embed)

    @commands.Cog.listener()
    async def on_stage_instance_create(self, stage: discord.StageInstance):
        pair = self._on(stage.guild.id, "stage")
        if pair:
            self._send(stage.guild.id, "stage", pair[1], make("Stage started", GREEN, [
                ("Topic", esc(stage.topic)), ("Channel", stage.channel.mention if stage.channel else None)]))

    @commands.Cog.listener()
    async def on_stage_instance_delete(self, stage: discord.StageInstance):
        pair = self._on(stage.guild.id, "stage")
        if pair:
            self._send(stage.guild.id, "stage", pair[1], make("Stage ended", RED, [
                ("Topic", esc(stage.topic)), ("Channel", stage.channel.mention if stage.channel else None)]))

    @commands.Cog.listener()
    async def on_stage_instance_update(self, before: discord.StageInstance, after: discord.StageInstance):
        pair = self._on(after.guild.id, "stage")
        if pair and before.topic != after.topic:
            self._send(after.guild.id, "stage", pair[1], make("Stage updated", GREY, [
                ("Channel", after.channel.mention if after.channel else None),
                ("Previous Topic", esc(before.topic)), ("New Topic", esc(after.topic))]))

    # ================================================================== MODERATION
    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User):
        pair = self._on(guild.id, "moderation")
        if not pair:
            return
        entry = await self._entry(guild, (A.ban,), user.id)
        self._send(guild.id, "moderation", pair[1], make("Member Banned", RED, [
            ("Member", user_line(user)), ("User ID", code(user.id)),
            ("Reason", esc(entry.reason) if entry and entry.reason else None),
        ], thumb=avatar_of(user), actor=self._who(entry)))

    @commands.Cog.listener()
    async def on_member_unban(self, guild: discord.Guild, user: discord.User):
        pair = self._on(guild.id, "moderation")
        if not pair:
            return
        entry = await self._entry(guild, (A.unban,), user.id)
        self._send(guild.id, "moderation", pair[1], make("Member Unbanned", GREEN, [
            ("Member", user_line(user)), ("User ID", code(user.id)),
            ("Reason", esc(entry.reason) if entry and entry.reason else None),
        ], thumb=avatar_of(user), actor=self._who(entry)))

    @commands.Cog.listener()
    async def on_automod_action(self, execution: discord.AutoModAction):
        pair = self._on(execution.guild_id, "moderation")
        if not pair:
            return
        self._send(execution.guild_id, "moderation", pair[1], make("AutoMod Action", ORANGE, [
            ("Member", f"<@{execution.user_id}>"),
            ("Channel", f"<#{execution.channel_id}>" if execution.channel_id else None),
            ("Trigger", code(execution.rule_trigger_type.name.replace("_", " ").title())),
            ("Action", code(execution.action.type.name.replace("_", " ").title())),
            ("Matched", code(execution.matched_keyword) if execution.matched_keyword else None),
        ], extra=f"**Content**\n{trim(execution.content, 800)}" if execution.content else None))

    # ================================================================== CHANNEL
    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel):
        guild = channel.guild
        pair = self._on(guild.id, "channel")
        if not pair or (pair[0].ignore_voice and _is_voice(channel)):
            return
        entry = await self._entry(guild, (A.channel_create,), channel.id)
        self._send(guild.id, "channel", pair[1], make("Channel created", GREEN, [
            ("Channel", _channel_text(channel)), ("Channel ID", code(channel.id)),
            ("Type", code(str(channel.type).replace("_", " ").title())),
            ("Category", esc(channel.category.name) if channel.category else "None"),
        ], actor=self._who(entry)))

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel):
        guild = channel.guild
        pair = self._on(guild.id, "channel")
        if not pair or (pair[0].ignore_voice and _is_voice(channel)):
            return
        entry = await self._entry(guild, (A.channel_delete,), channel.id)
        self._send(guild.id, "channel", pair[1], make("Channel deleted", RED, [
            ("Channel", esc(channel.name)), ("Channel ID", code(channel.id)),
            ("Type", code(str(channel.type).replace("_", " ").title())),
            ("Category", esc(channel.category.name) if channel.category else "None"),
        ], actor=self._who(entry)))

    @commands.Cog.listener()
    async def on_guild_channel_update(self, before: discord.abc.GuildChannel, after: discord.abc.GuildChannel):
        guild = after.guild
        pair = self._on(guild.id, "channel")
        if not pair or (pair[0].ignore_voice and _is_voice(after)):
            return
        rows = []
        if before.name != after.name:
            rows.append(("Previous Name", esc(before.name)))
        if before.category_id != after.category_id:
            rows.append(("Previous Category", esc(before.category.name) if before.category else "None"))
            rows.append(("New Category", esc(after.category.name) if after.category else "None"))
        for attr, label in (("topic", "Topic"), ("nsfw", "NSFW"), ("slowmode_delay", "Slowmode"),
                            ("bitrate", "Bitrate"), ("user_limit", "User Limit")):
            if hasattr(before, attr) and getattr(before, attr) != getattr(after, attr):
                rows.append((label, f"{_val(getattr(before, attr))} → {_val(getattr(after, attr))}"))
        if before.overwrites != after.overwrites:
            changed = {t for t in set(before.overwrites) | set(after.overwrites)
                       if before.overwrites.get(t) != after.overwrites.get(t)}
            rows.append(("Permissions", f"Updated for {', '.join(t.mention for t in list(changed)[:8])}"
                         + (f" (+{len(changed) - 8})" if len(changed) > 8 else "")))
        if not rows:
            return
        entry = await self._entry(guild, (A.channel_update, A.overwrite_create, A.overwrite_update,
                                          A.overwrite_delete), after.id)
        self._send(guild.id, "channel", pair[1], make("Channel updated", GREY, [
            ("Channel", _channel_text(after)), ("Channel ID", code(after.id)), *rows], actor=self._who(entry)))

    # ================================================================== SERVER
    @commands.Cog.listener()
    async def on_guild_update(self, before: discord.Guild, after: discord.Guild):
        pair = self._on(after.id, "server")
        if not pair:
            return
        rows = []
        for attr, label in GUILD_FIELDS:
            old, new = getattr(before, attr, None), getattr(after, attr, None)
            if old != new:
                rows.append((label, f"{_val(old) if attr != 'owner_id' else f'<@{old}>'} → "
                                    f"{_val(new) if attr != 'owner_id' else f'<@{new}>'}"))
        for attr, label in (("icon", "Icon"), ("banner", "Banner"), ("splash", "Invite Splash")):
            if getattr(before, attr) != getattr(after, attr):
                rows.append((label, "Changed"))
        if not rows:
            return
        entry = await self._entry(after, (A.guild_update,), after.id)
        self._send(after.id, "server", pair[1], make("Server updated", GREY, rows,
                   thumb=str(after.icon.url) if after.icon else None, actor=self._who(entry)))

    @commands.Cog.listener()
    async def on_invite_create(self, invite: discord.Invite):
        guild = invite.guild
        if guild is None:
            return
        pair = self._on(guild.id, "server")
        if not pair or (pair[0].ignore_voice and _is_voice(invite.channel)):
            return
        expires = f"{when(invite.expires_at)}" if invite.expires_at else "Never"
        self._send(guild.id, "server", pair[1], make("Invite created", GREY, [
            ("Code", code(invite.code)),
            ("Channel", _channel_text(invite.channel) if hasattr(invite.channel, "mention") else None),
            ("Expires", expires),
            ("Max users", invite.max_uses or "∞"),
            ("Temporary", "<:emoji_4:1566043104551768114>" if invite.temporary else None),
        ], actor=invite.inviter))

    @commands.Cog.listener()
    async def on_invite_delete(self, invite: discord.Invite):
        guild = invite.guild
        if guild is None:
            return
        pair = self._on(guild.id, "server")
        if not pair or (pair[0].ignore_voice and _is_voice(invite.channel)):
            return
        self._send(guild.id, "server", pair[1], make("Invite deleted", RED, [
            ("Code", code(invite.code)),
            ("Channel", _channel_text(invite.channel) if hasattr(invite.channel, "mention") else None),
        ]))

    @commands.Cog.listener()
    async def on_guild_emojis_update(self, guild: discord.Guild, before, after):
        pair = self._on(guild.id, "server")
        if not pair:
            return
        old = {e.id: e for e in before}
        new = {e.id: e for e in after}
        for eid, emoji in new.items():
            prev = old.get(eid)
            if prev is None:
                entry = await self._entry(guild, (A.emoji_create,), eid)
                embed = make("Emoji created", GREEN, [("Emoji", f"{emoji} `:{esc(emoji.name)}:`"),
                             ("Emoji ID", code(eid)), ("Animated", "<:emoji_4:1566043104551768114>" if emoji.animated else None)],
                             thumb=str(emoji.url), actor=self._who(entry))
            elif prev.name != emoji.name:
                entry = await self._entry(guild, (A.emoji_update,), eid)
                embed = make("Emoji updated", GREY, [("Emoji", f"{emoji}"), ("Emoji ID", code(eid)),
                             ("Previous Name", code(prev.name)), ("New Name", code(emoji.name))],
                             thumb=str(emoji.url), actor=self._who(entry))
            else:
                continue
            self._send(guild.id, "server", pair[1], embed)
        for eid, emoji in old.items():
            if eid not in new:
                entry = await self._entry(guild, (A.emoji_delete,), eid)
                self._send(guild.id, "server", pair[1], make("Emoji deleted", RED, [
                    ("Name", code(emoji.name)), ("Emoji ID", code(eid))], thumb=str(emoji.url),
                    actor=self._who(entry)))

    @commands.Cog.listener()
    async def on_guild_stickers_update(self, guild: discord.Guild, before, after):
        pair = self._on(guild.id, "server")
        if not pair:
            return
        old = {s.id: s for s in before}
        new = {s.id: s for s in after}
        for sid, sticker in new.items():
            prev = old.get(sid)
            if prev is None:
                entry = await self._entry(guild, (A.sticker_create,), sid)
                self._send(guild.id, "server", pair[1], make("Sticker created", GREEN, [
                    ("Name", code(sticker.name)), ("Sticker ID", code(sid))], thumb=str(sticker.url),
                    actor=self._who(entry)))
            elif prev.name != sticker.name:
                entry = await self._entry(guild, (A.sticker_update,), sid)
                self._send(guild.id, "server", pair[1], make("Sticker updated", GREY, [
                    ("Sticker ID", code(sid)), ("Previous Name", code(prev.name)), ("New Name", code(sticker.name))],
                    thumb=str(sticker.url), actor=self._who(entry)))
        for sid, sticker in old.items():
            if sid not in new:
                entry = await self._entry(guild, (A.sticker_delete,), sid)
                self._send(guild.id, "server", pair[1], make("Sticker deleted", RED, [
                    ("Name", code(sticker.name)), ("Sticker ID", code(sid))], actor=self._who(entry)))

    # ================================================================== EVENT
    @staticmethod
    def _event_rows(event: discord.ScheduledEvent):
        where = event.channel.mention if event.channel else (esc(event.location) if event.location else None)
        return [("Event", esc(event.name)), ("Event ID", code(event.id)), ("Location", where),
                ("Starts", f"{when(event.start_time, 'F')} ({when(event.start_time)})")]

    @commands.Cog.listener()
    async def on_scheduled_event_create(self, event: discord.ScheduledEvent):
        pair = self._on(event.guild_id, "event")
        if pair:
            self._send(event.guild_id, "event", pair[1], make(
                "Event created", GREEN, self._event_rows(event), actor=event.creator))

    @commands.Cog.listener()
    async def on_scheduled_event_delete(self, event: discord.ScheduledEvent):
        pair = self._on(event.guild_id, "event")
        if pair:
            self._send(event.guild_id, "event", pair[1], make(
                "Event deleted", RED, [("Event", esc(event.name)), ("Event ID", code(event.id))], actor=event.creator))

    @commands.Cog.listener()
    async def on_scheduled_event_update(self, before: discord.ScheduledEvent, after: discord.ScheduledEvent):
        pair = self._on(after.guild_id, "event")
        if not pair:
            return
        S = discord.EventStatus
        if before.status != after.status:
            if after.status == S.active:
                title, color = "Event started", TEAL
            elif after.status == S.completed:
                title, color = "Event ended", RED
            elif after.status == S.cancelled:
                title, color = "Event cancelled", RED
            else:
                title, color = "Event updated", GREY
            self._send(after.guild_id, "event", pair[1], make(title, color, [
                ("Event", esc(after.name)), ("Status", after.status.name.replace("_", " ").title())],
                actor=after.creator))
            return
        rows = []
        if before.name != after.name:
            rows += [("Previous Name", esc(before.name)), ("New Name", esc(after.name))]
        if before.description != after.description:
            rows.append(("Description", "Changed"))
        if before.start_time != after.start_time:
            rows.append(("Starts", f"{when(before.start_time)} → {when(after.start_time)}"))
        if before.location != after.location:
            rows.append(("Location", f"{_val(before.location)} → {_val(after.location)}"))
        if rows:
            self._send(after.guild_id, "event", pair[1], make(
                "Event updated", GREY, [("Event", esc(after.name)), *rows], actor=after.creator))

    @commands.Cog.listener()
    async def on_scheduled_event_user_add(self, event: discord.ScheduledEvent, user: discord.User):
        pair = self._on(event.guild_id, "event")
        if pair:
            self._send(event.guild_id, "event", pair[1], make("Subscribed to event", GREEN, [
                ("Event", esc(event.name)), ("User", user_line(user))], thumb=avatar_of(user)))

    @commands.Cog.listener()
    async def on_scheduled_event_user_remove(self, event: discord.ScheduledEvent, user: discord.User):
        pair = self._on(event.guild_id, "event")
        if pair:
            self._send(event.guild_id, "event", pair[1], make("Unsubscribed from event", RED, [
                ("Event", esc(event.name)), ("User", user_line(user))], thumb=avatar_of(user)))

    # ================================================================== ROLE
    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role):
        guild = role.guild
        cfg = store.get(guild.id)
        if cfg is None:
            return
        role_t, alert_t = cfg.target("role"), cfg.target("alert")
        if not (role_t or alert_t):
            return
        entry = await self._entry(guild, (A.role_create,), role.id)
        actor = self._who(entry)
        if role_t:
            self._send(guild.id, "role", role_t, make("Role Created", GREEN, [
                ("Role", f"{esc(role.name)} ({role.mention})"), ("Role ID", role.id),
                ("Bot Managed", "<:emoji_4:1566043104551768114>" if role.managed else "<a:emoji_38:1567096105299214336>")], actor=actor))
        risky = high_risk_of(role.permissions)
        if alert_t and risky:
            self._send(guild.id, "alert", alert_t, make("High-risk role created", RED, [
                ("Role", f"{esc(role.name)} ({role.mention})"),
                ("Grants Permissions", code(perm_list(risky)))], actor=actor))

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        guild = role.guild
        pair = self._on(guild.id, "role")
        if not pair:
            return
        entry = await self._entry(guild, (A.role_delete,), role.id)
        self._send(guild.id, "role", pair[1], make("Role Deleted", RED, [
            ("Role", esc(role.name)), ("Role ID", role.id)], actor=self._who(entry)))

    @commands.Cog.listener()
    async def on_guild_role_update(self, before: discord.Role, after: discord.Role):
        guild = after.guild
        cfg = store.get(guild.id)
        if cfg is None:
            return
        role_t, alert_t = cfg.target("role"), cfg.target("alert")
        if not (role_t or alert_t):
            return
        perms_changed = before.permissions != after.permissions
        rows = []
        if before.name != after.name:
            rows.append(("Previous Name", esc(before.name)))
        if before.color != after.color:
            rows.append(("Color", f"{code(str(before.color))} → {code(str(after.color))}"))
        if before.hoist != after.hoist:
            rows.append(("Hoisted", _val(after.hoist)))
        if before.mentionable != after.mentionable:
            rows.append(("Mentionable", _val(after.mentionable)))
        if before.icon != after.icon or before.unicode_emoji != after.unicode_emoji:
            rows.append(("Icon", "Changed"))
        if not rows and not perms_changed:
            return
        entry = await self._entry(guild, (A.role_update,), after.id)
        actor = self._who(entry)
        head = [("Role", f"{esc(after.name)} ({after.mention})"), ("Role ID", after.id)]
        if role_t and rows:
            self._send(guild.id, "role", role_t, make("Role Updated", GREY, head + rows, actor=actor))
        if perms_changed:
            names = [n for n, v in after.permissions if v != getattr(before.permissions, n)]
            added = [n for n in names if getattr(after.permissions, n)]
            removed = [n for n in names if not getattr(after.permissions, n)]
            if role_t:
                self._send(guild.id, "role", role_t, make("Role permission update", GREY, head + [
                    ("Permission(s) added", code(perm_list(added)) if added else None),
                    ("Permission(s) removed", code(perm_list(removed)) if removed else None),
                ], actor=actor))
            risky = [n for n in added if n in HIGH_RISK]
            if alert_t and risky:
                self._send(guild.id, "alert", alert_t, make("High-risk permission granted", RED, head + [
                    ("Grants Permissions", code(perm_list(risky)))], actor=actor))

    # ================================================================== AUDIT-DRIVEN (webhook / application / kick)
    @commands.Cog.listener()
    async def on_audit_log_entry_create(self, entry: discord.AuditLogEntry):
        self.audit.push(entry)
        action = entry.action
        guild = entry.guild
        cfg = store.get(guild.id)
        if cfg is None or not cfg.enabled:
            return
        actor = self._who(entry)

        if action in (A.webhook_create, A.webhook_update, A.webhook_delete):
            target = cfg.target("webhook")
            if not target or entry.user_id == self.bot.user.id:
                return
            snap = entry.before if action == A.webhook_delete else entry.after
            channel = getattr(snap, "channel", None) or getattr(entry.before, "channel", None)
            kind = getattr(snap, "type", None)
            title, color = {A.webhook_create: ("Webhook Created", GREEN), A.webhook_update: ("Webhook Updated", GREY),
                            A.webhook_delete: ("Webhook Deleted", RED)}[action]
            self._send(guild.id, "webhook", target, make(title, color, [
                ("Webhook", esc(getattr(snap, "name", None) or getattr(entry.before, "name", None) or "Unknown")),
                ("Webhook ID", code(entry.target_id)),
                ("Channel", f"<#{channel.id}>" if channel is not None else None),
                ("Type", WEBHOOK_KIND.get(getattr(kind, "value", kind), None) if kind is not None else None),
                ("Reason", esc(entry.reason) if entry.reason else None),
            ], actor=actor))

        elif action in (A.bot_add, A.integration_create, A.integration_delete):
            target = cfg.target("application")
            if not target:
                return
            if action == A.bot_add:
                app = entry.target
                name = getattr(app, "name", None)
                rows = [("Application", f"{esc(name)} ({app.mention})" if name else f"<@{entry.target_id}>"),
                        ("Application ID", code(entry.target_id))]
                self._send(guild.id, "application", target, make(
                    "Application Added", BLURPLE, rows, thumb=avatar_of(app), actor=actor))
            else:
                snap = entry.before if action == A.integration_delete else entry.after
                name = getattr(snap, "name", None) or "Unknown"
                added = action == A.integration_create
                self._send(guild.id, "application", target, make(
                    "Application Added" if added else "Application Removed", BLURPLE if added else RED,
                    [("Application", esc(name)), ("Application ID", code(entry.target_id))], actor=actor))

        elif action == A.kick:
            target = cfg.target("moderation")
            if not target:
                return
            who = entry.target
            name = getattr(who, "name", None)
            self._send(guild.id, "moderation", target, make("Member Kicked", RED, [
                ("Member", f"@{esc(name)} (<@{entry.target_id}>)" if name else f"<@{entry.target_id}>"),
                ("User ID", code(entry.target_id)),
                ("Reason", esc(entry.reason) if entry.reason else None),
            ], thumb=avatar_of(who) if who is not None else None, actor=actor))
