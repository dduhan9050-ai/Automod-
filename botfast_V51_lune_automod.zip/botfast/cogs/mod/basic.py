from __future__ import annotations

import asyncio
import collections
import time
from datetime import timedelta
from typing import Optional, Union

import discord
from discord.ext import commands

from core import Cog
from utils import modui as ui
from utils.modstore import store

AnyChannel = Union[discord.TextChannel, discord.VoiceChannel, discord.StageChannel, discord.ForumChannel]
VOICE = (discord.VoiceChannel, discord.StageChannel)

LOCK_TEXT = {"send_messages": False, "send_messages_in_threads": False}
LOCK_VOICE = {"connect": False}
MAX_TIMEOUT = 28 * 86400


def _is_voice(channel) -> bool:
    return isinstance(channel, VOICE)


async def _set_everyone(channel, guild: discord.Guild, reason: str, **perms) -> None:
    """Edit the @everyone overwrite in a single API call (no-op when nothing changes)."""
    default = guild.default_role
    current = channel.overwrites_for(default)
    wanted = channel.overwrites_for(default)
    wanted.update(**perms)
    if wanted == current:
        return
    await channel.set_permissions(default, overwrite=None if wanted.is_empty() else wanted, reason=reason)


class ModBasic(Cog, name="ModBasic"):
    """Core moderation commands."""

    def __init__(self, bot):
        self.bot = bot
        self._deleted: dict[int, collections.deque] = {}

    # ------------------------------------------------------------- listeners
    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        if message.guild is None or message.author.bot:
            return
        if not message.content and not message.attachments:
            return
        dq = self._deleted.get(message.channel.id)
        if dq is None:
            if len(self._deleted) >= 3000:
                self._deleted.pop(next(iter(self._deleted)), None)
            dq = self._deleted[message.channel.id] = collections.deque(maxlen=10)
        dq.appendleft((message.author.id, str(message.author), message.content[:1800],
                       [a.url for a in message.attachments][:3], time.time()))

    # ------------------------------------------------------------ punishments
    @commands.command(name="ban", help="Bans a user from the server.")
    @ui.guard({"ban_members": True}, {"ban_members": True})
    async def ban(self, ctx, user: discord.User, *, reason: str = None):
        member = ctx.guild.get_member(user.id)
        if (problem := ui.hierarchy(ctx, member or user)):
            return await ui.fail(ctx, problem)
        if member is not None:
            ui.spawn(ui.dm(member, f"You were **banned** from **{ui.esc(ctx.guild.name)}**.\nReason: {reason or ui.NO_REASON}"))
        await ctx.guild.ban(user, reason=ui.reason_text(ctx, reason), delete_message_seconds=0)
        await ui.ok(ctx, f"{ui.who(user)} has been **banned**.\n-# Reason: {reason or ui.NO_REASON}")

    @commands.command(name="softban", help="Bans then instantly unbans a user to wipe their recent messages.")
    @ui.guard({"ban_members": True}, {"ban_members": True})
    async def softban(self, ctx, user: discord.User, *, reason: str = None):
        member = ctx.guild.get_member(user.id)
        if (problem := ui.hierarchy(ctx, member or user)):
            return await ui.fail(ctx, problem)
        text = ui.reason_text(ctx, f"Softban: {reason or ui.NO_REASON}")
        await ctx.guild.ban(user, reason=text, delete_message_seconds=86400)
        await ctx.guild.unban(user, reason=text)
        await ui.ok(ctx, f"{ui.who(user)} has been **softbanned**.\n-# Reason: {reason or ui.NO_REASON}")

    @commands.command(name="kick", help="Kicks a member from the server.")
    @ui.guard({"kick_members": True}, {"kick_members": True})
    async def kick(self, ctx, member: discord.Member, *, reason: str = None):
        if (problem := ui.hierarchy(ctx, member)):
            return await ui.fail(ctx, problem)
        ui.spawn(ui.dm(member, f"You were **kicked** from **{ui.esc(ctx.guild.name)}**.\nReason: {reason or ui.NO_REASON}"))
        await member.kick(reason=ui.reason_text(ctx, reason))
        await ui.ok(ctx, f"{ui.who(member)} has been **kicked**.\n-# Reason: {reason or ui.NO_REASON}")

    @commands.command(name="mute", aliases=["timeout"], help="Times out a member (default 10 minutes).")
    @ui.guard({"moderate_members": True}, {"moderate_members": True})
    async def mute(self, ctx, member: discord.Member, duration: str = "10m", *, reason: str = None):
        if (problem := ui.hierarchy(ctx, member)):
            return await ui.fail(ctx, problem)
        seconds = ui.parse_duration(duration)
        if seconds is None:  # the "duration" was really the start of the reason
            reason = f"{duration} {reason or ''}".strip()
            seconds = 600
        if seconds > MAX_TIMEOUT:
            return await ui.fail(ctx, "The maximum mute duration is **28 days**.")
        await member.timeout(timedelta(seconds=seconds), reason=ui.reason_text(ctx, reason))
        ui.spawn(ui.dm(member, f"You were **muted** in **{ui.esc(ctx.guild.name)}** for {ui.fmt_duration(seconds)}.\nReason: {reason or ui.NO_REASON}"))
        await ui.ok(ctx, f"{ui.who(member)} has been **muted** for `{ui.fmt_duration(seconds)}`.\n-# Reason: {reason or ui.NO_REASON}")

    @commands.command(name="unmute", help="Removes the timeout from a member.")
    @ui.guard({"moderate_members": True}, {"moderate_members": True})
    async def unmute(self, ctx, member: discord.Member, *, reason: str = None):
        if not member.is_timed_out():
            return await ui.fail(ctx, f"{ui.who(member)} is not muted.")
        await member.timeout(None, reason=ui.reason_text(ctx, reason))
        await ui.ok(ctx, f"{ui.who(member)} has been **unmuted**.")

    @commands.command(name="unban", help="Unbans a user.")
    @ui.guard({"ban_members": True}, {"ban_members": True})
    async def unban(self, ctx, user: discord.User, *, reason: str = None):
        try:
            await ctx.guild.unban(user, reason=ui.reason_text(ctx, reason))
        except discord.NotFound:
            return await ui.fail(ctx, f"{ui.who(user)} is not banned.")
        await ui.ok(ctx, f"{ui.who(user)} has been **unbanned**.")

    @commands.command(name="unbanall", help="Unbans every banned user in the server.")
    @ui.guard({"administrator": True}, {"ban_members": True})
    async def unbanall(self, ctx):
        banned = [entry.user async for entry in ctx.guild.bans(limit=None)]
        if not banned:
            return await ui.fail(ctx, "There are no banned users in this server.")
        reason = ui.reason_text(ctx, "Unban all")
        await ui.run_bulk(ctx, banned, lambda u: ctx.guild.unban(u, reason=reason), workers=10, ack_over=5,
                          start=f"Unbanning **{len(banned)}** users...",
                          done=lambda p: f"Unbanned **{p.ok}** users" + (f" (`{p.bad}` failed)." if p.bad else "."))

    @commands.command(name="nick", help="Changes or resets a member's nickname.")
    @ui.guard({"manage_nicknames": True}, {"manage_nicknames": True})
    async def nick(self, ctx, member: discord.Member, *, nickname: str = None):
        if (problem := ui.hierarchy(ctx, member, allow_self=True)):
            return await ui.fail(ctx, problem)
        await member.edit(nick=nickname[:32] if nickname else None, reason=ui.reason_text(ctx, "Nickname change"))
        if nickname:
            await ui.ok(ctx, f"Changed {ui.who(member)}'s nickname to **{ui.esc(nickname[:32])}**.")
        else:
            await ui.ok(ctx, f"Reset {ui.who(member)}'s nickname.")

    # ----------------------------------------------------------------- snipe
    @commands.command(name="snipe", help="Shows the last deleted message in this channel.")
    @ui.guard({"manage_messages": True})
    async def snipe(self, ctx, number: int = 1):
        rows = self._deleted.get(ctx.channel.id)
        if not rows:
            return await ui.fail(ctx, "There is nothing to snipe in this channel.")
        if not 1 <= number <= len(rows):
            return await ui.fail(ctx, f"Pick a number between `1` and `{len(rows)}`.")
        author_id, author, content, files, when = rows[number - 1]
        body = [f"### {ui.TICK} Sniped message", f"**Author:** <@{author_id}> (`{ui.esc(author)}`)",
                f"**Deleted:** <t:{int(when)}:R>", ""]
        body.append(content or "*no text*")
        if files:
            body.append("\n" + "\n".join(f"[attachment {i}]({u})" for i, u in enumerate(files, 1)))
        body.append(f"-# {number}/{len(rows)}")
        await ui.send(ctx, ui.card("\n".join(body)))

    # ------------------------------------------------------- lock / hide one
    async def _toggle(self, ctx, channel, *, lock: Optional[bool] = None, hide: Optional[bool] = None):
        channel = channel or ctx.channel
        guild = ctx.guild
        if lock is not None:
            perms = LOCK_VOICE if _is_voice(channel) else LOCK_TEXT
            perms = {k: (False if lock else None) for k in perms}
            action = "Locked" if lock else "Unlocked"
        else:
            perms = {"view_channel": False if hide else None}
            action = "Hidden" if hide else "Unhidden"
        await _set_everyone(channel, guild, ui.reason_text(ctx, action), **perms)
        await ui.ok(ctx, f"{action} {channel.mention} for `@everyone`.")

    @commands.command(name="lock", help="Locks a channel for @everyone.")
    @ui.guard({"manage_channels": True}, {"manage_channels": True})
    async def lock(self, ctx, channel: Optional[AnyChannel] = None):
        await self._toggle(ctx, channel, lock=True)

    @commands.command(name="unlock", help="Unlocks a channel for @everyone.")
    @ui.guard({"manage_channels": True}, {"manage_channels": True})
    async def unlock(self, ctx, channel: Optional[AnyChannel] = None):
        await self._toggle(ctx, channel, lock=False)

    @commands.command(name="hide", help="Hides a channel from @everyone.")
    @ui.guard({"manage_channels": True}, {"manage_channels": True})
    async def hide(self, ctx, channel: Optional[AnyChannel] = None):
        await self._toggle(ctx, channel, hide=True)

    @commands.command(name="unhide", help="Makes a hidden channel visible again.")
    @ui.guard({"manage_channels": True}, {"manage_channels": True})
    async def unhide(self, ctx, channel: Optional[AnyChannel] = None):
        await self._toggle(ctx, channel, hide=False)

    # ------------------------------------------------------ lock / hide all
    async def _all(self, ctx, *, lock: Optional[bool] = None, hide: Optional[bool] = None):
        guild = ctx.guild
        channels = [c for c in guild.channels if not isinstance(c, discord.CategoryChannel)]
        if lock is not None:
            word = "locked" if lock else "unlocked"
            reason = ui.reason_text(ctx, f"{word.title()} all channels")

            async def work(ch):
                keys = LOCK_VOICE if _is_voice(ch) else LOCK_TEXT
                await _set_everyone(ch, guild, reason, **{k: (False if lock else None) for k in keys})
        else:
            word = "hidden" if hide else "unhidden"
            reason = ui.reason_text(ctx, f"{word.title()} all channels")

            async def work(ch):
                await _set_everyone(ch, guild, reason, view_channel=False if hide else None)

        await ui.run_bulk(ctx, channels, work, workers=10, start=f"Working on **{len(channels)}** channels...",
                          done=lambda p: f"**{p.ok}** channels {word}" + (f" (`{p.bad}` failed)." if p.bad else "."))

    @commands.command(name="lockall", help="Locks every channel for @everyone.")
    @ui.guard({"administrator": True}, {"manage_channels": True})
    async def lockall(self, ctx):
        await self._all(ctx, lock=True)

    @commands.command(name="unlockall", help="Unlocks every channel for @everyone.")
    @ui.guard({"administrator": True}, {"manage_channels": True})
    async def unlockall(self, ctx):
        await self._all(ctx, lock=False)

    @commands.command(name="hideall", help="Hides every channel from @everyone.")
    @ui.guard({"administrator": True}, {"manage_channels": True})
    async def hideall(self, ctx):
        await self._all(ctx, hide=True)

    @commands.command(name="unhideall", help="Makes every hidden channel visible again.")
    @ui.guard({"administrator": True}, {"manage_channels": True})
    async def unhideall(self, ctx):
        await self._all(ctx, hide=False)

    # ----------------------------------------------------- clone / nuke / slow
    @commands.command(name="clone", help="Clones a channel with all its settings.")
    @ui.guard({"manage_channels": True}, {"manage_channels": True})
    async def clone(self, ctx, channel: Optional[AnyChannel] = None):
        channel = channel or ctx.channel
        new = await channel.clone(reason=ui.reason_text(ctx, "Channel clone"))
        await new.edit(position=channel.position + 1)
        await ui.ok(ctx, f"Cloned {channel.mention} -> {new.mention}.")

    @commands.command(name="nuke", help="Deletes and recreates a channel (wipes all messages).")
    @ui.guard({"manage_channels": True}, {"manage_channels": True})
    async def nuke(self, ctx, channel: Optional[discord.TextChannel] = None):
        channel = channel or ctx.channel
        reason = ui.reason_text(ctx, "Channel nuke")
        new = await channel.clone(reason=reason)
        position = channel.position
        await asyncio.gather(channel.delete(reason=reason), new.edit(position=position))
        cfg = store.get_cfg(ctx.guild.id)
        if cfg["channel"] == channel.id:
            store.set_cfg(ctx.guild.id, channel=new.id)
        await new.send(view=ui.line(ui.TICK, f"Channel **nuked** by {ui.who(ctx.author)}."), allowed_mentions=ui.NO_PING)
        if channel.id != ctx.channel.id:
            await ui.ok(ctx, f"Nuked {new.mention}.")

    @commands.command(name="slowmode", help="Sets the slowmode of a channel (e.g. 5s, 2m).")
    @ui.guard({"manage_channels": True}, {"manage_channels": True})
    async def slowmode(self, ctx, duration: str, channel: Optional[discord.TextChannel] = None):
        channel = channel or ctx.channel
        seconds = 0 if duration.lower() in ("off", "0") else ui.parse_duration(duration, "s")
        if seconds is None or seconds > 21600:
            return await ui.fail(ctx, "Use a duration between `1s` and `6h` (e.g. `5s`, `2m`, `1h`).")
        await channel.edit(slowmode_delay=seconds, reason=ui.reason_text(ctx, "Slowmode"))
        await ui.ok(ctx, f"Slowmode of {channel.mention} is now `{ui.fmt_duration(seconds)}`." if seconds else f"Slowmode disabled in {channel.mention}.")

    @commands.command(name="unslowmode", help="Disables the slowmode of a channel.")
    @ui.guard({"manage_channels": True}, {"manage_channels": True})
    async def unslowmode(self, ctx, channel: Optional[discord.TextChannel] = None):
        channel = channel or ctx.channel
        await channel.edit(slowmode_delay=0, reason=ui.reason_text(ctx, "Slowmode off"))
        await ui.ok(ctx, f"Slowmode disabled in {channel.mention}.")
