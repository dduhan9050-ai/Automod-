from __future__ import annotations

import asyncio
import logging
import time
from typing import Optional, Union

import discord
from discord.ext import commands

from core import Cog
from utils import modui as ui
from utils.modstore import store

log = logging.getLogger("deathbot.mod.channels")

Target = Union[discord.Member, discord.Role]
MAX_DELAY = 365 * 86400


class ModChannels(Cog, name="ModChannels"):
    """Channel management group."""

    def __init__(self, bot):
        self.bot = bot
        self._timers: dict[int, asyncio.Task] = {}

    async def cog_load(self):
        await asyncio.to_thread(store.load)
        for cid, (_gid, due) in list(store.delete_after.items()):
            self._schedule(cid, due)

    async def cog_unload(self):
        for task in self._timers.values():
            task.cancel()
        self._timers.clear()

    # ----------------------------------------------------- scheduled deletion
    def _schedule(self, cid: int, due: float) -> None:
        old = self._timers.pop(cid, None)
        if old:
            old.cancel()
        self._timers[cid] = asyncio.ensure_future(self._runner(cid, due))

    async def _runner(self, cid: int, due: float) -> None:
        try:
            await self.bot.wait_until_ready()
            delay = due - time.time()
            if delay > 0:
                await asyncio.sleep(delay)
            channel = self.bot.get_channel(cid)
            if channel is not None:
                await channel.delete(reason="Scheduled deletion (channel deleteafter)")
        except asyncio.CancelledError:
            raise  # keep the DB row: it is rescheduled after a restart
        except Exception:
            log.exception("deleteafter failed for %s", cid)
        self._timers.pop(cid, None)
        store.del_delete_after(cid)

    # ----------------------------------------------------------------- group
    @commands.group(name="channel", invoke_without_command=True, help="Channel management commands.")
    @ui.guard()
    async def channel(self, ctx):
        await ctx.send_help(ctx.command)

    @channel.command(name="create", help="Creates a new text channel.")
    @ui.guard({"manage_channels": True}, {"manage_channels": True})
    async def channel_create(self, ctx, *, name: str):
        new = await ctx.guild.create_text_channel(name[:100], reason=ui.reason_text(ctx, "Channel create"))
        await ui.ok(ctx, f"Created {new.mention}.")

    @channel.command(name="delete", help="Deletes a channel.")
    @ui.guard({"manage_channels": True}, {"manage_channels": True})
    async def channel_delete(self, ctx, channel: discord.abc.GuildChannel):
        name = channel.name
        same = channel.id == ctx.channel.id
        self._cancel(channel.id)
        await channel.delete(reason=ui.reason_text(ctx, "Channel delete"))
        if same:
            ui.spawn(ui.dm(ctx.author, f"Deleted **#{ui.esc(name)}**."))
        else:
            await ui.ok(ctx, f"Deleted **#{ui.esc(name)}**.")

    @channel.command(name="rename", help="Renames a channel.")
    @ui.guard({"manage_channels": True}, {"manage_channels": True})
    async def channel_rename(self, ctx, channel: discord.abc.GuildChannel, *, name: str):
        await channel.edit(name=name[:100], reason=ui.reason_text(ctx, "Channel rename"))
        await ui.ok(ctx, f"Renamed to {channel.mention}.")

    @channel.command(name="deleteafter", help="Deletes a channel after a delay (use `off` to cancel).")
    @ui.guard({"manage_channels": True}, {"manage_channels": True})
    async def channel_deleteafter(self, ctx, channel: discord.abc.GuildChannel, duration: str):
        if duration.lower() in ("off", "cancel", "stop"):
            if channel.id not in store.delete_after:
                return await ui.fail(ctx, f"{channel.mention} has no scheduled deletion.")
            self._cancel(channel.id)
            return await ui.ok(ctx, f"Cancelled the scheduled deletion of {channel.mention}.")
        seconds = ui.parse_duration(duration)
        if seconds is None or seconds > MAX_DELAY:
            return await ui.fail(ctx, "Use a duration like `30m`, `12h` or `7d` (max 365 days).")
        due = time.time() + seconds
        store.set_delete_after(channel.id, ctx.guild.id, due)
        self._schedule(channel.id, due)
        await ui.ok(ctx, f"{channel.mention} will be deleted <t:{int(due)}:R>.")

    def _cancel(self, cid: int) -> None:
        task = self._timers.pop(cid, None)
        if task:
            task.cancel()
        store.del_delete_after(cid)

    @channel.command(name="transfer", help="Moves a channel into another category.")
    @ui.guard({"manage_channels": True}, {"manage_channels": True})
    async def channel_transfer(self, ctx, channel: discord.abc.GuildChannel, *, category: discord.CategoryChannel):
        if isinstance(channel, discord.CategoryChannel):
            return await ui.fail(ctx, "A category can't be moved into another category.")
        await channel.edit(category=category, reason=ui.reason_text(ctx, "Channel transfer"))
        await ui.ok(ctx, f"Moved {channel.mention} to **{ui.esc(category.name)}**.")

    @channel.command(name="add", help="Gives a member or role access to a channel.")
    @ui.guard({"manage_channels": True}, {"manage_channels": True, "manage_roles": True})
    async def channel_add(self, ctx, target: Target, channel: Optional[discord.abc.GuildChannel] = None):
        channel = channel or ctx.channel
        if isinstance(channel, (discord.VoiceChannel, discord.StageChannel)):
            overwrite = discord.PermissionOverwrite(view_channel=True, connect=True, speak=True)
        else:
            overwrite = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)
        await channel.set_permissions(target, overwrite=overwrite, reason=ui.reason_text(ctx, "Channel add"))
        await ui.ok(ctx, f"{target.mention} can now access {channel.mention}.")

    @channel.command(name="remove", help="Removes a member's or role's access overwrite from a channel.")
    @ui.guard({"manage_channels": True}, {"manage_channels": True, "manage_roles": True})
    async def channel_remove(self, ctx, target: Target, channel: Optional[discord.abc.GuildChannel] = None):
        channel = channel or ctx.channel
        await channel.set_permissions(target, overwrite=None, reason=ui.reason_text(ctx, "Channel remove"))
        await ui.ok(ctx, f"Removed the overwrite of {target.mention} from {channel.mention}.")
