from __future__ import annotations

import io
import re
from pathlib import PurePath
from typing import Optional

import discord
from components_v2 import media_gallery
from discord.ext import commands

from core import Cog
from utils import modui as ui

EMOJI_RE = re.compile(r"<(a?):(\w{2,32}):(\d{15,25})>")


def _clean_name(name: str) -> str:
    name = re.sub(r"\W", "_", name)[:32]
    return name if len(name) >= 2 else (name + "_e")


async def _replied(ctx) -> Optional[discord.Message]:
    ref = ctx.message.reference
    if not ref:
        return None
    if isinstance(ref.resolved, discord.Message):
        return ref.resolved
    try:
        return await ctx.channel.fetch_message(ref.message_id)
    except discord.HTTPException:
        return None


class ModEmoji(Cog, name="ModEmoji"):
    """Emoji / sticker tools."""

    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="enlarge", help="Shows a custom emoji in full size.")
    @ui.guard()
    async def enlarge(self, ctx, emoji: str):
        match = EMOJI_RE.search(emoji)
        if not match:
            return await ui.fail(ctx, "Give me a **custom emoji** to enlarge.")
        animated, name, eid = match.groups()
        url = f"https://cdn.discordapp.com/emojis/{eid}.{'gif' if animated else 'png'}?size=512&quality=lossless"
        gallery = media_gallery(url)
        await ui.send(ctx, ui.card(f"### {ui.TICK} {ui.esc(name)}", gallery, f"-# ID: {eid}"))

    @commands.command(name="steal", aliases=["eadd"], help="Adds emojis / stickers from text or a replied message.")
    @ui.guard({"manage_expressions": True}, {"manage_expressions": True})
    async def steal(self, ctx, *, emojis: str = None):
        sources: list[tuple[str, str, bool]] = []  # (kind, name/url, animated)
        stickers: list[discord.StickerItem] = []
        attachments: list[discord.Attachment] = []
        for animated, name, eid in EMOJI_RE.findall(emojis or ""):
            sources.append((eid, name, bool(animated)))
        replied = await _replied(ctx)
        if replied is not None:
            for animated, name, eid in EMOJI_RE.findall(replied.content or ""):
                sources.append((eid, name, bool(animated)))
            stickers = list(replied.stickers)
            attachments = [a for a in replied.attachments if (a.content_type or "").startswith("image/")]
        attachments += [a for a in ctx.message.attachments if (a.content_type or "").startswith("image/")]
        seen, unique = set(), []
        for item in sources:
            if item[0] not in seen:
                seen.add(item[0])
                unique.append(item)
        if not (unique or stickers or attachments):
            return await ui.fail(ctx, "No emoji, sticker or image found. Pass an emoji or reply to a message that has one.")

        added: list[str] = []
        errors = 0
        reason = ui.reason_text(ctx, "Steal")
        guild = ctx.guild

        async def add_emoji(eid, name, animated):
            partial = discord.PartialEmoji(name=name, id=int(eid), animated=animated)
            created = await guild.create_custom_emoji(name=_clean_name(name), image=await partial.read(), reason=reason)
            added.append(str(created))

        async def add_attachment(att):
            created = await guild.create_custom_emoji(name=_clean_name(PurePath(att.filename).stem),
                                                      image=await att.read(), reason=reason)
            added.append(str(created))

        async def add_sticker(item):
            sticker = await item.fetch()
            data = await ui.fetch_bytes(self.bot, sticker.url)
            created = await guild.create_sticker(
                name=_clean_name(sticker.name), description=(getattr(sticker, "description", None) or "Stolen sticker")[:100],
                emoji=getattr(sticker, "emoji", None) or "🙂",
                file=discord.File(io.BytesIO(data), filename=f"{sticker.id}.png"), reason=reason)
            added.append(f"sticker **{ui.esc(created.name)}**")

        progress = ui.Progress()
        jobs = ([(add_emoji, u) for u in unique] + [(add_attachment, (a,)) for a in attachments]
                + [(add_sticker, (s,)) for s in stickers])

        async def run(job):
            fn, args = job
            await fn(*args)

        await ui.pool(jobs, run, progress, workers=3)
        errors = progress.bad
        if not added:
            return await ui.err(ctx, "Couldn't add anything - the server may be out of emoji slots, or the file is invalid.")
        text = "Added " + " ".join(added[:20])
        if errors:
            text += f"\n-# {errors} failed"
        await ui.ok(ctx, text)

    @commands.command(name="deleteemoji", aliases=["removeemoji"], help="Deletes custom emojis from the server.")
    @ui.guard({"manage_expressions": True}, {"manage_expressions": True})
    async def deleteemoji(self, ctx, *, emojis: str):
        ids = [int(eid) for _, _, eid in EMOJI_RE.findall(emojis)]
        if not ids:
            return await ui.fail(ctx, "Give me one or more **custom emojis** to delete.")
        deleted = 0
        reason = ui.reason_text(ctx, "Delete emoji")
        for eid in ids:
            emoji = ctx.guild.get_emoji(eid)
            if emoji is None:
                continue
            await emoji.delete(reason=reason)
            deleted += 1
        if not deleted:
            return await ui.fail(ctx, "None of those emojis belong to this server.")
        await ui.ok(ctx, f"Deleted **{deleted}** emoji{'s' if deleted != 1 else ''}.")

    @commands.command(name="deletesticker", aliases=["removesticker"],
                      help="Deletes a server sticker (reply to it, or give its name).")
    @ui.guard({"manage_expressions": True}, {"manage_expressions": True})
    async def deletesticker(self, ctx, *, name: str = None):
        sticker = None
        replied = await _replied(ctx)
        if replied is not None and replied.stickers:
            sticker = discord.utils.get(ctx.guild.stickers, id=replied.stickers[0].id)
        if sticker is None and name:
            sticker = discord.utils.find(lambda s: s.name.lower() == name.lower() or str(s.id) == name.strip(), ctx.guild.stickers)
        if sticker is None:
            return await ui.fail(ctx, "Reply to a server sticker or give its name.")
        label = sticker.name
        await sticker.delete(reason=ui.reason_text(ctx, "Delete sticker"))
        await ui.ok(ctx, f"Deleted the sticker **{ui.esc(label)}**.")
