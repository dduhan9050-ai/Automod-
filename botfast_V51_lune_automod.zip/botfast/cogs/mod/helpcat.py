from __future__ import annotations

from core import Cog

SECTIONS = (
    ("Basic Commands", [
        "ban", "softban", "kick", "mute", "unmute", "unban", "nick", "clone", "nuke", "hideall", "unhideall",
        "lockall", "unlockall", "unbanall", "lock", "unlock", "hide", "unhide", "slowmode", "unslowmode",
        "channel", "channel rename", "channel deleteafter", "channel transfer", "channel remove", "channel create",
        "channel add", "channel delete", "enlarge", "steal", "deleteemoji", "deletesticker", "snipe"]),
    ("Role Commands", [
        "role", "role add", "role delete", "role bots", "role humans", "role icon", "role remove", "role create",
        "role colour", "role all", "role taskcancel", "role rename", "rrole", "rrole humans", "rrole bots", "rrole all"]),
    ("Purge Commands", [
        "clear", "clear emoji", "clear files", "clear all", "clear image", "clear user", "clear reactions",
        "clear mentions", "clear contain", "clear bots", "clear embed", "purgeuser", "purgebots"]),
    ("Quarantine Commands", [
        "quarantine", "quarantine remove", "quarantine add", "quarantine reset", "quarantine config",
        "quarantine setup", "quarantine show", "unquarantine"]),
)


class ModerationHelp(Cog, name="ModerationHelp"):
    """Help-menu category: Moderation"""

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        return "<a:emoji_71:1567130056093077665>", "Moderation", "Show you Commands of Moderation"

    def help_body(self, prefix: str = "") -> str:
        blocks = []
        for title, names in SECTIONS:
            blocks.append(f"__**{title}**__\n" + " , ".join(f"`{n}`" for n in names))
        return "\n\n".join(blocks)
