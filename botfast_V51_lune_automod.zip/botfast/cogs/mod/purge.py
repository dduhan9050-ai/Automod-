from __future__ import annotations

import re
from datetime import timedelta
from typing import Callable, Optional, Union

import discord
from discord.ext import commands

from core import Cog
from utils import modui as ui

MAX_SCAN = 1000
CUSTOM_EMOJI = re.compile(r"<a?:\w{2,32}:\d{15,25}>")
UNICODE_EMOJI = re.compile("[\U0001F300-\U0001FAFF\u2600-\u27BF\U0001F1E6-\U0001F1FF]")

Check = Callable[[discord.Message], bool]


def _is_image(m: discord.Message) -> bool:
    return any((a.content_type or "").startswith("image/") for a in m.attachments) or any(e.type == "image" for e in m.embeds)


def _has_emoji(m: discord.Message) -> bool:
    return bool(m.content and (CUSTOM_EMOJI.search(m.content) or UNICODE_EMOJI.search(m.content)))


def _is_mention(m: discord.Message) -> bool:
    return bool(m.mentions or m.role_mentions or m.mention_everyone)


class ModPurge(Cog, name="ModPurge"):
    """Message purging."""

    def __init__(self, bot):
        self.bot = bot

    async def _purge(self, ctx, scan: int, check: Optional[Check] = None, what: str = "messages"):
        scan = max(1, min(int(scan), MAX_SCAN))
        # Discord can only bulk-delete messages younger than 14 days - never walk older ones one by one.
        cutoff = discord.utils.utcnow() - timedelta(days=14) + timedelta(minutes=1)
        reason = ui.reason_text(ctx, f"Purge {what}")
        try:
            await ctx.message.delete()
        except discord.HTTPException:
            pass
        deleted = await ctx.channel.purge(limit=scan, check=check or (lambda m: True), before=ctx.message,
                                          after=cutoff, oldest_first=False, bulk=True, reason=reason)
        view = ui.line(ui.TICK if deleted else ui.CROSS,
                       f"Cleared **{len(deleted)}** {what}." if deleted else f"No {what} found to clear.")
        await ctx.channel.send(view=view, delete_after=4, allowed_mentions=ui.NO_PING)

    # ------------------------------------------------------------------ group
    @commands.group(name="clear", aliases=["purge"], invoke_without_command=True, extras={"help_self": True},
                    help="Deletes the given number of recent messages.")
    @ui.guard({"manage_messages": True}, {"manage_messages": True, "read_message_history": True})
    async def clear(self, ctx, amount: int):
        await self._purge(ctx, amount)

    @clear.command(name="all", help="Deletes all recent messages.")
    @ui.guard({"manage_messages": True}, {"manage_messages": True, "read_message_history": True})
    async def clear_all(self, ctx, amount: int = 100):
        await self._purge(ctx, amount)

    @clear.command(name="bots", aliases=["bot", "b"], help="Deletes messages sent by bots.")
    @ui.guard({"manage_messages": True}, {"manage_messages": True, "read_message_history": True})
    async def clear_bots(self, ctx, amount: int = 100):
        await self._purge(ctx, amount, lambda m: m.author.bot, "bot messages")

    @clear.command(name="contain", aliases=["contains"], help="Deletes messages containing a text.")
    @ui.guard({"manage_messages": True}, {"manage_messages": True, "read_message_history": True})
    async def clear_contain(self, ctx, *, text: str):
        needle = text.lower()
        await self._purge(ctx, 100, lambda m: needle in (m.content or "").lower(), f"messages containing `{text[:40]}`")

    @clear.command(name="embed", aliases=["embeds"], help="Deletes messages with embeds.")
    @ui.guard({"manage_messages": True}, {"manage_messages": True, "read_message_history": True})
    async def clear_embed(self, ctx, amount: int = 100):
        await self._purge(ctx, amount, lambda m: bool(m.embeds), "embed messages")

    @clear.command(name="emoji", aliases=["emojis"], help="Deletes messages containing emojis.")
    @ui.guard({"manage_messages": True}, {"manage_messages": True, "read_message_history": True})
    async def clear_emoji(self, ctx, amount: int = 100):
        await self._purge(ctx, amount, _has_emoji, "emoji messages")

    @clear.command(name="files", aliases=["file"], help="Deletes messages with attachments.")
    @ui.guard({"manage_messages": True}, {"manage_messages": True, "read_message_history": True})
    async def clear_files(self, ctx, amount: int = 100):
        await self._purge(ctx, amount, lambda m: bool(m.attachments), "file messages")

    @clear.command(name="image", aliases=["images"], help="Deletes messages with images.")
    @ui.guard({"manage_messages": True}, {"manage_messages": True, "read_message_history": True})
    async def clear_image(self, ctx, amount: int = 100):
        await self._purge(ctx, amount, _is_image, "image messages")

    @clear.command(name="mentions", aliases=["mention"], help="Deletes messages with mentions.")
    @ui.guard({"manage_messages": True}, {"manage_messages": True, "read_message_history": True})
    async def clear_mentions(self, ctx, amount: int = 100):
        await self._purge(ctx, amount, _is_mention, "mention messages")

    @clear.command(name="user", help="Deletes messages sent by a user.")
    @ui.guard({"manage_messages": True}, {"manage_messages": True, "read_message_history": True})
    async def clear_user(self, ctx, user: discord.User, amount: int = 100):
        await self._purge(ctx, amount, lambda m: m.author.id == user.id, f"messages from {user.name}")

    @clear.command(name="reactions", aliases=["reaction"], help="Removes reactions from recent messages.")
    @ui.guard({"manage_messages": True}, {"manage_messages": True, "read_message_history": True})
    async def clear_reactions(self, ctx, amount: int = 100):
        amount = max(1, min(amount, MAX_SCAN))
        targets = [m async for m in ctx.channel.history(limit=amount, before=ctx.message) if m.reactions]
        if not targets:
            return await ui.fail(ctx, "No reactions found to clear.")
        await ui.run_bulk(ctx, targets, lambda m: m.clear_reactions(), workers=6, ack_over=15,
                          start=f"Clearing reactions from **{len(targets)}** messages...",
                          done=lambda p: f"Cleared reactions from **{p.ok}** messages.")

    # ---------------------------------------------------------- shortcuts
    @commands.command(name="purgeuser", help="Deletes messages sent by a user.")
    @ui.guard({"manage_messages": True}, {"manage_messages": True, "read_message_history": True})
    async def purgeuser(self, ctx, user: discord.User, amount: int = 100):
        await self._purge(ctx, amount, lambda m: m.author.id == user.id, f"messages from {user.name}")

    @commands.command(name="purgebots", help="Deletes messages sent by bots.")
    @ui.guard({"manage_messages": True}, {"manage_messages": True, "read_message_history": True})
    async def purgebots(self, ctx, amount: int = 100):
        await self._purge(ctx, amount, lambda m: m.author.bot, "bot messages")
