from __future__ import annotations

import logging
from typing import Optional, Union

import discord
from discord.ext import commands

from core import Cog
from utils import modui as ui
from utils.modstore import store

log = logging.getLogger("deathbot.mod.quarantine")

ROLE_NAME = "Quarantine"
CHANNEL_NAME = "quarantine"

# What the quarantine role gets in EVERY other channel / category.
Q_DENY = discord.PermissionOverwrite(view_channel=False, send_messages=False, add_reactions=False,
                                     connect=False, speak=False)
# What it gets in the quarantine channel.
Q_ALLOW = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)


class QuarantineError(Exception):
    """A problem that can be shown to the user as-is."""


class Quarantine(Cog, name="Quarantine"):
    """Quarantine system - strips roles and locks a member into one channel."""

    def __init__(self, bot):
        self.bot = bot
        self._busy: set[int] = set()   # guilds currently running a setup / reset

    async def cog_load(self):
        import asyncio
        await asyncio.to_thread(store.load)

    # ----------------------------------------------------------------- core
    @staticmethod
    async def _apply(channel, role: discord.Role, overwrite: Optional[discord.PermissionOverwrite], reason: str) -> None:
        if overwrite is not None and channel.overwrites_for(role) == overwrite:
            return
        if overwrite is None and role not in channel.overwrites:
            return
        await channel.set_permissions(role, overwrite=overwrite, reason=reason)

    async def _sweep(self, guild: discord.Guild, role: discord.Role, skip_id: Optional[int],
                     overwrite: Optional[discord.PermissionOverwrite], reason: str) -> ui.Progress:
        """Apply (or clear) the quarantine overwrite on every category and channel."""
        targets = [c for c in guild.channels if c.id != skip_id]
        progress = ui.Progress(len(targets))
        await ui.pool(targets, lambda c: self._apply(c, role, overwrite, reason), progress, workers=10)
        return progress

    async def _ensure(self, guild: discord.Guild, role: Optional[discord.Role] = None,
                      channel: Optional[discord.TextChannel] = None, force_sweep: bool = False):
        """Create / reuse the quarantine role + channel and lock the role out of everything else."""
        me = guild.me
        if not me.guild_permissions.manage_roles or not me.guild_permissions.manage_channels:
            raise QuarantineError("I need **Manage Roles** and **Manage Channels** to set up quarantine.")
        cfg = store.get_cfg(guild.id)
        reason = "Quarantine setup"
        self._busy.add(guild.id)
        try:
            created_role = created_channel = False
            if role is None and cfg["role"]:
                role = guild.get_role(cfg["role"])
            if role is None:
                role = discord.utils.get(guild.roles, name=ROLE_NAME)
            if role is None:
                role = await guild.create_role(name=ROLE_NAME, permissions=discord.Permissions.none(),
                                               colour=discord.Colour(0x2B2D31), reason=reason)
                created_role = True
            else:
                if role.is_default() or role.managed:
                    raise QuarantineError("That role can't be used for quarantine.")
                if role >= me.top_role:
                    raise QuarantineError(f"My top role must be higher than **{ui.esc(role.name)}**.")

            if channel is None and cfg["channel"]:
                found = guild.get_channel(cfg["channel"])
                channel = found if isinstance(found, discord.TextChannel) else None
            if channel is None:
                channel = discord.utils.get(guild.text_channels, name=CHANNEL_NAME)
            if channel is None:
                channel = await guild.create_text_channel(
                    CHANNEL_NAME,
                    overwrites={
                        guild.default_role: discord.PermissionOverwrite(view_channel=False),
                        role: Q_ALLOW,
                        me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True),
                    },
                    topic="Quarantined members can only see this channel.", reason=reason)
                created_channel = True
            else:
                await self._apply(channel, role, Q_ALLOW, reason)

            same_role = cfg["role"] == role.id
            same_channel = cfg["channel"] == channel.id
            store.set_cfg(guild.id, role=role.id, channel=channel.id,
                          auto_role=created_role or (same_role and cfg["auto_role"]),
                          auto_channel=created_channel or (same_channel and cfg["auto_channel"]))

            swept = None
            if created_role or force_sweep or role.id != cfg["role"]:
                swept = await self._sweep(guild, role, channel.id, Q_DENY, reason)
            return role, channel, created_role, created_channel, swept
        finally:
            self._busy.discard(guild.id)

    def _current(self, guild: discord.Guild):
        cfg = store.get_cfg(guild.id)
        role = guild.get_role(cfg["role"]) if cfg["role"] else None
        channel = guild.get_channel(cfg["channel"]) if cfg["channel"] else None
        return cfg, role, channel

    # ------------------------------------------------------------- listeners
    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        guild = channel.guild
        cfg = store.cfg.get(guild.id)
        if not cfg or not cfg["role"] or guild.id in self._busy or channel.id == cfg["channel"]:
            return
        role = guild.get_role(cfg["role"])
        if role is not None:
            try:
                await self._apply(channel, role, Q_DENY, "Quarantine: new channel")
            except discord.HTTPException:
                pass

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if member.id not in store.guild_members(member.guild.id):
            return
        role = member.guild.get_role(store.get_cfg(member.guild.id)["role"] or 0)
        if role is not None:
            try:
                await member.add_roles(role, reason="Quarantine: rejoined while quarantined", atomic=False)
            except discord.HTTPException:
                pass

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        cfg = store.cfg.get(role.guild.id)
        if cfg and cfg["role"] == role.id:
            store.set_cfg(role.guild.id, role=None, auto_role=False)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        cfg = store.cfg.get(channel.guild.id)
        if cfg and cfg["channel"] == channel.id:
            store.set_cfg(channel.guild.id, channel=None, auto_channel=False)

    @commands.Cog.listener()
    async def on_guild_remove(self, guild: discord.Guild):
        store.clear_guild(guild.id)

    # ----------------------------------------------------------------- group
    @commands.group(name="quarantine", invoke_without_command=True, help="Quarantine commands.")
    @ui.guard()
    async def quarantine(self, ctx):
        await ctx.send_help(ctx.command)

    @quarantine.command(name="setup", help="Setup quarantine role and channel.")
    @ui.guard({"administrator": True}, {"manage_roles": True, "manage_channels": True})
    async def q_setup(self, ctx, role: Optional[discord.Role] = None, channel: Optional[discord.TextChannel] = None):
        ack = await ui.send(ctx, ui.line(ui.WAIT, "Setting up quarantine..."))
        try:
            role, channel, made_role, made_channel, swept = await self._ensure(ctx.guild, role, channel, force_sweep=True)
        except QuarantineError as exc:
            return await ui.edit(ack, ui.line(ui.CROSS, str(exc)))
        rows = [f"{ui.ARROW} **Role :** {role.mention}" + (" *(created)*" if made_role else ""),
                f"{ui.ARROW} **Channel :** {channel.mention}" + (" *(created)*" if made_channel else "")]
        if swept is not None:
            rows.append(f"{ui.ARROW} **Locked in :** `{swept.ok}` channels & categories"
                        + (f" (`{swept.bad}` failed)" if swept.bad else ""))
        await ui.edit(ack, ui.panel(ui.TICK, "Quarantine Setup Complete", *rows))

    @quarantine.command(name="config", help="Show the quarantine configuration.")
    @ui.guard({"manage_roles": True})
    async def q_config(self, ctx):
        cfg, role, channel = self._current(ctx.guild)
        count = len(store.guild_members(ctx.guild.id))
        body = (f"### <:emoji_81:1567148256260005978> Quarantine Configuration\n"
                f"__**Role**__ : {role.mention if role else '`Not Set`'}\n"
                f"__**Channel**__ : {channel.mention if channel else '`Not Set`'}\n"
                f"__**Quarantined**__ : `{count}` members")
        avatar = ctx.bot.user.display_avatar.url
        head = discord.ui.Section(discord.ui.TextDisplay(body), accessory=discord.ui.Thumbnail(media=avatar))
        foot = f"-# Requested by {ctx.author.mention} (`{ctx.author.name}`)"
        await ui.send(ctx, ui.card(head, discord.ui.Separator(), foot))

    async def _quarantine(self, ctx, member: discord.Member, reason: Optional[str]):
        guild = ctx.guild
        cfg, role, channel = self._current(guild)
        if role is None or channel is None:
            ack = await ui.send(ctx, ui.line(ui.WAIT, "Quarantine isn't set up yet - setting it up now..."))
            try:
                role, channel, *_ = await self._ensure(guild)
            except QuarantineError as exc:
                return await ui.edit(ack, ui.line(ui.CROSS, str(exc)))
        if member.id in store.guild_members(guild.id):
            return await ui.fail(ctx, f"{ui.who(member)} is already quarantined.")
        if (problem := ui.hierarchy(ctx, member)):
            return await ui.fail(ctx, problem)
        saved = [r.id for r in member.roles if not r.is_default() and not r.managed and r.id != role.id]
        keep = [r for r in member.roles if r.managed]
        fields = {"roles": keep + [role], "reason": ui.reason_text(ctx, f"Quarantine: {reason or ui.NO_REASON}")}
        if member.voice is not None:
            fields["voice_channel"] = None
        await member.edit(**fields)
        store.add_member(guild.id, member.id, saved, reason, ctx.author.id)
        await ui.ok(ctx, f"{ui.who(member)} has been **quarantined**.\n-# Reason: {reason or ui.NO_REASON}")
        ui.spawn(channel.send(
            view=ui.line(ui.WARN, f"{member.mention} you have been **quarantined**.\nReason: {reason or ui.NO_REASON}"),
            allowed_mentions=discord.AllowedMentions(users=[member])))

    async def _release(self, ctx, target: Union[discord.Member, discord.User], reason: Optional[str]):
        guild = ctx.guild
        record = store.guild_members(guild.id).get(target.id)
        cfg, role, _ = self._current(guild)
        has_role = isinstance(target, discord.Member) and role is not None and role in target.roles
        if record is None and not has_role:
            return await ui.fail(ctx, f"{ui.who(target)} is not quarantined.")
        if isinstance(target, discord.Member):
            await self._restore(guild, target, record, role, ui.reason_text(ctx, f"Unquarantine: {reason or ui.NO_REASON}"))
        store.remove_member(guild.id, target.id)
        await ui.ok(ctx, f"{ui.who(target)} has been **unquarantined**.")

    @staticmethod
    async def _restore(guild: discord.Guild, member: discord.Member, record: Optional[dict],
                       qrole: Optional[discord.Role], reason: str) -> None:
        final = {r.id: r for r in member.roles if not r.is_default() and (qrole is None or r.id != qrole.id)}
        for rid in (record or {}).get("roles", []):
            r = guild.get_role(rid)
            if r is not None and not r.managed and r < guild.me.top_role:
                final[r.id] = r
        await member.edit(roles=list(final.values()), reason=reason)

    @quarantine.command(name="add", help="Quarantine a member.")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def q_add(self, ctx, member: discord.Member, *, reason: str = None):
        await self._quarantine(ctx, member, reason)

    @quarantine.command(name="remove", help="Unquarantine a member.")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def q_remove(self, ctx, member: Union[discord.Member, discord.User], *, reason: str = None):
        await self._release(ctx, member, reason)

    @commands.command(name="unquarantine", help="Unquarantine a member.")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def unquarantine(self, ctx, member: Union[discord.Member, discord.User], *, reason: str = None):
        await self._release(ctx, member, reason)

    @quarantine.command(name="show", help="Show all quarantined members.")
    @ui.guard({"manage_roles": True})
    async def q_show(self, ctx):
        rows = store.guild_members(ctx.guild.id)
        if not rows:
            return await ui.fail(ctx, "No members are quarantined right now.")
        entries = []
        for i, (uid, rec) in enumerate(sorted(rows.items(), key=lambda kv: kv[1]["ts"], reverse=True), 1):
            entries.append(f"**{i}.** <@{uid}> (`{uid}`)\n> {ui.ARROW} {rec.get('reason') or ui.NO_REASON}\n"
                           f"> {ui.ARROW} by <@{rec['mod']}> • <t:{int(rec['ts'])}:R>")
        title = f"{ctx.bot.user.name} quarantined [{len(entries)}]"
        await ui.send_pager(ctx, ui.ListPager(ctx, title, entries, per_page=5, legend=False, sep="\n"))

    @quarantine.command(name="reset", help="Reset all quarantine data for this server.")
    @ui.guard({"administrator": True}, {"manage_roles": True})
    async def q_reset(self, ctx):
        guild = ctx.guild
        cfg, role, channel = self._current(guild)
        records = dict(store.guild_members(guild.id))
        if not cfg["role"] and not cfg["channel"] and not records:
            return await ui.fail(ctx, "There is no quarantine data to reset.")
        ack = await ui.send(ctx, ui.line(ui.WAIT, "Resetting quarantine..."))
        reason = ui.reason_text(ctx, "Quarantine reset")
        self._busy.add(guild.id)
        try:
            restored = ui.Progress(len(records))

            async def free(uid):
                member = guild.get_member(uid)
                if member is not None:
                    await self._restore(guild, member, records.get(uid), role, reason)

            await ui.pool(list(records), free, restored, workers=6)
            if role is not None:
                if cfg["auto_role"]:
                    await role.delete(reason=reason)
                else:
                    await self._sweep(guild, role, None, None, reason)
            if channel is not None and cfg["auto_channel"]:
                await channel.delete(reason=reason)
        except discord.HTTPException as exc:
            log.warning("quarantine reset: %s", exc)
        finally:
            self._busy.discard(guild.id)
        store.clear_guild(guild.id)
        await ui.edit(ack, ui.line(ui.TICK, f"Quarantine data reset. Restored **{restored.ok}** member"
                                           f"{'s' if restored.ok != 1 else ''}."))
