from __future__ import annotations

import asyncio
from typing import Optional

import discord
from discord.ext import commands

from core import Cog
from utils import modui as ui

HUMANS, BOTS, ALL = "humans", "bots", "all"
_KIND_LABEL = {HUMANS: "humans", BOTS: "bots", ALL: "members"}


def _wanted(kind: str):
    if kind == HUMANS:
        return lambda m: not m.bot
    if kind == BOTS:
        return lambda m: m.bot
    return lambda m: True


class ModRoles(Cog, name="ModRoles"):
    """Role management (single + bulk)."""

    def __init__(self, bot):
        self.bot = bot
        self._jobs: dict[int, tuple[asyncio.Task, ui.Progress, str]] = {}

    async def cog_unload(self):
        for task, _, _ in self._jobs.values():
            task.cancel()
        self._jobs.clear()

    # -------------------------------------------------------------- bulk job
    async def _bulk(self, ctx, role: discord.Role, kind: str, remove: bool):
        guild = ctx.guild
        if (problem := ui.role_error(ctx, role)):
            return await ui.fail(ctx, problem)
        if guild.id in self._jobs:
            return await ui.fail(ctx, "A role task is already running here. Use `role taskcancel` to stop it.")
        match = _wanted(kind)
        members = [m for m in guild.members if match(m) and ((role in m.roles) == remove)]
        verb, prep = ("Removing", "from") if remove else ("Giving", "to")
        if not members:
            return await ui.fail(ctx, f"Nothing to do - no {_KIND_LABEL[kind]} need this change for **{ui.esc(role.name)}**.")
        reason = ui.reason_text(ctx, f"Role {'remove' if remove else 'add'} {kind}")
        if remove:
            fn = lambda m: m.remove_roles(role, reason=reason, atomic=False)
        else:
            fn = lambda m: m.add_roles(role, reason=reason, atomic=False)
        ack = await ui.send(ctx, ui.line(ui.WAIT, f"{verb} **{ui.esc(role.name)}** {prep} **{len(members)}** {_KIND_LABEL[kind]}...\n"
                                                  f"-# Use `{ctx.clean_prefix}role taskcancel` to stop."))
        ui.spawn(self._run(guild.id, ack, members, fn, role, remove, kind))

    async def _run(self, gid, ack, members, fn, role, remove, kind):
        progress = ui.Progress(len(members))
        self._jobs[gid] = (asyncio.current_task(), progress, role.name)
        cancelled = False
        try:
            await ui.pool(members, fn, progress, workers=10)
        except asyncio.CancelledError:
            cancelled = True
        finally:
            self._jobs.pop(gid, None)
        word = "removed from" if remove else "given to"
        text = f"**{ui.esc(role.name)}** {word} **{progress.ok}** {_KIND_LABEL[kind]}"
        if progress.bad:
            text += f" (`{progress.bad}` failed)"
        if cancelled:
            text += f".\n-# Task cancelled with {progress.total - progress.ok - progress.bad} left"
        await ui.edit(ack, ui.line(ui.CROSS if cancelled else ui.TICK, text + "."))

    # ------------------------------------------------------------ role group
    @commands.group(name="role", invoke_without_command=True, extras={"help_self": True},
                    help="Gives a role to a member, or removes it if they have it.")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def role(self, ctx, member: discord.Member, *, role: discord.Role):
        if (problem := ui.role_error(ctx, role) or ui.hierarchy(ctx, member, allow_self=True)):
            return await ui.fail(ctx, problem)
        reason = ui.reason_text(ctx, "Role toggle")
        if role in member.roles:
            await member.remove_roles(role, reason=reason, atomic=False)
            await ui.ok(ctx, f"Removed **{ui.esc(role.name)}** from {ui.who(member)}.")
        else:
            await member.add_roles(role, reason=reason, atomic=False)
            await ui.ok(ctx, f"Gave **{ui.esc(role.name)}** to {ui.who(member)}.")

    @role.command(name="add", help="Gives a role to a member.")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def role_add(self, ctx, member: discord.Member, *, role: discord.Role):
        if (problem := ui.role_error(ctx, role) or ui.hierarchy(ctx, member, allow_self=True)):
            return await ui.fail(ctx, problem)
        if role in member.roles:
            return await ui.fail(ctx, f"{ui.who(member)} already has **{ui.esc(role.name)}**.")
        await member.add_roles(role, reason=ui.reason_text(ctx, "Role add"), atomic=False)
        await ui.ok(ctx, f"Gave **{ui.esc(role.name)}** to {ui.who(member)}.")

    @role.command(name="remove", help="Removes a role from a member.")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def role_remove(self, ctx, member: discord.Member, *, role: discord.Role):
        if (problem := ui.role_error(ctx, role) or ui.hierarchy(ctx, member, allow_self=True)):
            return await ui.fail(ctx, problem)
        if role not in member.roles:
            return await ui.fail(ctx, f"{ui.who(member)} doesn't have **{ui.esc(role.name)}**.")
        await member.remove_roles(role, reason=ui.reason_text(ctx, "Role remove"), atomic=False)
        await ui.ok(ctx, f"Removed **{ui.esc(role.name)}** from {ui.who(member)}.")

    @role.command(name="create", help="Creates a new role.")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def role_create(self, ctx, *, name: str):
        new = await ctx.guild.create_role(name=name[:100], reason=ui.reason_text(ctx, "Role create"))
        await ui.ok(ctx, f"Created the role {new.mention}.")

    @role.command(name="delete", aliases=["clear"], help="Deletes a role.")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def role_delete(self, ctx, *, role: discord.Role):
        if (problem := ui.role_error(ctx, role)):
            return await ui.fail(ctx, problem)
        name = role.name
        await role.delete(reason=ui.reason_text(ctx, "Role delete"))
        await ui.ok(ctx, f"Deleted the role **{ui.esc(name)}**.")

    @role.command(name="rename", help="Renames a role.")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def role_rename(self, ctx, role: discord.Role, *, name: str):
        if (problem := ui.role_error(ctx, role)):
            return await ui.fail(ctx, problem)
        await role.edit(name=name[:100], reason=ui.reason_text(ctx, "Role rename"))
        await ui.ok(ctx, f"Renamed the role to {role.mention}.")

    @role.command(name="colour", aliases=["color"], help="Changes the colour of a role (hex).")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def role_colour(self, ctx, role: discord.Role, colour: discord.Colour):
        if (problem := ui.role_error(ctx, role)):
            return await ui.fail(ctx, problem)
        await role.edit(colour=colour, reason=ui.reason_text(ctx, "Role colour"))
        await ui.ok(ctx, f"Changed the colour of {role.mention} to `{colour}`.")

    @role.command(name="icon", help="Sets a role icon (emoji, image link or attachment). Use `remove` to clear.")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def role_icon(self, ctx, role: discord.Role, icon: str = None):
        if (problem := ui.role_error(ctx, role)):
            return await ui.fail(ctx, problem)
        if "ROLE_ICONS" not in ctx.guild.features:
            return await ui.fail(ctx, "This server needs **Boost Level 2** to use role icons.")
        reason = ui.reason_text(ctx, "Role icon")
        if icon and icon.lower() in ("remove", "none", "off", "clear"):
            await role.edit(display_icon=None, reason=reason)
            return await ui.ok(ctx, f"Removed the icon of {role.mention}.")
        value: object
        if ctx.message.attachments:
            value = await ui.fetch_bytes(self.bot, ctx.message.attachments[0].url)
        elif icon and icon.startswith(("http://", "https://")):
            value = await ui.fetch_bytes(self.bot, icon)
        elif icon:
            partial = discord.PartialEmoji.from_str(icon)
            value = await partial.read() if partial.id else icon
        else:
            return await ctx.send_help(ctx.command)
        await role.edit(display_icon=value, reason=reason)
        await ui.ok(ctx, f"Updated the icon of {role.mention}.")

    @role.command(name="all", help="Gives a role to every member.")
    @ui.guard({"administrator": True}, {"manage_roles": True})
    async def role_all(self, ctx, *, role: discord.Role):
        await self._bulk(ctx, role, ALL, remove=False)

    @role.command(name="humans", help="Gives a role to every human.")
    @ui.guard({"administrator": True}, {"manage_roles": True})
    async def role_humans(self, ctx, *, role: discord.Role):
        await self._bulk(ctx, role, HUMANS, remove=False)

    @role.command(name="bots", help="Gives a role to every bot.")
    @ui.guard({"administrator": True}, {"manage_roles": True})
    async def role_bots(self, ctx, *, role: discord.Role):
        await self._bulk(ctx, role, BOTS, remove=False)

    @role.command(name="taskcancel", help="Cancels the running bulk role task.")
    @ui.guard({"manage_roles": True})
    async def role_taskcancel(self, ctx):
        job = self._jobs.get(ctx.guild.id)
        if not job:
            return await ui.fail(ctx, "There is no running role task.")
        job[0].cancel()
        await ui.ok(ctx, f"Cancelling the task for **{ui.esc(job[2])}**...")

    # ----------------------------------------------------------- rrole group
    @commands.group(name="rrole", invoke_without_command=True, extras={"help_self": True},
                    help="Removes a role from a member.")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def rrole(self, ctx, member: discord.Member, *, role: discord.Role):
        if (problem := ui.role_error(ctx, role) or ui.hierarchy(ctx, member, allow_self=True)):
            return await ui.fail(ctx, problem)
        if role not in member.roles:
            return await ui.fail(ctx, f"{ui.who(member)} doesn't have **{ui.esc(role.name)}**.")
        await member.remove_roles(role, reason=ui.reason_text(ctx, "Role remove"), atomic=False)
        await ui.ok(ctx, f"Removed **{ui.esc(role.name)}** from {ui.who(member)}.")

    @rrole.command(name="all", help="Removes a role from every member.")
    @ui.guard({"administrator": True}, {"manage_roles": True})
    async def rrole_all(self, ctx, *, role: discord.Role):
        await self._bulk(ctx, role, ALL, remove=True)

    @rrole.command(name="humans", help="Removes a role from every human.")
    @ui.guard({"administrator": True}, {"manage_roles": True})
    async def rrole_humans(self, ctx, *, role: discord.Role):
        await self._bulk(ctx, role, HUMANS, remove=True)

    @rrole.command(name="bots", help="Removes a role from every bot.")
    @ui.guard({"administrator": True}, {"manage_roles": True})
    async def rrole_bots(self, ctx, *, role: discord.Role):
        await self._bulk(ctx, role, BOTS, remove=True)
