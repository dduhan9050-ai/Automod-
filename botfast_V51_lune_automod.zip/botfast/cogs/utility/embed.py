"""Utility: Embed System  (embed + variables).

Every embed is stored per server under a name, edited through a dropdown + modals
and rendered as a white (#ffffff) Components V2 card.
"""
from __future__ import annotations

import asyncio
import copy
import io
from typing import Optional

import discord
from discord.ext import commands

from core import Cog
from utils import modui as ui
from utils import utilkit as kit
from utils.utility_store import MAX_EMBEDS, store

TICK, CROSS, CORNER = kit.TICK, kit.CROSS, kit.CORNER

# (label, description, key)
OPTIONS = (
    ("Basic Info", "Edit title, description, and color", "basic"),
    ("URL", "Edit the embed URL (makes title a link)", "url"),
    ("Thumbnail", "Edit the embed thumbnail URL", "thumbnail"),
    ("Image", "Edit the embed image URL", "image"),
    ("Footer", "Edit the embed footer text and icon", "footer"),
    ("Author", "Edit the embed author name, icon, and URL", "author"),
    ("Toggle Timestamp", "Add or remove timestamp from embed", "timestamp"),
    ("Add Field", "Add a new field (max 25)", "addfield"),
    ("Edit Field", "Edit an existing field", "editfield"),
    ("Remove Field", "Remove an existing field", "removefield"),
    ("Shift Field Up", "Move a field up one spot", "up"),
    ("Shift Field Down", "Move a field down one spot", "down"),
    ("Move Field", "Move a field to a specific index", "move"),
)


def variables_guide(name: str) -> discord.ui.LayoutView:
    return kit.card(
        "## <:emoji_81:1567148256260005978> Embed Variables Guide\n"
        "Variables allow you to dynamically insert user, server, and context-specific information into your embeds.",
        discord.ui.Separator(),
        f"{TICK} **How to Use Variables**\n"
        "❯ Run `/variables [module]` command\n"
        "❯ Select the module where you'll use this embed\n"
        "❯ View all available variables for that module\n"
        "❯ Copy and paste variables into your embed",
        f"{TICK} **Example Commands**\n"
        "`/variables embed` ❯ *View variables for embeds*\n"
        "`/variables sticky` ❯ *View variables for sticky messages*\n"
        "`/variables welcome` ❯ *View variables for welcome messages*\n"
        "`/variables greet` ❯ *View variables for greet system*",
        f"{TICK} **When are Variables Processed?**\n"
        "❯ Variables are replaced with actual values when the embed is sent\n"
        "❯ During editing, you'll see the variable placeholder (e.g., `{user_name}`)\n"
        "❯ When sent, it becomes the actual value (e.g., `John`)",
        discord.ui.Separator(),
        f"-# Embed: {name} • Variables make your embeds dynamic!",
    )


# ------------------------------------------------------------------ editor
class _EditorSelect(discord.ui.Select):
    def __init__(self):
        super().__init__(
            placeholder="Choose an option to edit the Embed", min_values=1, max_values=1,
            options=[discord.SelectOption(label=l, description=d, value=k, emoji="<a:emoji_39:1567099222103294022>") for l, d, k in OPTIONS])

    async def callback(self, interaction: discord.Interaction):
        await self.view.on_select(interaction, self.values[0])


class _EditorButton(discord.ui.Button):
    def __init__(self, action: str, **kw):
        super().__init__(**kw)
        self.action = action

    async def callback(self, interaction: discord.Interaction):
        await getattr(self.view, f"btn_{self.action}")(interaction)


class _Modal(discord.ui.Modal):
    """Generic modal: ``handler(new_data, values)`` mutates a copy of the embed or raises ValueError."""

    def __init__(self, editor: "EmbedEditor", title: str, inputs: list, handler):
        super().__init__(title=title[:45], timeout=300)
        self.editor, self.handler = editor, handler
        self.inputs: dict[str, discord.ui.TextInput] = {}
        for key, item in inputs:
            self.inputs[key] = item
            self.add_item(item)

    async def on_submit(self, interaction: discord.Interaction):
        values = {k: (v.value or "").strip() for k, v in self.inputs.items()}
        new = copy.deepcopy(self.editor.data)
        try:
            self.handler(new, values)
            kit.validate(new)
        except ValueError as exc:
            return await interaction.response.send_message(view=ui.line(CROSS, str(exc)), ephemeral=True)
        await self.editor.commit(interaction, new)

    async def on_error(self, interaction: discord.Interaction, error: Exception):
        try:
            await interaction.response.send_message(view=ui.line(ui.WARN, "Something went wrong."), ephemeral=True)
        except discord.HTTPException:
            pass


def _ti(label: str, *, default: Optional[str] = None, long: bool = False, required: bool = False,
        maxlen: int = 256, placeholder: Optional[str] = None) -> discord.ui.TextInput:
    return discord.ui.TextInput(
        label=label[:45], default=(default or None), required=required, max_length=maxlen,
        style=discord.TextStyle.paragraph if long else discord.TextStyle.short, placeholder=placeholder)


def _index(text: str, size: int, what: str = "Field") -> int:
    if not text.lstrip("-").isdigit():
        raise ValueError(f"{what} number must be a number from 1 to {size}.")
    n = int(text)
    if not 1 <= n <= size:
        raise ValueError(f"{what} number must be between 1 and {size}.")
    return n - 1


def _yes(text: str) -> bool:
    return text.lower() in ("yes", "y", "true", "1", "inline")


class EmbedEditor(discord.ui.LayoutView):
    """Dropdown + Done / Variables / Cancel under a live white preview."""

    def __init__(self, ctx: commands.Context, name: str, data: dict, created: bool = False):
        super().__init__(timeout=600)
        self.ctx, self.name, self.data, self.created = ctx, name, data, created
        self.owner_id = ctx.author.id
        self.edits = 0
        self.message: Optional[discord.Message] = None
        self.closed = False
        self._build()

    # ---------------------------------------------------------------- layout
    def _build(self) -> None:
        self.clear_items()
        head = (f"**You just created a new Embed with name `{self.name}`!**" if self.created
                else f"**Editing the Embed `{self.name}`**")
        box = discord.ui.Container(accent_colour=kit.WHITE)
        box.add_item(kit.td(
            f"{head}\n\n**What now?**\n"
            "• Use there the Dropdown to edit the Embed.\n"
            "• Can use the embed in Supported modules by referring as `{embed:" + self.name + "}`"))
        box.add_item(discord.ui.Separator())
        box.add_item(kit.td(
            "Update the Embed using the dropdown below!\n"
            "Use there the `/variables` command to know about variables\n\n"
            "-# Use there {embed:" + self.name + "} to use! | Timeout : 10 Minutes"))
        row = discord.ui.ActionRow()
        row.add_item(_EditorSelect())
        box.add_item(row)
        buttons = discord.ui.ActionRow()
        buttons.add_item(_EditorButton("done", label="Done", emoji="<:emoji_4:1566043104551768114>", style=discord.ButtonStyle.secondary))
        buttons.add_item(_EditorButton("variables", label="Variables", emoji="<:emoji_81:1567148256260005978>", style=discord.ButtonStyle.secondary))
        buttons.add_item(_EditorButton("cancel", label="Cancel", emoji="<a:emoji_38:1567096105299214336>", style=discord.ButtonStyle.danger))
        box.add_item(buttons)
        self.add_item(box)
        self.add_item(kit.embed_container(self.data, preview=True))

    def rebuild(self) -> "EmbedEditor":
        self._build()
        return self

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == self.owner_id:
            return True
        await interaction.response.send_message(
            view=ui.line(CROSS, "That message doesn't belong to you. You must run this command to interact with it."),
            ephemeral=True)
        return False

    # ----------------------------------------------------------------- state
    async def commit(self, interaction: discord.Interaction, new: dict) -> None:
        self.data = new
        self.edits += 1
        store.save_embed(self.ctx.guild.id, self.name, new)
        await interaction.response.edit_message(view=self.rebuild())

    async def _refresh(self) -> None:
        """Re-render after a modal opens so the dropdown is reset and can be picked again."""
        if self.message is not None and not self.closed:
            try:
                await self.message.edit(view=self.rebuild())
            except discord.HTTPException:
                pass

    async def _ask(self, interaction: discord.Interaction, title: str, inputs: list, handler) -> None:
        await interaction.response.send_modal(_Modal(self, title, inputs, handler))
        asyncio.ensure_future(self._refresh())

    async def _warn(self, interaction: discord.Interaction, text: str) -> None:
        await interaction.response.send_message(view=ui.line(CROSS, text), ephemeral=True)
        asyncio.ensure_future(self._refresh())

    # --------------------------------------------------------------- dropdown
    async def on_select(self, interaction: discord.Interaction, key: str) -> None:
        d = self.data
        fields = d.get("fields") or []

        if key == "timestamp":
            new = copy.deepcopy(d)
            new["timestamp"] = not d.get("timestamp")
            return await self.commit(interaction, new)

        if key == "basic":
            def apply(new, v):
                for k in ("title", "description"):
                    if v[k]:
                        new[k] = v[k]
                    else:
                        new.pop(k, None)
                color = kit.parse_color(v["color"])
                if color is None:
                    new.pop("color", None)
                else:
                    new["color"] = color
            col = d.get("color")
            return await self._ask(interaction, "Basic Info", [
                ("title", _ti("Title", default=d.get("title"))),
                ("description", _ti("Description", default=d.get("description"), long=True, maxlen=4000)),
                ("color", _ti("Color (hex)", default=f"#{col:06x}" if col is not None else None, maxlen=7,
                              placeholder="#ffffff")),
            ], apply)

        simple = {
            "url": ("Embed URL", "Embed URL", "url", d.get("url")),
            "thumbnail": ("Thumbnail", "Thumbnail URL", "thumbnail", d.get("thumbnail")),
            "image": ("Image", "Image URL", "image", d.get("image")),
        }
        if key in simple:
            title, label, field, current = simple[key]

            def apply(new, v, field=field, label=label):
                url = kit.check_url(v["url"], label)
                if url:
                    new[field] = url
                else:
                    new.pop(field, None)
            return await self._ask(interaction, title, [
                ("url", _ti(label, default=current, maxlen=500, placeholder="https://..."))], apply)

        if key == "footer":
            foot = d.get("footer") or {}

            def apply(new, v):
                if not v["text"]:
                    new.pop("footer", None)
                    return
                new["footer"] = {"text": v["text"], "icon_url": kit.check_url(v["icon"], "Footer icon") or None}
            return await self._ask(interaction, "Footer", [
                ("text", _ti("Footer text", default=foot.get("text"), maxlen=2048)),
                ("icon", _ti("Footer icon URL", default=foot.get("icon_url"), maxlen=500, placeholder="https://..."))], apply)

        if key == "author":
            auth = d.get("author") or {}

            def apply(new, v):
                if not v["name"]:
                    new.pop("author", None)
                    return
                new["author"] = {"name": v["name"], "icon_url": kit.check_url(v["icon"], "Author icon") or None,
                                 "url": kit.check_url(v["url"], "Author URL") or None}
            return await self._ask(interaction, "Author", [
                ("name", _ti("Author name", default=auth.get("name"))),
                ("icon", _ti("Author icon URL", default=auth.get("icon_url"), maxlen=500, placeholder="https://...")),
                ("url", _ti("Author URL", default=auth.get("url"), maxlen=500, placeholder="https://..."))], apply)

        if key == "addfield":
            if len(fields) >= kit.MAX_FIELDS:
                return await self._warn(interaction, f"An embed can have at most {kit.MAX_FIELDS} fields.")

            def apply(new, v):
                if not v["name"] or not v["value"]:
                    raise ValueError("A field needs both a name and a value.")
                new["fields"].append({"name": v["name"], "value": v["value"], "inline": _yes(v["inline"])})
            return await self._ask(interaction, "Add Field", [
                ("name", _ti("Field name", required=True)),
                ("value", _ti("Field value", long=True, required=True, maxlen=1024)),
                ("inline", _ti("Inline? (yes / no)", maxlen=3, placeholder="no"))], apply)

        # everything below needs at least one field
        if not fields:
            return await self._warn(interaction, "This embed has no fields yet. Use **Add Field** first.")
        size = len(fields)
        num = _ti("Field number", required=True, maxlen=2, placeholder=f"1 - {size}")

        if key == "editfield":
            def apply(new, v):
                f = new["fields"][_index(v["num"], size)]
                if v["name"]:
                    f["name"] = v["name"]
                if v["value"]:
                    f["value"] = v["value"]
                if v["inline"]:
                    f["inline"] = _yes(v["inline"])
            return await self._ask(interaction, "Edit Field", [
                ("num", num),
                ("name", _ti("New name (blank = keep)")),
                ("value", _ti("New value (blank = keep)", long=True, maxlen=1024)),
                ("inline", _ti("Inline? yes / no (blank = keep)", maxlen=3))], apply)

        if key == "removefield":
            def apply(new, v):
                new["fields"].pop(_index(v["num"], size))
            return await self._ask(interaction, "Remove Field", [("num", num)], apply)

        if key in ("up", "down"):
            def apply(new, v, up=key == "up"):
                i = _index(v["num"], size)
                j = i - 1 if up else i + 1
                if not 0 <= j < size:
                    raise ValueError("That field is already at the " + ("top." if up else "bottom."))
                new["fields"][i], new["fields"][j] = new["fields"][j], new["fields"][i]
            return await self._ask(interaction, "Shift Field Up" if key == "up" else "Shift Field Down",
                                   [("num", num)], apply)

        if key == "move":
            def apply(new, v):
                i, j = _index(v["num"], size), _index(v["to"], size, "Target")
                new["fields"].insert(j, new["fields"].pop(i))
            return await self._ask(interaction, "Move Field", [
                ("num", num), ("to", _ti("Move to index", required=True, maxlen=2, placeholder=f"1 - {size}"))], apply)

    # ---------------------------------------------------------------- buttons
    def _close_view(self, text: str, preview: bool = True) -> discord.ui.LayoutView:
        view = discord.ui.LayoutView(timeout=None)
        view.add_item(discord.ui.Container(kit.td(text), accent_colour=kit.WHITE))
        if preview:
            view.add_item(kit.embed_container(self.data, preview=True))
        return view

    async def btn_done(self, interaction: discord.Interaction) -> None:
        self.closed = True
        self.stop()
        p = self.ctx.clean_prefix
        await interaction.response.edit_message(view=self._close_view(
            f"{TICK} **Embed Saved**\n{CORNER} `{self.name}` is ready. Send it with `{p}embed send {self.name}` "
            "or use `{embed:" + self.name + "}` in supported modules."))

    async def btn_variables(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_message(view=variables_guide(self.name), ephemeral=True)

    async def btn_cancel(self, interaction: discord.Interaction) -> None:
        self.closed = True
        self.stop()
        if self.created and self.edits == 0:
            store.delete_embed(self.ctx.guild.id, self.name)
            text = f"{CROSS} **Setup Cancelled**\n{CORNER} The empty embed `{self.name}` was discarded."
        else:
            text = f"{CROSS} **Editor Closed**\n{CORNER} Changes made to `{self.name}` so far are saved."
        await interaction.response.edit_message(view=self._close_view(text, preview=False))

    async def on_timeout(self) -> None:
        if self.closed or self.message is None:
            return
        self.closed = True
        try:
            await self.message.edit(view=self._close_view(
                f"<a:emoji_40:1567099263513526273> **Editor Timed Out**\n{CORNER} Changes made to `{self.name}` are saved. "
                f"Run `{self.ctx.clean_prefix}embed edit {self.name}` to continue."))
        except discord.HTTPException:
            pass


# --------------------------------------------------------------------- cog
class UtilEmbed(Cog, name="UtilEmbed"):
    """Embed System."""

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        await store.load()

    async def cog_unload(self):
        await store.flush()

    # -------------------------------------------------------------- helpers
    @staticmethod
    def _norm(name: str) -> str:
        return (name or "").lower()

    async def _get(self, ctx, name: str) -> Optional[dict]:
        data = store.get_embed(ctx.guild.id, name)
        if data is None:
            await ui.fail(ctx, f"No embed named `{name}`. See `{ctx.clean_prefix}embed show`.")
        return data

    # ---------------------------------------------------------------- group
    @commands.group(name="embed", invoke_without_command=True, help="Create, edit, save and send custom embeds.")
    @ui.guard()
    async def embed(self, ctx):
        await ctx.send_help(ctx.command)

    @embed.command(name="create", help="Create and save a new embed.")
    @ui.guard({"manage_messages": True})
    async def embed_create(self, ctx, name: str):
        name = self._norm(name)
        if not kit.valid_name(name):
            return await ui.fail(ctx, "The name can only contain letters, numbers, `_` and `-` (max 32 characters).")
        saved = store.embeds_of(ctx.guild.id)
        if name in saved:
            return await ui.fail(ctx, f"An embed named `{name}` already exists. Use `{ctx.clean_prefix}embed edit {name}`.")
        if len(saved) >= MAX_EMBEDS:
            return await ui.fail(ctx, f"This server already has {MAX_EMBEDS} saved embeds.")
        data = kit.new_embed()
        store.save_embed(ctx.guild.id, name, data)
        editor = EmbedEditor(ctx, name, data, created=True)
        editor.message = await ui.send(ctx, editor)

    @embed.command(name="edit", help="Edit a saved embed.")
    @ui.guard({"manage_messages": True})
    async def embed_edit(self, ctx, name: str):
        name = self._norm(name)
        data = await self._get(ctx, name)
        if data is None:
            return
        editor = EmbedEditor(ctx, name, copy.deepcopy(data))
        editor.message = await ui.send(ctx, editor)

    @embed.command(name="show", help="Show a saved embed, or list all saved embeds.")
    @ui.guard({"manage_messages": True})
    async def embed_show(self, ctx, name: str = None):
        if name:
            name = self._norm(name)
            data = await self._get(ctx, name)
            if data is None:
                return
            return await ui.send(ctx, kit.embed_view(data, ctx.author, ctx.guild, extra_text=f"-# Embed: `{name}`"))
        saved = sorted(store.embeds_of(ctx.guild.id))
        if not saved:
            return await ui.fail(ctx, f"No saved embeds yet. Create one with `{ctx.clean_prefix}embed create <name>`.")
        entries = [f"`[{i:02d}]` `{n}`" for i, n in enumerate(saved, 1)]
        await ui.send_pager(ctx, ui.ListPager(ctx, f"Saved Embeds [{len(saved)}]", entries, per_page=10,
                                              legend=False, sep="\n"))

    @embed.command(name="delete", help="Delete a saved embed.")
    @ui.guard({"manage_messages": True})
    async def embed_delete(self, ctx, name: str):
        name = self._norm(name)
        if not store.delete_embed(ctx.guild.id, name):
            return await ui.fail(ctx, f"No embed named `{name}`.")
        await ui.send(ctx, kit.result("Embed Deleted", f"The embed `{name}` was deleted."))

    @embed.command(name="rename", help="Rename a saved embed.")
    @ui.guard({"manage_messages": True})
    async def embed_rename(self, ctx, old: str, new: str):
        old, new = self._norm(old), self._norm(new)
        if store.get_embed(ctx.guild.id, old) is None:
            return await ui.fail(ctx, f"No embed named `{old}`.")
        if not kit.valid_name(new):
            return await ui.fail(ctx, "The name can only contain letters, numbers, `_` and `-` (max 32 characters).")
        if store.get_embed(ctx.guild.id, new) is not None:
            return await ui.fail(ctx, f"An embed named `{new}` already exists.")
        store.rename_embed(ctx.guild.id, old, new)
        await ui.send(ctx, kit.result("Embed Renamed", f"`{old}` is now `{new}`."))

    @embed.command(name="save", help="Save the embed of an existing message under a name.")
    @ui.guard({"manage_messages": True})
    async def embed_save(self, ctx, name: str, message: discord.Message = None):
        name = self._norm(name)
        if not kit.valid_name(name):
            return await ui.fail(ctx, "The name can only contain letters, numbers, `_` and `-` (max 32 characters).")
        if message is None:
            ref = ctx.message.reference
            message = ref.resolved if ref and isinstance(ref.resolved, discord.Message) else None
        if message is None or not message.embeds:
            return await ui.fail(ctx, "Reply to a message with an embed, or pass its link / ID.")
        saved = store.embeds_of(ctx.guild.id)
        if name in saved:
            return await ui.fail(ctx, f"An embed named `{name}` already exists.")
        if len(saved) >= MAX_EMBEDS:
            return await ui.fail(ctx, f"This server already has {MAX_EMBEDS} saved embeds.")
        try:
            data = kit.from_message_embed(message.embeds[0])
        except ValueError as exc:
            return await ui.fail(ctx, str(exc))
        store.save_embed(ctx.guild.id, name, data)
        await ui.send(ctx, kit.result("Embed Saved", f"Saved that embed as `{name}`."))

    @embed.command(name="export", help="Export a saved embed as a JSON file.")
    @ui.guard({"manage_messages": True})
    async def embed_export(self, ctx, name: str):
        name = self._norm(name)
        data = await self._get(ctx, name)
        if data is None:
            return
        text = kit.to_json(data)
        filename = f"{name}.json"
        info = f"{TICK} **Embed Exported**\n{CORNER} `{name}` as JSON. Import it with `{ctx.clean_prefix}embed import <name>`."
        try:
            view = kit.card(info, discord.ui.File(f"attachment://{filename}"))
            return await ui.send(ctx, view, file=discord.File(io.BytesIO(text.encode()), filename=filename))
        except (AttributeError, TypeError, ValueError):
            pass
        await ui.send(ctx, kit.card(f"{info}\n```json\n{text[:3000]}\n```"))

    @embed.command(name="import", help="Import an embed from a JSON file or pasted JSON.")
    @ui.guard({"manage_messages": True})
    async def embed_import(self, ctx, name: str, *, data: str = None):
        name = self._norm(name)
        if not kit.valid_name(name):
            return await ui.fail(ctx, "The name can only contain letters, numbers, `_` and `-` (max 32 characters).")
        raw = data
        if ctx.message.attachments:
            att = ctx.message.attachments[0]
            if att.size > 100_000:
                return await ui.fail(ctx, "That file is too large (max 100 KB).")
            raw = (await att.read()).decode("utf-8", "replace")
        if not raw:
            return await ui.fail(ctx, "Attach a `.json` file or paste the JSON after the name.")
        try:
            parsed = kit.parse_json_text(raw)
        except ValueError as exc:
            return await ui.fail(ctx, str(exc))
        saved = store.embeds_of(ctx.guild.id)
        existed = name in saved
        if not existed and len(saved) >= MAX_EMBEDS:
            return await ui.fail(ctx, f"This server already has {MAX_EMBEDS} saved embeds.")
        store.save_embed(ctx.guild.id, name, parsed)
        await ui.send(ctx, kit.result("Embed Imported", f"`{name}` was {'updated' if existed else 'created'}."))

    @embed.command(name="send", help="Send a saved embed to a channel.")
    @ui.guard({"manage_messages": True})
    async def embed_send(self, ctx, name: str, channel: discord.TextChannel = None):
        name = self._norm(name)
        data = await self._get(ctx, name)
        if data is None:
            return
        if kit.is_blank(data):
            return await ui.fail(ctx, f"`{name}` is empty. Edit it with `{ctx.clean_prefix}embed edit {name}` first.")
        channel = channel or ctx.channel
        if not channel.permissions_for(ctx.author).send_messages:
            return await ui.fail(ctx, f"You can't send messages in {channel.mention}.")
        if not channel.permissions_for(ctx.guild.me).send_messages:
            return await ui.fail(ctx, f"I can't send messages in {channel.mention}.")
        await channel.send(view=kit.embed_view(data, ctx.author, ctx.guild), allowed_mentions=ui.NO_PING)
        await ui.send(ctx, kit.result("Embed Sent", f"Successfully sent the embed `{name}` to {channel.mention}."))

    # ------------------------------------------------------------ variables
    @commands.hybrid_command(name="variables", hidden=True,
                             help="Show the variables you can use in embeds and sticky messages.")
    @ui.guard()
    async def variables(self, ctx, module: str = None):
        known = {"embed": "embeds", "sticky": "sticky messages", "welcome": "welcome messages", "greet": "the greet system"}
        module = (module or "embed").lower()
        if module not in known:
            return await ui.fail(ctx, "Pick a module: " + ", ".join(f"`{m}`" for m in known) + ".")
        lines = "\n".join(f"`{{{name}}}` ❯ {desc}" for name, desc in kit.VARIABLES)
        await ui.send(ctx, kit.card(f"### <:emoji_81:1567148256260005978> Variables for {known[module]}\n{lines}",
                                    discord.ui.Separator(),
                                    "-# Variables are replaced with real values when the message is sent."))
