"""Help-menu category: Utility (Embed System, Sticky Message, Reaction Role)."""
from __future__ import annotations

from core import Cog

SECTIONS = (
    ("Embed System", [
        "embed", "embed show", "embed create", "embed delete", "embed save", "embed export",
        "embed import", "embed edit", "embed send", "embed rename"]),
    ("Sticky Message", [
        "sticky", "sticky remove", "sticky add", "sticky channel", "sticky channel remove",
        "sticky channel add", "sticky bump", "sticky show"]),
    ("Reaction Role", [
        "reactionrole", "reactionrole show", "reactionrole clone", "reactionrole maxroles", "reactionrole add",
        "reactionrole remove", "reactionrole info", "reactionrole edit", "reactionrole format",
        "reactionrole clear", "reactionrole addmany"]),
)


class UtilityHelp(Cog, name="UtilityHelp"):
    """Help-menu category: Utility"""

    def __init__(self, bot):
        self.bot = bot

    def help_custom(self):
        return "<a:emoji_9:1566444878303461566>", "Utility", "Show you Commands of Utility"

    def help_body(self, prefix: str = "") -> str:
        blocks = []
        for title, names in SECTIONS:
            shown = [n for n in names if self.bot.get_command(n)]
            if shown:
                blocks.append(f"__**{title}**__\n" + " , ".join(f"`{n}`" for n in shown))
        return "\n\n".join(blocks)
