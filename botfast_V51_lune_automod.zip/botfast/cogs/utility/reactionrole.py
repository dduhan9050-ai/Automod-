"""Utility: Reaction Role  (reactionrole ... ).

Panels live in memory: a reaction event is one dict lookup + one role request, no database.
"""
from __future__ import annotations

import asyncio
from typing import Optional

import discord
from discord.ext import commands

from core import Cog
from utils import modui as ui
from utils import utilkit as kit
from utils.utility_store import FORMATS, MAX_RR_PER_MESSAGE, Panel, emoji_key, store

REASON = "Reaction role"


class UtilReactionRole(Cog, name="UtilReactionRole"):
    """Reaction Role."""

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        await store.load()

    async def cog_unload(self):
        await store.flush()

    # -------------------------------------------------------------- helpers
    @staticmethod
    def _jump(message: discord.Message) -> str:
        return f"[Jump to message]({message.jump_url})"

    async def _msg_ok(self, ctx, message: discord.Message) -> bool:
        if message.guild is None or message.guild.id != ctx.guild.id:
            await ui.fail(ctx, "That message isn't in this server.")
            return False
        return True

    async def _panel(self, ctx, message: discord.Message) -> Optional[Panel]:
        if not await self._msg_ok(ctx, message):
            return None
        panel = store.panels.get(message.id)
        if panel is None:
            await ui.fail(ctx, "That message has no reaction roles.")
        return panel

    @staticmethod
    def _emoji(text: str) -> Optional[discord.PartialEmoji]:
        try:
            emoji = discord.PartialEmoji.from_str(text.strip())
        except Exception:
            return None
        return emoji if emoji_key(emoji) else None

    @staticmethod
    async def _react(message: discord.Message, emoji: discord.PartialEmoji) -> Optional[str]:
        """Add the bot's reaction; return an error text on failure."""
        try:
            await message.add_reaction(emoji)
        except discord.Forbidden:
            return "I can't add reactions to that message."
        except discord.HTTPException:
            return f"I can't use `{emoji}` - use a normal emoji or one from a server I'm in."
        return None

    @staticmethod
    async def _unreact(message: discord.Message, display: str, who: discord.abc.Snowflake) -> None:
        try:
            await message.remove_reaction(discord.PartialEmoji.from_str(display), who)
        except discord.HTTPException:
            pass

    @staticmethod
    def _role_text(guild: discord.Guild, role_id: int) -> str:
        role = guild.get_role(role_id)
        return role.mention if role else f"`deleted role {role_id}`"

    # ---------------------------------------------------------------- group
    @commands.group(name="reactionrole", aliases=["rr"], invoke_without_command=True,
                    help="Manage reaction roles.")
    @ui.guard()
    async def reactionrole(self, ctx):
        await ctx.send_help(ctx.command)

    @reactionrole.command(name="add", help="Add a reaction role to a message.")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def rr_add(self, ctx, message: discord.Message, emoji: str, *, role: discord.Role):
        if not await self._msg_ok(ctx, message):
            return
        if (problem := ui.role_error(ctx, role)):
            return await ui.fail(ctx, problem)
        pe = self._emoji(emoji)
        if pe is None:
            return await ui.fail(ctx, "That isn't a valid emoji.")
        key = emoji_key(pe)
        panel = store.panels.get(message.id)
        if panel and key in panel.roles:
            return await ui.fail(ctx, f"{pe} is already on that message. Use `{ctx.clean_prefix}reactionrole edit` to change its role.")
        if panel and len(panel.roles) >= MAX_RR_PER_MESSAGE:
            return await ui.fail(ctx, f"A message can have at most {MAX_RR_PER_MESSAGE} reaction roles.")
        if (error := await self._react(message, pe)):
            return await ui.fail(ctx, error)
        panel = panel or store.panel_create(ctx.guild.id, message.id, message.channel.id)
        store.item_set(panel, key, str(pe), role.id)
        await ui.send(ctx, kit.result("Reaction Role Added",
                                      f"React with {pe} to get {role.mention}.\n{self._jump(message)}"))

    @reactionrole.command(name="addmany", help="Add multiple reaction roles to a message at once.")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def rr_addmany(self, ctx, message: discord.Message, *, pairs: str):
        if not await self._msg_ok(ctx, message):
            return
        tokens = pairs.split()
        if len(tokens) < 2 or len(tokens) % 2:
            return await ui.fail(ctx, "Give `<emoji> <role>` pairs, e.g. `🔥 @Fire 💧 @Water` (use role mentions or IDs).")
        panel = store.panels.get(message.id)
        added: list[str] = []
        failed: list[str] = []
        converter = commands.RoleConverter()
        for emoji_text, role_text in zip(tokens[::2], tokens[1::2]):
            pe = self._emoji(emoji_text)
            if pe is None:
                failed.append(f"`{emoji_text}` - invalid emoji")
                continue
            key = emoji_key(pe)
            if panel and key in panel.roles:
                failed.append(f"{pe} - already on the message")
                continue
            if panel and len(panel.roles) >= MAX_RR_PER_MESSAGE:
                failed.append(f"{pe} - message is full ({MAX_RR_PER_MESSAGE} max)")
                continue
            try:
                role = await converter.convert(ctx, role_text)
            except commands.BadArgument:
                failed.append(f"{pe} - role `{role_text}` not found")
                continue
            if (problem := ui.role_error(ctx, role)):
                failed.append(f"{pe} - {problem}")
                continue
            if (error := await self._react(message, pe)):
                failed.append(f"{pe} - {error}")
                continue
            panel = panel or store.panel_create(ctx.guild.id, message.id, message.channel.id)
            store.item_set(panel, key, str(pe), role.id)
            added.append(f"{pe} ❯ {role.mention}")
        if not added:
            return await ui.fail(ctx, "Nothing was added.\n" + "\n".join(failed[:10]))
        body = "\n".join(added)
        if failed:
            body += "\n\n" + f"{kit.CROSS} **Skipped**\n" + "\n".join(failed[:10])
        await ui.send(ctx, kit.card(f"{kit.TICK} **Reaction Roles Added** ({len(added)})\n{body}\n{self._jump(message)}"))

    @reactionrole.command(name="remove", help="Remove a reaction role from a message.")
    @ui.guard({"manage_roles": True})
    async def rr_remove(self, ctx, message: discord.Message, emoji: str):
        panel = await self._panel(ctx, message)
        if panel is None:
            return
        pe = self._emoji(emoji)
        key = emoji_key(pe) if pe else None
        if key not in panel.roles:
            return await ui.fail(ctx, "That emoji isn't a reaction role on that message.")
        display = panel.roles[key][0]
        store.item_delete(panel, key)
        if not panel.roles:
            store.panel_delete(message.id)
        await ui.send(ctx, kit.result("Reaction Role Removed", f"{display} was removed from the message.\n{self._jump(message)}"))
        await self._unreact(message, display, ctx.guild.me)

    @reactionrole.command(name="edit", help="Edit the role assigned to an existing emoji on a panel.")
    @ui.guard({"manage_roles": True})
    async def rr_edit(self, ctx, message: discord.Message, emoji: str, *, role: discord.Role):
        panel = await self._panel(ctx, message)
        if panel is None:
            return
        pe = self._emoji(emoji)
        key = emoji_key(pe) if pe else None
        if key not in panel.roles:
            return await ui.fail(ctx, "That emoji isn't a reaction role on that message. Use `add` instead.")
        if (problem := ui.role_error(ctx, role)):
            return await ui.fail(ctx, problem)
        store.item_set(panel, key, panel.roles[key][0], role.id)
        await ui.send(ctx, kit.result("Reaction Role Edited", f"{panel.roles[key][0]} now gives {role.mention}.\n{self._jump(message)}"))

    @reactionrole.command(name="clear", help="Clear all reaction roles from a message.")
    @ui.guard({"manage_roles": True})
    async def rr_clear(self, ctx, message: discord.Message):
        panel = await self._panel(ctx, message)
        if panel is None:
            return
        store.panel_delete(message.id)
        await ui.send(ctx, kit.result("Reaction Roles Cleared",
                                      f"Removed **{len(panel.roles)}** reaction role(s) from the message.\n{self._jump(message)}"))
        await asyncio.gather(*(self._unreact(message, d, ctx.guild.me) for d, _ in panel.roles.values()))

    @reactionrole.command(name="clone", help="Clone a reaction role setup from one message to another.")
    @ui.guard({"manage_roles": True}, {"manage_roles": True})
    async def rr_clone(self, ctx, source: discord.Message, target: discord.Message):
        src = await self._panel(ctx, source)
        if src is None or not await self._msg_ok(ctx, target):
            return
        if source.id == target.id:
            return await ui.fail(ctx, "The source and target are the same message.")
        if target.id in store.panels:
            return await ui.fail(ctx, "The target already has reaction roles. Clear it first.")
        copy_panel = store.panel_create(ctx.guild.id, target.id, target.channel.id)
        copy_panel.format, copy_panel.maxroles = src.format, src.maxroles
        store.panel_save(copy_panel)
        done = 0
        for key, (display, role_id) in src.roles.items():
            if await self._react(target, discord.PartialEmoji.from_str(display)):
                continue
            store.item_set(copy_panel, key, display, role_id)
            done += 1
        if not done:
            store.panel_delete(target.id)
            return await ui.fail(ctx, "I couldn't add any of the reactions to the target message.")
        await ui.send(ctx, kit.result("Reaction Roles Cloned",
                                      f"Copied **{done}** reaction role(s) to the target.\n{self._jump(target)}"))

    @reactionrole.command(name="format", aliases=["mode"], help="Set the claiming format for a panel.")
    @ui.guard({"manage_roles": True})
    async def rr_format(self, ctx, message: discord.Message, format: str):
        panel = await self._panel(ctx, message)
        if panel is None:
            return
        fmt = format.lower()
        if fmt not in FORMATS:
            lines = "\n".join(f"`{k}` ❯ {v}" for k, v in FORMATS.items())
            return await ui.send(ctx, kit.card(f"{kit.CROSS} **Invalid format**\n{lines}"))
        panel.format = fmt
        store.panel_save(panel)
        await ui.send(ctx, kit.result("Format Updated", f"The panel now uses `{fmt}`. {FORMATS[fmt]}\n{self._jump(message)}"))

    @reactionrole.command(name="maxroles", help="Set the maximum roles a user can claim from a panel.")
    @ui.guard({"manage_roles": True})
    async def rr_maxroles(self, ctx, message: discord.Message, amount: int):
        panel = await self._panel(ctx, message)
        if panel is None:
            return
        if not 0 <= amount <= MAX_RR_PER_MESSAGE:
            return await ui.fail(ctx, f"The amount must be between 0 (unlimited) and {MAX_RR_PER_MESSAGE}.")
        panel.maxroles = amount
        store.panel_save(panel)
        text = "Users can now claim any number of roles." if not amount else f"Users can now claim up to **{amount}** role(s)."
        await ui.send(ctx, kit.result("Max Roles Updated", f"{text}\n{self._jump(message)}"))

    @reactionrole.command(name="info", help="View details of a specific reaction role panel.")
    @ui.guard({"manage_roles": True})
    async def rr_info(self, ctx, message: discord.Message):
        panel = await self._panel(ctx, message)
        if panel is None:
            return
        rows = "\n".join(f"{d} ❯ {self._role_text(ctx.guild, rid)}" for d, rid in panel.roles.values())
        await ui.send(ctx, kit.card(
            f"### Reaction Role Panel\n{self._jump(message)}",
            discord.ui.Separator(),
            f"**Format:** `{panel.format}` ❯ {FORMATS.get(panel.format, '')}\n"
            f"**Max roles:** {panel.maxroles or 'Unlimited'}\n"
            f"**Roles [{len(panel.roles)}]**\n{rows}"))

    @reactionrole.command(name="show", help="Shows all reaction role panels in this server.")
    @ui.guard({"manage_roles": True})
    async def rr_show(self, ctx):
        panels = sorted(store.guild_panels(ctx.guild.id), key=lambda p: p.message_id)
        if not panels:
            return await ui.fail(ctx, "This server has no reaction role panels.")
        entries = []
        for i, p in enumerate(panels, 1):
            link = p.jump()
            where = f"[Jump to message]({link})" if link else f"Message `{p.message_id}`"
            entries.append(f"`[{i:02d}]` {where} • `{len(p.roles)}` role(s) • `{p.format}`")
        await ui.send_pager(ctx, ui.ListPager(ctx, f"Reaction Role Panels [{len(panels)}]", entries, per_page=8,
                                              legend=False, sep="\n"))

    # ------------------------------------------------------------- listeners
    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        panel = store.panels.get(payload.message_id)
        if panel is None or payload.user_id == self.bot.user.id:
            return
        key = emoji_key(payload.emoji)
        entry = panel.roles.get(key)
        member = payload.member
        if entry is None or member is None or member.bot:
            return
        role = member.guild.get_role(entry[1])
        if role is None:
            return
        try:
            await self._claim(member, panel, role, key, payload)
        except discord.HTTPException:
            pass

    async def _claim(self, member: discord.Member, panel: Panel, role: discord.Role, key: str,
                     payload: discord.RawReactionActionEvent) -> None:
        has = member.get_role(role.id) is not None
        fmt = panel.format
        if fmt == "reverse":
            if has:
                await member.remove_roles(role, reason=REASON, atomic=False)
            return
        if fmt == "unique":
            others = [r for rid in panel.role_ids() if rid != role.id and (r := member.get_role(rid))]
            jobs = []
            if others:
                jobs.append(member.remove_roles(*others, reason=REASON, atomic=False))
            if not has:
                jobs.append(member.add_roles(role, reason=REASON, atomic=False))
            if jobs:
                await asyncio.gather(*jobs, return_exceptions=True)
            channel = member.guild.get_channel(payload.channel_id)
            if channel is not None:
                partial = channel.get_partial_message(payload.message_id)
                for other_key, (display, _) in panel.roles.items():
                    if other_key != key:
                        asyncio.ensure_future(self._silent_unreact(partial, display, member))
            return
        if panel.maxroles and not has:
            held = sum(1 for rid in panel.role_ids() if member.get_role(rid))
            if held >= panel.maxroles:
                channel = member.guild.get_channel(payload.channel_id)
                if channel is not None:
                    await self._silent_unreact(channel.get_partial_message(payload.message_id), panel.roles[key][0], member)
                return
        if not has:
            await member.add_roles(role, reason=REASON, atomic=False)

    @staticmethod
    async def _silent_unreact(partial: discord.PartialMessage, display: str, who: discord.abc.Snowflake) -> None:
        try:
            await partial.remove_reaction(discord.PartialEmoji.from_str(display), who)
        except discord.HTTPException:
            pass

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload: discord.RawReactionActionEvent):
        panel = store.panels.get(payload.message_id)
        if panel is None or payload.user_id == self.bot.user.id:
            return
        entry = panel.roles.get(emoji_key(payload.emoji))
        if entry is None or panel.format == "verify":
            return
        guild = self.bot.get_guild(payload.guild_id) if payload.guild_id else None
        member = guild.get_member(payload.user_id) if guild else None
        if member is None or member.bot:
            return
        role = guild.get_role(entry[1])
        if role is None:
            return
        has = member.get_role(role.id) is not None
        try:
            if panel.format == "reverse":
                if not has:
                    await member.add_roles(role, reason=REASON, atomic=False)
            elif has:
                await member.remove_roles(role, reason=REASON, atomic=False)
        except discord.HTTPException:
            pass

    @commands.Cog.listener()
    async def on_raw_message_delete(self, payload: discord.RawMessageDeleteEvent):
        if payload.message_id in store.panels:
            store.panel_delete(payload.message_id)

    @commands.Cog.listener()
    async def on_raw_bulk_message_delete(self, payload: discord.RawBulkMessageDeleteEvent):
        for mid in payload.message_ids:
            if mid in store.panels:
                store.panel_delete(mid)
