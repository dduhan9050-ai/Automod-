"""Utility: Sticky Message  (sticky ... ).

A sticky message is re-posted at the bottom of its channel whenever somebody talks.
All lookups are in-memory; re-posts are coalesced per channel (one per ``DELAY`` s) and
the new message is sent while the old one is deleted in parallel.
"""
from __future__ import annotations

import asyncio
from typing import Optional

import discord
from discord.ext import commands

from core import Cog
from utils import modui as ui
from utils import utilkit as kit
from utils.utility_store import MAX_STICKY, Sticky, store

DELAY = 0.8          # seconds - coalesces bursts of chat into a single re-post
MAX_LEN = 1900


class UtilSticky(Cog, name="UtilSticky"):
    """Sticky Message."""

    def __init__(self, bot):
        self.bot = bot
        self._pending: dict[int, asyncio.Task] = {}
        self._locks: dict[int, asyncio.Lock] = {}

    async def cog_load(self):
        await store.load()

    async def cog_unload(self):
        for task in self._pending.values():
            task.cancel()
        self._pending.clear()
        await store.flush()

    # ------------------------------------------------------------ rendering
    @staticmethod
    def _view(rec: Sticky, guild: discord.Guild) -> discord.ui.LayoutView:
        text, token = kit.split_embed_token(rec.content)
        data = store.get_embed(rec.guild_id, token) if token else None
        view = discord.ui.LayoutView(timeout=None)
        if data and not kit.is_blank(data):
            if text:
                view.add_item(discord.ui.Container(kit.td(kit.apply_vars(text, None, guild)), accent_colour=kit.WHITE))
            view.add_item(kit.embed_container(data, None, guild))
        else:
            body = kit.apply_vars(rec.content, None, guild) or "​"
            view.add_item(discord.ui.Container(kit.td(f"{body}\n\n-# 📌 Sticky Message"), accent_colour=kit.WHITE))
        return view

    @staticmethod
    async def _delete(channel: discord.abc.Messageable, message_id: int) -> None:
        try:
            await channel.get_partial_message(message_id).delete()
        except discord.HTTPException:
            pass

    async def _post(self, channel: discord.TextChannel, rec: Sticky) -> Optional[discord.Message]:
        """Send the sticky to the bottom of ``channel`` and delete the previous one in parallel."""
        lock = self._locks.setdefault(channel.id, asyncio.Lock())
        async with lock:
            send = channel.send(view=self._view(rec, channel.guild), allowed_mentions=ui.NO_PING)
            try:
                if rec.message_id:
                    msg, _ = await asyncio.gather(send, self._delete(channel, rec.message_id))
                else:
                    msg = await send
            except discord.HTTPException:
                return None
            store.sticky_message(rec, msg.id)
            return msg

    # ------------------------------------------------------------- listeners
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        cid = message.channel.id
        if cid not in store.sticky or cid in self._pending or message.guild is None:
            return
        if message.author.id == self.bot.user.id:
            return
        self._pending[cid] = asyncio.ensure_future(self._debounced(message.channel, cid))

    async def _debounced(self, channel: discord.TextChannel, cid: int) -> None:
        try:
            await asyncio.sleep(DELAY)
            rec = store.sticky.get(cid)
            if rec is not None:
                await self._post(channel, rec)
        except asyncio.CancelledError:
            raise
        except Exception:
            pass
        finally:
            self._pending.pop(cid, None)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        store.sticky_delete(channel.id)
        task = self._pending.pop(channel.id, None)
        if task:
            task.cancel()

    # -------------------------------------------------------------- commands
    async def _set(self, ctx, channel: discord.TextChannel, text: str):
        text = text.strip()
        if not text:
            return await ctx.send_help(ctx.command)
        if len(text) > MAX_LEN:
            return await ui.fail(ctx, f"The sticky message can be at most {MAX_LEN} characters.")
        if not channel.permissions_for(ctx.author).send_messages:
            return await ui.fail(ctx, f"You can't send messages in {channel.mention}.")
        mine = channel.permissions_for(ctx.guild.me)
        if not (mine.view_channel and mine.send_messages):
            return await ui.fail(ctx, f"I can't send messages in {channel.mention}.")
        rec = store.sticky.get(channel.id)
        if rec is None and len(store.guild_sticky(ctx.guild.id)) >= MAX_STICKY:
            return await ui.fail(ctx, f"This server already has {MAX_STICKY} sticky messages.")
        updated = rec is not None
        if updated:
            rec.content = text
            store.sticky_save(rec)
        else:
            rec = Sticky(channel.id, ctx.guild.id, text)
            store.sticky_save(rec)
        await ui.send(ctx, kit.result("Sticky Message " + ("Updated" if updated else "Added"),
                                      f"The sticky message for {channel.mention} has been {'updated' if updated else 'set'}."))
        await self._post(channel, rec)

    async def _drop(self, ctx, channel: discord.TextChannel):
        rec = store.sticky_delete(channel.id)
        if rec is None:
            return await ui.fail(ctx, f"{channel.mention} has no sticky message.")
        task = self._pending.pop(channel.id, None)
        if task:
            task.cancel()
        await ui.send(ctx, kit.result("Sticky Message Removed", f"The sticky message for {channel.mention} has been removed."))
        if rec.message_id:
            await self._delete(channel, rec.message_id)

    @commands.group(name="sticky", invoke_without_command=True, help="Manage sticky messages.")
    @ui.guard()
    async def sticky(self, ctx):
        await ctx.send_help(ctx.command)

    @sticky.command(name="add", help="Add or update a sticky message for a channel.")
    @ui.guard({"manage_messages": True})
    async def sticky_add(self, ctx, *, message: str):
        await self._set(ctx, ctx.channel, message)

    @sticky.command(name="remove", help="Remove a sticky message from a channel.")
    @ui.guard({"manage_messages": True})
    async def sticky_remove(self, ctx, channel: discord.TextChannel = None):
        await self._drop(ctx, channel or ctx.channel)

    @sticky.command(name="bump", help="Manually resend the sticky message in a channel.")
    @ui.guard({"manage_messages": True})
    async def sticky_bump(self, ctx, channel: discord.TextChannel):
        rec = store.sticky.get(channel.id)
        if rec is None:
            return await ui.fail(ctx, f"{channel.mention} has no sticky message.")
        msg = await self._post(channel, rec)
        if msg is None:
            return await ui.fail(ctx, f"I couldn't send the sticky message in {channel.mention}.")
        await ui.send(ctx, kit.result("Sticky Message Bumped", f"The sticky message for {channel.mention} has been bumped."))

    @sticky.command(name="show", help="Show all sticky messages in the server.")
    @ui.guard({"manage_messages": True})
    async def sticky_show(self, ctx):
        recs = sorted(store.guild_sticky(ctx.guild.id), key=lambda r: r.channel_id)
        if not recs:
            return await ui.fail(ctx, "This server has no sticky messages.")
        entries = []
        for i, rec in enumerate(recs, 1):
            link = rec.jump()
            entries.append(f"`[{i:02d}]` <#{rec.channel_id}>" + (f" - [Jump to message]({link})" if link else ""))
        await ui.send_pager(ctx, ui.ListPager(ctx, f"Sticky Messages [{len(recs)}]", entries, per_page=10,
                                              legend=False, sep="\n"))

    # ------------------------------------------------------ sticky channel ...
    @sticky.group(name="channel", invoke_without_command=True, help="Manage sticky messages for specific channels.")
    @ui.guard()
    async def sticky_channel(self, ctx):
        await ctx.send_help(ctx.command)

    @sticky_channel.command(name="add", help="Add or update the sticky message of a specific channel.")
    @ui.guard({"manage_messages": True})
    async def sticky_channel_add(self, ctx, channel: discord.TextChannel, *, message: str):
        await self._set(ctx, channel, message)

    @sticky_channel.command(name="remove", help="Remove the sticky message of a specific channel.")
    @ui.guard({"manage_messages": True})
    async def sticky_channel_remove(self, ctx, channel: discord.TextChannel):
        await self._drop(ctx, channel)
