from __future__ import annotations

"""Neutral Discord Components V2 compatibility layer.

Converts legacy embeds and ordinary text sends into native V2 LayoutViews,
while carrying supported legacy View buttons/selects into V2 ActionRows.
No Container has a colour bar: missing / #ffffff accents are dropped, other explicit colours are kept.
"""

import copy
import functools
import logging
from typing import Any

import discord

log = logging.getLogger("deathbot.components_v2")

WHITE = discord.Colour(0xFFFFFF)
NO_ACCENT = object()  # pass accent_colour=NO_ACCENT to get a container without any accent bar


def _install_white_accent() -> None:
    """No container gets a colour bar.

    A container without an accent colour, or with the old white #ffffff, is created without any accent
    (this covers every cog that still passes WHITE explicitly).  Any other colour that a cog sets on
    purpose - e.g. the colour a server picked for its welcome message - is kept.
    """
    original = discord.ui.Container.__init__
    if getattr(original, "_deathbot_white", False):
        return

    @functools.wraps(original)
    def __init__(self, *children, **kwargs):
        colour = kwargs.pop("accent_color", None)
        if colour is None:
            colour = kwargs.get("accent_colour")
        if colour is NO_ACCENT or colour is None or getattr(colour, "value", colour) == WHITE.value:
            kwargs["accent_colour"] = None
        else:
            kwargs["accent_colour"] = colour
        original(self, *children, **kwargs)

    __init__._deathbot_white = True
    discord.ui.Container.__init__ = __init__


def media_gallery(*urls: str) -> "discord.ui.MediaGallery":
    """Build a MediaGallery for one or more image URLs.

    `MediaGalleryItem` lives at `discord.MediaGalleryItem` (it is NOT exported from `discord.ui`),
    so `discord.ui.MediaGalleryItem(...)` raises AttributeError.  That was why every command that
    shows an image card (avatar / banner / servericon / serverbanner, greet images, map, ...) died.
    """
    item_cls = getattr(discord, "MediaGalleryItem", None) or getattr(discord.ui, "MediaGalleryItem")
    return discord.ui.MediaGallery(*[item_cls(media=u) for u in urls])


def _chunk(text: str, limit: int = 3900) -> list[str]:
    text = text or "\u200b"
    return [text[i:i + limit] for i in range(0, len(text), limit)] or ["\u200b"]


def _embed_text(embed: discord.Embed) -> str:
    data = embed.to_dict()
    blocks: list[str] = []
    author = data.get("author", {}).get("name")
    title = data.get("title")
    description = data.get("description")
    if author:
        blocks.append(f"**{author}**")
    if title:
        blocks.append(f"# {title}")
    if description:
        blocks.append(description)
    for field in data.get("fields", []):
        name = field.get("name") or "Details"
        value = field.get("value") or "\u200b"
        blocks.append(f"**{name}**\n{value}")
    footer = data.get("footer", {}).get("text")
    if footer:
        blocks.append(f"-# {footer}")
    return "\n\n".join(blocks) or "\u200b"


def _add_text(container: discord.ui.Container, text: str) -> None:
    # Discord TextDisplay has a 4000-character limit. Keep the component count
    # within the container's 10-child limit by combining oversized text safely.
    chunks = _chunk(text)
    if len(chunks) > 10:
        chunks = chunks[:9] + ["\n\n".join(chunks[9:])[:3900]]
    for part in chunks:
        container.add_item(discord.ui.TextDisplay(part))


def _convert_legacy_view(view: Any, layout: discord.ui.LayoutView) -> None:
    """Copy supported buttons/selects from a classic View into V2 ActionRows."""
    if view is None or isinstance(view, discord.ui.LayoutView):
        if isinstance(view, discord.ui.LayoutView):
            # Existing V2 view is already the required view.
            for item in view.children:
                layout.add_item(item)
        return
    children = list(getattr(view, "children", []) or [])
    if not children:
        return

    rows: dict[int, Any] = {}
    auto_row = 0
    for child in children:
        try:
            item = copy.copy(child)
            # Detach the clone from the original View before assigning it to V2.
            if hasattr(item, "_view"):
                item._view = None
            if hasattr(item, "_parent"):
                item._parent = None
            if hasattr(item, "_row"):
                item._row = None
            row_index = getattr(child, "row", None)
            if row_index is None:
                row_index = auto_row
                if isinstance(child, discord.ui.Select):
                    auto_row += 1
                elif len(rows.get(row_index, discord.ui.ActionRow()).children) >= 5:
                    auto_row += 1
                    row_index = auto_row
            row = rows.setdefault(row_index, discord.ui.ActionRow())
            row.add_item(item)
        except Exception as exc:
            log.warning("Skipped unsupported legacy view item %r: %s", child, exc)
    for _, row in sorted(rows.items()):
        if row.children:
            layout.add_item(row)


def to_v2(content: Any = None, kwargs: dict[str, Any] | None = None):
    """Return content=None and V2 LayoutView for message-send/edit kwargs."""
    kwargs = dict(kwargs or {})
    embeds = []
    embed = kwargs.pop("embed", None)
    if embed is not None:
        embeds.append(embed)
    embeds.extend(kwargs.pop("embeds", None) or [])
    legacy_view = kwargs.pop("view", None)

    # Preserve explicit component-only edits that contain no text/embed.
    should_convert = bool(embeds) or content is not None or legacy_view is not None
    if not should_convert:
        return content, kwargs

    if isinstance(legacy_view, discord.ui.LayoutView):
        layout = legacy_view
    else:
        layout = discord.ui.LayoutView(timeout=getattr(legacy_view, "timeout", 180))
    if content:
        container = discord.ui.Container()
        _add_text(container, str(content))
        layout.add_item(container)

    for embed_obj in embeds:
        if not isinstance(embed_obj, discord.Embed):
            continue
        container = discord.ui.Container()
        embed_data = embed_obj.to_dict()
        thumb_url = embed_data.get("thumbnail", {}).get("url")
        text_chunks = _chunk(_embed_text(embed_obj))
        if thumb_url:
            section = discord.ui.Section(
                *[discord.ui.TextDisplay(part) for part in text_chunks[:3]],
                accessory=discord.ui.Thumbnail(media=thumb_url),
            )
            container.add_item(section)
            for part in text_chunks[3:10]:
                container.add_item(discord.ui.TextDisplay(part))
        else:
            _add_text(container, _embed_text(embed_obj))
        image_url = embed_data.get("image", {}).get("url")
        if image_url:
            container.add_item(media_gallery(image_url))
        # Legacy embed colours are ignored: every card has no colour bar.
        layout.add_item(container)

    if not isinstance(legacy_view, discord.ui.LayoutView):
        _convert_legacy_view(legacy_view, layout)
    kwargs["view"] = layout
    return None, kwargs


def install_v2_send_patch() -> None:
    """Patch Discord.py send/edit entry points so cogs share one V2 renderer."""
    _install_white_accent()
    targets = [
        (discord.abc.Messageable, "send"),
        (discord.Webhook, "send"),
        (discord.Message, "edit"),
        (discord.InteractionResponse, "send_message"),
        (discord.InteractionResponse, "edit_message"),
        (discord.Interaction, "edit_original_response"),
    ]
    for cls, method_name in targets:
        original = getattr(cls, method_name, None)
        if original is None or getattr(original, "_deathbot_v2_patched", False):
            continue

        @functools.wraps(original)
        async def wrapped(self, *args, __original=original, __method=method_name, **kwargs):
            # Opt-out used by the logging engine: real embeds through log webhooks.
            if kwargs.pop("legacy_embed", False):
                return await __original(self, *args, **kwargs)
            content = args[0] if args else kwargs.get("content")
            # Do not transform an explicit empty edit, defer, or attachment-only
            # operation. Embed and text responses become V2 everywhere.
            new_content, new_kwargs = to_v2(content, kwargs)
            if args:
                args = (new_content,) + args[1:]
                new_kwargs.pop("content", None)
            else:
                if "content" in new_kwargs:
                    new_kwargs["content"] = new_content
            return await __original(self, *args, **new_kwargs)

        wrapped._deathbot_v2_patched = True
        setattr(cls, method_name, wrapped)
    # Webhook.edit_message has message_id as its first positional argument,
    # unlike send methods; transform only its keyword content/embed/view.
    original_edit = getattr(discord.Webhook, "edit_message", None)
    if original_edit is not None and not getattr(original_edit, "_deathbot_v2_patched", False):
        @functools.wraps(original_edit)
        async def webhook_edit(self, message_id, **kwargs):
            content = kwargs.get("content")
            new_content, new_kwargs = to_v2(content, kwargs)
            if "content" in new_kwargs:
                new_kwargs["content"] = new_content
            return await original_edit(self, message_id, **new_kwargs)
        webhook_edit._deathbot_v2_patched = True
        discord.Webhook.edit_message = webhook_edit

    log.info("Components V2 send/edit middleware installed (no accent colour)")
