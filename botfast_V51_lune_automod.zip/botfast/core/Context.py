from __future__ import annotations

from discord.ext import commands
import discord
import functools
from typing import Optional, Any
import asyncio



from components_v2 import to_v2

def _convert_embed_kwargs(content, kwargs):
    """Convert command responses to the shared Components V2 UI (white #ffffff accent)."""
    return to_v2(content, kwargs)


__all__ = ("Context", )


class Context(commands.Context):

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)

    def __repr__(self):
        return "<core.Context>"

    @property
    def session(self):
        """Shared aiohttp session owned by the bot (created lazily)."""
        return self.bot.session

    async def error(self, message: str, **kwargs) -> Optional[discord.Message]:
        """Short error reply (was called by several commands but never defined)."""
        embed = discord.Embed(description=f"<a:cross:1567096105299214336> | {message}", color=0x000000)
        return await self.send(embed=embed, **kwargs)

    async def success(self, message: str, **kwargs) -> Optional[discord.Message]:
        embed = discord.Embed(description=f"<:emoji_4:1566043104551768114> | {message}", color=0x000000)
        return await self.send(embed=embed, **kwargs)

    @discord.utils.cached_property
    def replied_reference(self) -> Optional[discord.Message]:
        ref = self.message.reference
        if ref and isinstance(ref.resolved, discord.Message):
            return ref.resolved.to_reference()
        return None

    def with_type(func):

        @functools.wraps(func)
        async def wrapped(self, *args, **kwargs):
            context = args[0] if isinstance(args[0],
                                            commands.Context) else args[1]
            try:
                async with context.typing():
                    await func(*args, **kwargs)
            except discord.Forbidden:  
                await func(*args, **kwargs)

        return wrapped

    async def show_help(self, command: str = None) -> Any:
        cmd = self.bot.get_command('help')
        command = command or self.command.qualified_name
        await self.invoke(cmd, command=command)

    async def send(self,
                   content: Optional[str] = None,
                   **kwargs) -> Optional[discord.Message]:
        if not (self.channel.permissions_for(self.me)).send_messages:
            try:
                await self.author.send(
                    "bot dont have perms to send msg in that channel")
            except discord.Forbidden:  
                pass
            return
        content, kwargs = _convert_embed_kwargs(content, kwargs)
        return await super().send(content, **kwargs)

    async def reply(self,
                    content: Optional[str] = None,
                    **kwargs) -> Optional[discord.Message]:
        if not (self.channel.permissions_for(self.me)).send_messages:
            try:
                await self.author.send(
                    "bot dont have perms to send msg in that channel")
            except discord.Forbidden:  
                pass
            return
        content, kwargs = _convert_embed_kwargs(content, kwargs)
        return await super().reply(content, **kwargs)

    async def release(self, delay: Optional[int] = None) -> None:
        delay = delay or 0
        await asyncio.sleep(delay)
