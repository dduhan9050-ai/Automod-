from importlib import import_module

from .Cog import Cog
from .Context import Context

__all__ = ("Cog", "Context", "axon")

def __getattr__(name):
    if name == "axon":
        return import_module(".axon", __name__)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

def __dir__():
    return sorted(set(globals()) | set(__all__))
