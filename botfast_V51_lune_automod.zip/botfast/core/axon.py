from __future__ import annotations
import os
from discord.ext import commands
import discord
import aiohttp
import json
import jishaku
import asyncio
import typing
from typing import List
import aiosqlite
from utils.config import OWNER_IDS
from utils import getConfig, updateConfig
from utils.premium_store import store as premium_store
from utils.team_store import team as team_store
from .Context import Context
from discord.ext import commands, tasks
from colorama import Fore, Style, init
import importlib
import inspect
import time

init(autoreset=True)

extensions: List[str] = [
    "cogs"
]

class axon(commands.AutoShardedBot):

    def __init__(self, *arg, **kwargs):
        intents = discord.Intents.all()
        # Presence updates are the busiest gateway event and are parsed on the same loop that runs antinuke.
        # Set DISCORD_PRESENCES=0 in .env for the lowest antinuke latency (vanity-role / stream-notify cogs then stop working).
        intents.presences = os.getenv("DISCORD_PRESENCES", "1") != "0"
        intents.members = True
        intents.typing = False      # TYPING_START is parsed + dispatched for nothing: no cog uses on_typing
        # Short-lived caches keep prefix resolution off SQLite's hot message path.
        # Entries expire automatically so dashboard/database changes still apply.
        self._prefix_cache: dict[int, tuple[float, str]] = {}
        self._noprefix_cache: dict[int, tuple[float, bool]] = {}
        self._prefix_cache_ttl = 20.0
        self._noprefix_cache_ttl = 20.0
        # SHARD_COUNT=0 (default) lets Discord.py request the recommended
        # shard count from Discord. For a multi-process deployment, set an
        # explicit SHARD_COUNT and SHARD_IDS for each worker.
        configured_shard_count = int(os.getenv("SHARD_COUNT", "0"))
        shard_count = configured_shard_count or None
        raw_shard_ids = os.getenv("SHARD_IDS", "").strip()
        shard_ids = ([int(value.strip()) for value in raw_shard_ids.split(",") if value.strip()]
                     if raw_shard_ids else None)
        max_messages = int(os.getenv("DISCORD_MAX_MESSAGES", "1000"))

        super().__init__(command_prefix=self.get_prefix,
                         case_insensitive=True,
                         intents=intents,
                         status=discord.Status.online,
                         strip_after_prefix=True,
                         owner_ids=OWNER_IDS,
                         allowed_mentions=discord.AllowedMentions(
                             everyone=False, replied_user=False, roles=False),
                         shard_count=shard_count,
                         shard_ids=shard_ids,
                         max_messages=max_messages)

    @property
    def session(self) -> aiohttp.ClientSession:
        """One shared HTTP session for the whole bot (connection pooling = faster requests)."""
        s = getattr(self, "_session", None)
        if s is None or s.closed:
            self._session = s = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=15),
                connector=aiohttp.TCPConnector(limit=100, ttl_dns_cache=300),
            )
        return s

    async def close(self) -> None:
        s = getattr(self, "_session", None)
        if s is not None and not s.closed:
            await s.close()
        await super().close()

    async def setup_hook(self):
        # Command rate-limit protection: escalating temporary blacklist (10m, 20m, 40m, ...)
        from utils import ratelimit
        await ratelimit.load()
        self.add_check(ratelimit.global_check, call_once=True)
        await self.load_extensions() 

    async def load_extensions(self):
        for extension in extensions:
            try:
                await self.load_extension(extension) 
                print(Fore.BLUE + Style.BRIGHT + f"Loaded extension: {extension}")
            except Exception as e:
                print(
                    f"{Fore.RED}{Style.BRIGHT}Failed to load extension {extension}. {e}"
                )
        print(Fore.GREEN + Style.BRIGHT + "*" * 20)

    
    async def on_connect(self):
        await self.change_presence(status=discord.Status.dnd,
                                   activity=discord.Activity(
                                       type=discord.ActivityType.playing,
                                       name='>help | >invite'))

    async def send_raw(self, channel_id: int, content: str,
                       **kwargs) -> typing.Optional[discord.Message]:
        await self.http.send_message(channel_id, content, **kwargs)

    async def invoke_help_command(self, ctx: Context) -> None:
        """Invoke the help command or default help command if help extensions is not loaded."""
        return await ctx.send_help(ctx.command)

    async def fetch_message_by_channel(
            self, channel: discord.TextChannel,
            messageID: int) -> typing.Optional[discord.Message]:
        async for msg in channel.history(
                limit=1,
                before=discord.Object(messageID + 1),
                after=discord.Object(messageID - 1),
        ):
            return msg

    async def get_prefix(self, message: discord.Message):
        """Resolve prefixes with TTL caching to avoid opening SQLite per message."""
        now = time.monotonic()
        user_id = message.author.id
        cached_np = self._noprefix_cache.get(user_id)
        if cached_np and cached_np[0] > now:
            is_np = cached_np[1]
        else:
            async with aiosqlite.connect('db/np.db', timeout=5) as db:
                async with db.execute("SELECT 1 FROM np WHERE id = ? LIMIT 1", (user_id,)) as cursor:
                    is_np = await cursor.fetchone() is not None
            # Bot team (owner / developer / core team) always has global no-prefix.
            is_np = is_np or team_store.has_perks(user_id)
            self._noprefix_cache[user_id] = (now + self._noprefix_cache_ttl, is_np)

        if message.guild:
            guild_id = message.guild.id
            cached_prefix = self._prefix_cache.get(guild_id)
            if cached_prefix and cached_prefix[0] > now:
                prefix = cached_prefix[1]
            else:
                data = await getConfig(guild_id)
                prefix = data.get("prefix", ">")
                self._prefix_cache[guild_id] = (now + self._prefix_cache_ttl, prefix)
            # Global no-prefix (np.db) OR premium server no-prefix (servernoprefix).
            if is_np or premium_store.has_server_np(guild_id, user_id):
                return commands.when_mentioned_or(prefix, '')(self, message)
            return commands.when_mentioned_or(prefix)(self, message)

        if is_np:
            return commands.when_mentioned_or('>', '')(self, message)
        return commands.when_mentioned_or('')(self, message)

    async def get_context(self, origin, *, cls=commands.Context):
        """Normal context + premium custom aliases (``cmdalias``).

        Only runs the alias lookup when no real command matched, so normal
        commands pay nothing; the lookup is a dict access in memory."""
        ctx = await super().get_context(origin, cls=cls)
        if ctx.command is None and ctx.prefix is not None and ctx.guild is not None and ctx.invoked_with:
            target = premium_store.resolve_alias(ctx.guild.id, ctx.invoked_with)
            if target:
                command = self.get_command(target)
                if command is not None and command.parent is None:
                    ctx.command = command
        return ctx

    def invalidate_prefix_cache(self, guild_id: int | None = None, user_id: int | None = None):
        """Call after changing a guild prefix or a user's no-prefix status."""
        if guild_id is None:
            self._prefix_cache.clear()
        else:
            self._prefix_cache.pop(guild_id, None)
        if user_id is None:
            self._noprefix_cache.clear()
        else:
            self._noprefix_cache.pop(user_id, None)


    async def on_message_edit(self, before, after):
        if before.content == after.content or after.guild is None or after.author.bot:
            return
        if (discord.utils.utcnow() - after.created_at).total_seconds() > 120:
            return
        ctx: Context = await self.get_context(after, cls=Context)
        if ctx.command is None:
            return
        await self.invoke(ctx)




def setup_bot():
    intents = discord.Intents.all()
    bot = axon(intents=intents)
    return bot