#!/usr/bin/env bash
# Roll back to the pre-V44 backup taken by upgrade_linkinvite.sh.
# Usage: bash deploy/rollback_linkinvite.sh /path/to/production/botfast
# db/linkinvite.db is NEW and additive: the old code ignores it, so it is kept for forensic evidence.
set -euo pipefail
PROD="${1:?usage: rollback_linkinvite.sh /path/to/production/botfast}"
PROD="$(cd "$PROD" && pwd)"
SERVICE="${SERVICE:-deathbot}"
BACKUP_DIR="${BACKUP_DIR:-$HOME/deathbot_backups}"
ARCHIVE="${2:-$(cat "$BACKUP_DIR/LAST_BACKUP")}"
[ -f "$ARCHIVE" ] || { echo "backup not found: $ARCHIVE"; exit 1; }
echo "restoring code from $ARCHIVE"
sudo systemctl stop "$SERVICE" || true
TMP="$(mktemp -d)"
tar -xzf "$ARCHIVE" -C "$TMP"
SRC="$TMP/$(basename "$PROD")"
for f in cogs/antinuke/engine.py cogs/__init__.py; do install -D -m 0644 "$SRC/$f" "$PROD/$f"; done
rm -f "$PROD/cogs/antinuke/linkinvite.py"
rm -rf "$TMP"
sudo systemctl start "$SERVICE"
sleep 10
systemctl is-active "$SERVICE" && echo "rolled back; service is active" || { echo "service NOT active: journalctl -u $SERVICE -e"; exit 1; }
