#!/usr/bin/env bash
# One-time setup for Ubuntu 22.04/24.04 on AWS EC2.   Usage:  bash deploy/setup_aws.sh
set -euo pipefail
cd "$(dirname "$0")/.."

sudo apt-get update -y
sudo apt-get install -y python3 python3-venv python3-pip python3-dev build-essential \
     libffi-dev libssl-dev libopus0 ffmpeg libjpeg-dev zlib1g-dev git

# small instances (1 GB RAM) crash while installing/running without swap
if ! swapon --show | grep -q .; then
  sudo fallocate -l 2G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile
  grep -q '/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab >/dev/null
fi

python3 -m venv .venv
.venv/bin/pip install --upgrade pip wheel
.venv/bin/pip install -r requirements.txt

# .env without editing anything by hand: token comes from  TOKEN=xxx bash deploy/setup_aws.sh  or is asked once
[ -f .env ] || cp .env.example .env
if ! grep -qE '^TOKEN=.{20,}' .env; then
  if [ -z "${TOKEN:-}" ]; then
    read -rsp "Paste your bot TOKEN (hidden): " TOKEN; echo
  fi
  [ -n "$TOKEN" ] || { echo "No token given, stopping."; exit 1; }
  if grep -q '^TOKEN=' .env; then sed -i "s|^TOKEN=.*|TOKEN=${TOKEN}|" .env; else echo "TOKEN=${TOKEN}" >> .env; fi
  chmod 600 .env
fi

# systemd service (auto start on boot, auto restart on crash)
SERVICE=/etc/systemd/system/deathbot.service
sed -e "s#__DIR__#$(pwd)#g" -e "s#__USER__#$(whoami)#g" deploy/deathbot.service | sudo tee "$SERVICE" >/dev/null
sudo systemctl daemon-reload
sudo systemctl enable deathbot
.venv/bin/python preflight.py || true
sudo systemctl restart deathbot
sleep 5
sudo systemctl --no-pager --lines=15 status deathbot || true
echo
echo "Bot started. Live logs: journalctl -u deathbot -f"
