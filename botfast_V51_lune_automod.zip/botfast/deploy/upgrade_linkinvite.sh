#!/usr/bin/env bash
# V44 Linked Role upgrade for an EXISTING production install.  Does not touch deathbot.service, .env or any database.
# Usage (run from the unpacked NEW version, the staging copy):
#     bash deploy/upgrade_linkinvite.sh /path/to/production/botfast
# Production files are only overwritten after the tests pass in staging, and a backup is taken first.
set -euo pipefail
STAGE="$(cd "$(dirname "$0")/.." && pwd)"
PROD="${1:?usage: upgrade_linkinvite.sh /path/to/production/botfast}"
PROD="$(cd "$PROD" && pwd)"
SERVICE="${SERVICE:-deathbot}"
PY="$PROD/.venv/bin/python"; [ -x "$PY" ] || PY="$(command -v python3)"
BACKUP_DIR="${BACKUP_DIR:-$HOME/deathbot_backups}"
STAMP="$(date +%Y%m%d_%H%M%S)"
FILES=(cogs/antinuke/linkinvite.py cogs/antinuke/engine.py cogs/__init__.py)

[ "$STAGE" != "$PROD" ] || { echo "Run this from the staging copy, not from production."; exit 1; }
echo "== 1/6 dependency check ($PY)"
"$PY" - <<'PYEOF'
import sys, importlib
assert sys.version_info >= (3, 11), f"Python 3.11+ required, found {sys.version.split()[0]}"
missing = [m for m in ("discord", "aiohttp", "aiosqlite", "dotenv", "yaml") if importlib.util.find_spec(m) is None]
assert not missing, f"missing modules: {missing}  (pip install -r requirements.txt)"
import discord
assert tuple(int(x) for x in discord.__version__.split(".")[:2]) >= (2, 6), f"discord.py >= 2.6 required, found {discord.__version__}"
print("python", sys.version.split()[0], "discord.py", discord.__version__, "- ok (no new dependencies are introduced)")
PYEOF

echo "== 2/6 compile + tests in STAGING (production untouched)"
(cd "$STAGE" && "$PY" -m py_compile "${FILES[@]}" && "$PY" -m unittest discover -s tests)

echo "== 3/6 backup"
mkdir -p "$BACKUP_DIR"
tar -czf "$BACKUP_DIR/botfast_pre_V44_$STAMP.tar.gz" -C "$(dirname "$PROD")" "$(basename "$PROD")" \
    --exclude='.venv' --exclude='__pycache__' --exclude='*.log'
echo "$BACKUP_DIR/botfast_pre_V44_$STAMP.tar.gz" > "$BACKUP_DIR/LAST_BACKUP"
ls -lh "$BACKUP_DIR/botfast_pre_V44_$STAMP.tar.gz"

echo "== 4/6 install changed files only (nothing is deleted)"
for f in "${FILES[@]}"; do install -D -m 0644 "$STAGE/$f" "$PROD/$f"; done
mkdir -p "$PROD/tests" "$PROD/reports"
cp -f "$STAGE"/tests/*.py "$PROD/tests/"
cp -f "$STAGE"/reports/*.md "$PROD/reports/" 2>/dev/null || true
cp -f "$STAGE"/CHANGES_V44_LINKINVITE.md "$PROD/"
cp -f "$STAGE"/deploy/upgrade_linkinvite.sh "$STAGE"/deploy/rollback_linkinvite.sh "$PROD/deploy/"

echo "== 5/6 restart ($SERVICE)"
SINCE="$(date '+%Y-%m-%d %H:%M:%S')"
sudo systemctl restart "$SERVICE"
sleep 12

echo "== 6/6 verify logs"
LOGS="$(sudo journalctl -u "$SERVICE" --since "$SINCE" --no-pager 2>/dev/null || true)"
echo "$LOGS" | grep -E "Loaded [0-9]+/[0-9]+ cogs|Failed (to load )?cog|Traceback|linkinvite" | tail -20 || true
if ! systemctl is-active --quiet "$SERVICE" || echo "$LOGS" | grep -qE "Failed to load cog LinkInvite|Failed to load cog AntinukeEngine|Traceback"; then
  echo "!! verification FAILED - rolling back automatically"
  bash "$PROD/deploy/rollback_linkinvite.sh" "$PROD"
  exit 1
fi
echo "OK. In Discord run:  ?linkinvite   (owner only) and confirm 'invite cache: ready'."
echo "Live logs: journalctl -u $SERVICE -f | grep -E 'li_event|linkinvite'"
