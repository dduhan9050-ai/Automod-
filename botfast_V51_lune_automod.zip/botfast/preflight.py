#!/usr/bin/env python3
"""Preflight checks for DEATH DEVELOPMENT / source bot deployment."""
from __future__ import annotations

import importlib.util
import os
import sqlite3
import sys
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
load_dotenv(ROOT / ".env", override=False)

REQUIRED_MODULES = {
    "discord": "discord.py",
    "aiohttp": "aiohttp",
    "aiosqlite": "aiosqlite",
    "wavelink": "wavelink",
    "jishaku": "jishaku",
    "flask": "Flask",
    "quart": "Quart",
    "PIL": "Pillow",
    "dotenv": "python-dotenv",
    "yaml": "PyYAML",
    "colorama": "colorama",
    "psutil": "psutil",
    "openai": "openai",
    "duckduckgo_search": "duckduckgo-search",
    "langdetect": "langdetect",
    "deep_translator": "deep-translator",
    "gtts": "gTTS",
    "requests": "requests",
    "httpx": "httpx",
    "pytz": "pytz",
    "typing_extensions": "typing-extensions",
}

def main() -> int:
    errors = []
    warnings = []
    print("=== Discord bot preflight ===")
    print(f"Python: {sys.version.split()[0]}")
    if sys.version_info < (3, 11) or sys.version_info >= (3, 13):
        warnings.append("Python 3.11 or 3.12 is recommended for this dependency set.")

    missing = []
    for module, package in REQUIRED_MODULES.items():
        if importlib.util.find_spec(module) is None:
            missing.append(package)
    if missing:
        errors.append("Missing packages: " + ", ".join(missing))
    else:
        print("Dependencies: all checked modules are installed")
        try:
            import discord
            required_v2 = ("LayoutView", "Container", "TextDisplay", "ActionRow")
            absent_v2 = [name for name in required_v2 if not hasattr(discord.ui, name)]
            if absent_v2:
                errors.append("Discord.py lacks Components V2 classes: " + ", ".join(absent_v2))
            else:
                print(f"Components V2: available (discord.py {discord.__version__})")
        except Exception as exc:
            errors.append(f"Components V2 check failed: {exc}")

    if not os.getenv("TOKEN"):
        warnings.append("TOKEN is missing. Add it to .env or hosting environment variables.")

    if not (os.getenv("LAVALINK_URI") or os.getenv("LAVALINK_HOST")):
        warnings.append("Lavalink is not configured; music commands will not be able to play tracks.")

    db_files = sorted(ROOT.rglob("*.db"))
    for db_file in db_files:
        try:
            with sqlite3.connect(str(db_file)) as connection:
                result = connection.execute("PRAGMA integrity_check").fetchone()[0]
            if result != "ok":
                errors.append(f"SQLite integrity failure: {db_file.relative_to(ROOT)}: {result}")
        except Exception as exc:
            errors.append(f"Could not check {db_file.relative_to(ROOT)}: {exc}")
    print(f"SQLite files checked: {len(db_files)}")

    for warning in warnings:
        print("[WARN]", warning)
    for error in errors:
        print("[ERROR]", error)

    if errors:
        print("Preflight failed.")
        return 1
    print("Preflight passed (warnings may require configuration).")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
