# Benchmark report - linkinvite (V44)

**What this is:** bot-side overhead only, measured with `python tests/bench_linkinvite.py` on the build sandbox
(Python 3.12.3, stub Discord library, no network). "Discord RTT" is a fixed `asyncio.sleep` standing in for the HTTP call.

**What this is not:** a measurement of real event-to-action latency. Gateway delivery, Discord's processing and rate limits
are outside this test and depend on your VPS region and Discord. No guaranteed or millisecond-level figure is claimed.
Real numbers: `?linkinvite` shows p50/p95 of event -> request-sent on your VPS, and every strip/lockdown writes a
`latency_ms` field in its `li_event` log line.

| Scenario | Event -> request handed to HTTP layer | Event -> request completed |
|---|---|---|
| 200 sequential linked roles, 0 ms RTT | p50 0.01 ms, p95 0.04 ms, max 0.09 ms | p50 0.01 ms |
| 200 sequential linked roles, 60 ms RTT | p50 0.01 ms, p95 0.02 ms, max 0.09 ms | p50 64.0 ms, p95 65.5 ms |
| 25 simultaneous role creations, 60 ms RTT | p50 0.01 ms, p95 0.05 ms, max 0.25 ms | p50 62.8 ms, p95 63.0 ms |
| Lockdown, 100 eligible roles, 0 ms RTT | first request 1.6 ms | all done 3.1 ms |
| Lockdown, 100 eligible roles, 60 ms RTT | first request 1.3 ms | all done 789 ms |
| Lockdown, 250 eligible roles, 60 ms RTT | first request 2.9 ms | all done 1944 ms |

Reading: the module adds negligible CPU time before the request is sent (the strip task starts eagerly in the gateway
handler; DB writes go to a separate thread and are never awaited before the PATCH). Lockdown time is dominated by
round-trips / concurrency (8 in flight); the first request leaves after the snapshot commit (~1-3 ms here).
In production Discord's per-route rate limits will dominate large lockdowns.

Design choices that bound cost: no REST on the strip path; role creator taken from the audit entry the gateway already pushes;
one `guild.invites()` call per join in tracked guilds only (none otherwise); all SQLite I/O on one worker thread;
bounded caches (candidates 5000, joins 20000); maintenance every 60 s.
