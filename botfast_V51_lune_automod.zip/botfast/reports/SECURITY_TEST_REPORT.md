# Security test report - linkinvite (V44)

Run: `python -m unittest discover -s tests -v` -> **60 tests, 60 passed** (build sandbox, Python 3.12.3).
Environment: Discord and the HTTP layer are **test doubles** (`tests/fakes.py`; a stub `discord` module was used because
discord.py is not installable offline here). Hierarchy errors, 403s, 429s and 5xx are scripted, not observed from Discord.
The same tests run unchanged against real discord.py (the stub is only installed when the import fails).
Not covered by any test: real gateway event ordering, real Discord rate-limit buckets, real audit-log latency,
the engine's own listeners (checked only by source-contract tests + `py_compile`).

## Required scenarios -> tests
| # | Scenario | Test(s) | Result |
|---|---|---|---|
| 1 | Normal role creation | `RoleCreation.test_1_normal_role_untouched`, `test_untracked_guild_ignored`, `PureLogic.test_strip_only_three_bits` | pass |
| 2 | Linked role + Administrator | `RoleCreation.test_2_administrator` | pass |
| 3 | Linked role + Manage Server | `RoleCreation.test_3_manage_server` | pass |
| 4 | Linked role + Manage Roles | `RoleCreation.test_4_manage_roles` | pass |
| 5 | All three | `RoleCreation.test_5_all_three`, `test_original_never_overwritten` | pass |
| 6 | Member receives monitored role | `Receipt.test_6_*`, `test_unmonitored_role_ignored`, `test_duplicate_receipt_deduped` | pass |
| 7 | Normal invite detected | `Invites.test_7_*`, `test_invite_create_delete_cache`, `test_last_use_invite_deleted_by_discord`, `PureLogic.test_diff_invites` | pass |
| 8 | Vanity, unknown creator | `Invites.test_8_vanity_never_fabricates_inviter`, `test_no_diff_is_unknown_not_guilty` | pass |
| 9 | X = Y | `CrossVerify.test_9_*` (ban, reason + evidence + executor recorded, no lockdown) | pass |
| 10 | X != Y | `CrossVerify.test_10_*` (alert, no ban, no lockdown) | pass |
| 11 | X missing / Y available (and reverse) | `test_11_*`, `test_11b_*` | pass |
| 12 | Both missing | `CrossVerify.test_12_*` (lockdown, **no ban**) | pass |
| 13 | Trusted bot exemption | `Lockdown.test_selective_permissions_and_protection`, `Receipt.test_13_*`, `CrossVerify.test_confirmed_but_inviter_trusted_not_banned` | pass |
| 14 | Bot hierarchy restriction | `RoleCreation.test_14_*`, lockdown test (roles above/equal untouched), `Security.test_ban_hierarchy_respected` | pass |
| 15 | API rate limits | `RoleCreation.test_15_*`, `Lockdown.test_15b_*`, `test_forbidden_is_not_retried` | pass |
| 16 | Restart during lockdown | `Lockdown.test_16_*` (resume), `test_16b_*` (resume recovery) | pass |
| 17 | Recovery after lockdown | `Lockdown.test_17_*`, `test_unlock_force_*`, `test_failed_restore_keeps_row_for_retry`, `test_restore_wrongly_flagged_role` | pass |
| 18 | Simultaneous role creation | `RoleCreation.test_18_*` (25 roles + duplicate dispatch -> exactly 25 PATCHes), `Lockdown.test_18b_*` (10 concurrent lockdowns -> 1 runs) | pass |

## Extra security properties checked
- Only bits 3, 5, 28 are ever removed; every other permission bit preserved (`test_strip_only_three_bits`, lockdown test).
- Candidate X expires after 1 h and is purged; store is size-bounded; an expired X blocks a ban (`test_x_expired_*`).
- Unknown / ambiguous / unavailable attribution can never produce a ban (verdict matrix + `test_12_*`, `test_below_threshold_*`).
- Ordinary joins never touch roles or bans (`test_normal_joins_never_trigger_anything`).
- First original bitfield is never overwritten, in the role table or the lockdown snapshot table.
- A role edited after lockdown is not overwritten by a plain unlock (`test_17_*`); every recovery step is an `li_events` row.
- Cross-guild isolation: another guild's roles are never read or changed (`test_cross_guild_isolation`).
- Invalid ids (0, negative, bool, string, >= 2^63) are rejected (`PureLogic.test_valid_id`, `test_invalid_ids_rejected`).
- A bot token present in the environment never appears in log output or in the database (`test_no_secrets_in_logs_or_db`).
- Antinuke disabled for a guild -> the module is inert (`test_disabled_antinuke_guild_is_inert`).
- Ban runs in its own task; a failed/retried ban does not delay stripping (`test_ban_never_blocks_stripping_*`).
- Engine contract: three hooks present, no listener count change, no duplicate listeners in `linkinvite.py`.

## Bug found by these tests during development (fixed)
`@everyone` was excluded from lockdown because `guild.me.roles` contains it; it is now eligible (the bot's own *non-default*
roles stay protected).

## Residual risks (honest list)
- Lockdown snapshot is awaited with a 0.5 s cap; if SQLite stalls longer, lockdown proceeds from the RAM snapshot and a crash in
  that window would lose the originals for that lockdown.
- Y is inference from invite counters; a determined attacker joining via vanity / simultaneous joins yields UNKNOWN (lockdown
  + alert, never ban) - by design, but it means attribution can be evaded.
- A malicious role *creator* can only be punished when X = Y; otherwise the existing engine path (executor of the linked role)
  still bans per your `antinuke linkrole` settings.
