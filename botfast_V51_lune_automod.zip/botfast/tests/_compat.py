"""Lets the linkinvite tests run with OR without discord.py / aiosqlite installed (e.g. in CI or a bare sandbox).

If the real libraries are importable they are used.  `utils/__init__` pulls in half of the bot, so the tests load
only utils/antinuke_store.py under a stub `utils` package - the real store logic, nothing else.
"""
import enum
import importlib.util
import os
import sys
import types

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

USING_STUB_DISCORD = False


def _stub_discord():
    d = types.ModuleType("discord")

    class DiscordException(Exception):
        pass

    class HTTPException(DiscordException):
        def __init__(self, response, message=None):
            self.response, self.status, self.text, self.code = response, response.status, message or "", 0
            self.retry_after = getattr(response, "retry_after", 0)
            super().__init__(self.text)

    class Forbidden(HTTPException):
        pass

    class NotFound(HTTPException):
        pass

    class AllowedMentions:
        @classmethod
        def none(cls):
            return cls()

    class Permissions:
        def __init__(self, value=0):
            self.value = value

    class AuditLogAction(enum.Enum):
        bot_add = 28
        role_create = 30
        role_update = 31
        role_delete = 32
        integration_create = 80
        integration_update = 81
        integration_delete = 82

    class Object:
        def __init__(self, id):
            self.id = id

    for n, v in dict(DiscordException=DiscordException, HTTPException=HTTPException, Forbidden=Forbidden,
                     NotFound=NotFound, AllowedMentions=AllowedMentions, Permissions=Permissions,
                     AuditLogAction=AuditLogAction, Object=Object).items():
        setattr(d, n, v)
    ext = types.ModuleType("discord.ext")
    commands = types.ModuleType("discord.ext.commands")

    class Cog:
        @staticmethod
        def listener(*a, **k):
            return lambda f: f

    class _Group:
        def __init__(self, fn):
            self.fn = fn

        def command(self, *a, **k):
            return lambda f: f

    commands.Cog = Cog
    commands.group = lambda *a, **k: (lambda f: _Group(f))
    commands.command = lambda *a, **k: (lambda f: f)
    commands.guild_only = lambda: (lambda f: f)
    ext.commands = commands
    d.ext = ext
    sys.modules.update({"discord": d, "discord.ext": ext, "discord.ext.commands": commands})


def install():
    global USING_STUB_DISCORD
    try:
        import discord  # noqa: F401
    except ImportError:
        USING_STUB_DISCORD = True
        _stub_discord()
    try:
        import aiosqlite  # noqa: F401
    except ImportError:
        sys.modules["aiosqlite"] = types.ModuleType("aiosqlite")
    if "utils.antinuke_store" not in sys.modules:
        pkg = types.ModuleType("utils")
        pkg.__path__ = []
        sys.modules.setdefault("utils", pkg)
        spec = importlib.util.spec_from_file_location("utils.antinuke_store", os.path.join(ROOT, "utils", "antinuke_store.py"))
        mod = importlib.util.module_from_spec(spec)
        sys.modules["utils.antinuke_store"] = mod
        spec.loader.exec_module(mod)
        pkg.antinuke_store = mod


install()
