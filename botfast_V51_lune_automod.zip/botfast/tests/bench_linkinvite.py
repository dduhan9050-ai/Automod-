"""Bot-side latency benchmark (NO network): measures how long linkinvite spends between receiving the event and
handing the request to the HTTP layer.  Discord's own round-trip is simulated with a fixed sleep and is NOT a
measurement of real Discord latency - run `linkinvite` (status) on the VPS for real numbers.

    python tests/bench_linkinvite.py
"""
import asyncio
import os
import statistics
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _compat  # noqa: F401,E402
import importlib.util  # noqa: E402

from fakes import DANGER, SEND, Bot, Clock, Guild  # noqa: E402
from utils import antinuke_store as store  # noqa: E402

spec = importlib.util.spec_from_file_location("li_bench", os.path.join(_compat.ROOT, "cogs", "antinuke", "linkinvite.py"))
li = importlib.util.module_from_spec(spec)
sys.modules["li_bench"] = li
spec.loader.exec_module(li)

ALL3 = DANGER["admin"] | DANGER["guild"] | DANGER["roles"]


def pct(v, q):
    v = sorted(v)
    return v[min(len(v) - 1, int(len(v) * q))]


async def scenario(name, n, latency, roles_in_lockdown=0):
    g = Guild()
    bot = Bot(g, latency=latency)
    store._cfg[g.id] = store.GuildCfg(enabled=True, mods=store.ALL_MASK)
    tmp = tempfile.mkdtemp()
    cog = li.LinkInvite(bot, db_path=os.path.join(tmp, "b.db"), clock=Clock())
    await cog.ledger.open()
    out = {}
    if n:
        roles = [g.add_role(10_000 + i, f"r{i}", ALL3 | SEND, 1) for i in range(n)]
        for r in roles:
            cog.linked_role_created(r)
            await asyncio.sleep(0)
        await asyncio.gather(*list(cog._bg))
        req = [b["to_request_ms"] for b in cog.bench if b["what"] == "strip"]
        done = [b["to_done_ms"] for b in cog.bench if b["what"] == "strip"]
        out = {"n": len(req), "to_request_p50": statistics.median(req), "to_request_p95": pct(req, .95),
               "to_request_max": max(req), "to_done_p50": statistics.median(done), "to_done_p95": pct(done, .95)}
    if roles_in_lockdown:
        for i in range(roles_in_lockdown):
            g.add_role(50_000 + i, f"m{i}", DANGER["admin"] | SEND, 3)
        t = li.time.perf_counter()
        await cog.lockdown(g, "bench")
        out["lockdown_total_ms"] = (li.time.perf_counter() - t) * 1000
        req = [b["to_request_ms"] for b in cog.bench if b["what"] == "lockdown"]
        out["lockdown_first_request_ms"] = min(req)
        out["lockdown_roles"] = len(req)
    await cog.ledger.close()
    store._cfg.clear()
    print(f"{name:<44}", {k: (round(v, 2) if isinstance(v, float) else v) for k, v in out.items()})


async def main():
    print(f"python {sys.version.split()[0]}  stub_discord={_compat.USING_STUB_DISCORD}")
    await scenario("strip: 200 sequential linked roles, 0ms rtt", 200, 0.0)
    await scenario("strip: 200 sequential linked roles, 60ms rtt", 200, 0.06)
    await scenario("strip: 25 simultaneous (burst), 60ms rtt", 25, 0.06)
    await scenario("lockdown: 100 eligible roles, 0ms rtt", 0, 0.0, 100)
    await scenario("lockdown: 100 eligible roles, 60ms rtt", 0, 0.06, 100)
    await scenario("lockdown: 250 eligible roles, 60ms rtt", 0, 0.06, 250)


asyncio.run(main())
