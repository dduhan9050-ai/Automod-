"""Minimal Discord doubles: just enough surface for cogs/antinuke/linkinvite.py."""
import asyncio
import types

import discord

DANGER = {"admin": 1 << 3, "guild": 1 << 5, "roles": 1 << 28}
SEND, KICK = 1 << 11, 1 << 1


def exc(cls, status=403, retry_after=0):
    return cls(types.SimpleNamespace(status=status, reason="x", retry_after=retry_after), "boom")


class Perms:
    def __init__(self, value):
        self.value = value


class Role:
    def __init__(self, guild, rid, name, perms, position, bot_id=None, managed=False):
        self.guild, self.id, self.name, self.position = guild, rid, name, position
        self.permissions = Perms(perms)
        self.tags = types.SimpleNamespace(bot_id=bot_id)
        self.managed = managed

    def is_default(self):
        return self.id == self.guild.id

    def is_integration(self):
        return False

    def is_premium_subscriber(self):
        return False

    __lt__ = lambda s, o: s.position < o.position          # noqa: E731
    __le__ = lambda s, o: s.position <= o.position         # noqa: E731
    __gt__ = lambda s, o: s.position > o.position          # noqa: E731
    __ge__ = lambda s, o: s.position >= o.position         # noqa: E731


class Member:
    def __init__(self, guild, uid, roles=(), bot=False):
        self.guild, self.id, self.bot, self.roles = guild, uid, bot, list(roles)

    @property
    def top_role(self):
        return max(self.roles, key=lambda r: r.position)


class Invite:
    def __init__(self, guild, code, uses, inviter_id, max_uses=0):
        self.guild, self.code, self.uses, self.max_uses = guild, code, uses, max_uses
        self.inviter = types.SimpleNamespace(id=inviter_id) if inviter_id else None


class Channel:
    def __init__(self):
        self.sent = []

    async def send(self, **kw):
        self.sent.append(kw)


class Guild:
    def __init__(self, gid=1000, owner_id=1, bot_id=100):
        self.id, self.owner_id = gid, owner_id
        self.everyone = Role(self, gid, "@everyone", SEND, 0)
        self.roles = [self.everyone]
        self.members = {}
        self.channels = {}
        self._invites = []
        self.vanity_url_code = None
        self.vanity_uses = 0
        self.invites_forbidden = False
        self.audit_forbidden = True
        self.me_role = self.add_role(bot_id + 1, "botrole", DANGER["admin"], 10, bot_id=bot_id)
        self.me = Member(self, bot_id, [self.everyone, self.me_role], bot=True)
        self.members[bot_id] = self.me

    def add_role(self, rid, name, perms, position, **kw):
        r = Role(self, rid, name, perms, position, **kw)
        self.roles.append(r)
        return r

    def get_role(self, rid):
        return next((r for r in self.roles if r.id == rid), None)

    def get_member(self, uid):
        return self.members.get(uid)

    def add_member(self, uid, roles=(), bot=False):
        m = Member(self, uid, [self.everyone, *roles], bot)
        self.members[uid] = m
        return m

    def get_channel(self, cid):
        return self.channels.get(cid)

    async def invites(self):
        if self.invites_forbidden:
            raise exc(discord.Forbidden)
        return list(self._invites)

    async def vanity_invite(self):
        return types.SimpleNamespace(uses=self.vanity_uses)

    async def audit_logs(self, limit=6, action=None):
        if self.audit_forbidden:
            raise exc(discord.Forbidden)
        return
        yield


class Http:
    """Records every request; optional latency and scripted failures."""

    def __init__(self, guild_lookup, latency=0.0):
        self.guilds, self.latency = guild_lookup, latency
        self.edits, self.bans = [], []
        self.fail_edit = []          # exceptions raised by the next edit_role calls (FIFO)
        self.fail_ban = []

    async def edit_role(self, gid, rid, *, reason=None, **fields):
        if self.latency:
            await asyncio.sleep(self.latency)
        if self.fail_edit:
            raise self.fail_edit.pop(0)
        self.edits.append((gid, rid, int(fields["permissions"]), reason))
        role = self.guilds[gid].get_role(rid)
        if role is None:
            raise exc(discord.NotFound, 404)
        role.permissions.value = int(fields["permissions"])

    async def ban(self, uid, gid, days, *, reason=None):
        if self.fail_ban:
            raise self.fail_ban.pop(0)
        self.bans.append((uid, gid, reason))


class Bot:
    def __init__(self, guild, latency=0.0):
        self.user = types.SimpleNamespace(id=guild.me.id)
        self.guilds = [guild]
        self.http = Http({guild.id: guild}, latency)
        self.cogs = {}

    def get_cog(self, name):
        return self.cogs.get(name)

    async def wait_until_ready(self):
        return None


class Clock:
    def __init__(self, t=1_000_000.0):
        self.t = t

    def __call__(self):
        return self.t
