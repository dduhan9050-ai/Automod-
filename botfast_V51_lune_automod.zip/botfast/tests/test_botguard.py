"""Tests for cogs/antinuke/botguard.py  (run: python -m unittest discover -s tests -v)

Doubles only: NOT verified against real Discord.  They cover authorization, detection, audit-log delay handling,
strip -> restore -> ban ordering, honest failure reporting, duplicate suppression and the help text."""
import asyncio
import importlib.util
import os
import sys
import tempfile
import types
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _compat  # noqa: F401,E402
import discord  # noqa: E402
from fakes import exc  # noqa: E402
from utils import antinuke_store as store  # noqa: E402

_spec = importlib.util.spec_from_file_location("botguard_under_test", os.path.join(_compat.ROOT, "cogs", "antinuke", "botguard.py"))
bg = importlib.util.module_from_spec(_spec)
sys.modules["botguard_under_test"] = bg
_spec.loader.exec_module(bg)
AL = discord.AuditLogAction
bg.HINT_WAIT = 0.01                                    # tests: do not really wait for a gateway entry that never comes

ADMIN, MROLES, BAN, KICK, AUDIT, SEND = 1 << 3, 1 << 28, 1 << 2, 1 << 1, 1 << 7, 1 << 11
OWNER, BOT, EXTRA, ADM, LOWADM, NOW = 1, 100, 7, 50, 51, 1_000_000.0


class Perm:
    def __init__(self, v): self.value = v
    def __eq__(self, o): return self.value == o.value
    def __ne__(self, o): return self.value != o.value
    @property
    def administrator(self): return bool(self.value & ADMIN)
    @property
    def manage_roles(self): return bool(self.value & MROLES)
    @property
    def view_audit_log(self): return bool(self.value & AUDIT)


class Role:
    def __init__(self, guild, rid, name, perms, pos, bot_id=None, managed=False):
        self.guild, self.id, self.name, self.position, self.managed = guild, rid, name, pos, managed
        self.permissions = Perm(perms)
        self.tags = types.SimpleNamespace(bot_id=bot_id)
    def is_default(self): return self.id == self.guild.id
    async def edit(self, **kw):
        self.guild.calls.append(("role.edit", self.id, sorted(kw)))
        if self.guild.edit_exc:
            raise self.guild.edit_exc
        if self.guild.edit_noop:
            return
        if "permissions" in kw:
            self.permissions = Perm(kw["permissions"].value)
        if "position" in kw:
            self.position = kw["position"]
    __lt__ = lambda s, o: s.position < o.position  # noqa: E731
    __gt__ = lambda s, o: s.position > o.position  # noqa: E731


class Member:
    def __init__(self, guild, uid, roles=(), bot=False):
        self.guild, self.id, self.bot, self.roles, self.name = guild, uid, bot, [guild.everyone, *roles], f"u{uid}"
    @property
    def top_role(self): return max(self.roles, key=lambda r: r.position)
    @property
    def guild_permissions(self):
        v = 0
        for r in self.roles:
            v |= r.permissions.value
        return Perm(v)
    async def remove_roles(self, *roles, reason=None, atomic=True):
        self.guild.calls.append(("remove_roles", self.id, [r.id for r in roles]))
        if self.guild.rr_exc:
            raise self.guild.rr_exc
        self.roles = [r for r in self.roles if r not in roles]


class Entry:
    def __init__(self, eid, action, user_id, target_id, visible_poll=1):
        self.id, self.action, self.user_id, self.target_id = eid, action, user_id, target_id
        self.created_at, self.visible_poll = NOW - 1, visible_poll


class Guild:
    def __init__(self):
        self.id, self.owner_id, self.name = 1000, OWNER, "G"
        self.calls, self.entries, self.polls = [], [], 0
        self.audit_exc = self.ban_exc = self.kick_exc = self.edit_exc = self.rr_exc = None
        self.edit_noop = False
        self.banned, self.channels = set(), {}
        self.everyone = Role(self, self.id, "@everyone", SEND, 0)
        self.roles = [self.everyone]
        self.managed = self.add_role(5, "BotRole", ADMIN | BAN | KICK | AUDIT | MROLES | SEND, 10, bot_id=BOT, managed=True)
        self.higher = self.add_role(6, "Above", MROLES, 20)             # role the bot wears above its integration role
        self.me = Member(self, BOT, [self.managed, self.higher], bot=True)
        self.members = {BOT: self.me}
    def add_role(self, rid, name, perms, pos, **kw):
        r = Role(self, rid, name, perms, pos, **kw)
        self.roles.append(r)
        return r
    def get_role(self, rid): return next((r for r in self.roles if r.id == rid), None)
    def get_member(self, uid): return self.members.get(uid)
    def get_channel(self, cid): return self.channels.get(cid)
    def add_member(self, uid, roles=(), bot=False):
        m = self.members[uid] = Member(self, uid, roles, bot)
        return m
    async def fetch_member(self, uid):
        if uid not in self.members:
            raise exc(discord.NotFound, 404)
        return self.members[uid]
    async def fetch_roles(self): return list(self.roles)
    async def audit_logs(self, limit=10, action=None):
        self.polls += 1
        self.calls.append(("audit", action))
        if self.audit_exc:
            raise self.audit_exc
        for e in self.entries:
            if e.action == action and e.visible_poll <= self.polls:
                yield e
    async def ban(self, obj, reason=None, delete_message_seconds=0):
        self.calls.append(("ban", obj.id))
        if self.ban_exc:
            raise self.ban_exc
        self.banned.add(obj.id)
    async def kick(self, m, reason=None):
        self.calls.append(("kick", m.id))
        if self.kick_exc:
            raise self.kick_exc
        self.members.pop(m.id, None)
    async def fetch_ban(self, obj):
        if obj.id not in self.banned:
            raise exc(discord.NotFound, 404)


class Chan:
    def __init__(self): self.sent = []
    async def send(self, **kw): self.sent.append(kw)


class User:
    def __init__(self, fail=False): self.fail, self.sent = fail, []
    async def send(self, **kw):
        if self.fail:
            raise exc(discord.Forbidden)
        self.sent.append(kw)


class Bot:
    def __init__(self, guild):
        self.user, self.guilds, self.cogs = types.SimpleNamespace(id=BOT), [guild], {}
        self.owner_user = User()
    def get_cog(self, n): return self.cogs.get(n)
    def get_user(self, uid): return None
    async def fetch_user(self, uid): return self.owner_user
    def get_guild(self, gid): return self.guilds[0] if gid == self.guilds[0].id else None
    async def wait_until_ready(self): return None


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.g = Guild()
        self.bot = Bot(self.g)
        self.chan = Chan()
        self.g.channels[999] = self.chan
        store._cfg[self.g.id] = store.GuildCfg(enabled=True, autorec=True, log=999)
        self.sleeps = []

        async def fake_sleep(d): self.sleeps.append(d)
        self.cog = bg.BotGuard(self.bot, db_path=os.path.join(self.tmp.name, "bg.db"), clock=lambda: NOW, sleep=fake_sleep,
                               global_extra=frozenset(), settle=0)
        await self.cog.ledger.open()
        await self.cog._load_state()
        self.cog.flags[self.g.id] = {"integration": True, "botadd": True}
        await self.cog.resnapshot(self.g)
        self.admin = self.g.add_member(ADM, [self.g.add_role(70, "Admin", ADMIN, 5)])
        self.lowadm = self.g.add_member(LOWADM, [self.g.add_role(71, "LowAdmin", MROLES | BAN, 4)])

    async def asyncTearDown(self):
        await self.drain()
        await self.cog.ledger.close()
        store._cfg.clear()
        self.tmp.cleanup()

    async def drain(self):
        for _ in range(5):
            if self.cog._bg:
                await asyncio.gather(*list(self.cog._bg), return_exceptions=True)
            await asyncio.sleep(0)

    def ops(self, name): return [c for c in self.g.calls if c[0] == name]
    def card(self): return self.chan.sent[-1] if self.chan.sent else None
    def card_text(self): return self.card()["content"] if self.card() else ""

    async def add_bot(self, bot_id=300, executor=ADM, visible_poll=1):
        m = self.g.add_member(bot_id, bot=True)
        if executor is not None:
            self.g.entries.append(Entry(900 + bot_id, AL.bot_add, executor, bot_id, visible_poll))
        self.cog._spawn(self.cog._bot_added(m))
        await self.drain()
        return m

    def tamper(self, strip=ADMIN | BAN | KICK | MROLES, executor=LOWADM, visible_poll=1, eid=800):
        r = self.g.managed
        r.permissions = Perm(r.permissions.value & ~strip)
        self.g.entries.append(Entry(eid, AL.role_update, executor, r.id, visible_poll))
        self.cog._kick_role_check(self.g)


class PureTests(unittest.TestCase):
    def test_authorization_policy(self):
        self.assertTrue(bg.is_authorized(1, {7}, 1))
        self.assertTrue(bg.is_authorized(1, {7}, 7))
        for uid in (50, 0, -3, None, True, "7"):
            self.assertFalse(bg.is_authorized(1, {7}, uid))

    def test_config_validation(self):
        ids, problems = bg.parse_ids([5, "6", "x", 5, -1, True, 1 << 70])
        self.assertEqual(ids, [5, 6])
        self.assertEqual(len(problems), 5)
        self.assertEqual(bg.parse_ids("1, 2 3")[0], [1, 2, 3])
        self.assertEqual(bg.parse_ids(None), ([], []))
        self.assertTrue(bg.parse_ids(12.5)[1])

    def test_dangerous_list_is_complete(self):
        self.assertEqual(set(bg.DANGER_BITS), {"Administrator", "Manage Guild", "Manage Roles", "Manage Channels", "Manage Webhooks",
                                               "Ban Members", "Kick Members", "Manage Messages", "Mention Everyone", "Moderate Members"})
        self.assertEqual(bg.dangerous_in(ADMIN | SEND), ["Administrator"])

    def test_diff_uses_rank_not_absolute_position(self):
        g = Guild()
        snap = bg.RoleSnap(5, "x", g.managed.permissions.value, 10, bg.count_above(g.roles, g.managed))
        self.assertFalse(bg.diff_role(snap, g.managed, g.roles).any)
        g.add_role(90, "new low", 0, 1)                        # a role created BELOW does not change rank
        self.assertFalse(bg.diff_role(snap, g.managed, g.roles).any)
        g.add_role(91, "above", 0, 99)                         # a role above the bot = rank worse
        self.assertTrue(bg.diff_role(snap, g.managed, g.roles).rank_worse)
        self.assertTrue(bg.diff_role(snap, None, g.roles).deleted)

    def test_help_text_has_every_entry_syntax_and_status(self):
        pages = bg.help_text("?", {"integration": True, "botadd": False, "autorec": True, "extra_count": 2})
        text = "\n".join(pages)
        for needle in ("ANTI BOT NUKER", "Integration Protection", "Bot Role Permission Protection", "Bot Role Position Protection", "Command Permission Protection",
                       "Automatic Permission Recovery", "BOT ADD PROTECTION", "Authorized Bot Addition", "Extra Owner Authorization",
                       "Unauthorized Bot Removal", "Unauthorized Executor Punishment", "?antinuke integration on",
                       "?antinuke integration off", "?antinuke integration status", "?antinuke botadd on", "?antinuke botadd off",
                       "?antinuke botadd status", "?antinuke extraowner add", "?antinuke extraowner remove", "?antinuke extraowner list"):
            self.assertIn(needle, text)
        self.assertIn("ANTI BOT NUKER ON", pages[0])
        self.assertIn("BOT ADD PROTECTION OFF", pages[1])
        off = bg.help_text("?", {"integration": True, "botadd": True, "autorec": False, "extra_count": 0})[0]
        self.assertIn("**Automatic Permission Recovery** OFF", off)


class BotAddTests(Base):
    async def test_unauthorized_admin_add_removes_bot_and_bans_executor(self):
        await self.add_bot(executor=ADM)
        self.assertEqual(self.ops("kick"), [("kick", 300)])
        self.assertIn(ADM, self.g.banned)
        text = self.card_text()
        self.assertIn("UNAUTHORIZED", text)
        self.assertIn("Remove bot", text)
        self.assertEqual(len(self.bot.owner_user.sent), 1)                      # owner notified
        self.assertLess([c[0] for c in self.g.calls].index("kick"), [c[0] for c in self.g.calls].index("ban"))

    async def test_server_owner_add_is_allowed(self):
        await self.add_bot(executor=OWNER)
        self.assertEqual((self.ops("kick"), self.ops("ban")), ([], []))
        self.assertEqual(self.chan.sent, [])

    async def test_guild_extra_owner_add_is_allowed(self):
        self.assertEqual(await self.cog.add_extra(self.g, EXTRA, OWNER), "added")
        await self.add_bot(executor=EXTRA)
        self.assertEqual((self.ops("kick"), self.ops("ban")), ([], []))

    async def test_config_extra_owner_add_is_allowed(self):
        self.cog._global_extra = frozenset({EXTRA})
        await self.add_bot(executor=EXTRA)
        self.assertEqual(self.ops("ban"), [])

    async def test_whitelisted_user_is_not_authorized_for_bot_add(self):
        store._cfg[self.g.id].wl[ADM] = store.ALL_MASK
        await self.add_bot(executor=ADM)
        self.assertIn(ADM, self.g.banned)

    async def test_owner_and_extra_owner_never_banned_even_if_flagged_unauthorized(self):
        st, _ = await self.cog._ban(self.g, OWNER, "x")
        self.assertEqual(st, "skipped")

    async def test_audit_log_delay_is_retried_then_succeeds(self):
        await self.add_bot(executor=ADM, visible_poll=3)
        self.assertEqual(len(self.ops("audit")), 3)
        self.assertIn(ADM, self.g.banned)
        self.assertEqual(self.sleeps, [0.4, 0.8])

    async def test_audit_never_appears_no_punishment_and_bounded(self):
        await self.add_bot(executor=ADM, visible_poll=99)
        self.assertEqual(len(self.ops("audit")), 5)                              # bounded
        self.assertEqual((self.ops("kick"), self.ops("ban")), ([], []))
        self.assertIn("could not be identified", self.card_text())
        self.assertEqual(len(self.bot.owner_user.sent), 1)

    async def test_audit_forbidden_is_not_retried_and_does_not_punish(self):
        self.g.audit_exc = exc(discord.Forbidden)
        await self.add_bot(executor=ADM)
        self.assertEqual(len(self.ops("audit")), 1)
        self.assertEqual(self.ops("ban"), [])
        self.assertIn("View Audit Log", self.card_text())

    async def test_ban_and_kick_failures_are_reported_not_claimed(self):
        self.g.ban_exc, self.g.kick_exc = exc(discord.Forbidden), exc(discord.Forbidden)
        await self.add_bot(executor=ADM)
        inc_text = self.card_text()
        self.assertIn("`failed`", inc_text)
        self.assertNotIn(ADM, self.g.banned)
        self.assertEqual(self.cog.stats["bans"], 0)

    async def test_owner_dm_failure_is_reported(self):
        self.bot.owner_user.fail = True
        await self.add_bot(executor=ADM)
        self.assertIn("could not DM", self.card_text())

    async def test_duplicate_member_join_events_punish_once(self):
        m = self.g.add_member(300, bot=True)
        self.g.entries.append(Entry(1, AL.bot_add, ADM, 300))
        for _ in range(4):
            self.cog._spawn(self.cog._bot_added(m))
        await self.drain()
        self.assertEqual(len(self.ops("ban")), 1)
        self.assertEqual(len(self.ops("kick")), 1)

    async def test_two_bots_same_executor_one_ban(self):
        await self.add_bot(300, ADM)
        await self.add_bot(301, ADM)
        self.assertEqual(len(self.ops("ban")), 1)
        self.assertEqual(len(self.ops("kick")), 2)

    async def test_engine_claim_is_respected_and_verified(self):
        eng = types.SimpleNamespace(flagged={(self.g.id, ADM): __import__("time").monotonic()})
        self.bot.cogs["AntinukeEngine"] = eng
        await self.add_bot(executor=ADM)
        self.assertEqual(self.ops("ban"), [])                                    # no second ban
        self.assertIn("`unverified`", self.card_text())                          # and no false "banned" claim

    async def test_disabled_module_does_nothing(self):
        self.cog.flags[self.g.id]["botadd"] = False
        m = self.g.add_member(300, bot=True)
        await self.cog.on_member_join(m)
        await self.drain()
        self.assertEqual(self.g.calls, [])

    async def test_antinuke_engine_disabled_does_nothing(self):
        store._cfg[self.g.id].enabled = False
        m = self.g.add_member(300, bot=True)
        await self.cog.on_member_join(m)
        await self.drain()
        self.assertEqual(self.g.calls, [])


class BotRoleTests(Base):
    async def test_lower_admin_strip_attack_full_sequence_in_order(self):
        self.tamper()
        await self.drain()
        order = [c[0] for c in self.g.calls if c[0] in ("remove_roles", "role.edit", "ban")]
        self.assertEqual(order, ["remove_roles", "role.edit", "ban"])           # strip -> restore -> ban
        self.assertEqual(self.g.managed.permissions.value, self.cog.snaps[self.g.id].perms)
        self.assertIn(LOWADM, self.g.banned)
        self.assertNotIn(71, [r.id for r in self.lowadm.roles])                  # attacker's dangerous role stripped
        text = self.card_text()
        self.assertIn("re-read confirmed", text)
        self.assertEqual(len(self.bot.owner_user.sent), 1)

    async def test_recovery_not_claimed_when_discord_ignores_the_edit(self):
        self.g.edit_noop = True
        self.tamper()
        await self.drain()
        self.assertIn("still differs", self.card_text())
        self.assertEqual(self.cog.stats["restores"], 0)

    async def test_restore_blocked_by_hierarchy_is_reported_and_ban_still_runs(self):
        self.g.me.roles.remove(self.g.higher)                                    # integration role is now my top role
        self.tamper(strip=KICK | MROLES)                                         # still keeps Ban + Admin
        await self.drain()
        self.assertEqual(self.ops("role.edit"), [])
        self.assertIn("`blocked`", self.card_text())
        self.assertIn("highest role", self.card_text())
        self.assertIn(LOWADM, self.g.banned)

    async def test_missing_manage_roles_blocks_restore(self):
        self.g.higher.permissions = Perm(0)                                      # no other source of Manage Roles
        self.tamper(strip=ADMIN | MROLES)
        await self.drain()
        self.assertEqual(self.ops("role.edit"), [])
        self.assertIn("Manage Roles", self.card_text())

    async def test_discord_403_on_restore_is_failed_not_ok(self):
        self.g.edit_exc = exc(discord.Forbidden)
        self.tamper()
        await self.drain()
        self.assertIn("`failed`", self.card_text())
        self.assertNotEqual(self.g.managed.permissions.value, self.cog.snaps[self.g.id].perms)

    async def test_auto_recovery_off_skips_restore_but_still_punishes(self):
        store._cfg[self.g.id].autorec = False
        self.tamper()
        await self.drain()
        self.assertEqual(self.ops("role.edit"), [])
        self.assertIn(LOWADM, self.g.banned)

    async def test_authorized_owner_change_is_accepted_and_snapshot_updated(self):
        self.tamper(executor=OWNER)
        await self.drain()
        self.assertEqual(self.g.managed.permissions.value, self.cog.snaps[self.g.id].perms)
        self.assertEqual((self.ops("ban"), self.ops("role.edit")), ([], []))
        self.assertEqual(self.chan.sent, [])

    async def test_extra_owner_change_is_accepted(self):
        self.cog._global_extra = frozenset({EXTRA})
        self.tamper(executor=EXTRA)
        await self.drain()
        self.assertEqual(self.ops("ban"), [])

    async def test_trusted_whitelisted_user_not_punished_nor_modified(self):
        store._cfg[self.g.id].wl[LOWADM] = store.BIT["integration"]
        self.tamper()
        await self.drain()
        self.assertEqual((self.ops("ban"), self.ops("remove_roles"), self.ops("role.edit")), ([], [], []))
        self.assertIn("not punished", self.card_text())

    async def test_unidentified_executor_never_punished(self):
        self.tamper(visible_poll=99)
        await self.drain()
        self.assertEqual((self.ops("ban"), self.ops("remove_roles")), ([], []))
        self.assertIn("could not be identified", self.card_text())

    async def test_gateway_burst_produces_one_punishment(self):
        self.tamper()
        for _ in range(6):
            self.cog._kick_role_check(self.g)
        await self.drain()
        self.assertEqual(len(self.ops("ban")), 1)
        self.assertEqual(len(self.ops("remove_roles")), 1)
        self.assertEqual(len(self.chan.sent), 1)

    async def test_our_own_restore_event_is_a_noop(self):
        self.tamper()
        await self.drain()
        n = len(self.g.calls)
        self.cog._kick_role_check(self.g)
        await self.drain()
        self.assertEqual(len(self.g.calls), n)

    async def test_permission_gain_by_non_owner_is_absorbed_without_punishment(self):
        self.g.managed.permissions = Perm(self.g.managed.permissions.value | (1 << 5))
        self.g.entries.append(Entry(801, AL.role_update, LOWADM, 5))
        self.cog._kick_role_check(self.g)
        await self.drain()
        self.assertEqual(self.ops("ban"), [])

    async def test_position_demotion_unidentified_is_alerted_not_punished(self):
        self.g.add_role(95, "boss", 0, 50)                                       # something now outranks the bot role
        self.cog._kick_role_check(self.g)
        await self.drain()
        self.assertEqual(self.ops("ban"), [])
        self.assertLessEqual(len(self.ops("audit")), 2)                          # short bounded wait for position-only

    async def test_role_deleted_cannot_self_recover(self):
        self.g.roles.remove(self.g.managed)
        self.g.entries.append(Entry(802, AL.role_delete, LOWADM, 5))
        self.cog._kick_role_check(self.g)
        await self.drain()
        self.assertIn("`impossible`", self.card_text())
        self.assertIn(LOWADM, self.g.banned)

    async def test_integration_deleted_and_guild_remove_admit_no_self_recovery(self):
        self.g.entries.append(Entry(803, AL.integration_delete, LOWADM, 77))
        payload = types.SimpleNamespace(guild_id=self.g.id, integration_id=77, application_id=BOT)
        await self.cog.on_raw_integration_delete(payload)
        await self.drain()
        self.assertIn("cannot re-add myself", self.card_text())
        self.assertIn("`impossible`", self.card_text())
        await self.cog.on_raw_integration_delete(types.SimpleNamespace(guild_id=self.g.id, integration_id=78, application_id=12345))
        await self.drain()
        n = len(self.chan.sent)
        self.bot.owner_user.sent.clear()
        await self.cog.on_guild_remove(self.g)
        self.assertEqual(len(self.bot.owner_user.sent), 1)
        self.assertIn("re-invite", self.bot.owner_user.sent[0]["content"])
        self.assertEqual(len(self.chan.sent), n)                                 # cannot write to a guild we left

    async def test_offline_drift_is_reported_never_reverted(self):
        self.g.managed.permissions = Perm(SEND)
        await self.cog._baseline(self.g)
        self.assertEqual((self.ops("role.edit"), self.ops("ban")), ([], []))
        self.assertIn("while I was offline", self.card_text())


class FastPathTests(Base):
    def hint(self, action, uid, target, eid=1):
        e = Entry(eid, action, uid, target)
        e.guild = self.g
        return e

    async def test_bot_add_uses_gateway_entry_with_zero_rest_polls_and_parallel_kick_ban(self):
        m = self.g.add_member(300, bot=True)
        await self.cog.on_audit_log_entry_create(self.hint(AL.bot_add, ADM, 300))
        self.cog._spawn(self.cog._bot_added(m))
        await self.drain()
        self.assertEqual(self.ops("audit"), [])
        self.assertIn(ADM, self.g.banned)
        self.assertEqual(self.sleeps, [])                                         # no waiting at all
        self.assertIn("gateway audit entry", self.card_text())
        self.assertIn("handled in", self.card_text())

    async def test_gateway_entry_arriving_after_the_join_event_is_awaited_not_polled(self):
        bg.HINT_WAIT = 1.0
        try:
            m = self.g.add_member(300, bot=True)
            self.cog._spawn(self.cog._bot_added(m))
            await asyncio.sleep(0.01)
            await self.cog.on_audit_log_entry_create(self.hint(AL.bot_add, ADM, 300))
            await self.drain()
        finally:
            bg.HINT_WAIT = 0.01
        self.assertEqual(self.ops("audit"), [])
        self.assertIn(ADM, self.g.banned)

    async def test_role_tamper_uses_gateway_entry(self):
        r = self.g.managed
        r.permissions = Perm(r.permissions.value & ~(ADMIN | BAN | KICK | MROLES))
        await self.cog.on_audit_log_entry_create(self.hint(AL.role_update, LOWADM, 5, eid=7))
        self.cog._kick_role_check(self.g)
        await self.drain()
        self.assertEqual(self.ops("audit"), [])
        self.assertEqual([c[0] for c in self.g.calls if c[0] in ("remove_roles", "role.edit", "ban")],
                         ["remove_roles", "role.edit", "ban"])                    # spec order unchanged

    async def test_gateway_entry_is_single_use_and_stale_ones_ignored(self):
        await self.cog.on_audit_log_entry_create(self.hint(AL.bot_add, ADM, 300, eid=5))
        f1 = await self.cog._find_executor(self.g, [AL.bot_add], 300)
        self.assertEqual(f1.executor_id, ADM)
        f2 = await self.cog._find_executor(self.g, [AL.bot_add], 300)            # same entry cannot punish twice
        self.assertIsNone(f2.executor_id)
        e = self.hint(AL.bot_add, ADM, 301, eid=6)
        await self.cog.on_audit_log_entry_create(e)
        self.cog._now = lambda: NOW + 500
        self.assertIsNone((await self.cog._find_executor(self.g, [AL.bot_add], 301)).executor_id)


class RawPathTests(Base):
    def raw(self, at, uid, target, eid=11):
        return {"action_type": at, "guild_id": str(self.g.id), "id": str(eid), "user_id": str(uid), "target_id": str(target)}

    async def test_raw_unauthorized_bot_add_fires_kick_and_ban_without_member_or_rest(self):
        self.cog._raw_audit(self.raw(28, ADM, 300))               # no member_join, no audit REST, no cache needed
        await self.drain()
        self.assertEqual(self.ops("audit"), [])
        self.assertEqual(self.ops("kick"), [("kick", 300)])
        self.assertIn(ADM, self.g.banned)
        self.assertIn("raw gateway", self.card_text())
        self.assertIn("punishment sent in", self.card_text())

    async def test_raw_then_member_join_and_gateway_listener_do_not_duplicate(self):
        self.cog._raw_audit(self.raw(28, ADM, 300))
        m = self.g.add_member(300, bot=True)
        await self.cog.on_member_join(m)
        e = Entry(11, AL.bot_add, ADM, 300)
        e.guild = self.g
        await self.cog.on_audit_log_entry_create(e)
        await self.drain()
        self.assertEqual(len(self.ops("ban")), 1)
        self.assertEqual(len(self.ops("kick")), 1)

    async def test_raw_authorized_owner_and_extra_do_nothing(self):
        await self.cog.add_extra(self.g, EXTRA, OWNER)
        self.cog._raw_audit(self.raw(28, OWNER, 300, 1))
        self.cog._raw_audit(self.raw(28, EXTRA, 301, 2))
        await self.drain()
        self.assertEqual((self.ops("kick"), self.ops("ban")), ([], []))

    async def test_raw_garbage_and_disabled_are_ignored(self):
        for bad in ({}, {"action_type": 28}, {"action_type": 28, "guild_id": "x", "id": "1", "user_id": "2", "target_id": "3"},
                    {"action_type": 999, "guild_id": "1000", "id": "1", "user_id": "2", "target_id": "3"}):
            self.cog._raw_audit(bad)
        self.cog.flags[self.g.id]["botadd"] = False
        self.cog._raw_audit(self.raw(28, ADM, 300))
        await self.drain()
        self.assertEqual(self.g.calls, [])

    async def test_raw_role_update_seeds_hint_so_reconcile_needs_no_rest(self):
        r = self.g.managed
        r.permissions = Perm(r.permissions.value & ~(ADMIN | BAN | KICK | MROLES))
        self.cog._raw_audit(self.raw(31, LOWADM, 5, 12))
        self.cog._kick_role_check(self.g)
        await self.drain()
        self.assertEqual(self.ops("audit"), [])
        self.assertIn(LOWADM, self.g.banned)

    async def test_confirmations_run_after_the_ban(self):
        order = []
        orig_fetch_member, orig_fetch_roles, orig_ban = self.g.fetch_member, self.g.fetch_roles, self.g.ban
        async def fm(uid): order.append("fetch_member"); return await orig_fetch_member(uid)
        async def fr(): order.append("fetch_roles"); return await orig_fetch_roles()
        async def bn(o, **k): order.append("ban"); return await orig_ban(o, **k)
        self.g.fetch_member, self.g.fetch_roles, self.g.ban = fm, fr, bn
        self.g.managed.permissions = Perm(self.g.managed.permissions.value & ~(ADMIN | BAN | KICK | MROLES))
        self.cog._raw_audit(self.raw(31, LOWADM, 5, 13))
        self.cog._kick_role_check(self.g)
        await self.drain()
        self.assertEqual(order[0], "ban")                          # no re-read round trip before the ban
        self.assertIn("re-read confirmed", self.card_text())

    async def test_direct_ban_is_used_when_engine_offers_it_and_refusal_is_failed(self):
        calls = []
        async def direct(gid, uid, note): calls.append(uid); return False
        self.bot.cogs["AntinukeEngine"] = types.SimpleNamespace(flagged={}, _direct_ban=direct)
        st, _ = await self.cog._ban(self.g, ADM, "x")
        self.assertEqual((calls, st), ([ADM], "failed"))
        self.assertNotIn(ADM, self.g.banned)


class CommandPermissionTests(Base):
    def raw(self, uid, app=BOT, eid=21):
        return {"action_type": 121, "guild_id": str(self.g.id), "id": str(eid), "user_id": str(uid), "target_id": "999",
                "options": {"application_id": str(app)}, "changes": []}

    async def test_untrusted_command_permission_edit_is_stripped_banned_and_logged_honestly(self):
        self.cog._raw_audit(self.raw(LOWADM))
        await self.drain()
        self.assertIn(LOWADM, self.g.banned)
        self.assertEqual(len(self.ops("remove_roles")), 1)
        text = self.card_text()
        self.assertIn("Command Permissions", text)
        self.assertIn("`impossible`", text)                                       # no false restore claim
        self.assertEqual(len(self.bot.owner_user.sent), 1)

    async def test_other_apps_owner_extra_and_trusted(self):
        self.cog._raw_audit(self.raw(LOWADM, app=12345, eid=1))                   # someone else's bot: ignored
        self.cog._raw_audit(self.raw(OWNER, eid=2))
        await self.cog.add_extra(self.g, EXTRA, OWNER)
        self.cog._raw_audit(self.raw(EXTRA, eid=3))
        await self.drain()
        self.assertEqual((self.ops("ban"), self.chan.sent), ([], []))
        store._cfg[self.g.id].wl[ADM] = store.BIT["integration"]
        self.cog._raw_audit(self.raw(ADM, eid=4))
        await self.drain()
        self.assertEqual(self.ops("ban"), [])
        self.assertIn("not punished", self.card_text())

    async def test_burst_of_edits_is_one_incident_and_disabled_is_ignored(self):
        for i in range(5):
            self.cog._raw_audit(self.raw(LOWADM, eid=30 + i))
        await self.drain()
        self.assertEqual((len(self.ops("ban")), len(self.chan.sent)), (1, 1))
        self.cog.flags[self.g.id]["integration"] = False
        self.cog._raw_audit(self.raw(ADM, eid=99))
        await self.drain()
        self.assertNotIn(ADM, self.g.banned)


class ExtraOwnerStoreTests(Base):
    async def test_add_remove_persist_and_guards(self):
        self.assertEqual(await self.cog.add_extra(self.g, EXTRA, OWNER), "added")
        self.assertEqual(await self.cog.add_extra(self.g, EXTRA, OWNER), "exists")
        self.assertEqual(await self.cog.add_extra(self.g, OWNER, OWNER), "implicit")
        self.assertEqual(await self.cog.add_extra(self.g, 9, OWNER, is_bot=True), "invalid")
        self.assertEqual(await self.cog.add_extra(self.g, -4, OWNER), "invalid")
        self.cog._global_extra = frozenset({33})
        self.assertEqual(await self.cog.remove_extra(self.g.id, 33, OWNER), "config")
        again = bg.BotGuard(self.bot, db_path=self.cog.ledger.path, clock=lambda: NOW, global_extra=frozenset())
        await again.ledger.open()
        await again._load_state()
        self.assertIn(EXTRA, again.extra[self.g.id])
        self.assertEqual(again.snaps[self.g.id].role_id, 5)
        await again.ledger.close()
        self.assertEqual(await self.cog.remove_extra(self.g.id, EXTRA, OWNER), "removed")
        self.assertEqual(await self.cog.remove_extra(self.g.id, EXTRA, OWNER), "absent")

    async def test_limit(self):
        for i in range(bg.MAX_EXTRA_OWNERS):
            self.assertEqual(await self.cog.add_extra(self.g, 5000 + i, OWNER), "added")
        self.assertEqual(await self.cog.add_extra(self.g, 9999, OWNER), "limit")

    async def test_managers_are_owner_and_extra_only(self):
        await self.cog.add_extra(self.g, EXTRA, OWNER)
        self.assertTrue(self.cog.is_manager(self.g, OWNER))
        self.assertTrue(self.cog.is_manager(self.g, EXTRA))
        self.assertFalse(self.cog.is_manager(self.g, ADM))


class SourceWiringTests(unittest.TestCase):
    def read(self, *p):
        with open(os.path.join(_compat.ROOT, *p), encoding="utf-8") as fh:
            return fh.read()

    def test_commands_exist_in_antinuke_group_and_help_menu(self):
        s = self.read("cogs", "commands", "antinuke.py")
        for needle in ('name="integration"', 'name="botadd"', 'name="extraowner"', 'extraowner_add', 'extraowner_remove',
                       'extraowner_list', "extra_pages=self._module_pages(ctx)", "_manager_gate"):
            self.assertIn(needle, s)
        self.assertIn("extra_pages", self.read("utils", "antinuke_ui.py"))

    def test_registered_and_config_default_empty_and_no_hardcoded_ids(self):
        self.assertIn("BotGuard", self.read("cogs", "__init__.py"))
        self.assertIn("EXTRA_OWNER_IDS = []", self.read("utils", "config.py"))
        src = self.read("cogs", "antinuke", "botguard.py")
        import re
        self.assertEqual([m for m in re.findall(r"\b\d{17,20}\b", src)], [])
        self.assertNotIn("TOKEN", src)

    def test_existing_engine_untouched(self):
        s = self.read("cogs", "antinuke", "engine.py")
        self.assertEqual(s.count("@commands.Cog.listener()"), 10)               # same 10 listeners as before


if __name__ == "__main__":
    unittest.main()
