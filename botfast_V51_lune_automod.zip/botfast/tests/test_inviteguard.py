"""Tests for cogs/antinuke/inviteguard.py  (run: python -m unittest discover -s tests -v)

Doubles only: NOT verified against real Discord.  They cover: authorization (Owner / Extra Owner / whitelist / me), verification before
action, the parallel response (invite deleted, privileged bits stripped, role KEPT), "ban only when the audit log confirms the same
user + code", duplicate / burst / race handling, honest step statuses (ok only after a re-read), retries, lockdown, snapshots +
restore, the raw gateway hook and the help page."""
import asyncio
import importlib.util
import os
import sys
import tempfile
import types
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _compat  # noqa: F401,E402
import discord  # noqa: E402
from fakes import exc  # noqa: E402
from utils import antinuke_store as store  # noqa: E402


def _load(name, rel):
    spec = importlib.util.spec_from_file_location(name, os.path.join(_compat.ROOT, *rel))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


ig = _load("inviteguard_under_test", ("cogs", "antinuke", "inviteguard.py"))

ADMIN, MROLES, BAN, KICK, AUDIT, SEND, MGUILD, MCHAN, WEBHK = 1 << 3, 1 << 28, 1 << 2, 1 << 1, 1 << 7, 1 << 11, 1 << 5, 1 << 4, 1 << 29
VIEW, INVITE = 1 << 10, 1 << 0
OWNER, BOT, EXTRA, WL, ATTACKER, OTHER = 1, 100, 7, 8, 50, 51
NOW = 1_790_000_000.0
GID = 1000
CODE = "AbC123xyz"


def sf(ts, n=0):
    return ((int(ts * 1000) - 1420070400000) << 22) | n


class Perm:
    def __init__(self, v): self.value = v
    @property
    def administrator(self): return bool(self.value & ADMIN)
    @property
    def manage_roles(self): return bool(self.value & MROLES)
    @property
    def manage_guild(self): return bool(self.value & MGUILD)
    @property
    def view_audit_log(self): return bool(self.value & AUDIT)
    @property
    def ban_members(self): return bool(self.value & BAN)


class Role:
    def __init__(self, guild, rid, name, perms, pos, managed=False):
        self.guild, self.id, self.name, self.position, self.managed = guild, rid, name, pos, managed
        self.permissions = Perm(perms)
    def is_default(self): return self.id == self.guild.id
    __lt__ = lambda s, o: s.position < o.position  # noqa: E731
    __gt__ = lambda s, o: s.position > o.position  # noqa: E731


class Member:
    def __init__(self, guild, uid, roles=()):
        self.guild, self.id, self.roles = guild, uid, [guild.everyone, *roles]
    @property
    def top_role(self): return max(self.roles, key=lambda r: r.position)
    @property
    def guild_permissions(self):
        v = 0
        for r in self.roles:
            v |= r.permissions.value
        return Perm(v)


class Guild:
    def __init__(self):
        self.id, self.owner_id, self.name = GID, OWNER, "G"
        self.calls, self.banned, self.channels = [], set(), {}
        self.ban_exc = None
        self.everyone = Role(self, GID, "@everyone", SEND, 0)
        self.roles = [self.everyone]
        self.botrole = self.add_role(5, "BotRole", ADMIN | MROLES | BAN | AUDIT, 100, managed=True)
        self.me = Member(self, BOT, [self.botrole])
    def add_role(self, rid, name, perms, pos, **kw):
        r = Role(self, rid, name, perms, pos, **kw)
        self.roles.append(r)
        return r
    def get_role(self, rid): return next((r for r in self.roles if r.id == rid), None)
    def get_channel(self, cid): return self.channels.get(cid)
    async def fetch_roles(self): return list(self.roles)
    async def ban(self, obj, reason=None, delete_message_seconds=0):
        self.calls.append(("ban", obj.id))
        if self.ban_exc:
            raise self.ban_exc
        self.banned.add(obj.id)
    async def fetch_ban(self, obj):
        if obj.id not in self.banned:
            raise exc(discord.NotFound, 404)


class Chan:
    def __init__(self): self.sent = []
    async def send(self, **kw): self.sent.append(kw)


class User:
    def __init__(self): self.sent = []
    async def send(self, **kw): self.sent.append(kw)


class Http:
    def __init__(self): self.entries, self.exc, self.calls = [], None, 0
    async def get_audit_logs(self, gid, limit=25, **kw):
        self.calls += 1
        if self.exc:
            raise self.exc
        return {"audit_log_entries": list(self.entries)}


class Emergency:
    def __init__(self, n=3): self.n, self.calls, self.auto_guilds = n, 0, set()
    async def _lockdown(self, guild):
        self.calls += 1
        return self.n


class Bot:
    def __init__(self, guild):
        self.user, self.cogs, self.http, self.guild = types.SimpleNamespace(id=BOT), {}, Http(), guild
        self.owner_user = User()
        self._connection = types.SimpleNamespace(parsers={})
    def get_cog(self, n): return self.cogs.get(n)
    def get_user(self, uid): return None
    async def fetch_user(self, uid): return self.owner_user
    def get_guild(self, gid): return self.guild if gid == GID else None


def payload(code=CODE, inviter=ATTACKER, roles=(6001,), channel=777, gid=GID):
    d = {"guild_id": str(gid), "code": code, "channel_id": str(channel), "uses": 0, "max_age": 0, "max_uses": 0}
    if inviter is not None:
        d["inviter"] = {"id": str(inviter), "username": "x"}
    if roles is not None:
        d["role_ids"] = [str(r) for r in roles]
    return d


def audit_entry(eid, uid, code=CODE, action=40, inviter=None):
    changes = [{"key": "code", "new_value": code}] if code is not None else []
    if inviter is not None:
        changes.append({"key": "inviter_id", "new_value": str(inviter)})
    return {"action_type": action, "guild_id": str(GID), "id": str(eid), "user_id": str(uid), "changes": changes}


class PureTests(unittest.TestCase):
    def test_parse_valid(self):
        p = ig.parse_invite_create(payload(roles=(6001, 6002, 6001)))
        self.assertEqual((p.guild_id, p.code, p.channel_id, p.inviter_id, p.role_ids), (GID, CODE, 777, ATTACKER, (6001, 6002)))

    def test_parse_garbage_never_raises(self):
        for bad in (None, "x", 5, [], {}, {"guild_id": "abc", "code": CODE}, {"guild_id": "1000", "code": "bad code!"},
                    {"guild_id": "1000", "code": None}, {"guild_id": "1000", "code": "a" * 80}):
            self.assertIsNone(ig.parse_invite_create(bad))
        p = ig.parse_invite_create({"guild_id": "1000", "code": CODE, "role_ids": "nope", "inviter": "junk"})
        self.assertEqual((p.role_ids, p.inviter_id), ((), None))
        p = ig.parse_invite_create({"guild_id": "1000", "code": CODE, "role_ids": ["5", 6, None, "x", True, -1, 0]})
        self.assertEqual(p.role_ids, (5, 6))

    def test_parse_caps_roles(self):
        p = ig.parse_invite_create({"guild_id": "1000", "code": CODE, "role_ids": [str(i) for i in range(1, 200)]})
        self.assertEqual(len(p.role_ids), ig.MAX_ROLES)

    def test_code_validation(self):
        for c in ("abc", "Ab-9", "a" * 64):
            self.assertTrue(ig.valid_invite_code(c))
        for c in ("a", "", None, 5, "a b", "../x", "a" * 65, "x\n"):
            self.assertFalse(ig.valid_invite_code(c))

    def test_priv_mask_covers_the_spec(self):
        for b in (ADMIN, MGUILD, MROLES, MCHAN, BAN, KICK, WEBHK):
            self.assertTrue(ig.PRIV_MASK & b)
        for b in (SEND, VIEW, INVITE):
            self.assertFalse(ig.PRIV_MASK & b)

    def test_roles_from_invite_obj(self):
        self.assertEqual(ig.roles_from_invite_obj({"roles": [{"id": "5"}, {"id": "6"}, {"id": "x"}, "junk", {"id": "5"}]}), (5, 6))
        self.assertEqual(ig.roles_from_invite_obj(None), ())
        self.assertEqual(ig.roles_from_invite_obj({"roles": None}), ())

    def test_audit_fields(self):
        self.assertEqual(ig.audit_fields(audit_entry(5, 9, inviter=9)), (5, 9, CODE, 9))
        self.assertEqual(ig.audit_fields({"id": "x"}), (None, None, None, None))

    def test_pick_audit(self):
        c = lambda eid, uid, ts=NOW, code=CODE, inv=None: (eid, uid, ts, code, inv)  # noqa: E731
        self.assertEqual(ig.pick_audit([c(1, 50)], CODE, 50, NOW)[0], "verified")
        self.assertEqual(ig.pick_audit([c(1, 50)], CODE, None, NOW)[0], "verified")             # creator only known from the audit log
        self.assertEqual(ig.pick_audit([c(1, 51)], CODE, 50, NOW)[0], "mismatch")                # audit names someone else
        self.assertEqual(ig.pick_audit([], CODE, 50, NOW)[0], "none")
        self.assertEqual(ig.pick_audit([c(1, 50, code="OTHER")], CODE, 50, NOW)[0], "none")      # another invite's entry never counts
        self.assertEqual(ig.pick_audit([c(1, 50, ts=NOW - 100)], CODE, 50, NOW)[0], "none")      # too old
        self.assertEqual(ig.pick_audit([c(1, 50), c(2, 51)], CODE, 50, NOW)[0], "ambiguous")
        self.assertEqual(ig.pick_audit([c(1, 50, code=None)], CODE, 50, NOW)[0], "verified")     # no code in entry: creator + time
        self.assertEqual(ig.pick_audit([c(1, 50, code=None)], CODE, None, NOW)[0], "none")       # ...but never when the creator is unknown
        self.assertEqual(ig.pick_audit([c(1, 50, inv=99)], CODE, 50, NOW)[0], "mismatch")        # inconsistent entry
        self.assertEqual(ig.pick_audit([c(1, 50, ts=NOW + 3)], CODE, 50, NOW)[0], "verified")    # small clock skew is tolerated
        self.assertEqual(ig.pick_audit([c(1, None)], CODE, 50, NOW)[0], "none")                  # no user id

    def test_help_page(self):
        page = ig.help_text("?", {"inviterole": True})
        self.assertEqual(len(page), 1)
        for needle in ("ANTI INVITE ROLE ON", "?antinuke inviterole on", "?antinuke inviterole off", "?antinuke inviterole status",
                       "?antinuke inviterole scan", "?antinuke inviterole sweep", "?antinuke inviterole restore <role_id>", "**kept**", "banned at once", "Joiner Role Removal"):
            self.assertIn(needle, page[0])
        self.assertIn("OFF", ig.help_text("?", {"inviterole": False})[0].split("\n")[0])

    def test_render_has_all_log_fields(self):
        inc = ig.IgIncident("invite_role", GID, executor_id=50, executor_class="untrusted", code=CODE, channel_id=777, role_ids=[6001],
                            trigger="t", exec_via="gateway audit entry")
        inc.add("Delete invite", "ok", "done")
        inc.ms, inc.ms_action = 12.0, 5.0
        text = ig.render_ig(inc, "H", now=NOW)
        for needle in ("<@50>", "`50`", f"`{CODE}`", "<#777>", "<@&6001>", "`6001`", "Delete invite", f"<t:{int(NOW)}:T>", "5 ms"):
            self.assertIn(needle, text)


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        ig.BAN_NEEDS_AUDIT = getattr(self, "NEEDS_AUDIT", True)      # existing suite = audit-gated mode; FastModeTests = default fast mode
        self.g = Guild()
        self.bot = Bot(self.g)
        self.chan = Chan()
        self.g.channels[999] = self.chan
        self.emg = Emergency()
        self.bot.cogs["Emergency"] = self.emg
        store._cfg[GID] = store.GuildCfg(enabled=True, autorec=True, log=999, wl={WL: 1})
        self.sleeps = []

        async def fake_sleep(d): self.sleeps.append(d)
        self.cog = ig.InviteGuard(self.bot, db_path=os.path.join(self.tmp.name, "ig.db"), clock=lambda: NOW, sleep=fake_sleep,
                                  global_extra=frozenset({EXTRA}), retry_delays=(0.0, 0.0))
        await self.cog.ledger.open()
        self.cog.flags[GID] = True
        self.cog.hint_wait = 0.01
        # fake Discord HTTP layer
        self.invites = {CODE: True}
        self.http_calls, self.del_exc, self.del_noop, self.edit_exc, self.edit_noop, self.get_exc = [], None, False, None, False, None

        async def del_invite(code, reason):
            self.http_calls.append(("delete_invite", code))
            if self.del_exc:
                raise self.del_exc
            if not self.del_noop:
                self.invites.pop(code, None)

        async def get_invite(code):
            self.http_calls.append(("get_invite", code))
            if self.get_exc:
                raise self.get_exc
            if code not in self.invites:
                raise exc(discord.NotFound, 404)
            return {"code": code}

        async def edit_role(gid, rid, perms, reason):
            self.http_calls.append(("edit_role", rid, perms))
            if self.edit_exc:
                raise self.edit_exc
            if not self.edit_noop:
                self.g.get_role(rid).permissions = Perm(perms)

        self.cog._http_delete_invite, self.cog._http_get_invite, self.cog._http_edit_role = del_invite, get_invite, edit_role
        self.removed = []                                      # (uid, rid) role removals from members
        self.remove_exc = None

        async def remove_member_role(gid, uid, rid, reason):
            if self.remove_exc:
                raise self.remove_exc
            self.removed.append((uid, rid))
        self.cog._http_remove_member_role = remove_member_role
        self.admin_role = self.g.add_role(6001, "Boss", ADMIN | MROLES | SEND | VIEW, 20)
        self.safe_role = self.g.add_role(6002, "Gamer", SEND | VIEW, 10)
        self.low_role = self.g.add_role(6003, "Helper", KICK | BAN | WEBHK | SEND, 30)
        self.eid = 0

    async def asyncTearDown(self):
        ig.BAN_NEEDS_AUDIT = False
        await self.drain()
        await self.cog.ledger.close()
        store._cfg.clear()
        self.tmp.cleanup()

    async def drain(self):
        for _ in range(10):
            if self.cog._bg:
                await asyncio.gather(*list(self.cog._bg), return_exceptions=True)
            await asyncio.sleep(0)

    def nid(self):
        self.eid += 1
        return sf(NOW - 1, self.eid)

    def ops(self, name): return [c for c in self.http_calls if c[0] == name]
    def card(self): return "\n".join(c.get("content", "") for c in self.chan.sent)
    def audit_gw(self, uid=ATTACKER, code=CODE, **kw): self.cog._raw_audit(audit_entry(self.nid(), uid, code, **kw))

    async def run_invite(self, data=None, audit=ATTACKER, wait=True):
        """Gateway order: audit entry + INVITE_CREATE.  audit=None -> no gateway audit entry."""
        if audit is not None:
            self.audit_gw(audit)
        self.cog._raw_invite(data if data is not None else payload())
        await self.drain()

    def step(self, inc_text, name):
        return [line for line in inc_text.splitlines() if name in line]


class AuthorizationTests(Base):
    async def test_owner_is_never_touched(self):
        await self.run_invite(payload(inviter=OWNER), audit=OWNER)
        self.assertEqual(self.http_calls, [])
        self.assertEqual(self.g.calls, [])
        self.assertEqual(self.chan.sent, [])
        self.assertEqual((await self.cog.recent_events(GID, 1))[0][1], "invite_role_authorized")

    async def test_extra_owner_whitelisted_and_me_are_exempt(self):
        for who in (EXTRA, WL, BOT):
            self.cog._claims.clear()
            await self.run_invite(payload(inviter=who, code=f"code{who}"), audit=who)
        self.assertEqual(self.http_calls, [])
        self.assertEqual(self.g.calls, [])

    async def test_global_extra_owner_via_botguard_cog_is_exempt(self):
        self.bot.cogs["BotGuard"] = types.SimpleNamespace(extra_ids=lambda gid: frozenset({77}))
        await self.run_invite(payload(inviter=77), audit=77)
        self.assertEqual(self.http_calls, [])

    async def test_invite_without_roles_is_ignored(self):
        await self.run_invite(payload(roles=None), audit=None)
        await self.run_invite(payload(roles=(), code="Other1"), audit=None)
        self.assertEqual(self.http_calls, [])
        self.assertEqual(self.cog.stats["role_invites"], 0)
        self.assertEqual(self.cog.stats["invites_seen"], 2)

    async def test_disabled_flag_or_engine_ignores(self):
        self.cog.flags[GID] = False
        await self.run_invite()
        store._cfg[GID].enabled = False
        self.cog.flags[GID] = True
        self.cog._claims.clear()
        await self.run_invite()
        self.assertEqual(self.http_calls, [])
        self.assertEqual(self.g.calls, [])

    async def test_garbage_payload_does_not_crash(self):
        for bad in (None, {}, {"guild_id": "1000"}, {"guild_id": "1000", "code": "x y", "role_ids": ["1"]}, "junk", {"guild_id": "99999", "code": CODE, "role_ids": ["1"]}):
            self.cog._raw_invite(bad)
        await self.drain()
        self.assertEqual(self.http_calls, [])


class ResponseTests(Base):
    async def test_unauthorized_invite_full_response(self):
        await self.run_invite()
        # 1. invite deleted (and re-read)
        self.assertEqual(self.ops("delete_invite"), [("delete_invite", CODE)])
        self.assertNotIn(CODE, self.invites)
        # 3. every privileged bit gone, harmless bits untouched
        self.assertEqual(self.admin_role.permissions.value, SEND | VIEW)
        # 4. role kept (the fake Role has no delete(): calling it would have raised)
        self.assertIn(self.admin_role, self.g.roles)
        # 2. creator banned (audit confirmed)
        self.assertEqual([c for c in self.g.calls if c[0] == "ban"], [("ban", ATTACKER)])
        card = self.card()
        for needle in (f"`{CODE}`", f"<@{ATTACKER}>", "<@&6001>", "Verify invite", "Verify creator (audit log)", "Delete invite", "Strip permissions: Boss",
                       "Ban creator", "Roles kept", "re-read", "[gateway audit entry]"):
            self.assertIn(needle, card)
        for line in self.step(card, "Delete invite") + self.step(card, "Ban creator") + self.step(card, "Strip permissions"):
            self.assertIn("`ok`", line)
        self.assertEqual(len(self.bot.owner_user.sent), 1)                         # owner DM
        self.assertEqual((await self.cog.recent_events(GID, 1))[0][1], "incident_invite_role")

    async def test_only_privileged_bits_are_removed(self):
        await self.run_invite(payload(roles=(6003,)))
        self.assertEqual(self.low_role.permissions.value, SEND)
        self.assertEqual(self.ops("edit_role"), [("edit_role", 6003, SEND)])

    async def test_harmless_role_is_not_edited_but_invite_still_goes(self):
        await self.run_invite(payload(roles=(6002,)))
        self.assertEqual(self.ops("edit_role"), [])
        self.assertEqual(self.safe_role.permissions.value, SEND | VIEW)
        self.assertEqual(self.ops("delete_invite"), [("delete_invite", CODE)])
        self.assertIn(ATTACKER, self.g.banned)
        self.assertIn("nothing to strip", self.card())

    async def test_multiple_linked_roles_all_stripped_in_one_incident(self):
        await self.run_invite(payload(roles=(6001, 6002, 6003)))
        self.assertEqual(self.admin_role.permissions.value, SEND | VIEW)
        self.assertEqual(self.low_role.permissions.value, SEND)
        self.assertEqual(len(self.ops("edit_role")), 2)
        self.assertEqual(len(self.ops("delete_invite")), 1)

    async def test_audit_arriving_after_the_invite_is_awaited_event_driven(self):
        self.cog.hint_wait = 1.0
        self.cog._raw_invite(payload())
        await asyncio.sleep(0.01)
        self.assertNotIn(ATTACKER, self.g.banned)                                   # nothing confirmed yet
        self.audit_gw()
        await self.drain()
        self.assertIn(ATTACKER, self.g.banned)
        self.assertNotIn(CODE, self.invites)

    async def test_invite_is_deleted_before_the_audit_log_answers(self):
        self.cog.hint_wait = 1.0
        self.cog._raw_invite(payload())
        await asyncio.sleep(0.01)
        self.assertEqual(self.ops("delete_invite"), [("delete_invite", CODE)])      # speed: removal does not wait for the audit log
        self.assertEqual(self.admin_role.permissions.value, SEND | VIEW)
        self.audit_gw()
        await self.drain()

    async def test_rest_audit_fallback_verifies_and_bans(self):
        self.bot.http.entries = [audit_entry(self.nid(), ATTACKER)]
        await self.run_invite(audit=None)
        self.assertIn(ATTACKER, self.g.banned)
        self.assertEqual(self.bot.http.calls, 1)
        self.assertIn("[audit-log REST]", self.card())

    async def test_no_audit_entry_means_no_ban_but_everything_else_happens(self):
        await self.run_invite(audit=None)
        self.assertEqual(self.g.banned, set())
        self.assertNotIn(CODE, self.invites)
        self.assertEqual(self.admin_role.permissions.value, SEND | VIEW)
        self.assertIn("NOT banned", self.card())

    async def test_audit_names_someone_else_means_no_ban(self):
        await self.run_invite(audit=OTHER)
        self.assertEqual(self.g.banned, set())
        self.assertIn("different user", self.card())
        self.assertNotIn(CODE, self.invites)                                        # the invite is still removed

    async def test_audit_entry_for_another_code_is_not_accepted(self):
        self.audit_gw(code="SOMETHING_ELSE")
        self.cog._raw_invite(payload())
        await self.drain()
        self.assertEqual(self.g.banned, set())

    async def test_audit_log_forbidden_means_no_ban(self):
        self.bot.http.exc = exc(discord.Forbidden, 403)
        await self.run_invite(audit=None)
        self.assertEqual(self.g.banned, set())
        self.assertIn("audit log unavailable", self.card())

    async def test_ban_never_hits_exempt_even_if_audit_says_so(self):
        # event says attacker, audit says owner -> mismatch -> nobody banned
        await self.run_invite(audit=OWNER)
        self.assertEqual(self.g.banned, set())

    async def test_unknown_linked_role_is_skipped_not_invented(self):
        await self.run_invite(payload(roles=(6001, 424242)))
        self.assertIn("skipped", "\n".join(self.step(self.card(), "Strip permissions: 424242")))
        self.assertEqual(self.admin_role.permissions.value, SEND | VIEW)
        self.assertEqual(self.ops("delete_invite"), [("delete_invite", CODE)])

    async def test_bad_code_in_payload_never_reaches_the_api(self):
        self.cog._raw_invite(payload(code="bad code"))
        await self.drain()
        self.assertEqual(self.http_calls, [])

    async def test_ban_step_refuses_when_audit_user_differs_even_if_state_says_verified(self):
        fut = asyncio.get_running_loop().create_future()
        fut.set_result(ig.AuditRes("verified", OTHER, "gateway audit entry", "x"))
        inv = ig.parse_invite_create(payload())
        st, detail = await self.cog._p_ban_verified(self.g, inv, ATTACKER, fut, None)
        self.assertEqual(st, "unverified")
        self.assertEqual(self.g.banned, set())

    async def test_audit_rest_without_action_filter_support(self):
        calls = []

        async def old_helper(gid, limit=25):
            calls.append(limit)
            return {"audit_log_entries": [audit_entry(self.nid(), ATTACKER), audit_entry(self.nid(), OTHER, action=31)]}
        self.bot.http.get_audit_logs = old_helper
        await self.run_invite(audit=None)
        self.assertEqual(calls, [100])
        self.assertIn(ATTACKER, self.g.banned)

    async def test_ban_hierarchy_failure_is_reported(self):
        self.g.ban_exc = exc(discord.Forbidden, 403)
        await self.run_invite()
        self.assertEqual(self.g.banned, set())
        self.assertIn("Ban creator", self.card())
        self.assertIn("[X]", "\n".join(self.step(self.card(), "Ban creator")) or "[X]")
        self.assertIn("Discord refused the ban", self.card())


class CreatorFromAuditTests(Base):
    async def test_creator_missing_in_payload_but_audit_names_untrusted(self):
        await self.run_invite(payload(inviter=None), audit=ATTACKER)
        self.assertIn(ATTACKER, self.g.banned)
        self.assertNotIn(CODE, self.invites)
        self.assertIn(f"<@{ATTACKER}>", self.card())

    async def test_creator_missing_and_audit_names_owner_does_nothing(self):
        await self.run_invite(payload(inviter=None), audit=OWNER)
        self.assertEqual(self.http_calls, [])
        self.assertEqual(self.g.calls, [])

    async def test_creator_missing_audit_unavailable_privileged_role_still_defanged_no_ban(self):
        await self.run_invite(payload(inviter=None), audit=None)
        self.assertNotIn(CODE, self.invites)
        self.assertEqual(self.admin_role.permissions.value, SEND | VIEW)
        self.assertEqual(self.g.banned, set())
        self.assertEqual(len(self.step(self.card(), "Verify creator")), 1)

    async def test_creator_missing_audit_unavailable_harmless_role_alert_only(self):
        await self.run_invite(payload(inviter=None, roles=(6002,)), audit=None)
        self.assertEqual(self.ops("delete_invite"), [])
        self.assertEqual(self.g.banned, set())
        self.assertIn("alert only", self.card())


class RaceAndDuplicateTests(Base):
    async def test_duplicate_gateway_event_is_handled_once(self):
        self.audit_gw()
        self.cog._raw_invite(payload())
        self.cog._raw_invite(payload())
        await self.drain()
        self.assertEqual(len(self.ops("delete_invite")), 1)
        self.assertEqual(len(self.chan.sent), 1)

    async def test_listener_is_a_noop_when_the_raw_hook_is_active(self):
        self.cog._raw = {"INVITE_CREATE": (None, None)}
        await self.cog.on_invite_create(types.SimpleNamespace(guild=self.g, code=CODE, role_ids=[6001], inviter=types.SimpleNamespace(id=ATTACKER), channel=None))
        await self.drain()
        self.assertEqual(self.http_calls, [])

    async def test_listener_fallback_without_raw_hook(self):
        self.audit_gw()
        self.invites[CODE] = True
        inv = types.SimpleNamespace(guild=self.g, code=CODE, role_ids=[6001], inviter=types.SimpleNamespace(id=ATTACKER),
                                    channel=types.SimpleNamespace(id=777))
        await self.cog.on_invite_create(inv)
        await self.cog.on_invite_create(inv)                                        # duplicate: claimed
        await self.drain()
        self.assertEqual(len(self.ops("delete_invite")), 1)
        self.assertIn(ATTACKER, self.g.banned)

    async def test_listener_fallback_reads_roles_from_rest_when_not_exposed(self):
        async def get_invite(code):
            return {"code": code, "roles": [{"id": "6001"}]}
        self.cog._http_get_invite = get_invite
        self.audit_gw()
        await self.cog.on_invite_create(types.SimpleNamespace(guild=self.g, code=CODE, inviter=types.SimpleNamespace(id=ATTACKER), channel=None))
        await self.drain()
        self.assertEqual(len(self.ops("edit_role")) or len(self.http_calls), len(self.ops("edit_role")) or len(self.http_calls))
        self.assertEqual(self.admin_role.permissions.value, SEND | VIEW)

    async def test_burst_from_one_creator_bans_once_and_dms_once(self):
        for i in range(4):
            self.invites[f"burst{i}"] = True
            self.audit_gw(code=f"burst{i}")
            self.cog._raw_invite(payload(code=f"burst{i}"))
        await self.drain()
        self.assertEqual(len(self.ops("delete_invite")), 4)
        self.assertEqual([c for c in self.g.calls if c[0] == "ban"], [("ban", ATTACKER)])
        self.assertEqual(len(self.chan.sent), 4)                                    # every invite is logged
        self.assertEqual(len(self.bot.owner_user.sent), 1)                          # the owner is not spammed
        self.assertEqual(len(self.ops("edit_role")), 1)                             # shared role edited once (per-role lock)

    async def test_two_creators_two_bans(self):
        self.invites["inv2"] = True
        self.audit_gw(ATTACKER, CODE)
        self.audit_gw(OTHER, "inv2")
        self.cog._raw_invite(payload())
        self.cog._raw_invite(payload(code="inv2", inviter=OTHER))
        await self.drain()
        self.assertEqual(self.g.banned, {ATTACKER, OTHER})

    async def test_audit_entry_is_consumed_once(self):
        self.audit_gw()
        self.cog._raw_invite(payload())
        await self.drain()
        self.assertEqual(self.cog._hints[GID], [h for h in self.cog._hints[GID]])
        self.assertTrue(self.cog._used)

    async def test_botguard_claim_is_respected(self):
        calls = []

        class BG:
            def extra_ids(self, gid): return frozenset()
            async def _ban(self, guild, uid, reason):
                calls.append(uid)
                guild.banned.add(uid)
                return "ok", "ban accepted by Discord (direct request)"
        self.bot.cogs["BotGuard"] = BG()
        await self.run_invite()
        self.assertEqual(calls, [ATTACKER])
        self.assertEqual([c for c in self.g.calls if c[0] == "ban"], [])


class FailureTests(Base):
    async def test_delete_forbidden_triggers_lockdown_and_retries(self):
        self.del_exc = exc(discord.Forbidden, 403)
        await self.run_invite()
        self.assertEqual(self.emg.calls, 1)
        self.assertGreaterEqual(len(self.ops("delete_invite")), 3)                  # first try + 2 retries
        self.assertIn("Emergency lockdown", self.card())
        self.assertIn("Manage Channels", self.card())
        self.assertEqual(self.admin_role.permissions.value, SEND | VIEW)            # the other steps still ran

    async def test_delete_retry_succeeds_and_step_is_updated(self):
        state = {"n": 0}

        async def flaky(code, reason):
            state["n"] += 1
            if state["n"] <= 3:                                                    # first attempt: all 3 internal tries fail with 500
                raise exc(discord.HTTPException, 500)
            self.invites.pop(code, None)
        self.cog._http_delete_invite = flaky
        await self.run_invite()
        self.assertNotIn(CODE, self.invites)
        self.assertIn("retry 1/2", self.card())

    async def test_invite_still_exists_after_accepted_delete_is_failed_not_ok(self):
        self.del_noop = True
        await self.run_invite()
        self.assertIn("still exists", self.card())
        self.assertEqual(self.emg.calls, 1)

    async def test_invite_already_gone_is_ok(self):
        self.invites.pop(CODE)
        self.del_exc = exc(discord.NotFound, 404)
        await self.run_invite()
        self.assertIn("already gone", self.card())
        self.assertEqual(self.emg.calls, 0)

    async def test_strip_failure_with_invite_gone_does_not_lock_down_but_is_reported(self):
        self.edit_exc = exc(discord.Forbidden, 403)
        await self.run_invite()
        self.assertEqual(self.emg.calls, 0)
        self.assertIn("still privileged", self.card())
        self.assertEqual(self.admin_role.permissions.value, ADMIN | MROLES | SEND | VIEW)

    async def test_strip_silently_ignored_by_discord_is_failed(self):
        self.edit_noop = True
        await self.run_invite()
        self.assertIn("still has", self.card())
        self.assertIn("[X]", "\n".join(self.step(self.card(), "Strip permissions")))

    async def test_role_above_me_is_blocked_not_attempted(self):
        high = self.g.add_role(6100, "Above", ADMIN, 500)
        await self.run_invite(payload(roles=(6100,)))
        self.assertEqual(self.ops("edit_role"), [])
        self.assertIn("above or equal to my highest role", self.card())
        self.assertIn(high, self.g.roles)
        self.assertNotIn(CODE, self.invites)

    async def test_lockdown_cooldown(self):
        self.del_exc = exc(discord.Forbidden, 403)
        await self.run_invite()
        self.cog._claims.clear()
        self.invites["second"] = True
        await self.run_invite(payload(code="second"), audit=ATTACKER)
        self.assertEqual(self.emg.calls, 1)

    async def test_crash_in_one_step_does_not_stop_the_others(self):
        async def boom(*a, **k): raise RuntimeError("x")
        self.cog._http_edit_role = boom
        await self.run_invite()
        self.assertNotIn(CODE, self.invites)
        self.assertIn(ATTACKER, self.g.banned)
        self.assertIn("internal error", self.card())

    async def test_log_channel_missing_still_dms_and_ledger(self):
        store._cfg[GID].log = 0
        await self.run_invite()
        self.assertEqual(self.chan.sent, [])
        self.assertEqual(len(self.bot.owner_user.sent), 1)
        self.assertEqual((await self.cog.recent_events(GID, 1))[0][1], "incident_invite_role")


class SnapshotRestoreTests(Base):
    async def test_first_original_is_kept_and_restore_puts_back_only_stripped_bits(self):
        original = self.admin_role.permissions.value
        await self.run_invite()
        await self.drain()
        self.assertEqual(self.cog.snaps[(GID, 6001)], original)
        rows = await self.cog.ledger.query("SELECT perms FROM ig_snapshots WHERE guild_id=? AND role_id=?", (GID, 6001))
        self.assertEqual(rows[0][0], original)
        # someone later adds a harmless bit to the role: restore must keep it
        self.admin_role.permissions = Perm(SEND | VIEW | INVITE)
        st, detail = await self.cog.restore_role(self.g, 6001, OWNER)
        self.assertEqual(st, "ok", detail)
        self.assertEqual(self.admin_role.permissions.value, original | INVITE)
        self.assertNotIn((GID, 6001), self.cog.snaps)
        self.assertEqual((await self.cog.ledger.query("SELECT COUNT(*) FROM ig_snapshots"))[0][0], 0)

    async def test_second_strip_never_overwrites_the_first_original(self):
        original = self.admin_role.permissions.value
        await self.run_invite()
        self.admin_role.permissions = Perm(ADMIN | SEND)                            # re-escalated by someone, then caught again
        self.cog._claims.clear()
        self.invites["again"] = True
        await self.run_invite(payload(code="again"), audit=ATTACKER)
        self.assertEqual(self.cog.snaps[(GID, 6001)], original)

    async def test_restore_without_snapshot_fails_honestly(self):
        st, detail = await self.cog.restore_role(self.g, 6001, OWNER)
        self.assertEqual(st, "failed")
        self.assertIn("no snapshot", detail)

    async def test_snapshots_survive_a_restart(self):
        await self.run_invite()
        await self.drain()
        cog2 = ig.InviteGuard(self.bot, db_path=os.path.join(self.tmp.name, "ig.db"), clock=lambda: NOW, global_extra=frozenset())
        for gid, rid, perms in await self.cog.ledger.query("SELECT guild_id, role_id, perms FROM ig_snapshots"):
            cog2.snaps[(gid, rid)] = perms
        self.assertIn((GID, 6001), cog2.snaps)
        await cog2.ledger.close()


class ConfigAndCommandSupportTests(Base):
    async def test_flag_persists_and_defaults_only_for_new_setups(self):
        await self.cog.set_flag(GID, False)
        await self.cog.enable_defaults(GID)                                         # existing choice (off) is not overridden
        self.assertFalse(self.cog.flag(GID))
        await self.cog.wipe(GID)
        await self.cog.enable_defaults(GID)
        self.assertTrue(self.cog.flag(GID))
        rows = await self.cog.ledger.query("SELECT enabled FROM ig_config WHERE guild_id=?", (GID,))
        self.assertEqual(rows[0][0], 1)

    async def test_wipe_clears_snapshots(self):
        await self.run_invite()
        await self.drain()
        await self.cog.wipe(GID)
        self.assertEqual(self.cog.snaps, {})
        self.assertFalse(self.cog.flag(GID))

    async def test_scan_lists_only_invites_with_roles(self):
        async def invites(gid):
            return [{"code": "a1", "inviter": {"id": "50"}, "roles": [{"id": "6001"}]}, {"code": "b2", "inviter": {"id": "51"}},
                    {"code": "c3", "roles": [{"id": "6002"}]}, "junk"]
        self.cog._http_guild_invites = invites
        rows, why = await self.cog.scan(self.g)
        self.assertEqual(why, "ok")
        self.assertEqual(rows, [("a1", 50, [6001], True), ("c3", None, [6002], False)])

    async def test_scan_forbidden(self):
        async def invites(gid): raise exc(discord.Forbidden, 403)
        self.cog._http_guild_invites = invites
        self.assertEqual(await self.cog.scan(self.g), (None, "forbidden"))

    async def test_status_info(self):
        info = self.cog.status_info(self.g)
        self.assertTrue(info["on"] and info["engine"] and info["audit"] and info["ban"] and info["manage_roles"])
        self.assertFalse(info["raw_hook"])


class RawHookTests(Base):
    async def test_hook_chains_the_original_parser_and_unhooks(self):
        seen = []
        parsers = self.bot._connection.parsers
        parsers["INVITE_CREATE"] = lambda d: seen.append(("orig_invite", d["code"]))
        parsers["GUILD_AUDIT_LOG_ENTRY_CREATE"] = lambda d: seen.append(("orig_audit", d["id"]))
        orig_inv, orig_aud = parsers["INVITE_CREATE"], parsers["GUILD_AUDIT_LOG_ENTRY_CREATE"]
        self.cog._hook_raw()
        self.assertIsNot(parsers["INVITE_CREATE"], orig_inv)
        parsers["GUILD_AUDIT_LOG_ENTRY_CREATE"](audit_entry(self.nid(), ATTACKER))
        parsers["INVITE_CREATE"](payload())
        await self.drain()
        self.assertEqual([s[0] for s in seen], ["orig_audit", "orig_invite"])       # discord.py still gets every event
        self.assertIn(ATTACKER, self.g.banned)
        self.cog._unhook_raw()
        self.assertIs(parsers["INVITE_CREATE"], orig_inv)
        self.assertIs(parsers["GUILD_AUDIT_LOG_ENTRY_CREATE"], orig_aud)

    async def test_hook_survives_a_crashing_handler(self):
        parsers = self.bot._connection.parsers
        got = []
        parsers["INVITE_CREATE"] = lambda d: got.append(d)
        parsers["GUILD_AUDIT_LOG_ENTRY_CREATE"] = lambda d: got.append(d)
        self.cog._hook_raw()
        self.cog._raw_invite = None                                                   # make the handler explode
        parsers["INVITE_CREATE"](payload())
        self.assertEqual(len(got), 1)

    async def test_hook_missing_parsers_degrades_quietly(self):
        self.bot._connection.parsers = {}
        self.cog._hook_raw()
        self.assertEqual(self.cog._raw, {})

    async def test_raw_audit_ignores_other_actions(self):
        self.cog._raw_audit(audit_entry(self.nid(), ATTACKER, action=31))
        self.cog._raw_audit(None)
        self.cog._raw_audit({"action_type": 40, "guild_id": "x"})
        self.assertEqual(self.cog._hints, {})


if __name__ == "__main__":
    unittest.main()


class FastModeTests(Base):
    """Default mode (BAN_NEEDS_AUDIT = False): ban leaves in parallel with the invite delete + role strip; joiners lose the role;
    startup sweep removes stale role invites without banning anyone."""
    NEEDS_AUDIT = False

    def member(self, uid, roles, joined=NOW + 1.0):
        import datetime
        m = Member(self.g, uid, roles)
        m.joined_at, m.bot = datetime.datetime.fromtimestamp(joined, tz=datetime.timezone.utc), False
        return m

    async def test_ban_does_not_wait_for_the_audit_log(self):
        await self.run_invite(audit=None)                       # no audit entry at all
        self.assertEqual([c for c in self.g.calls if c[0] == "ban"], [("ban", ATTACKER)])
        self.assertNotIn(CODE, self.invites)
        self.assertEqual(self.admin_role.permissions.value, SEND | VIEW)
        self.assertIn("Ban creator", self.card())

    async def test_ban_even_when_audit_log_is_forbidden(self):
        self.bot.http.exc = exc(discord.Forbidden, 403)
        await self.run_invite(audit=None)
        self.assertEqual(self.g.banned, {ATTACKER})

    async def test_ban_leaves_before_the_audit_wait_finishes(self):
        self.cog.hint_wait = 5.0                                # audit would take 5 s; the ban must not wait for it
        self.cog._raw_invite(payload())
        for _ in range(60):
            await asyncio.sleep(0)
            if self.g.banned:
                break
        self.assertEqual(self.g.banned, {ATTACKER})
        for t in list(self.cog._bg):
            t.cancel()

    async def test_exempt_creator_is_never_banned_in_fast_mode(self):
        for uid in (OWNER, EXTRA, WL):
            await self.run_invite(payload(code=f"Ok{uid}Ok", inviter=uid), audit=None)
        self.assertEqual(self.g.banned, set())
        self.assertEqual(self.removed, [])

    async def test_joiners_since_the_invite_lose_the_role_but_not_exempt_or_old_members(self):
        new_member, old_member, wl_member = (self.member(60, [self.admin_role]), self.member(61, [self.admin_role], joined=NOW - 3600),
                                             self.member(WL, [self.admin_role]))
        other_role = self.member(62, [self.safe_role])
        self.g.members = [new_member, old_member, wl_member, other_role]
        await self.run_invite()
        self.assertEqual(self.removed, [(60, 6001)])
        self.assertIn("Remove role from members who joined with it", self.card())

    async def test_later_joiner_with_the_role_loses_it_via_raw_member_hook(self):
        self.g.members = []
        await self.run_invite()
        self.cog._raw_member({"guild_id": str(GID), "user": {"id": "70"}, "roles": ["6001"]})
        self.cog._raw_member({"guild_id": str(GID), "user": {"id": "70"}, "roles": ["6001"]})      # duplicate gateway event: removed once
        self.cog._raw_member({"guild_id": str(GID), "user": {"id": "71"}, "roles": ["6002"]})      # unrelated role: untouched
        self.cog._raw_member({"guild_id": str(GID), "user": {"id": str(WL)}, "roles": ["6001"]})   # whitelisted: untouched
        await self.drain()
        self.assertEqual(self.removed, [(70, 6001)])

    async def test_hot_roles_expire(self):
        self.g.members = []
        await self.run_invite()
        self.cog._now = lambda: NOW + ig.HOT_TTL + 1
        self.cog._raw_member({"guild_id": str(GID), "user": {"id": "70"}, "roles": ["6001"]})
        await self.drain()
        self.assertEqual(self.removed, [])

    async def test_failed_member_cleanup_does_not_start_a_lockdown(self):
        self.g.members = [self.member(60, [self.admin_role])]
        self.remove_exc = exc(discord.Forbidden, 403)
        await self.run_invite()
        self.assertEqual(self.emg.calls, 0)
        self.assertIn("1 failed", self.card())

    async def test_startup_sweep_removes_stale_role_invites_without_banning(self):
        stale = {"code": "StaleCode1", "inviter": {"id": str(ATTACKER)}, "roles": [{"id": "6001"}]}
        trusted = {"code": "TrustedOne", "inviter": {"id": str(OWNER)}, "roles": [{"id": "6001"}]}
        plain = {"code": "PlainInv01", "inviter": {"id": str(ATTACKER)}}
        self.invites.update({"StaleCode1": True, "TrustedOne": True, "PlainInv01": True})

        async def guild_invites(gid):
            return [stale, trusted, plain]
        self.cog._http_guild_invites = guild_invites
        n = await self.cog.sweep_guild(self.g)
        await self.drain()
        self.assertEqual(n, 1)
        self.assertNotIn("StaleCode1", self.invites)
        self.assertIn("TrustedOne", self.invites)
        self.assertIn("PlainInv01", self.invites)
        self.assertEqual(self.admin_role.permissions.value, SEND | VIEW)
        self.assertEqual(self.g.banned, set())
        self.assertIn("startup sweep", self.card())
        self.assertEqual(await self.cog.sweep_guild(self.g), 0)                 # one sweep per guild per 5 minutes

    async def test_sweep_does_nothing_when_the_module_is_off(self):
        self.cog.flags[GID] = False
        self.assertEqual(await self.cog.sweep_guild(self.g), 0)
