"""Unit + integration tests for cogs/antinuke/linkinvite.py   (run:  python -m unittest discover -s tests -v)"""
import asyncio
import logging
import os
import sqlite3
import sys
import tempfile
import types
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _compat  # noqa: F401,E402  (installs stubs only if discord.py / aiosqlite are missing)
import discord  # noqa: E402
from fakes import DANGER, KICK, SEND, Bot, Channel, Clock, Guild, Invite, exc  # noqa: E402

from utils import antinuke_store as store  # noqa: E402
import importlib.util  # noqa: E402

_spec = importlib.util.spec_from_file_location(              # load by path: `cogs/__init__` imports the whole bot
    "linkinvite_under_test", os.path.join(_compat.ROOT, "cogs", "antinuke", "linkinvite.py"))
li = importlib.util.module_from_spec(_spec)
sys.modules["linkinvite_under_test"] = li
_spec.loader.exec_module(li)

def _read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


ALL3 = DANGER["admin"] | DANGER["guild"] | DANGER["roles"]
li.X_WAIT = 0.02


def cfg_for(gid, **kw):
    c = store.GuildCfg(enabled=True, mods=store.ALL_MASK, **kw)
    store._cfg[gid] = c
    return c


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = os.path.join(self.tmp.name, "li.db")
        self.clock = Clock()
        self.guild = Guild()
        self.bot = Bot(self.guild)
        self.cfg = cfg_for(self.guild.id)
        self.chan = Channel()
        self.guild.channels[999] = self.chan
        self.cfg.log = 999
        self.cog = await self.new_cog()

    async def new_cog(self):
        cog = li.LinkInvite(self.bot, db_path=self.db, clock=self.clock)
        await cog.ledger.open()
        await cog._load_state()
        return cog

    async def asyncTearDown(self):
        await self.drain()
        await self.cog.ledger.close()
        store._cfg.clear()
        self.tmp.cleanup()

    async def drain(self, cog=None):
        cog = cog or self.cog
        for _ in range(5):
            if cog._bg:
                await asyncio.gather(*list(cog._bg), return_exceptions=True)
            await asyncio.sleep(0)

    def flagged_role(self, rid=5000, perms=ALL3 | SEND, pos=2):
        return self.guild.add_role(rid, f"linked{rid}", perms, pos)

    async def create_linked(self, role, creator=None):
        if creator:
            self.cog.note_role_audit(types.SimpleNamespace(target=role, user_id=creator, guild=self.guild))
        self.cog.linked_role_created(role)
        await self.drain()

    async def receive(self, member, role):
        before = types.SimpleNamespace(roles=list(member.roles), id=member.id, guild=self.guild)
        member.roles.append(role)
        after = types.SimpleNamespace(roles=list(member.roles), id=member.id, guild=self.guild)
        after.guild = self.guild
        self.cog.member_roles_changed(before, after)
        await self.drain()

    def events(self, kind=None):
        c = sqlite3.connect(self.db)
        q = "SELECT kind, role_id, member_id, x_id, y_id, verdict, detail FROM li_events" + (" WHERE kind=?" if kind else "")
        rows = c.execute(q, (kind,) if kind else ()).fetchall()
        c.close()
        return rows

    async def flush(self):                      # wait for queued ledger writes
        await self.cog.ledger.run(lambda: None)


# ------------------------------------------------------------------ pure logic
class PureLogic(unittest.TestCase):
    def test_cross_verify_matrix(self):                                  # scenarios 9-12
        self.assertEqual(li.cross_verify(7, 7), li.CONFIRMED)
        self.assertEqual(li.cross_verify(7, 8), li.MISMATCH)
        self.assertEqual(li.cross_verify(None, 8), li.X_MISSING)
        self.assertEqual(li.cross_verify(7, None), li.Y_MISSING)
        self.assertEqual(li.cross_verify(None, None), li.V_UNKNOWN)
        self.assertEqual(li.cross_verify(0, -1), li.V_UNKNOWN)           # invalid ids are "unavailable"
        self.assertEqual(li.cross_verify(True, True), li.V_UNKNOWN)

    def test_strip_only_three_bits(self):
        self.assertEqual(li.strip_value(ALL3 | SEND | KICK), SEND | KICK)
        self.assertEqual(li.strip_value(SEND), SEND)
        for bit in DANGER.values():
            self.assertEqual(li.strip_value(bit | SEND), SEND)

    def test_lockdown_wanted(self):
        self.assertTrue(li.lockdown_wanted(li.V_UNKNOWN, 2, 2))
        self.assertTrue(li.lockdown_wanted(li.Y_MISSING, 3, 2))
        self.assertFalse(li.lockdown_wanted(li.V_UNKNOWN, 1, 2))          # below threshold
        for v in (li.CONFIRMED, li.MISMATCH, li.X_MISSING):
            self.assertFalse(li.lockdown_wanted(v, 99, 2))

    def test_evidence_all_must_hold(self):
        ok = dict(role_was_dangerous=True, x_alive=True, same_inviter=True, attribution="NORMAL",
                  inviter_trusted=False, receiver_trusted=False)
        self.assertEqual(li.evidence_check(ok), [])
        for k, v in (("role_was_dangerous", False), ("x_alive", False), ("same_inviter", False),
                     ("attribution", "VANITY"), ("inviter_trusted", True), ("receiver_trusted", True)):
            self.assertTrue(li.evidence_check({**ok, k: v}), k)

    def test_candidate_expiry_and_cleanup(self):
        clk = Clock()
        cs = li.CandidateStore(clock=clk)
        cs.put(1, 10, 7, 8)
        clk.t += 3599
        self.assertIsNotNone(cs.get(1, 10))
        clk.t += 2
        self.assertIsNone(cs.get(1, 10))
        cs.put(1, 11, 7, 8)
        clk.t += 4000
        self.assertEqual(cs.purge(), 1)
        self.assertEqual(len(cs), 0)

    def test_candidate_store_is_bounded(self):
        cs = li.CandidateStore(clock=Clock(), cap=10)
        for i in range(1, 50):
            cs.put(1, i, 7, 8)
        self.assertLessEqual(len(cs), 10)

    def test_diff_invites(self):
        I = li.Inv
        self.assertEqual(li.diff_invites({"a": I(1, 5)}, {"a": I(2, 5)}, {}).inviter, 5)
        self.assertEqual(li.diff_invites({"a": I(1, 5)}, {"a": I(2, 5)}, {}).kind, li.NORMAL)
        self.assertEqual(li.diff_invites({"a": I(1, 5), "b": I(0, 6)}, {"a": I(2, 5), "b": I(1, 6)}, {}).kind, li.AMBIGUOUS)
        self.assertEqual(li.diff_invites({"a": I(1, 5)}, {"a": I(4, 5)}, {}).kind, li.AMBIGUOUS)
        self.assertEqual(li.diff_invites({"a": I(1, 5)}, {"a": I(1, 5)}, {}).kind, li.UNKNOWN)
        # last use of a max_uses=2 invite: the invite is gone from the fresh list
        att = li.diff_invites({"a": I(1, 5, 2)}, {}, {})
        self.assertEqual((att.kind, att.inviter), (li.NORMAL, 5))
        # same via the invite_delete event
        att = li.diff_invites({}, {}, {"a": I(1, 5, 2)})
        self.assertEqual((att.kind, att.inviter), (li.NORMAL, 5))
        # inviter missing -> never invent one
        att = li.diff_invites({"a": I(1, None)}, {"a": I(2, None)}, {})
        self.assertEqual((att.kind, att.inviter), (li.UNKNOWN, None))

    def test_valid_id(self):
        for bad in (0, -5, None, "5", 1 << 63, True, 1.5):
            self.assertFalse(li.valid_id(bad), bad)
        self.assertTrue(li.valid_id(123456789012345678))


# ------------------------------------------------------------------ 1. role creation
class RoleCreation(Base):
    async def test_1_normal_role_untouched(self):
        r = self.flagged_role(perms=SEND | KICK)                         # linked role with NO dangerous bits
        await self.create_linked(r)
        self.assertEqual(self.bot.http.edits, [])
        self.assertEqual(r.permissions.value, SEND | KICK)
        self.assertNotIn((self.guild.id, r.id), self.cog._monitored)

    async def test_untracked_guild_ignored(self):
        store._cfg.clear()
        r = self.flagged_role()
        await self.create_linked(r)
        self.assertEqual(self.bot.http.edits, [])

    async def _single(self, bit):
        r = self.flagged_role(perms=bit | SEND | KICK)
        await self.create_linked(r)
        await self.flush()
        self.assertEqual(r.permissions.value, SEND | KICK)               # only that bit removed
        row = sqlite3.connect(self.db).execute("SELECT original_perms, stripped_perms, status FROM li_roles").fetchone()
        self.assertEqual(row[0], bit | SEND | KICK)                      # original saved
        self.assertEqual(row[1], bit)

    async def test_2_administrator(self):
        await self._single(DANGER["admin"])

    async def test_3_manage_server(self):
        await self._single(DANGER["guild"])

    async def test_4_manage_roles(self):
        await self._single(DANGER["roles"])

    async def test_5_all_three(self):
        r = self.flagged_role(perms=ALL3 | SEND)
        await self.create_linked(r, creator=77)
        await self.flush()
        self.assertEqual(r.permissions.value, SEND)
        self.assertEqual(self.cog.cand.get(self.guild.id, r.id).x, 77)   # X recorded
        row = sqlite3.connect(self.db).execute("SELECT creator_id, original_perms, status FROM li_roles").fetchone()
        self.assertEqual(row, (77, ALL3 | SEND, "stripped"))

    async def test_original_never_overwritten(self):
        r = self.flagged_role(perms=ALL3 | SEND)
        await self.create_linked(r, creator=77)
        r.permissions.value = DANGER["admin"]
        self.cog._seen_roles.clear()
        await self.create_linked(r, creator=77)
        await self.flush()
        row = sqlite3.connect(self.db).execute("SELECT original_perms FROM li_roles").fetchone()
        self.assertEqual(row[0], ALL3 | SEND)

    async def test_14_hierarchy_restriction(self):
        above = self.flagged_role(rid=6000, pos=12)                      # above the bot's top role (10)
        await self.create_linked(above)
        self.assertEqual(self.bot.http.edits, [])                        # not even attempted
        self.assertEqual(self.cog.stats["strip_fail"], 1)
        self.assertEqual(self.events("linked_role_strip_failed")[0][6].count("hierarchy"), 1)

    async def test_forbidden_is_not_retried(self):
        self.bot.http.fail_edit = [exc(discord.Forbidden), exc(discord.Forbidden)]
        ok, err = await self.cog._edit_perms(self.guild, self.flagged_role(), 0, "t", 0.0, "t")
        self.assertEqual((ok, err), (False, "forbidden"))
        self.assertEqual(len(self.bot.http.fail_edit), 1)               # exactly one attempt consumed

    async def test_15_rate_limit_then_success(self):
        r = self.flagged_role()
        self.bot.http.fail_edit = [exc(discord.HTTPException, 429, retry_after=0.01), exc(discord.HTTPException, 502)]
        await self.create_linked(r, creator=77)
        self.assertEqual(r.permissions.value, SEND)
        self.assertEqual(self.cog.stats["strips"], 1)

    async def test_18_simultaneous_role_creation(self):
        roles = [self.flagged_role(rid=7000 + i, pos=1) for i in range(25)]
        for r in roles:
            self.cog.linked_role_created(r)
        for r in roles:                                                  # duplicate gateway dispatch
            self.cog.linked_role_created(r)
        await self.drain()
        self.assertTrue(all(r.permissions.value == SEND for r in roles))
        self.assertEqual(len(self.bot.http.edits), 25)                   # idempotent: one PATCH per role
        await self.flush()
        n = sqlite3.connect(self.db).execute("SELECT COUNT(*) FROM li_roles").fetchone()[0]
        self.assertEqual(n, 25)


# ------------------------------------------------------------------ 2. receipt monitoring
class Receipt(Base):
    async def test_6_member_receives_monitored_role(self):
        r = self.flagged_role()
        await self.create_linked(r, creator=77)
        m = self.guild.add_member(300)
        await self.receive(m, r)
        await self.flush()
        rows = self.events("receipt")
        self.assertEqual((rows[0][1], rows[0][2]), (r.id, 300))          # role id + member id recorded
        self.assertEqual(self.bot.http.bans, [])                         # receiving a role alone never bans

    async def test_unmonitored_role_ignored(self):
        other = self.guild.add_role(8000, "plain", SEND, 2)
        m = self.guild.add_member(300)
        await self.receive(m, other)
        await self.flush()
        self.assertEqual(self.events("receipt"), [])

    async def test_13_trusted_receiver_exempt(self):
        r = self.flagged_role()
        await self.create_linked(r, creator=77)
        self.cfg.wl[300] = store.ALL_MASK
        m = self.guild.add_member(300)
        await self.receive(m, r)
        await self.flush()
        self.assertEqual(len(self.events("receipt_trusted")), 1)
        self.assertEqual(self.events("cross_verify"), [])
        self.assertEqual(self.cog._state.get(self.guild.id), None)

    async def test_duplicate_receipt_deduped(self):
        r = self.flagged_role()
        await self.create_linked(r, creator=77)
        m = self.guild.add_member(300)
        await self.receive(m, r)
        m.roles.remove(r)
        await self.receive(m, r)
        await self.flush()
        self.assertEqual(len(self.events("receipt")), 1)


# ------------------------------------------------------------------ 3. invite tracking
class Invites(Base):
    async def prime_with(self, *invites):
        self.guild._invites = list(invites)
        self.cog.invites.clear()
        self.cog._primed.clear()
        await self.cog._prime(self.guild)

    async def test_7_normal_invite_detected(self):
        inv = Invite(self.guild, "abc", 3, 77)
        await self.prime_with(inv)
        inv.uses = 4
        await self.cog.on_member_join(self.guild.add_member(300))
        att = self.cog._joins[(self.guild.id, 300)]
        self.assertEqual((att.kind, att.inviter, att.code), (li.NORMAL, 77, "abc"))
        await self.flush()
        row = sqlite3.connect(self.db).execute("SELECT inviter_id, kind FROM li_joins WHERE member_id=300").fetchone()
        self.assertEqual(row, (77, "NORMAL"))

    async def test_invite_create_delete_cache(self):
        await self.prime_with()
        new = Invite(self.guild, "new", 0, 88)
        await self.cog.on_invite_create(new)
        self.assertEqual(self.cog.invites[self.guild.id]["new"].inviter, 88)
        await self.cog.on_invite_delete(new)
        self.assertNotIn("new", self.cog.invites[self.guild.id])

    async def test_last_use_invite_deleted_by_discord(self):
        inv = Invite(self.guild, "once", 0, 77, max_uses=1)
        await self.prime_with(inv)
        self.guild._invites = []                                          # Discord removed the consumed invite
        await self.cog.on_member_join(self.guild.add_member(300))
        self.assertEqual(self.cog._joins[(self.guild.id, 300)].inviter, 77)

    async def test_8_vanity_never_fabricates_inviter(self):
        self.guild.vanity_url_code = "cool"
        self.guild.vanity_uses = 10
        await self.prime_with(Invite(self.guild, "abc", 3, 77))
        self.guild.vanity_uses = 11
        await self.cog.on_member_join(self.guild.add_member(300))
        att = self.cog._joins[(self.guild.id, 300)]
        self.assertEqual((att.kind, att.inviter), (li.VANITY, None))

    async def test_no_diff_is_unknown_not_guilty(self):
        await self.prime_with(Invite(self.guild, "abc", 3, 77))
        await self.cog.on_member_join(self.guild.add_member(300))
        att = self.cog._joins[(self.guild.id, 300)]
        self.assertEqual((att.kind, att.inviter), (li.UNKNOWN, None))

    async def test_invites_unavailable(self):
        self.guild.invites_forbidden = True
        await self.cog.on_member_join(self.guild.add_member(300))
        self.assertEqual(self.cog._joins[(self.guild.id, 300)].kind, li.UNAVAILABLE)
        self.assertEqual(self.guild.id in self.cog._noperm, True)

    async def test_bot_join_skips_invite_lookup(self):
        await self.prime_with(Invite(self.guild, "abc", 3, 77))
        await self.cog.on_member_join(self.guild.add_member(301, bot=True))
        self.assertEqual(self.cog._joins[(self.guild.id, 301)].kind, li.BOT)

    async def test_restart_gap_is_reported_not_misattributed(self):
        inv = Invite(self.guild, "abc", 3, 77)
        await self.prime_with(inv)
        await self.flush()
        await self.cog.ledger.close()
        inv.uses = 6                                                      # 3 joins happened while the bot was offline
        self.cog = await self.new_cog()
        await self.cog._prime(self.guild)
        await self.flush()
        gap = self.events("offline_gap")
        self.assertEqual(len(gap), 1)
        self.assertIn("3", gap[0][6])
        await self.cog.on_member_join(self.guild.add_member(300))        # no fresh diff -> UNKNOWN, not 77
        self.assertEqual(self.cog._joins[(self.guild.id, 300)].inviter, None)


# ------------------------------------------------------------------ 4/6. X/Y + ban / alerts
class CrossVerify(Base):
    async def setUpFlow(self, creator, inviter, extra_receivers=0):
        """Role created by `creator`; member 300 joined through `inviter`'s invite and receives the role."""
        inv = Invite(self.guild, "abc", 0, inviter) if inviter else Invite(self.guild, "abc", 0, 55)
        self.guild._invites = [inv]
        await self.cog._prime(self.guild)
        inv.uses = 1
        m = self.guild.add_member(300)
        if inviter:
            await self.cog.on_member_join(m)
        else:
            inv.uses = 0
            await self.cog.on_member_join(m)                              # no diff -> unknown
        r = self.flagged_role()
        await self.create_linked(r, creator=creator)
        await self.receive(m, r)
        await self.flush()
        return r, m

    async def test_9_x_equals_y_bans_confirmed_inviter(self):
        await self.setUpFlow(creator=77, inviter=77)
        self.assertEqual([b[0] for b in self.bot.http.bans], [77])
        self.assertIn("X=Y", self.bot.http.bans[0][2])
        self.assertNotEqual(self.cog._state.get(self.guild.id), "locked")  # no lockdown when the culprit is known
        ban = self.events("ban")[0]
        self.assertIn("evidence", ban[6])                                 # reason + evidence + executor recorded
        self.assertIn("executor", ban[6])

    async def test_10_x_differs_from_y_alerts_no_ban(self):
        await self.setUpFlow(creator=77, inviter=88)
        self.assertEqual(self.bot.http.bans, [])
        self.assertNotEqual(self.cog._state.get(self.guild.id), "locked")
        self.assertEqual(self.events("cross_verify")[0][5], "MISMATCH")   # evidence preserved
        self.assertTrue(any("differ" in str(s.get("content", "")) for s in self.chan.sent))

    async def test_11_x_unavailable_y_available_no_ban(self):
        await self.setUpFlow(creator=None, inviter=88)
        self.assertEqual(self.bot.http.bans, [])
        self.assertNotEqual(self.cog._state.get(self.guild.id), "locked")
        self.assertEqual(self.events("cross_verify")[0][5], "X_MISSING")

    async def test_11b_y_unavailable_x_available_locks_down_never_bans(self):
        self.guild.add_role(9100, "mod", DANGER["admin"], 5)
        await self.setUpFlow(creator=77, inviter=None)
        self.assertEqual(self.bot.http.bans, [])
        self.assertEqual(self.cog._state.get(self.guild.id), "locked")
        self.assertEqual(self.events("cross_verify")[0][5], "Y_MISSING")

    async def test_12_both_unavailable_is_unknown_lockdown_no_ban(self):
        mod = self.guild.add_role(9100, "mod", DANGER["admin"] | SEND, 5)
        await self.setUpFlow(creator=None, inviter=None)
        self.assertEqual(self.events("cross_verify")[0][5], "UNKNOWN")
        self.assertEqual(self.bot.http.bans, [])                          # never guess a culprit
        self.assertEqual(self.cog._state.get(self.guild.id), "locked")
        self.assertEqual(mod.permissions.value, SEND)                     # only the dangerous bit removed

    async def test_below_threshold_no_lockdown(self):
        self.cog._cfg[self.guild.id] = (5, 600.0)
        await self.setUpFlow(creator=None, inviter=None)
        self.assertNotEqual(self.cog._state.get(self.guild.id), "locked")
        self.assertEqual(self.bot.http.bans, [])

    async def test_x_expired_after_one_hour_blocks_ban(self):
        inv = Invite(self.guild, "abc", 0, 77)
        self.guild._invites = [inv]
        await self.cog._prime(self.guild)
        inv.uses = 1
        m = self.guild.add_member(300)
        await self.cog.on_member_join(m)
        r = self.flagged_role()
        await self.create_linked(r, creator=77)
        self.clock.t += 3601
        await self.receive(m, r)
        self.assertEqual(self.bot.http.bans, [])

    async def test_confirmed_but_inviter_trusted_not_banned(self):
        self.cfg.wl[77] = store.ALL_MASK
        await self.setUpFlow(creator=77, inviter=77)
        self.assertEqual(self.bot.http.bans, [])

    async def test_normal_joins_never_trigger_anything(self):
        inv = Invite(self.guild, "abc", 0, 77)
        self.guild._invites = [inv]
        await self.cog._prime(self.guild)
        for i in range(10):
            inv.uses += 1
            await self.cog.on_member_join(self.guild.add_member(400 + i))
        self.assertEqual(self.bot.http.edits, [])
        self.assertEqual(self.bot.http.bans, [])
        self.assertIsNone(self.cog._state.get(self.guild.id))


# ------------------------------------------------------------------ 5/7. lockdown + recovery
class Lockdown(Base):
    def build(self):
        g = self.guild
        self.mod = g.add_role(9101, "mod", DANGER["admin"] | SEND, 5)
        self.helper = g.add_role(9102, "helper", DANGER["roles"] | DANGER["guild"] | KICK, 3)
        self.safe = g.add_role(9103, "safe", SEND, 2)
        self.trusted = g.add_role(9104, "trusted-admin", DANGER["admin"], 4)
        self.tbot = g.add_role(9105, "trusted-bot", DANGER["admin"], 6, bot_id=555)
        self.xbot = g.add_role(9106, "other-bot", DANGER["roles"], 6, bot_id=666)
        self.above = g.add_role(9107, "above", DANGER["admin"], 12)
        self.equal = g.add_role(9108, "equal", DANGER["admin"], 10)
        self.cfg.mainroles.add(9104)
        self.cfg.wl[555] = store.ALL_MASK
        self.cfg.barrier = 0

    async def test_selective_permissions_and_protection(self):           # scenarios 13, 14
        self.build()
        self.guild.everyone.permissions.value = SEND | DANGER["admin"]
        res = await self.cog.lockdown(self.guild, "test")
        self.assertEqual(res, "locked")
        self.assertEqual(self.mod.permissions.value, SEND)
        self.assertEqual(self.helper.permissions.value, KICK)             # every other bit preserved
        self.assertEqual(self.safe.permissions.value, SEND)
        self.assertEqual(self.guild.everyone.permissions.value, SEND)
        self.assertEqual(self.xbot.permissions.value, 0)                  # NON-trusted bot role is stripped
        for untouched, bits in ((self.trusted, DANGER["admin"]), (self.tbot, DANGER["admin"]),
                                (self.above, DANGER["admin"]), (self.equal, DANGER["admin"]),
                                (self.guild.me_role, DANGER["admin"])):
            self.assertEqual(untouched.permissions.value, bits, untouched.name)

    async def test_snapshot_saved_before_apply_and_never_overwritten(self):
        self.build()
        await self.cog.lockdown(self.guild, "one")
        await self.flush()
        c = sqlite3.connect(self.db)
        snap = {r[0]: r[1:] for r in c.execute("SELECT role_id, original, applied, stripped FROM li_snapshots")}
        self.assertEqual(snap[9101], (DANGER["admin"] | SEND, SEND, DANGER["admin"]))
        # second lockdown attempt while locked: refused; even a forced second snapshot must not overwrite
        self.assertEqual(await self.cog.lockdown(self.guild, "two"), "duplicate")
        self.cog.ledger.w_snapshots(self.guild.id, "x", [(9101, 123, 0, 0)], 0)
        again = c.execute("SELECT original FROM li_snapshots WHERE role_id=9101").fetchone()[0]
        c2 = sqlite3.connect(self.db)
        self.assertEqual(c2.execute("SELECT original FROM li_snapshots WHERE role_id=9101").fetchone()[0],
                         DANGER["admin"] | SEND)
        c.close(); c2.close()

    async def test_17_unlock_restores_only_what_it_changed(self):
        self.build()
        await self.cog.lockdown(self.guild, "t")
        self.safe.permissions.value = SEND | KICK                         # legit change made AFTER lockdown (not stripped)
        self.helper.permissions.value = KICK | (1 << 4)                   # edited by a human after the lockdown
        res = await self.cog.unlock(self.guild, actor=1)
        self.assertEqual(self.mod.permissions.value, DANGER["admin"] | SEND)       # unchanged role: fully restored
        self.assertEqual(self.helper.permissions.value, KICK | (1 << 4))           # edited role: NOT overwritten
        self.assertEqual(self.safe.permissions.value, SEND | KICK)                 # never snapshotted: untouched
        self.assertEqual([x["role"] for x in res["skipped_changed"]], [9102])
        self.assertEqual(self.cog._state[self.guild.id], "idle")
        self.assertEqual((await self.cog.unlock(self.guild))["status"], "not_locked")   # idempotent
        await self.flush()
        self.assertEqual(len(self.events("recovery_restored")), len(res["restored"]))
        self.assertEqual(len(self.events("recovery_skipped_changed")), 1)          # audit trail of every recovery step

    async def test_unlock_force_merges_stripped_bits_only(self):
        self.build()
        await self.cog.lockdown(self.guild, "t")
        self.helper.permissions.value = KICK | (1 << 4)
        await self.cog.unlock(self.guild, force=True, actor=1)
        self.assertEqual(self.helper.permissions.value, KICK | (1 << 4) | DANGER["roles"] | DANGER["guild"])

    async def test_16_restart_during_lockdown_resumes(self):
        self.build()
        # simulate a crash after the snapshot + first strip but before finishing: state 'applying'
        rows = [(r.id, r.permissions.value, li.strip_value(r.permissions.value), r.permissions.value & ALL3)
                for r in (self.mod, self.helper)]
        await self.cog.ledger.run(self.cog.ledger.w_lockdown, self.guild.id, "applying", "crash", 1.0, "L")
        await self.cog.ledger.run(self.cog.ledger.w_snapshots, self.guild.id, "L", rows, 1.0)
        self.mod.permissions.value = SEND                                  # first role already stripped
        await self.cog.ledger.close()
        self.cog = await self.new_cog()                                    # "restart"
        self.assertEqual(self.cog._state[self.guild.id], "applying")
        await self.cog._resume(self.guild, "applying")
        self.assertEqual(self.helper.permissions.value, KICK)              # remaining role finished
        self.assertEqual(self.cog._state[self.guild.id], "locked")
        self.assertEqual(await self.cog.lockdown(self.guild, "again"), "duplicate")   # not started twice
        res = await self.cog.unlock(self.guild)                            # originals survived the restart
        self.assertEqual(self.mod.permissions.value, DANGER["admin"] | SEND)
        self.assertEqual(self.helper.permissions.value, DANGER["roles"] | DANGER["guild"] | KICK)

    async def test_16b_restart_during_recovery_resumes(self):
        self.build()
        await self.cog.lockdown(self.guild, "t")
        await self.cog.ledger.run(self.cog.ledger.w_lockdown, self.guild.id, "restoring", "crash", 1.0, "")
        await self.cog.ledger.close()
        self.cog = await self.new_cog()
        await self.cog._resume(self.guild, "restoring")
        self.assertEqual(self.mod.permissions.value, DANGER["admin"] | SEND)
        self.assertEqual(self.cog._state[self.guild.id], "idle")

    async def test_failed_restore_keeps_row_for_retry(self):
        self.build()
        await self.cog.lockdown(self.guild, "t")
        self.bot.http.fail_edit = [exc(discord.Forbidden)]
        res = await self.cog.unlock(self.guild)
        self.assertEqual(res["status"], "partial")
        self.assertEqual(self.cog._state[self.guild.id], "locked")
        res2 = await self.cog.unlock(self.guild)
        self.assertEqual(res2["status"], "ok")

    async def test_18b_simultaneous_lockdowns_run_once(self):
        self.build()
        results = await asyncio.gather(*(self.cog.lockdown(self.guild, f"r{i}") for i in range(10)))
        self.assertEqual(results.count("locked"), 1)
        self.assertEqual(results.count("duplicate"), 9)
        self.assertEqual(self.cog.stats["lockdowns"], 1)

    async def test_15b_rate_limits_during_lockdown(self):
        self.build()
        self.bot.http.fail_edit = [exc(discord.HTTPException, 429, retry_after=0.01)] * 3
        await self.cog.lockdown(self.guild, "t")
        self.assertEqual(self.mod.permissions.value, SEND)
        self.assertEqual(self.helper.permissions.value, KICK)

    async def test_restore_wrongly_flagged_role(self):
        r = self.flagged_role(perms=ALL3 | SEND)
        await self.create_linked(r, creator=77)
        await self.flush()
        ok, _ = await self.cog.restore_role(self.guild, r.id, actor=1)
        self.assertTrue(ok)
        self.assertEqual(r.permissions.value, ALL3 | SEND)

    async def test_cross_guild_isolation(self):
        other = Guild(gid=2000)
        cfg_for(2000)
        self.bot.guilds.append(other)
        self.bot.http.guilds[2000] = other
        victim = other.add_role(3001, "victim", DANGER["admin"], 3)
        self.build()
        await self.cog.lockdown(self.guild, "t")
        self.assertEqual(victim.permissions.value, DANGER["admin"])
        self.assertNotIn(3001, self.cog._snap.get(self.guild.id, {}))


# ------------------------------------------------------------------ security / hygiene
class Security(Base):
    async def test_ban_never_blocks_stripping_and_unknown_never_banned(self):
        self.bot.http.fail_ban = [exc(discord.HTTPException, 500)]
        self.build_confirmed = True
        inv = Invite(self.guild, "abc", 0, 77)
        self.guild._invites = [inv]
        await self.cog._prime(self.guild)
        inv.uses = 1
        m = self.guild.add_member(300)
        await self.cog.on_member_join(m)
        r = self.flagged_role()
        await self.create_linked(r, creator=77)
        self.assertEqual(r.permissions.value, SEND)                      # stripped before any receipt/ban logic
        await self.receive(m, r)
        await self.flush()
        self.assertEqual([b[0] for b in self.bot.http.bans], [77])       # retried after the 500

    async def test_ban_hierarchy_respected(self):
        high = self.guild.add_role(9500, "highmod", SEND, 11)
        self.guild.add_member(77, [high])
        inv = Invite(self.guild, "abc", 0, 77)
        self.guild._invites = [inv]
        await self.cog._prime(self.guild)
        inv.uses = 1
        m = self.guild.add_member(300)
        await self.cog.on_member_join(m)
        r = self.flagged_role()
        await self.create_linked(r, creator=77)
        await self.receive(m, r)
        await self.flush()
        self.assertEqual(self.bot.http.bans, [])
        self.assertEqual(len(self.events("ban_skipped_hierarchy")), 1)

    async def test_no_secrets_in_logs_or_db(self):
        token = "MTIzNDU2Nzg5MDEyMzQ1Njc4.G1abcd.abcdefghijklmnopqrstuvwxyz0123456"
        os.environ["TOKEN"] = token
        try:
            with self.assertLogs("deathbot.linkinvite", level="INFO") as cm:
                self.cog._emit("probe", self.guild.id, note=f"leak {token}", token=token)
            await self.flush()
        finally:
            del os.environ["TOKEN"]
        self.assertNotIn(token, "\n".join(cm.output))
        stored = " ".join(str(r) for r in self.events("probe"))
        self.assertNotIn(token, stored)

    async def test_invalid_ids_rejected(self):
        self.cog.note_role_audit(types.SimpleNamespace(target=types.SimpleNamespace(id=-1), user_id=0, guild=self.guild))
        self.assertEqual(self.cog._hint, {})
        self.cog._record_join(self.guild.id, -5, li.Attribution(li.NORMAL, 1))
        self.assertEqual(self.cog._joins, {})

    async def test_disabled_antinuke_guild_is_inert(self):
        self.cfg.enabled = False
        r = self.flagged_role()
        await self.create_linked(r, creator=77)
        self.assertEqual(self.bot.http.edits, [])
        self.assertEqual(await self.cog.lockdown(self.guild, "x"), "disabled")


class EngineContract(unittest.TestCase):
    """The engine hooks must exist, stay tiny and not add listeners."""

    def setUp(self):
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.src = _read(os.path.join(root, "cogs", "antinuke", "engine.py"))
        self.init = _read(os.path.join(root, "cogs", "__init__.py"))

    def test_hooks_present(self):
        for call in ("li.linked_role_created(role)", "li.member_roles_changed(before, after)", "li.note_role_audit(entry)"):
            self.assertIn(call, self.src)
        self.assertEqual(self.src.count('get_cog("LinkInvite")'), 3)

    def test_no_new_listeners_in_engine(self):
        self.assertEqual(self.src.count("@commands.Cog.listener()"), 10)  # same count as V43

    def test_linkinvite_has_no_duplicate_listeners(self):
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        mod = _read(os.path.join(root, "cogs", "antinuke", "linkinvite.py"))
        for dup in ("on_guild_role_create", "on_member_update", "on_audit_log_entry_create"):
            self.assertNotIn(f"def {dup}", mod)

    def test_cog_registered(self):
        self.assertIn("from .antinuke.linkinvite import LinkInvite", self.init)
        self.assertIn("AntinukeEngine, LinkInvite,", self.init)


if __name__ == "__main__":
    unittest.main()
