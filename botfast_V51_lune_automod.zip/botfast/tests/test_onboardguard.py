"""Tests for cogs/antinuke/onboardguard.py  (run: python -m unittest discover -s tests -v)

Doubles only: NOT verified against real Discord.  They cover authorization, executor verification (never punish on a guess),
duplicate suppression, honest step statuses (success is claimed only after a re-read), lockdown on failure, retries,
configuration sanitising and the help page."""
import asyncio
import copy
import importlib.util
import os
import sys
import tempfile
import types
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _compat  # noqa: F401,E402
import discord  # noqa: E402
from fakes import exc  # noqa: E402
from utils import antinuke_store as store  # noqa: E402


def _load(name, rel):
    spec = importlib.util.spec_from_file_location(name, os.path.join(_compat.ROOT, *rel))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


bgm = _load("botguard_for_ob_tests", ("cogs", "antinuke", "botguard.py"))
ob = _load("onboardguard_under_test", ("cogs", "antinuke", "onboardguard.py"))

ADMIN, MROLES, BAN, KICK, AUDIT, SEND, MGUILD = 1 << 3, 1 << 28, 1 << 2, 1 << 1, 1 << 7, 1 << 11, 1 << 5
OWNER, BOT, EXTRA, TRUST, ATTACKER, OTHER, JOINER = 1, 100, 7, 8, 50, 51, 60
NOW = 1_790_000_000.0
GID = 1000


def sf(ts, n=0):
    """A snowflake whose embedded timestamp is ts."""
    return ((int(ts * 1000) - ob.DISCORD_EPOCH_MS) << 22) | n


class Perm:
    def __init__(self, v): self.value = v
    @property
    def administrator(self): return bool(self.value & ADMIN)
    @property
    def manage_roles(self): return bool(self.value & MROLES)
    @property
    def manage_guild(self): return bool(self.value & MGUILD)
    @property
    def view_audit_log(self): return bool(self.value & AUDIT)
    @property
    def ban_members(self): return bool(self.value & BAN)


class Role:
    def __init__(self, guild, rid, name, perms, pos, managed=False):
        self.guild, self.id, self.name, self.position, self.managed = guild, rid, name, pos, managed
        self.permissions = Perm(perms)
    def is_default(self): return self.id == self.guild.id
    @property
    def members(self): return [m for m in self.guild.members.values() if self in m.roles]
    async def delete(self, reason=None):
        self.guild.calls.append(("role.delete", self.id))
        if self.guild.delete_exc:
            raise self.guild.delete_exc
        if self.guild.delete_noop:
            return
        self.guild.roles.remove(self)
        for m in self.guild.members.values():
            if self in m.roles:
                m.roles.remove(self)
    async def edit(self, permissions=None, reason=None, **kw):
        self.guild.calls.append(("role.edit", self.id, permissions.value))
        if self.guild.edit_exc:
            raise self.guild.edit_exc
        self.permissions = Perm(permissions.value)
    __lt__ = lambda s, o: s.position < o.position  # noqa: E731
    __gt__ = lambda s, o: s.position > o.position  # noqa: E731


class Member:
    def __init__(self, guild, uid, roles=(), bot=False):
        self.guild, self.id, self.bot = guild, uid, bot
        self.roles = [guild.everyone, *roles]
    @property
    def top_role(self): return max(self.roles, key=lambda r: r.position)
    @property
    def guild_permissions(self):
        v = 0
        for r in self.roles:
            v |= r.permissions.value
        return Perm(v)
    async def add_roles(self, *roles, reason=None, atomic=True):
        self.guild.calls.append(("add_roles", self.id, [r.id for r in roles]))
        self.roles += [r for r in roles if r not in self.roles]

    async def remove_roles(self, *roles, reason=None, atomic=True):
        self.guild.calls.append(("remove_roles", self.id, [r.id for r in roles]))
        if self.guild.rr_exc:
            raise self.guild.rr_exc
        if self.guild.rr_noop:
            return
        self.roles = [r for r in self.roles if r.id not in [x.id for x in roles]]


class Guild:
    def __init__(self):
        self.id, self.owner_id, self.name, self.chunked = GID, OWNER, "G", True
        self.calls, self.banned, self.channels, self.members = [], set(), {}, {}
        self.delete_exc = self.edit_exc = self.rr_exc = self.ban_exc = None
        self.delete_noop = self.rr_noop = False
        self.everyone = Role(self, GID, "@everyone", SEND, 0)
        self.roles = [self.everyone]
        self.botrole = self.add_role(5, "BotRole", ADMIN | MROLES | BAN | AUDIT, 100, managed=True)
        self.me = Member(self, BOT, [self.botrole], bot=True)
        self.members[BOT] = self.me
    def add_role(self, rid, name, perms, pos, **kw):
        r = Role(self, rid, name, perms, pos, **kw)
        self.roles.append(r)
        return r
    def add_member(self, uid, roles=()):
        m = self.members[uid] = Member(self, uid, roles)
        return m
    def get_role(self, rid): return next((r for r in self.roles if r.id == rid), None)
    def get_member(self, uid): return self.members.get(uid)
    def get_channel(self, cid): return self.channels.get(cid)
    async def fetch_member(self, uid):
        if uid not in self.members:
            raise exc(discord.NotFound, 404)
        return self.members[uid]
    async def fetch_roles(self): return list(self.roles)
    async def ban(self, obj, reason=None, delete_message_seconds=0):
        self.calls.append(("ban", obj.id))
        if self.ban_exc:
            raise self.ban_exc
        self.banned.add(obj.id)
    async def fetch_ban(self, obj):
        if obj.id not in self.banned:
            raise exc(discord.NotFound, 404)


class Chan:
    def __init__(self): self.sent = []
    async def send(self, **kw): self.sent.append(kw)


class User:
    def __init__(self): self.sent = []
    async def send(self, **kw): self.sent.append(kw)


class Http:
    def __init__(self): self.entries, self.exc, self.calls = [], None, 0
    async def get_audit_logs(self, gid, limit=25, **kw):
        self.calls += 1
        if self.exc:
            raise self.exc
        return {"audit_log_entries": list(self.entries)}


class Emergency:
    def __init__(self, n=3): self.n, self.calls, self.auto_guilds = n, 0, set()
    async def _lockdown(self, guild):
        self.calls += 1
        return self.n


class Bot:
    def __init__(self, guild):
        self.user, self.guilds, self.cogs, self.http = types.SimpleNamespace(id=BOT), [guild], {}, Http()
        self.owner_user = User()
    def get_cog(self, n): return self.cogs.get(n)
    def get_user(self, uid): return None
    async def fetch_user(self, uid): return self.owner_user
    def get_guild(self, gid): return self.guilds[0] if gid == GID else None
    async def wait_until_ready(self): return None


class Api:
    """Fake onboarding endpoint: GET returns the config, PUT replaces it."""
    def __init__(self, config):
        self.config, self.calls, self.get_exc, self.put_exc, self.put_noop, self.puts = config, [], None, None, False, []
    async def __call__(self, method, gid, suffix, *, json_body=None, reason=None):
        self.calls.append(method)
        if method == "GET":
            if self.get_exc:
                raise self.get_exc
            return copy.deepcopy(self.config)
        if self.put_exc:
            raise self.put_exc
        self.puts.append(copy.deepcopy(json_body))
        if not self.put_noop:
            self.config = copy.deepcopy(json_body)


def onboarding(*option_roles, channels=("c1",)):
    """One prompt, one option per entry of option_roles (each a list of role ids)."""
    return {"guild_id": str(GID), "enabled": True, "mode": 0, "default_channel_ids": ["d1"],
            "prompts": [{"id": "p1", "title": "Pick", "single_select": False, "required": False, "in_onboarding": True, "type": 0,
                         "options": [{"id": f"o{i}", "title": f"opt{i}", "description": None, "role_ids": [str(r) for r in roles],
                                      "channel_ids": list(channels), "emoji": {"id": None, "name": "x", "animated": False}}
                                     for i, roles in enumerate(option_roles)]}]}


def raw(action, eid, uid, **extra):
    return {"action_type": action, "guild_id": str(GID), "id": str(eid), "user_id": str(uid), **extra}


class PureTests(unittest.TestCase):
    def test_tiers(self):
        self.assertEqual(ob.danger_tier(ADMIN | SEND), 2)
        self.assertEqual(ob.danger_tier(MROLES), 1)
        self.assertEqual(ob.danger_tier(SEND), 0)
        self.assertEqual(ob.danger_tier(0), 0)

    def test_role_ids_tolerates_garbage(self):
        cfg = {"prompts": [{"options": [{"role_ids": ["5", 6, None, "x", True, -1]}, "junk", {"role_ids": None}]}, "junk", None]}
        self.assertEqual(ob.role_ids_in(cfg), {5, 6})
        self.assertEqual(ob.role_ids_in(None), set())
        self.assertEqual(ob.role_ids_in({}), set())

    def test_sanitize_removes_only_the_role_and_converts_emoji(self):
        cfg = onboarding([10, 11], [12])
        before = copy.deepcopy(cfg)
        payload, removed = ob.sanitize_config(cfg, {10})
        self.assertEqual(cfg, before)                                   # input untouched
        opts = payload["prompts"][0]["options"]
        self.assertEqual(opts[0]["role_ids"], ["11"])
        self.assertEqual(opts[1]["role_ids"], ["12"])
        self.assertEqual(opts[0]["id"], "o0")
        self.assertEqual((opts[0]["emoji_name"], opts[0]["emoji_animated"]), ("x", False))
        self.assertNotIn("emoji", opts[0])
        self.assertEqual(payload["default_channel_ids"], ["d1"])
        self.assertTrue(payload["enabled"])
        self.assertEqual(removed, [{"prompt": "Pick", "option": "opt0", "role_id": 10, "dropped_option": False}])

    def test_sanitize_drops_empty_option_then_empty_prompt(self):
        cfg = onboarding([10], channels=())
        payload, removed = ob.sanitize_config(cfg, {10})
        self.assertEqual(payload["prompts"], [])
        self.assertTrue(any(r.get("dropped_option") for r in removed))
        self.assertTrue(any(r.get("dropped_prompt") for r in removed))
        keep, _ = ob.sanitize_config(onboarding([10], channels=("c",)), {10})   # still has a channel: kept
        self.assertEqual(keep["prompts"][0]["options"][0]["role_ids"], [])

    def test_sanitize_noop(self):
        _, removed = ob.sanitize_config(onboarding([10]), {99})
        self.assertEqual(removed, [])

    def test_pick_executor_never_guesses(self):
        self.assertEqual(ob.pick_executor([(1, 5, 100.0, 164)], 90.0), ("verified", [5]))
        self.assertEqual(ob.pick_executor([(1, 5, 100.0, 164), (2, 5, 101.0, 165)], 90.0), ("verified", [5]))
        self.assertEqual(ob.pick_executor([(1, 5, 100.0, 164), (2, 6, 101.0, 165)], 90.0)[0], "ambiguous")
        self.assertEqual(ob.pick_executor([], 90.0)[0], "none")
        self.assertEqual(ob.pick_executor([(1, 5, 50.0, 164)], 90.0)[0], "none")           # too old
        self.assertEqual(ob.pick_executor([(1, None, 100.0, 164)], 90.0)[0], "none")      # no user id

    def test_entry_mentions_role(self):
        self.assertTrue(ob.entry_mentions_role({"changes": [{"key": "options", "new_value": [{"role_ids": ["123456789012345678"]}]}]}, 123456789012345678))
        self.assertFalse(ob.entry_mentions_role({"changes": [{"key": "title"}]}, 123456789012345678))
        self.assertFalse(ob.entry_mentions_role({"changes": object()}, 5))

    def test_snowflake_roundtrip(self):
        self.assertAlmostEqual(ob.snowflake_ts(sf(NOW)), NOW, places=2)

    def test_help_page(self):
        page = ob.help_text("?", {"onboarding": True, "trusted_count": 2})
        self.assertEqual(len(page), 1)
        for needle in ("ANTI-ONBOARDING ON", "?antinuke onboarding on", "?antinuke onboarding off", "?antinuke onboarding status",
                       "?antinuke onboarding scan", "?antinuke onboarding clean", "?antinuke onboarding trust add <user>",
                       "?antinuke onboarding trust list", "2 trusted", "Emergency Lockdown"):
            self.assertIn(needle, page[0])
        self.assertIn("OFF", ob.help_text("?", {"onboarding": False})[0].split("\n")[0])

    def test_render_has_all_log_fields(self):
        inc = ob.OnbIncident("assigned", GID, executor_id=50, executor_class="untrusted", member_id=60, role_id=77, role_name="Boss",
                             perms=ADMIN | MROLES, trigger="t", exec_via="gateway audit entry")
        inc.add("Remove from member", "ok", "done")
        inc.ms = 12.0
        text = ob.render_onb(inc, "H", now=NOW)
        for needle in ("<@50>", "`50`", "<@60>", "<@&77>", "`77`", "Administrator", "Manage Roles", f"`{ADMIN | MROLES}`", "Remove from member", f"<t:{int(NOW)}:T>"):
            self.assertIn(needle, text)


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.g = Guild()
        self.bot = Bot(self.g)
        self.chan = Chan()
        self.g.channels[999] = self.chan
        self.emg = Emergency()
        self.bot.cogs["Emergency"] = self.emg
        store._cfg[GID] = store.GuildCfg(enabled=True, autorec=True, log=999)
        self.sleeps = []

        async def fake_sleep(d): self.sleeps.append(d)
        self.cog = ob.OnboardGuard(self.bot, db_path=os.path.join(self.tmp.name, "ob.db"), clock=lambda: NOW, sleep=fake_sleep,
                                   global_extra=frozenset({EXTRA}))
        await self.cog.ledger.open()
        self.cog.flags[GID] = True
        self.cog.hint_wait = 0.01                          # tests: do not really wait for a gateway entry that never comes
        self.api = Api(onboarding([5001]))                 # onboarding hands out one harmless role
        self.cog._api = self.api
        self.safe = self.g.add_role(5001, "Gamer", SEND, 10)
        self.admin_role = self.g.add_role(6001, "Boss", ADMIN, 20)
        self.g.add_member(ATTACKER)
        self.g.add_member(OTHER)
        self.joiner = self.g.add_member(JOINER, [self.safe])
        self.cog.cfg_roles[GID] = frozenset({5001})        # baseline taken
        self.eid = 0

    async def asyncTearDown(self):
        await self.drain()
        await self.cog.ledger.close()
        store._cfg.clear()
        self.tmp.cleanup()

    async def drain(self):
        for _ in range(8):
            if self.cog._bg:
                await asyncio.gather(*list(self.cog._bg), return_exceptions=True)
            await asyncio.sleep(0)

    def nid(self):
        self.eid += 1
        return sf(NOW - 1, self.eid)

    def ops(self, name): return [c for c in self.g.calls if c[0] == name]
    def card_text(self): return "\n".join(c.get("content", "") for c in self.chan.sent)
    def step(self, name):
        for c in self.chan.sent:
            for line in c.get("content", "").splitlines():
                if f"**" in line and f" {name}**" in line:
                    return line
        return ""

    async def add_dangerous_to_config(self, rid=6001):
        """Someone adds role rid to onboarding: the API now returns it, and the gateway hint arrives."""
        self.api.config = onboarding([5001], [rid])
        self.cog._raw_audit(raw(164, self.nid(), ATTACKER))
        await self.drain()


class ConfigFlow(Base):
    async def test_unauthorized_admin_role_is_cleaned_deleted_and_executor_banned(self):
        await self.add_dangerous_to_config()
        self.assertEqual(self.ops("ban"), [("ban", ATTACKER)])
        self.assertEqual(self.ops("role.delete"), [("role.delete", 6001)])
        self.assertIsNone(self.g.get_role(6001))
        self.assertNotIn(6001, ob.role_ids_in(self.api.config))        # confirmed by re-read
        self.assertEqual(self.api.puts[0]["prompts"][0]["options"][0]["role_ids"], ["5001"])
        text = self.card_text()
        for needle in ("<@50>", "Administrator", "`6001`", "Clean onboarding", "Ban executor", "Delete role"):
            self.assertIn(needle, text)
        self.assertEqual(self.emg.calls, 0)
        self.assertEqual(self.bot.owner_user.sent[0]["content"].count("Security Log"), 1)   # owner DM'd

    async def test_owner_extra_owner_and_trusted_are_exempt(self):
        await self.cog.add_trusted(self.g, TRUST, OWNER)
        for uid in (OWNER, EXTRA, TRUST):
            self.cog._claims.clear()
            self.cog.cfg_roles[GID] = frozenset({5001})
            self.api.config = onboarding([5001], [6001])
            self.cog._raw_audit(raw(164, self.nid(), uid))
            await self.drain()
        self.assertEqual(self.g.calls, [])
        self.assertEqual(self.chan.sent, [])
        self.assertEqual(self.api.puts, [])

    async def test_two_different_people_is_ambiguous_nobody_punished(self):
        self.api.config = onboarding([5001], [6001])
        self.cog._raw_audit(raw(164, self.nid(), ATTACKER))
        self.cog._note_cfg_entry(GID, self.nid(), OTHER, 164)
        await self.drain()
        self.assertEqual(self.ops("ban"), [])
        self.assertEqual(self.ops("role.delete"), [])
        self.assertEqual(len(self.api.puts), 1)                       # config is still cleaned (protective, Administrator)
        self.assertIn("unverified", self.step("Verify executor"))

    async def test_no_audit_entry_anywhere_means_no_punishment(self):
        self.api.config = onboarding([5001], [6001])
        self.cog._kick_cfg_check(self.g, "poll")
        await self.drain()
        self.assertEqual(self.ops("ban"), [])
        self.assertEqual(self.ops("role.delete"), [])
        self.assertEqual(len(self.api.puts), 1)
        self.assertGreaterEqual(self.bot.http.calls, 1)               # the REST fallback was tried

    async def test_rest_fallback_verifies_a_single_recent_entry(self):
        self.bot.http.entries = [{"id": str(sf(NOW - 2, 1)), "user_id": str(ATTACKER), "action_type": 164}]
        self.api.config = onboarding([5001], [6001])
        self.cog._kick_cfg_check(self.g, "poll")
        await self.drain()
        self.assertEqual(self.ops("ban"), [("ban", ATTACKER)])

    async def test_stale_rest_entry_is_not_blamed(self):
        self.bot.http.entries = [{"id": str(sf(NOW - 3600, 1)), "user_id": str(ATTACKER), "action_type": 164}]
        self.api.config = onboarding([5001], [6001])
        self.cog._kick_cfg_check(self.g, "poll")
        await self.drain()
        self.assertEqual(self.ops("ban"), [])

    async def test_audit_log_forbidden_is_reported_not_guessed(self):
        self.bot.http.exc = exc(discord.Forbidden, 403)
        self.api.config = onboarding([5001], [6001])
        self.cog._kick_cfg_check(self.g, "poll")
        await self.drain()
        self.assertEqual(self.ops("ban"), [])
        self.assertIn("no onboarding audit entry found", self.card_text())

    async def test_role_with_existing_holders_is_never_deleted_but_executor_is_banned(self):
        self.g.add_member(OTHER, [self.admin_role])                  # a legitimate admin already holds it
        await self.add_dangerous_to_config()
        self.assertEqual(self.ops("role.delete"), [])
        self.assertEqual(self.ops("ban"), [("ban", ATTACKER)])
        self.assertIn("demote", self.card_text())
        self.assertEqual(len(self.api.puts), 1)

    async def test_protected_roles_are_never_deleted(self):
        store._cfg[GID].mainroles.add(6001)
        await self.add_dangerous_to_config()
        self.assertEqual(self.ops("role.delete"), [])
        self.assertIn("protected antinuke role", self.card_text())
        self.g.roles.append(self.admin_role) if self.admin_role not in self.g.roles else None
        ok, why = self.cog.delete_check(self.g, self.g.botrole)
        self.assertFalse(ok)
        self.assertIn("managed", why)
        self.assertFalse(self.cog.delete_check(self.g, self.g.everyone)[0])
        self.g.chunked = False
        self.assertIn("cache", self.cog.delete_check(self.g, self.safe)[1])

    async def test_other_dangerous_permissions_are_cleaned_but_never_banned(self):
        mod = self.g.add_role(6002, "Mod", MROLES, 20)
        self.api.config = onboarding([5001], [6002])
        self.cog._raw_audit(raw(164, self.nid(), ATTACKER))
        await self.drain()
        self.assertEqual(self.ops("ban"), [])
        self.assertEqual(self.ops("role.delete"), [])
        self.assertEqual(len(self.api.puts), 1)                       # verified unauthorized -> cleaned
        self.assertIsNotNone(self.g.get_role(6002))

    async def test_other_dangerous_permissions_with_unverified_executor_is_alert_only(self):
        self.g.add_role(6002, "Mod", MROLES, 20)
        self.api.config = onboarding([5001], [6002])
        self.cog._kick_cfg_check(self.g, "poll")
        await self.drain()
        self.assertEqual(self.api.puts, [])
        self.assertEqual(self.g.calls, [])
        self.assertIn("alert only", self.card_text())

    async def test_harmless_role_added_is_ignored(self):
        self.g.add_role(5002, "Colour", SEND, 11)
        self.api.config = onboarding([5001], [5002])
        self.cog._raw_audit(raw(164, self.nid(), ATTACKER))
        await self.drain()
        self.assertEqual(self.g.calls, [])
        self.assertEqual(self.chan.sent, [])

    async def test_first_look_is_a_baseline_report_and_changes_nothing(self):
        self.cog.cfg_roles.pop(GID)
        self.api.config = onboarding([5001], [6001])
        self.cog._kick_cfg_check(self.g, "startup")
        await self.drain()
        self.assertEqual(self.g.calls, [])
        self.assertEqual(self.api.puts, [])
        self.assertIn("already configured", self.card_text())
        self.assertIn(6001, self.cog.cfg_roles[GID])                  # now watched: assignments are still guarded

    async def test_unreadable_onboarding_is_reported_once(self):
        self.api.get_exc = exc(discord.Forbidden, 403)
        for _ in range(3):
            self.cog._kick_cfg_check(self.g, "poll")
            await self.drain()
        self.assertEqual(self.card_text().count("Cannot read the onboarding configuration"), 1)

    async def test_disabled_guild_is_ignored(self):
        self.cog.flags[GID] = False
        self.api.config = onboarding([5001], [6001])
        self.cog._raw_audit(raw(164, self.nid(), ATTACKER))
        await self.drain()
        self.assertEqual(self.g.calls, [])
        store._cfg[GID].enabled = False
        self.cog.flags[GID] = True
        self.cog._raw_audit(raw(164, self.nid(), ATTACKER))
        await self.drain()
        self.assertEqual(self.g.calls, [])

    async def test_burst_of_audit_entries_is_one_incident(self):
        self.api.config = onboarding([5001], [6001])
        for _ in range(5):
            self.cog._raw_audit(raw(164, self.nid(), ATTACKER))
        await self.drain()
        self.assertEqual(len(self.ops("ban")), 1)
        self.assertEqual(len(self.ops("role.delete")), 1)

    async def test_two_roles_added_at_once_are_both_removed_despite_config_reuse(self):
        self.g.add_role(6003, "Boss2", ADMIN, 21)
        self.api.config = onboarding([5001], [6001], [6003])
        self.cog._raw_audit(raw(164, self.nid(), ATTACKER))
        await self.drain()
        left = ob.role_ids_in(self.api.config)
        self.assertNotIn(6001, left)
        self.assertNotIn(6003, left)                                   # the 2nd clean must not re-add the 1st role from a stale read
        self.assertIn(5001, left)

    async def test_ban_time_is_measured_at_acceptance(self):
        await self.add_dangerous_to_config()
        self.assertIn("punishment sent in", self.card_text())

    async def test_config_is_rechecked_after_the_incident(self):
        await self.add_dangerous_to_config()
        gets = self.api.calls.count("GET")
        self.assertGreaterEqual(gets, 3)                              # check, confirm after PUT, post-incident recheck


class AssignmentFlow(Base):
    async def assign(self, via_raw=True, role=None):
        role = role or self.admin_role
        self.cog.cfg_roles[GID] = frozenset({5001, role.id})
        self.api.config = onboarding([5001], [role.id])
        old = {r.id for r in self.joiner.roles}
        if via_raw:
            data = {"guild_id": str(GID), "user": {"id": str(JOINER)}, "roles": [str(r) for r in (*old, role.id)]}
            self.cog._raw_member(data)                                 # before discord.py applies it: cache has the old roles
            self.joiner.roles.append(role)
        else:
            before = types.SimpleNamespace(roles=list(self.joiner.roles), guild=self.g, id=JOINER)
            self.joiner.roles.append(role)
            await self.cog.on_member_update(before, self.joiner)
        await self.drain()

    async def test_assignment_with_known_unauthorized_configurer(self):
        self.cog._blame[(GID, 6001)] = (ATTACKER, "untrusted", NOW)
        await self.assign()
        self.assertNotIn(self.admin_role, self.joiner.roles)
        self.assertIsNone(self.g.get_role(6001))
        self.assertEqual(self.ops("ban"), [("ban", ATTACKER)])
        self.assertNotIn(JOINER, self.g.banned)                       # the affected member is NEVER punished
        self.assertIn(self.safe, self.joiner.roles)                   # and keeps every other role
        text = self.card_text()
        for needle in ("<@60>", "never punished", "<@&6001>", "Administrator", "Remove from member"):
            self.assertIn(needle, text)

    async def test_assignment_with_unverified_configurer_only_removes_and_cleans(self):
        await self.assign()
        self.assertNotIn(self.admin_role, self.joiner.roles)
        self.assertEqual(self.ops("ban"), [])
        self.assertEqual(self.ops("role.delete"), [])
        self.assertIsNotNone(self.g.get_role(6001))
        self.assertEqual(len(self.api.puts), 1)
        self.assertIn("unverified", self.step("Verify executor"))
        self.assertIn("only deleted when its configurer is verified unauthorized", self.card_text())

    async def test_assignment_blamed_via_rest_entry_that_names_the_role(self):
        self.bot.http.entries = [{"id": str(sf(NOW - 30, 1)), "user_id": str(ATTACKER), "action_type": 164,
                                  "changes": [{"key": "options", "new_value": [{"role_ids": ["6001"]}]}]}]
        await self.assign()
        self.assertEqual(self.ops("ban"), [("ban", ATTACKER)])

    async def test_rest_entry_not_naming_the_role_is_not_blamed(self):
        self.bot.http.entries = [{"id": str(sf(NOW - 30, 1)), "user_id": str(ATTACKER), "action_type": 164, "changes": [{"key": "title"}]}]
        await self.assign()
        self.assertEqual(self.ops("ban"), [])

    async def test_two_people_named_in_rest_entries_is_ambiguous(self):
        self.bot.http.entries = [{"id": str(sf(NOW - 30, i)), "user_id": str(u), "action_type": 164, "changes": [{"v": "6001"}]}
                                 for i, u in enumerate((ATTACKER, OTHER), 1)]
        await self.assign()
        self.assertEqual(self.ops("ban"), [])

    async def test_authorized_configurer_means_allowed(self):
        self.cog._blame[(GID, 6001)] = (OWNER, "owner", NOW)
        await self.assign()
        self.assertIn(self.admin_role, self.joiner.roles)
        self.assertEqual(self.g.calls, [])
        self.assertEqual(self.chan.sent, [])

    async def test_role_is_removed_before_the_slow_audit_lookup_finishes(self):
        order = []
        orig_rest = self.cog._audit_rest
        async def slow_rest(guild):
            order.append("lookup-start")
            await asyncio.sleep(0)
            order.append("lookup-end")
            return await orig_rest(guild)
        self.cog._audit_rest = slow_rest
        orig_remove = self.g.me.guild.members[JOINER].remove_roles
        async def spy(*a, **k):
            order.append("remove")
            return await orig_remove(*a, **k)
        self.joiner.remove_roles = spy
        await self.assign()
        self.assertLess(order.index("remove"), order.index("lookup-end"))   # protection did not wait for attribution
        self.assertNotIn(self.admin_role, self.joiner.roles)

    async def test_role_is_given_back_if_the_lookup_shows_an_exempt_configurer(self):
        self.bot.http.entries = [{"id": str(sf(NOW - 30, 1)), "user_id": str(OWNER), "action_type": 164,
                                  "changes": [{"key": "options", "new_value": [{"role_ids": ["6001"]}]}]}]
        await self.assign()
        self.assertIn(self.admin_role, self.joiner.roles)
        self.assertEqual(self.ops("ban"), [])
        self.assertEqual(len(self.ops("add_roles")), 1)

    async def test_affected_member_who_is_owner_keeps_the_role(self):
        self.g.owner_id = JOINER
        self.cog._blame[(GID, 6001)] = (ATTACKER, "untrusted", NOW)
        await self.assign()
        self.assertEqual(self.ops("remove_roles"), [])                 # the exempt member is not edited ...
        self.assertNotIn(JOINER, self.g.banned)                        # ... and never punished
        self.assertEqual(self.ops("ban"), [("ban", ATTACKER)])         # (the attacker's role itself is still deleted)
        self.assertIn("exempt", self.card_text())

    async def test_duplicate_events_raw_plus_listener_are_one_incident(self):
        self.cog._blame[(GID, 6001)] = (ATTACKER, "untrusted", NOW)
        self.cog.cfg_roles[GID] = frozenset({5001, 6001})
        self.api.config = onboarding([5001], [6001])
        data = {"guild_id": str(GID), "user": {"id": str(JOINER)}, "roles": ["5001", "6001"]}
        before = types.SimpleNamespace(roles=list(self.joiner.roles), guild=self.g, id=JOINER)
        self.cog._raw_member(data)
        self.joiner.roles.append(self.admin_role)
        await self.cog.on_member_update(before, self.joiner)          # the same event arriving through the normal listener
        await self.drain()
        self.assertEqual(len(self.ops("ban")), 1)
        self.assertEqual(len(self.ops("role.delete")), 1)
        self.assertEqual(len([c for c in self.chan.sent if "Security Log" in c.get("content", "")]), 1)

    async def test_many_joiners_get_role_removed_but_role_level_work_happens_once(self):
        self.cog._blame[(GID, 6001)] = (ATTACKER, "untrusted", NOW)
        for uid in (61, 62, 63):                                       # all three received the role in the same instant
            self.g.add_member(uid, [self.admin_role])
            self.cog._claim((GID, "assign", uid, 6001), 5.0)
            self.cog._note_affected(GID, 6001, uid)                    # what the detection hooks do synchronously
        for uid in (61, 62, 63):
            self.cog._spawn(self.cog._assigned(self.g, uid, 6001))
        await self.drain()
        self.assertEqual(len(self.ops("remove_roles")), 3)
        self.assertEqual(len(self.ops("ban")), 1)
        self.assertEqual(len(self.ops("role.delete")), 1)              # burst members were AFFECTED, not established holders
        self.assertTrue(all(JOINER != b and b not in (61, 62, 63) for b in self.g.banned))

    async def test_raw_hook_ignores_members_that_already_had_the_role(self):
        self.cog.cfg_roles[GID] = frozenset({6001})
        self.joiner.roles.append(self.admin_role)
        self.cog._raw_member({"guild_id": str(GID), "user": {"id": str(JOINER)}, "roles": ["5001", "6001"]})   # e.g. nickname change
        await self.drain()
        self.assertEqual(self.g.calls, [])

    async def test_harmless_role_assignment_is_ignored(self):
        await self.assign(role=self.safe)
        self.assertEqual(self.g.calls, [])

    async def test_listener_fallback_also_works_without_the_raw_hook(self):
        self.cog._blame[(GID, 6001)] = (ATTACKER, "untrusted", NOW)
        await self.assign(via_raw=False)
        self.assertEqual(self.ops("ban"), [("ban", ATTACKER)])


class HonestyAndFailure(Base):
    async def test_deletion_claimed_ok_only_after_reread(self):
        self.g.delete_noop = True                                      # Discord "accepts" but the role is still there
        self.cog._blame[(GID, 6001)] = (ATTACKER, "untrusted", NOW)
        self.cog.cfg_roles[GID] = frozenset({5001, 6001})
        self.g.add_member(61, [self.admin_role])
        self.api.config = onboarding([5001], [6001])
        self.cog._spawn(self.cog._assigned(self.g, 61, 6001))
        await self.drain()
        self.assertIn("still exists", self.card_text())
        self.assertNotIn("role deleted; roles re-read and it is gone", self.card_text())

    async def test_removal_claimed_ok_only_after_reread(self):
        self.g.rr_noop = True
        self.cog._blame[(GID, 6001)] = (ATTACKER, "untrusted", NOW)
        self.g.add_member(61, [self.admin_role])
        self.cog.cfg_roles[GID] = frozenset({5001, 6001})
        self.api.config = onboarding([5001], [6001])
        self.cog._spawn(self.cog._assigned(self.g, 61, 6001))
        await self.drain()
        self.assertIn("still has the role", self.card_text())

    async def test_config_clean_claimed_ok_only_after_reread(self):
        self.api.put_noop = True
        await self.add_dangerous_to_config()
        self.assertIn("still contains", self.card_text())

    async def test_ban_claimed_ok_only_after_fetch_ban(self):
        self.g.ban_exc = None
        orig = self.g.ban
        async def ban_but_not_really(obj, **kw):
            self.g.calls.append(("ban", obj.id))
        self.g.ban = ban_but_not_really
        await self.add_dangerous_to_config()
        self.assertIn("not banned", self.card_text())

    async def test_failure_triggers_lockdown_alert_and_bounded_retries(self):
        self.g.botrole.position = 1                                    # role is now above the bot: nothing can be edited / deleted
        self.cog._blame[(GID, 6001)] = (ATTACKER, "untrusted", NOW)
        self.admin_role.position = 500
        self.api.put_exc = exc(discord.Forbidden, 403)
        self.g.add_member(61, [self.admin_role])
        self.cog.cfg_roles[GID] = frozenset({5001, 6001})
        self.api.config = onboarding([5001], [6001])
        self.cog._spawn(self.cog._assigned(self.g, 61, 6001))
        await self.drain()
        self.assertEqual(self.emg.calls, 1)
        text = self.card_text()
        self.assertIn("Emergency lockdown", text)
        self.assertIn("3 channel(s) locked", text)
        self.assertIn("above or equal to my highest role", text)
        self.assertTrue(self.bot.owner_user.sent)                      # owner alerted
        self.assertIn(1.5, self.sleeps)                                # retry schedule used after the lockdown
        self.assertIn(4.0, self.sleeps)

    async def test_no_lockdown_when_step_failed_but_threat_is_gone(self):
        self.cog._blame[(GID, 6001)] = (ATTACKER, "untrusted", NOW)
        self.api.put_exc = exc(discord.Forbidden, 403)                 # cleaning fails ...
        self.cog.cfg_roles[GID] = frozenset({5001, 6001})
        self.g.add_member(61, [self.admin_role])
        self.api.config = onboarding([5001], [6001])
        self.cog._spawn(self.cog._assigned(self.g, 61, 6001))
        await self.drain()
        self.assertIsNone(self.g.get_role(6001))                       # ... but the role was deleted (re-read confirms)
        self.assertEqual(self.emg.calls, 0)
        self.assertIn("threat gone", self.card_text())

    async def test_retry_recovers_and_is_reported(self):
        self.api.put_exc = exc(discord.Forbidden, 403)
        calls = {"n": 0}
        orig = self.cog._p_clean
        async def flaky(guild, remove, by="incident"):
            calls["n"] += 1
            if calls["n"] >= 2:
                self.api.put_exc = None
            return await orig(guild, remove, by)
        self.cog._p_clean = flaky
        self.g.delete_noop = True                                      # keep the role alive so the lockdown path runs
        await self.add_dangerous_to_config()
        self.assertGreaterEqual(calls["n"], 2)
        self.assertEqual(self.emg.calls, 1)
        self.assertIn("retry 1/2", self.card_text())

    async def test_lockdown_cooldown_and_missing_emergency_module(self):
        self.assertEqual((await self.cog._lockdown(self.g, "x"))[0], "ok")
        self.assertEqual((await self.cog._lockdown(self.g, "x"))[0], "skipped")
        self.bot.cogs.pop("Emergency")
        self.cog._lockdown_at.clear()
        st, d = await self.cog._lockdown(self.g, "x")
        self.assertEqual(st, "failed")
        self.assertIn("no lockdown possible", d)

    async def test_ban_forbidden_is_reported_failed(self):
        self.g.ban_exc = exc(discord.Forbidden, 403)
        await self.add_dangerous_to_config()
        self.assertIn("Discord refused the ban", self.card_text())


class RoleGainFlow(Base):
    def gain(self, uid=ATTACKER, eid=None, with_raw=True):
        self.cog.cfg_roles[GID] = frozenset({5001, 5002})
        self.watched = self.g.add_role(5002, "Colour", SEND, 30)
        self.watched.permissions = Perm(SEND | ADMIN)                  # the attacker just made it Administrator
        data = raw(31, eid or self.nid(), uid, target_id=str(5002),
                   changes=[{"key": "permissions", "old_value": str(SEND), "new_value": str(SEND | ADMIN)}])
        if with_raw:
            self.cog._raw_audit(data)
        return data

    async def test_unauthorized_permission_gain_is_reverted_cleaned_and_banned(self):
        self.gain()
        await self.drain()
        self.assertEqual(self.watched.permissions.value, SEND)
        self.assertEqual(self.ops("ban"), [("ban", ATTACKER)])
        self.assertIsNotNone(self.g.get_role(5002))                    # an established role is reverted, never deleted
        self.assertEqual(self.ops("role.delete"), [])
        self.assertEqual(len(self.api.puts), 0 if 5002 not in ob.role_ids_in(self.api.config) else 1)

    async def test_owner_changing_the_role_is_exempt(self):
        self.gain(uid=OWNER)
        await self.drain()
        self.assertEqual(self.g.calls, [])

    async def test_unverified_gain_cleans_config_but_never_edits_the_role_or_bans(self):
        self.cog.cfg_roles[GID] = frozenset({5001, 5002})
        self.api.config = onboarding([5001], [5002])
        self.watched = self.g.add_role(5002, "Colour", SEND | ADMIN, 30)
        before = types.SimpleNamespace(permissions=Perm(SEND), id=5002, guild=self.g)
        await self.cog.on_guild_role_update(before, self.watched)      # listener path, no gateway entry, REST empty
        await self.drain()
        self.assertEqual(self.ops("ban"), [])
        self.assertEqual(self.ops("role.edit"), [])
        self.assertEqual(len(self.api.puts), 1)

    async def test_duplicate_raw_and_listener_gain_is_one_incident(self):
        data = self.gain()
        before = types.SimpleNamespace(permissions=Perm(SEND), id=5002, guild=self.g)
        await self.cog.on_guild_role_update(before, self.watched)
        await self.drain()
        self.assertEqual(len(self.ops("ban")), 1)

    async def test_engine_already_reverted_means_no_work(self):
        self.gain(with_raw=False)
        self.watched.permissions = Perm(SEND)
        await self.cog._role_gain(self.g, 5002, SEND, SEND | ADMIN, ATTACKER, 1)
        self.assertEqual(self.g.calls, [])

    async def test_revert_claimed_ok_only_after_reread(self):
        self.gain(with_raw=False)
        async def edit_noop(permissions=None, reason=None, **kw): self.g.calls.append(("role.edit", 5002, permissions.value))
        self.watched.edit = edit_noop
        await self.cog._role_gain(self.g, 5002, SEND, SEND | ADMIN, ATTACKER, 1)
        self.assertIn("still has", self.card_text())
        self.assertEqual(self.emg.calls, 1)


class Integration(Base):
    async def test_shares_ban_claim_and_extra_owners_with_botguard(self):
        bgc = bgm.BotGuard(self.bot, db_path=os.path.join(self.tmp.name, "bg.db"), clock=lambda: NOW, sleep=self.cog._sleep,
                           global_extra=frozenset({EXTRA}), settle=0)
        await bgc.ledger.open()
        self.bot.cogs["BotGuard"] = bgc
        self.assertEqual(self.cog.classify(self.g, EXTRA), "extra_owner")
        bgc.extra.setdefault(GID, set()).add(OTHER)
        self.assertEqual(self.cog.classify(self.g, OTHER), "extra_owner")
        await self.add_dangerous_to_config()
        self.assertEqual(self.ops("ban"), [("ban", ATTACKER)])
        self.assertIn((GID, ATTACKER), bgc._punished)                  # claim shared: the engine / botguard will not ban again
        await bgc.ledger.close()

    async def test_ban_primitive_refuses_every_exempt_user(self):
        await self.cog.add_trusted(self.g, TRUST, OWNER)
        for uid in (OWNER, EXTRA, TRUST, BOT):
            st, _ = await self.cog._p_ban(self.g, uid, "x")
            self.assertEqual(st, "skipped")
        self.assertEqual(self.ops("ban"), [])

    async def test_trust_management(self):
        self.assertEqual(await self.cog.add_trusted(self.g, TRUST, OWNER), "added")
        self.assertEqual(await self.cog.add_trusted(self.g, TRUST, OWNER), "exists")
        self.assertEqual(await self.cog.add_trusted(self.g, OWNER, OWNER), "implicit")
        self.assertEqual(await self.cog.add_trusted(self.g, EXTRA, OWNER), "implicit")
        self.assertEqual(await self.cog.add_trusted(self.g, 0, OWNER), "invalid")
        self.assertEqual(await self.cog.add_trusted(self.g, 99, OWNER, is_bot=True), "invalid")
        self.assertEqual(self.cog.classify(self.g, TRUST), "trusted")
        self.assertEqual(await self.cog.remove_trusted(GID, TRUST, OWNER), "removed")
        self.assertEqual(await self.cog.remove_trusted(GID, TRUST, OWNER), "absent")
        self.assertEqual(self.cog.classify(self.g, TRUST), "untrusted")
        self.assertEqual(self.cog.classify(self.g, BOT), "self")
        self.assertEqual(self.cog.classify(self.g, None), "unknown")

    async def test_state_survives_restart_and_wipe(self):
        await self.cog.add_trusted(self.g, TRUST, OWNER)
        await self.cog.set_flag(GID, True)
        again = ob.OnboardGuard(self.bot, db_path=self.cog.ledger.path, clock=lambda: NOW, global_extra=frozenset())
        await again.ledger.open()
        self.assertEqual(await again.ledger.query("SELECT user_id FROM ob_trusted"), [(TRUST,)])
        self.assertEqual(await again.ledger.query("SELECT enabled FROM ob_config"), [(1,)])
        await again.ledger.close()
        await self.cog.wipe(GID)
        self.assertFalse(self.cog.flag(GID))
        self.assertEqual(await self.cog.ledger.query("SELECT * FROM ob_trusted"), [])

    async def test_enable_defaults_only_for_new_setups(self):
        await self.cog.wipe(GID)
        await self.cog.enable_defaults(GID)
        self.assertTrue(self.cog.flag(GID))
        await self.cog.set_flag(GID, False)
        await self.cog.enable_defaults(GID)                            # the owner switched it off: stay off
        self.assertFalse(self.cog.flag(GID))

    async def test_scan_and_clean_commands(self):
        self.api.config = onboarding([5001], [6001])
        cfg, why, rows = await self.cog.scan(self.g)
        self.assertEqual(why, "ok")
        self.assertEqual([(r[0], r[2]) for r in rows], [(5001, 0), (6001, 2)])
        st, detail, roles = await self.cog.clean_now(self.g, OWNER)
        self.assertEqual((st, roles), ("ok", [6001]))
        self.assertNotIn(6001, ob.role_ids_in(self.api.config))
        st, _, roles = await self.cog.clean_now(self.g, OWNER)
        self.assertEqual((st, roles), ("ok", []))
        self.api.get_exc = exc(discord.Forbidden, 403)
        self.assertEqual((await self.cog.clean_now(self.g, OWNER))[0], "failed")

    async def test_events_are_written_to_the_ledger_with_all_fields(self):
        await self.add_dangerous_to_config()
        rows = await self.cog.ledger.query("SELECT kind, executor_id, target_id, details FROM ob_events WHERE kind LIKE 'incident_%'")
        self.assertEqual(len(rows), 1)
        kind, executor, target, details = rows[0]
        self.assertEqual((kind, executor, target), ("incident_config", ATTACKER, 6001))
        for key in ("role", "perms", "trigger", "ts", "steps"):
            self.assertIn(f'"{key}"', details)

    async def test_hook_installs_chains_and_unhooks(self):
        seen = []
        parsers = {"GUILD_AUDIT_LOG_ENTRY_CREATE": lambda d: seen.append("audit"), "GUILD_MEMBER_UPDATE": lambda d: seen.append("member")}
        self.bot._connection = types.SimpleNamespace(parsers=parsers)
        origs = dict(parsers)
        self.cog._hook_raw()
        parsers["GUILD_MEMBER_UPDATE"]({"garbage": True})              # garbage payloads must not break discord.py's own parser
        parsers["GUILD_AUDIT_LOG_ENTRY_CREATE"]({"action_type": "x"})
        self.assertEqual(seen, ["member", "audit"])
        self.cog._unhook_raw()
        self.assertIs(parsers["GUILD_MEMBER_UPDATE"], origs["GUILD_MEMBER_UPDATE"])


if __name__ == "__main__":
    unittest.main()
