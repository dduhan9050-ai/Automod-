"""Tests for cogs/antinuke/vanityguard.py  (run: python -m unittest discover -s tests -v)

Doubles only: NOT verified against real Discord.  They cover: authorization (Owner / Extra Owner / whitelist / me), "restore + ban
only when the audit log names ONE user for THIS change", alert-only when the actor cannot be proven, parallel restore + ban, honest
step statuses (ok only after a re-read), duplicate events, our own restore never starting an incident, vanity removal, offline
differences, owner commands, the raw gateway hook and the help page."""
import asyncio
import importlib.util
import os
import sys
import tempfile
import types
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _compat  # noqa: F401,E402
import discord  # noqa: E402
from fakes import exc  # noqa: E402
from utils import antinuke_store as store  # noqa: E402


def _load(name, rel):
    spec = importlib.util.spec_from_file_location(name, os.path.join(_compat.ROOT, *rel))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


vg = _load("vanityguard_under_test", ("cogs", "antinuke", "vanityguard.py"))

ADMIN, BAN, AUDIT, MGUILD, SEND = 1 << 3, 1 << 2, 1 << 7, 1 << 5, 1 << 11
OWNER, BOT, EXTRA, WL, ATTACKER, OTHER = 1, 100, 7, 8, 50, 51
NOW = 1_790_000_000.0
GID = 1000
OLD, NEW = "mycode", "evilcode"


def sf(ts, n=0):
    return ((int(ts * 1000) - 1420070400000) << 22) | n


class Perm:
    def __init__(self, v): self.value = v
    @property
    def administrator(self): return bool(self.value & ADMIN)
    @property
    def manage_guild(self): return bool(self.value & MGUILD)
    @property
    def view_audit_log(self): return bool(self.value & AUDIT)
    @property
    def ban_members(self): return bool(self.value & BAN)


class Guild:
    def __init__(self):
        self.id, self.owner_id, self.name = GID, OWNER, "G"
        self.channels, self.banned, self.calls, self.ban_exc = {}, set(), [], None
        self.vanity_url_code = OLD
        self.me = types.SimpleNamespace(id=BOT, guild_permissions=Perm(ADMIN))
    def get_channel(self, cid): return self.channels.get(cid)
    async def ban(self, obj, reason=None, delete_message_seconds=0):
        self.calls.append(("ban", obj.id))
        if self.ban_exc:
            raise self.ban_exc
        self.banned.add(obj.id)
    async def fetch_ban(self, obj):
        if obj.id not in self.banned:
            raise exc(discord.NotFound, 404)


class Chan:
    def __init__(self): self.sent = []
    async def send(self, **kw): self.sent.append(kw)


class User:
    def __init__(self): self.sent = []
    async def send(self, **kw): self.sent.append(kw)


class Http:
    def __init__(self): self.entries, self.exc, self.calls = [], None, 0
    async def get_audit_logs(self, gid, limit=25, **kw):
        self.calls += 1
        if self.exc:
            raise self.exc
        return {"audit_log_entries": list(self.entries)}


class Bot:
    def __init__(self, guild):
        self.user, self.cogs, self.http, self.guild = types.SimpleNamespace(id=BOT), {}, Http(), guild
        self.owner_user = User()
        self._connection = types.SimpleNamespace(parsers={})
        self.guilds = [guild]
    def get_cog(self, n): return self.cogs.get(n)
    def get_user(self, uid): return None
    async def fetch_user(self, uid): return self.owner_user
    def get_guild(self, gid): return self.guild if gid == GID else None
    def is_ready(self): return False


def audit_entry(eid, uid, old=OLD, new=NEW, action=1, key="vanity_url_code"):
    ch = {"key": key}
    if old is not None:
        ch["old_value"] = old
    if new is not None:
        ch["new_value"] = new
    return {"action_type": action, "guild_id": str(GID), "id": str(eid), "user_id": str(uid), "changes": [ch]}


def guild_update(code, gid=GID):
    return {"id": str(gid), "name": "G", "vanity_url_code": code}


class PureTests(unittest.TestCase):
    def test_parse_guild_update(self):
        self.assertEqual(vg.parse_guild_update(guild_update(NEW)), (GID, NEW))
        self.assertEqual(vg.parse_guild_update(guild_update(None)), (GID, None))
        for bad in (None, "x", 5, [], {}, {"id": "1000"}, {"id": "abc", "vanity_url_code": NEW}, {"id": "1000", "vanity_url_code": "bad code!"},
                    {"id": "1000", "vanity_url_code": 5}, {"id": "1000", "vanity_url_code": "a" * 80}):
            self.assertIsNone(vg.parse_guild_update(bad))

    def test_case_insensitive_compare(self):
        self.assertTrue(vg.same_code("MyCode", "mycode"))
        self.assertTrue(vg.same_code(None, None))
        self.assertFalse(vg.same_code("a1", None))

    def test_audit_vanity(self):
        self.assertEqual(vg.audit_vanity(audit_entry(5, 9)), (5, 9, OLD, NEW))
        self.assertEqual(vg.audit_vanity(audit_entry(5, 9, new=None)), (5, 9, OLD, None))          # removal
        self.assertIsNone(vg.audit_vanity(audit_entry(5, 9, key="name")))                          # another guild change
        self.assertIsNone(vg.audit_vanity({"id": "x"}))
        self.assertIsNone(vg.audit_vanity(None))

    def test_pick_audit(self):
        c = lambda eid, uid, ts=NOW, old=OLD, new=NEW: (eid, uid, ts, old, new)  # noqa: E731
        self.assertEqual(vg.pick_audit([c(1, 50)], NEW, NOW)[0], "verified")
        self.assertEqual(vg.pick_audit([c(1, 50, new="other")], NEW, NOW)[0], "none")             # another change never counts
        self.assertEqual(vg.pick_audit([c(1, 50, ts=NOW - 100)], NEW, NOW)[0], "none")            # too old
        self.assertEqual(vg.pick_audit([c(1, 50), c(2, 51)], NEW, NOW)[0], "ambiguous")
        self.assertEqual(vg.pick_audit([c(1, 50), c(2, 50)], NEW, NOW)[0], "verified")            # same user twice is fine
        self.assertEqual(vg.pick_audit([c(1, None)], NEW, NOW)[0], "none")
        self.assertEqual(vg.pick_audit([c(1, 50, new=None)], None, NOW)[0], "verified")           # removal
        self.assertEqual(vg.pick_audit([c(1, 50, ts=NOW + 3)], NEW, NOW)[0], "verified")          # small clock skew
        self.assertEqual(vg.pick_audit([c(1, 50, new="EvilCode")], NEW, NOW)[0], "verified")      # case-insensitive

    def test_help_page(self):
        page = vg.help_text("?", {"vanity": True})
        self.assertEqual(len(page), 1)
        for needle in ("ANTI VANITY ON", "?antinuke vanity on", "?antinuke vanity off", "?antinuke vanity status", "?antinuke vanity restore",
                       "?antinuke vanity sync", "?antinuke vanity fast on|off", "Fast mode", "claims", "banned"):
            self.assertIn(needle, page[0])
        self.assertIn("OFF", vg.help_text("?", {"vanity": False})[0].split("\n")[0])

    def test_render(self):
        inc = vg.VgIncident("vanity", GID, executor_id=50, executor_class="untrusted", old_code=OLD, new_code=NEW, trigger="t", exec_via="v")
        inc.add("Restore vanity", "ok", "done")
        inc.ms, inc.ms_action = 12.0, 5.0
        text = vg.render_vg(inc, "H", now=NOW)
        for needle in ("<@50>", "`50`", f"discord.gg/{OLD}", f"discord.gg/{NEW}", "Restore vanity", f"<t:{int(NOW)}:T>", "5 ms"):
            self.assertIn(needle, text)


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.g = Guild()
        self.bot = Bot(self.g)
        self.chan = Chan()
        self.g.channels[999] = self.chan
        store._cfg[GID] = store.GuildCfg(enabled=True, autorec=True, log=999, wl={WL: 1})

        async def fake_sleep(d): pass
        self.cog = vg.VanityGuard(self.bot, db_path=os.path.join(self.tmp.name, "vg.db"), clock=lambda: NOW, sleep=fake_sleep,
                                  global_extra=frozenset({EXTRA}), retry_delays=(0.0, 0.0))
        await self.cog.ledger.open()
        self.cog.flags[GID] = True
        self.cog.base[GID] = OLD
        self.cog.hint_wait, self.cog.rest_recheck = 0.01, 0.0
        self.cog.fast[GID] = getattr(self, "FAST", False)           # existing suite = audit-gated mode; FastModeTests = the default
        self.server_code = OLD                                   # what Discord really holds
        self.http_calls, self.set_exc, self.set_noop, self.get_exc = [], None, False, None

        async def set_vanity(gid, code, reason):
            self.http_calls.append(("set", code))
            if self.set_exc:
                raise self.set_exc
            if not self.set_noop:
                self.server_code = code
                self.g.vanity_url_code = code

        async def get_vanity(gid):
            self.http_calls.append(("get",))
            if self.get_exc:
                raise self.get_exc
            return {"code": self.server_code, "uses": 0}
        self.cog._http_set_vanity, self.cog._http_get_vanity = set_vanity, get_vanity
        self.eid = 0

    async def asyncTearDown(self):
        await self.drain()
        await self.cog.ledger.close()
        store._cfg.clear()
        self.tmp.cleanup()

    async def drain(self):
        for _ in range(10):
            if self.cog._bg:
                await asyncio.gather(*list(self.cog._bg), return_exceptions=True)

    def hint(self, uid, old=OLD, new=NEW):
        self.eid += 1
        self.cog._note_audit(GID, self.eid, uid, old, new)

    def change(self, code=NEW, actor=ATTACKER, with_hint=True):
        """The server's vanity changes to `code`: Discord's audit entry (optional) + the GUILD_UPDATE event."""
        self.server_code = code
        self.g.vanity_url_code = code
        if with_hint and actor is not None:
            self.hint(actor, OLD, code)
        self.cog._changed(GID, code, "raw gateway")

    def steps(self):
        text = self.chan.sent[-1].get("content", "") if self.chan.sent else ""
        return text


class ResponseTests(Base):
    async def test_untrusted_change_is_restored_and_actor_banned(self):
        self.change()
        await self.drain()
        self.assertEqual(self.server_code, OLD)
        self.assertIn(ATTACKER, self.g.banned)
        self.assertEqual(self.cog.base[GID], OLD)                                 # the protected code never moved
        self.assertEqual(len(self.chan.sent), 1)
        card = self.steps()
        for needle in ("Restore vanity", "Ban actor", f"<@{ATTACKER}>", f"discord.gg/{OLD}", f"discord.gg/{NEW}"):
            self.assertIn(needle, card)
        self.assertEqual(len(self.bot.owner_user.sent), 1)                        # owner DM
        self.assertEqual(self.cog.stats["restores"], 1)
        self.assertIn(("get",), self.http_calls)                                  # re-read before ok

    async def test_restore_and_ban_both_start_before_either_finishes(self):
        order = []
        orig_set, orig_ban = self.cog._http_set_vanity, self.g.ban

        async def slow_set(gid, code, reason):
            order.append("set-start")
            await asyncio.sleep(0.02)
            await orig_set(gid, code, reason)
            order.append("set-end")

        async def slow_ban(obj, reason=None, delete_message_seconds=0):
            order.append("ban-start")
            await asyncio.sleep(0.02)
            await orig_ban(obj, reason, delete_message_seconds)
            order.append("ban-end")
        self.cog._http_set_vanity, self.g.ban = slow_set, slow_ban
        self.change()
        await self.drain()
        self.assertEqual(sorted(order[:2]), ["ban-start", "set-start"])           # parallel, not one after the other
        self.assertEqual(self.server_code, OLD)
        self.assertIn(ATTACKER, self.g.banned)

    async def test_exempt_actors_move_the_protected_code(self):
        for i, actor in enumerate((OWNER, EXTRA, WL)):
            code = f"code{i}"
            self.cog._claims.clear()
            self.change(code, actor)
            await self.drain()
            self.assertEqual(self.cog.base[GID], code)                            # authorized: the new code is the new truth
            self.assertEqual(self.server_code, code)                              # not restored
            self.assertEqual(self.g.banned, set())
            self.assertEqual(self.chan.sent, [])
            self.cog.base[GID] = code
            self.cog._hints.clear()

    async def test_unproven_actor_means_alert_only(self):
        self.change(with_hint=False)                                              # no gateway entry, REST empty
        await self.drain()
        self.assertEqual(self.server_code, NEW)                                   # NOT restored: it may be the owner
        self.assertEqual(self.g.banned, set())
        self.assertEqual(self.cog.base[GID], OLD)
        self.assertIn(GID, self.cog._off)
        self.assertEqual(len(self.chan.sent), 1)
        self.assertIn("antinuke vanity restore", self.steps())
        self.assertEqual(self.bot.http.calls, 2)                                  # REST read, then one re-read after a short wait

    async def test_audit_unavailable_means_alert_only(self):
        self.bot.http.exc = exc(discord.Forbidden, 403)
        self.change(with_hint=False)
        await self.drain()
        self.assertEqual((self.server_code, self.g.banned), (NEW, set()))
        self.assertIn("unavailable", self.steps())

    async def test_ambiguous_actor_means_alert_only(self):
        self.hint(ATTACKER, OLD, NEW)
        self.hint(OTHER, OLD, NEW)
        self.change(with_hint=False)
        await self.drain()
        self.assertEqual((self.server_code, self.g.banned), (NEW, set()))

    async def test_actor_found_through_rest(self):
        self.bot.http.entries = [audit_entry(sf(NOW), ATTACKER)]
        self.change(with_hint=False)
        await self.drain()
        self.assertEqual(self.server_code, OLD)
        self.assertIn(ATTACKER, self.g.banned)
        self.assertIn("audit-log REST", self.steps())

    async def test_stale_rest_entry_for_another_change_is_ignored(self):
        self.bot.http.entries = [audit_entry(sf(NOW), ATTACKER, new="somethingelse")]
        self.change(with_hint=False)
        await self.drain()
        self.assertEqual((self.server_code, self.g.banned), (NEW, set()))

    async def test_restore_failed_code_taken(self):
        self.set_exc = exc(discord.HTTPException, 400)
        self.change()
        await self.drain()
        card = self.steps()
        self.assertEqual(self.server_code, NEW)
        self.assertIn(ATTACKER, self.g.banned)                                    # the ban still happens
        self.assertIn("claimed by another server", card)
        self.assertIn("NOT back", card)
        self.assertEqual(self.cog.stats["restores"], 0)
        self.assertIn(GID, self.cog._off)                                         # reported once, not an incident per event

    async def test_restore_forbidden(self):
        self.set_exc = exc(discord.Forbidden, 403)
        self.change()
        await self.drain()
        self.assertIn("Manage Server", self.steps())

    async def test_restore_accepted_but_reread_differs_is_not_ok(self):
        self.set_noop = True
        self.change()
        await self.drain()
        self.assertIn("accepted the edit but the code reads", self.steps())
        self.assertEqual(self.cog.stats["restores"], 0)

    async def test_reread_failure_is_unverified_not_ok(self):
        self.get_exc = exc(discord.HTTPException, 500)
        self.change()
        await self.drain()
        self.assertIn("unverified", self.steps())
        self.assertEqual(self.cog.stats["restores"], 0)

    async def test_5xx_is_retried(self):
        n = {"i": 0}
        orig = self.cog._http_set_vanity

        async def flaky(gid, code, reason):
            n["i"] += 1
            if n["i"] == 1:
                raise exc(discord.HTTPException, 502)
            await orig(gid, code, reason)
        self.cog._http_set_vanity = flaky
        self.change()
        await self.drain()
        self.assertEqual(self.server_code, OLD)
        self.assertEqual(n["i"], 2)

    async def test_ban_forbidden_reported_restore_still_done(self):
        self.g.ban_exc = exc(discord.Forbidden, 403)
        self.change()
        await self.drain()
        self.assertEqual(self.server_code, OLD)
        self.assertIn("Discord refused the ban", self.steps())
        self.assertEqual(self.g.banned, set())

    async def test_vanity_removal_is_restored(self):
        self.change(None)
        await self.drain()
        self.assertEqual(self.server_code, OLD)
        self.assertIn(ATTACKER, self.g.banned)
        self.assertIn("`none`", self.steps())

    async def test_our_own_restore_never_starts_an_incident(self):
        self.change()
        await self.drain()
        n = len(self.chan.sent)
        self.cog._changed(GID, OLD, "raw gateway")                                # the GUILD_UPDATE our restore causes
        await self.drain()
        self.assertEqual(len(self.chan.sent), n)
        self.assertNotIn(GID, self.cog._off)

    async def test_duplicate_events_are_handled_once(self):
        self.change()
        self.cog._changed(GID, NEW, "gateway event")                              # raw hook + listener both report it
        self.cog._changed(GID, NEW, "raw gateway")
        await self.drain()
        self.assertEqual(len(self.chan.sent), 1)
        self.assertEqual(self.g.calls.count(("ban", ATTACKER)), 1)

    async def test_burst_of_two_changes_bans_once(self):
        self.change("a1", ATTACKER)
        self.change("b2", ATTACKER)
        await self.drain()
        self.assertEqual(self.g.calls.count(("ban", ATTACKER)), 1)
        self.assertEqual(self.server_code, OLD)

    async def test_disabled_or_untracked_guild_is_ignored(self):
        self.cog.flags[GID] = False
        self.change()
        await self.drain()
        self.assertEqual((self.server_code, self.g.banned, self.chan.sent), (NEW, set(), []))
        self.cog.flags[GID] = True
        self.cog.base.pop(GID)
        self.cog._claims.clear()
        self.cog._changed(GID, "zzz1", "raw gateway")
        await self.drain()
        self.assertEqual(self.g.banned, set())

    async def test_antinuke_engine_off_is_ignored(self):
        store._cfg[GID].enabled = False
        self.change()
        await self.drain()
        self.assertEqual((self.server_code, self.g.banned), (NEW, set()))

    async def test_botguard_ban_is_shared(self):
        calls = []

        class BG:
            def extra_ids(self, gid): return frozenset({EXTRA})
            async def _ban(self, guild, uid, reason):
                calls.append(uid)
                guild.banned.add(uid)
                return "ok", "ban accepted"
        self.bot.cogs["BotGuard"] = BG()
        self.change()
        await self.drain()
        self.assertEqual(calls, [ATTACKER])


class FastModeTests(Base):
    FAST = True

    async def test_restore_leaves_before_the_actor_is_known(self):
        self.change(with_hint=False)                                              # no audit entry yet
        self.assertEqual(self.http_calls[:1], [("set", OLD)])                     # PATCH already sent in the same tick
        self.assertEqual(self.g.banned, set())
        self.hint(ATTACKER)                                                       # the audit entry arrives a moment later
        await self.drain()
        self.assertIn(ATTACKER, self.g.banned)
        self.assertEqual(self.server_code, OLD)
        self.assertEqual(self.http_calls.count(("set", OLD)), 1)                  # restored once, not twice

    async def test_untrusted_still_restored_and_banned(self):
        self.change()
        await self.drain()
        self.assertEqual((self.server_code, self.cog.base[GID]), (OLD, OLD))
        self.assertIn(ATTACKER, self.g.banned)
        self.assertEqual(len(self.chan.sent), 1)
        self.assertIn("Restore vanity", self.steps())

    async def test_owner_change_is_reapplied_and_becomes_protected(self):
        for i, actor in enumerate((OWNER, EXTRA, WL)):
            code = f"newcode{i}"
            self.cog._claims.clear()
            self.cog._hints.clear()
            self.cog.base[GID] = self.server_code if i else OLD
            self.change(code, actor)
            await self.drain()
            self.assertEqual(self.server_code, code)                              # the owner's code is back
            self.assertEqual(self.cog.base[GID], code)
            self.assertEqual(self.g.banned, set())
            self.assertEqual(self.chan.sent, [])                                  # nothing alarming happened
            self.cog._changed(GID, code, "raw gateway")                           # the GUILD_UPDATE echo of the re-apply
            await self.drain()
            self.assertNotIn(GID, self.cog._off)
            self.assertEqual(self.chan.sent, [])

    async def test_reapply_events_never_look_like_a_change(self):
        self.change("ownercode", OWNER)
        await self.drain()
        self.cog._changed(GID, OLD, "raw gateway")                                # the flash of the old code
        self.cog._changed(GID, "ownercode", "raw gateway")
        await self.drain()
        self.assertEqual((self.chan.sent, self.g.banned), ([], set()))

    async def test_owner_change_that_cannot_be_reapplied_alerts_the_owner(self):
        orig = self.cog._http_set_vanity

        async def snipe(gid, code, reason):
            if code != OLD:
                raise exc(discord.HTTPException, 400)                            # someone grabbed the owner's new code in between
            await orig(gid, code, reason)
        self.cog._http_set_vanity = snipe
        self.change("ownercode", OWNER)
        await self.drain()
        self.assertEqual(self.g.banned, set())
        self.assertEqual(len(self.chan.sent), 1)
        self.assertIn("could NOT be applied again", self.steps())
        self.assertEqual(self.cog.base[GID], "ownercode")

    async def test_unproven_actor_stays_restored_but_nobody_is_banned(self):
        self.change(with_hint=False)
        await self.drain()
        self.assertEqual((self.server_code, self.g.banned), (OLD, set()))
        self.assertIn("nobody was banned", self.steps())
        self.assertNotIn(GID, self.cog._off)

    async def test_no_audit_permission_means_no_immediate_restore(self):
        self.g.me.guild_permissions = Perm(BAN | MGUILD)                          # cannot read the audit log
        self.change(with_hint=False)
        await self.drain()
        self.assertEqual(self.http_calls, [])                                     # the owner could never be recognised: do not revert blindly
        self.assertEqual((self.server_code, self.g.banned), (NEW, set()))

    async def test_removal_restored_immediately(self):
        self.change(None, with_hint=False)
        self.assertEqual(self.http_calls[:1], [("set", OLD)])
        await self.drain()

    async def test_no_previous_code_no_immediate_restore(self):
        self.cog.base[GID] = None
        self.change("firstcode", ATTACKER)
        await self.drain()
        self.assertNotIn(("set", None), self.http_calls)
        self.assertIn(ATTACKER, self.g.banned)

    async def test_fast_flag_persists_and_defaults_on(self):
        self.cog.fast.pop(GID)
        self.assertTrue(self.cog.is_fast(GID))
        await self.cog.set_fast(GID, False)
        self.assertFalse(self.cog.is_fast(GID))
        self.assertEqual(await self.cog.ledger.query("SELECT fast FROM vg_fast WHERE guild_id = ?", (GID,)), [(0,)])
        await self.cog.wipe(GID)
        self.assertTrue(self.cog.is_fast(GID))


class ConfirmTests(Base):
    async def test_response_with_code_confirms_without_get(self):
        async def set_vanity(gid, code, reason):
            self.http_calls.append(("set", code))
            self.server_code = self.g.vanity_url_code = code
            return {"code": code}
        self.cog._http_set_vanity = set_vanity
        st, d = await self.cog._p_restore(self.g, OLD, "r")
        self.assertEqual(st, "ok")
        self.assertIn("Discord's response", d)
        self.assertNotIn(("get",), self.http_calls)                               # no extra round trip

    async def test_response_with_other_code_is_not_ok(self):
        async def set_vanity(gid, code, reason):
            return {"code": "somethingelse"}
        self.cog._http_set_vanity = set_vanity
        st, d = await self.cog._p_restore(self.g, OLD, "r")
        self.assertEqual(st, "failed")
        self.assertIn("somethingelse", d)

    async def test_response_without_code_falls_back_to_get(self):
        st, _ = await self.cog._p_restore(self.g, OLD, "r")                       # base fake returns None
        self.assertEqual(st, "ok")
        self.assertIn(("get",), self.http_calls)

    async def test_direct_path_success_and_refusals(self):
        results = iter([(200, {"code": OLD}), (400, None), (403, None)])
        calls = []

        async def direct(gid, code, reason):
            calls.append(code)
            return next(results)
        self.cog._direct_set_vanity = direct
        st, d = await self.cog._p_restore(self.g, OLD, "r")
        self.assertEqual((st, "direct request" in d), ("ok", True))
        self.assertEqual(self.http_calls, [])                                     # normal client untouched
        st, d = await self.cog._p_restore(self.g, OLD, "r")
        self.assertEqual(st, "failed")
        self.assertIn("claimed by another server", d)
        st, d = await self.cog._p_restore(self.g, OLD, "r")
        self.assertIn("Manage Server", d)
        self.assertEqual(self.http_calls, [])                                     # definitive refusals are not retried

    async def test_direct_path_falls_back_on_429_or_none(self):
        for res in (None, (429, None), (502, None)):
            async def direct(gid, code, reason, res=res):
                return res
            self.cog._direct_set_vanity = direct
            self.http_calls.clear()
            st, _ = await self.cog._p_restore(self.g, OLD, "r")
            self.assertEqual(st, "ok")
            self.assertEqual(self.http_calls[0], ("set", OLD))

    async def test_direct_unavailable_without_prepared_request(self):
        self.assertIsNone(await self.cog._direct_set_vanity(GID, OLD, "r"))


class GuardTests(Base):
    async def test_ban_primitive_never_touches_protected_users(self):
        for uid in (OWNER, EXTRA, WL, BOT):
            st, _ = await self.cog._p_ban(self.g, uid, "x")
            self.assertEqual(st, "skipped")
        self.assertEqual((self.g.calls, self.g.banned), ([], set()))


class CommandTests(Base):
    async def test_set_flag_on_takes_the_current_code(self):
        self.cog.flags.pop(GID), self.cog.base.pop(GID)
        self.g.vanity_url_code = "current1"
        await self.cog.set_flag(GID, True, self.g)
        self.assertEqual(self.cog.base[GID], "current1")
        rows = await self.cog.ledger.query("SELECT code FROM vg_codes WHERE guild_id = ?", (GID,))
        self.assertEqual(rows, [("current1",)])
        await self.cog.set_flag(GID, False, self.g)
        self.assertNotIn(GID, self.cog.base)
        self.assertEqual(await self.cog.ledger.query("SELECT code FROM vg_codes WHERE guild_id = ?", (GID,)), [])

    async def test_enable_defaults_only_for_new_setups(self):
        self.cog.flags.pop(GID), self.cog.base.pop(GID)
        await self.cog.enable_defaults(GID)
        self.assertTrue(self.cog.flag(GID))
        await self.cog.set_flag(GID, False, self.g)
        await self.cog.enable_defaults(GID)                                       # an explicit OFF stays off
        self.assertFalse(self.cog.flag(GID))

    async def test_restore_now_and_sync_now(self):
        self.server_code = self.g.vanity_url_code = NEW
        st, _ = await self.cog.restore_now(self.g, OWNER)
        self.assertEqual((st, self.server_code), ("ok", OLD))
        st, d = await self.cog.restore_now(self.g, OWNER)
        self.assertIn("already uses", d)
        self.server_code = NEW
        st, _ = await self.cog.sync_now(self.g, OWNER)
        self.assertEqual((st, self.cog.base[GID]), ("ok", NEW))
        self.assertNotIn(GID, self.cog._off)
        self.cog.base[GID] = None
        self.assertEqual((await self.cog.restore_now(self.g, OWNER))[0], "failed")

    async def test_wipe(self):
        await self.cog.wipe(GID)
        self.assertEqual((self.cog.flag(GID), GID in self.cog.base), (False, False))

    async def test_status_info(self):
        info = self.cog.status_info(self.g)
        self.assertTrue(info["on"] and info["audit"] and info["manage_guild"] and info["ban"])
        self.assertEqual((info["protected"], info["live"]), (OLD, OLD))
        self.g.me.guild_permissions = Perm(SEND)
        info = self.cog.status_info(self.g)
        self.assertFalse(info["audit"] or info["manage_guild"] or info["ban"])

    async def test_events_are_recorded(self):
        self.change()
        await self.drain()
        ev = await self.cog.recent_events(GID)
        self.assertEqual(ev[0][1], "vanity_incident")


class OfflineTests(Base):
    async def test_change_while_offline_alerts_but_never_acts(self):
        self.g.vanity_url_code = NEW
        await self.cog._sync_guild(self.g)
        self.assertEqual((self.g.banned, self.server_code), (set(), OLD))
        self.assertEqual(len(self.chan.sent), 1)
        self.assertIn("offline", self.chan.sent[0]["content"])
        self.assertEqual(self.cog.base[GID], OLD)
        self.cog._changed(GID, NEW, "raw gateway")                                # an unrelated GUILD_UPDATE with the same code
        await self.drain()
        self.assertEqual(len(self.chan.sent), 1)                                  # not reported again
        await self.cog._sync_guild(self.g)
        self.assertEqual(len(self.chan.sent), 1)

    async def test_first_start_takes_the_current_code(self):
        self.cog.base.pop(GID)
        await self.cog._sync_guild(self.g)
        self.assertEqual(self.cog.base[GID], OLD)
        self.assertEqual(self.chan.sent, [])


class RawHookTests(Base):
    async def test_hook_chains_and_detects(self):
        seen = []
        self.bot._connection.parsers.update({"GUILD_UPDATE": lambda d: seen.append(("orig-guild", d)),
                                             "GUILD_AUDIT_LOG_ENTRY_CREATE": lambda d: seen.append(("orig-audit", d))})
        self.cog._hook_raw()
        p = self.bot._connection.parsers
        p["GUILD_AUDIT_LOG_ENTRY_CREATE"](audit_entry(sf(NOW), ATTACKER))
        self.server_code = self.g.vanity_url_code = NEW
        p["GUILD_UPDATE"](guild_update(NEW))
        await self.drain()
        self.assertEqual([s[0] for s in seen], ["orig-audit", "orig-guild"])      # discord.py's own parsers still run
        self.assertEqual(self.server_code, OLD)
        self.assertIn(ATTACKER, self.g.banned)
        self.cog._unhook_raw()
        self.assertEqual(self.bot._connection.parsers["GUILD_UPDATE"].__name__, "<lambda>")

    async def test_garbage_payloads_never_raise(self):
        self.bot._connection.parsers.update({"GUILD_UPDATE": lambda d: None, "GUILD_AUDIT_LOG_ENTRY_CREATE": lambda d: None})
        self.cog._hook_raw()
        for bad in (None, 5, "x", {}, {"id": "1000"}, {"id": None, "vanity_url_code": "x"}):
            self.bot._connection.parsers["GUILD_UPDATE"](bad)
            self.bot._connection.parsers["GUILD_AUDIT_LOG_ENTRY_CREATE"](bad)
        await self.drain()
        self.assertEqual(self.chan.sent, [])

    async def test_listener_fallback_without_raw_hook(self):
        after = types.SimpleNamespace(id=GID, vanity_url_code=NEW)
        self.server_code = self.g.vanity_url_code = NEW
        self.hint(ATTACKER)
        await self.cog.on_guild_update(None, after)
        await self.drain()
        self.assertEqual(self.server_code, OLD)
        self.assertIn(ATTACKER, self.g.banned)

    async def test_audit_listener_fallback(self):
        entry = types.SimpleNamespace(guild=self.g, action=types.SimpleNamespace(value=1), id=77, user_id=ATTACKER,
                                      before=types.SimpleNamespace(vanity_url_code=OLD), after=types.SimpleNamespace(vanity_url_code=NEW))
        await self.cog.on_audit_log_entry_create(entry)
        self.assertEqual(self.cog._hints[GID][0][:2], (77, ATTACKER))
        other = types.SimpleNamespace(guild=self.g, action=types.SimpleNamespace(value=40), id=78, user_id=ATTACKER, before=None, after=None)
        await self.cog.on_audit_log_entry_create(other)
        self.assertEqual(len(self.cog._hints[GID]), 1)


if __name__ == "__main__":
    unittest.main()
