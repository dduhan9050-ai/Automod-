# Make `from discord.ext import menus` work even when discord-ext-menus is not installed.
try:
    from discord.ext import menus as _menus  # noqa: F401
except ImportError:
    from . import _menus_shim
    _menus_shim.install()

from .config import *
from .Tools import *
from .paginators import *
from .paginator import *