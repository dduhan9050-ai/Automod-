"""Tiny drop-in replacement for ``discord.ext.menus`` (PageSource / ListPageSource).

``discord-ext-menus`` is not published on PyPI for discord.py 2.x, so on a clean
host ``from discord.ext import menus`` used to crash the bot at start-up.
``utils/__init__.py`` installs this shim only when the real package is missing,
so nothing changes on machines where the real package is already installed.
"""
from __future__ import annotations

import sys
import types
from typing import Any, Sequence


class PageSource:
    async def _prepare_once(self) -> None:
        if not getattr(self, "_prepared", False):
            await self.prepare()
            self._prepared = True

    async def prepare(self) -> None:
        return

    def is_paginating(self) -> bool:
        raise NotImplementedError

    def get_max_pages(self) -> int | None:
        return None

    async def get_page(self, page_number: int) -> Any:
        raise NotImplementedError

    async def format_page(self, menu: Any, page: Any) -> Any:
        raise NotImplementedError


class ListPageSource(PageSource):
    def __init__(self, entries: Sequence[Any], *, per_page: int) -> None:
        self.entries = entries
        self.per_page = per_page
        pages, left_over = divmod(len(entries), per_page)
        if left_over:
            pages += 1
        self._max_pages = pages

    def is_paginating(self) -> bool:
        return len(self.entries) > self.per_page

    def get_max_pages(self) -> int:
        return self._max_pages

    async def get_page(self, page_number: int) -> Any:
        if self.per_page == 1:
            return self.entries[page_number]
        base = page_number * self.per_page
        return self.entries[base:base + self.per_page]


def install() -> None:
    """Register the shim as ``discord.ext.menus``."""
    import discord.ext

    module = types.ModuleType("discord.ext.menus")
    module.PageSource = PageSource
    module.ListPageSource = ListPageSource
    sys.modules["discord.ext.menus"] = module
    discord.ext.menus = module  # type: ignore[attr-defined]
