"""Antinuke data layer.

Speed model: every guild's config lives in plain Python objects in RAM. The engine
reads them with ONE synchronous dict lookup (no await, no SQLite) on every audit-log
event. SQLite (db/antinuke.db) is only touched by commands, which write through.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field

import aiosqlite

DB_PATH = "db/antinuke.db"
LEGACY_DB = "db/anti.db"

# (key, label) - order is the order shown in `antinuke manage`. Max 25 (select menu limit).
MODULES: tuple[tuple[str, str], ...] = (
    ("ban", "Anti Ban"),
    ("unban", "Anti Unban"),
    ("kick", "Anti Kick"),
    ("prune", "Anti Prune"),
    ("botadd", "Anti Bot Add"),
    ("chcr", "Anti Channel Create"),
    ("chdl", "Anti Channel Delete"),
    ("chup", "Anti Channel Update"),
    ("rlcr", "Anti Role Create"),
    ("rldl", "Anti Role Delete"),
    ("rlup", "Anti Role Update"),
    ("memup", "Anti Member Role Update"),
    ("serverup", "Anti Server Update"),
    ("webhook", "Anti Webhook"),
    ("emoji", "Anti Emoji & Sticker"),
    ("integration", "Anti Integration"),
    ("everyone", "Anti Everyone/Here"),
    ("linkrole", "Anti Linked Role"),
)
KEYS = tuple(k for k, _ in MODULES)
LABELS = dict(MODULES)
BIT = {k: 1 << i for i, k in enumerate(KEYS)}
ALL_MASK = (1 << len(KEYS)) - 1
OLD_ALL_MASK = ALL_MASK & ~(1 << KEYS.index("linkrole"))   # every module that existed before V40

# How many actions a WHITELISTED user may do per window before betrayal guard fires.
DEFAULT_LIMITS = {
    "ban": 3, "unban": 3, "kick": 3, "prune": 1, "botadd": 2, "chcr": 5, "chdl": 3,
    "chup": 6, "rlcr": 5, "rldl": 3, "rlup": 6, "memup": 5, "serverup": 3,
    "webhook": 4, "emoji": 8, "integration": 2, "everyone": 3, "linkrole": 2,
}
MAX_LIMIT = 50
PUNISHMENTS = ("ban", "kick", "timeout", "strip")   # what happens to a nuker
WINDOW = 60.0   # seconds a limit is counted over


def _norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]", "", text.lower())


_ALIAS: dict[str, str] = {}
for _k, _l in MODULES:
    _ALIAS[_norm(_k)] = _k
    _n = _norm(_l)
    _ALIAS[_n] = _k
    if _n.startswith("anti"):
        _ALIAS[_n[4:]] = _k
_ALIAS.update({
    "bot": "botadd", "bots": "botadd", "memberprune": "prune", "channelcreate": "chcr",
    "channeldelete": "chdl", "channelupdate": "chup", "rolecreate": "rlcr",
    "roledelete": "rldl", "roleupdate": "rlup", "memberupdate": "memup",
    "memberroleupdate": "memup", "roleadd": "memup", "server": "serverup",
    "guild": "serverup", "webhooks": "webhook", "emojis": "emoji", "sticker": "emoji",
    "stickers": "emoji", "emojisticker": "emoji", "here": "everyone",
    "everyonehere": "everyone", "integrations": "integration",
    "linkroles": "linkrole", "linkedrole": "linkrole", "linkedroles": "linkrole",
    "antilinkrole": "linkrole", "lr": "linkrole",
})


def resolve(text: str) -> str | None:
    return _ALIAS.get(_norm(text))


def mask_of(keys) -> int:
    m = 0
    for k in keys:
        m |= BIT[k]
    return m


def keys_of(mask: int) -> list[str]:
    return [k for k in KEYS if mask & BIT[k]]


@dataclass(slots=True)
class GuildCfg:
    enabled: bool = False
    autorec: bool = False
    betrayal: bool = False
    owneronly: bool = False
    barrier: int = 0
    log: int = 0
    mods: int = ALL_MASK                                   # enabled-module bitmask
    limits: dict = field(default_factory=dict)             # key -> int overrides
    wl: dict = field(default_factory=dict)                 # user_id -> module bitmask
    mainroles: set = field(default_factory=set)
    punish: str = "ban"                                    # ban | kick | timeout | strip

    def limit(self, key: str) -> int:
        return self.limits.get(key, DEFAULT_LIMITS[key])


# ------------------------------------------------------------------ state
_cfg: dict[int, GuildCfg] = {}
_db: aiosqlite.Connection | None = None


def peek(guild_id: int) -> GuildCfg | None:
    """Hot path: pure dict lookup. None = guild never configured."""
    return _cfg.get(guild_id)


def get(guild_id: int) -> GuildCfg:
    """Read-only access for commands (returns a throw-away default when unconfigured)."""
    return _cfg.get(guild_id) or GuildCfg()


def _mut(guild_id: int) -> GuildCfg:
    cfg = _cfg.get(guild_id)
    if cfg is None:
        cfg = _cfg[guild_id] = GuildCfg()
    return cfg


# ------------------------------------------------------------------ load
async def load() -> None:
    """Open the DB, create tables, migrate the legacy anti.db once, load everything."""
    global _db
    if _db is not None:
        return
    os.makedirs("db", exist_ok=True)
    db = await aiosqlite.connect(DB_PATH)
    for pragma in ("journal_mode=WAL", "synchronous=NORMAL", "temp_store=MEMORY"):
        try:
            await db.execute(f"PRAGMA {pragma}")
        except Exception:
            pass
    await db.executescript(
        """
        CREATE TABLE IF NOT EXISTS guilds (
            guild_id INTEGER PRIMARY KEY, enabled INTEGER DEFAULT 0, autorec INTEGER DEFAULT 0,
            betrayal INTEGER DEFAULT 0, owneronly INTEGER DEFAULT 0, barrier INTEGER DEFAULT 0,
            log INTEGER DEFAULT 0, mods INTEGER, limits TEXT DEFAULT '{}', punish TEXT DEFAULT 'ban');
        CREATE TABLE IF NOT EXISTS wl (
            guild_id INTEGER, user_id INTEGER, mask INTEGER, PRIMARY KEY (guild_id, user_id));
        CREATE TABLE IF NOT EXISTS mainroles (
            guild_id INTEGER, role_id INTEGER, PRIMARY KEY (guild_id, role_id));
        CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
        """
    )
    try:                                                # V40: punishment type column for existing databases
        await db.execute("ALTER TABLE guilds ADD COLUMN punish TEXT DEFAULT 'ban'")
    except Exception:
        pass
    await db.commit()
    _db = db
    await _migrate_legacy()

    async with db.execute(
        "SELECT guild_id, enabled, autorec, betrayal, owneronly, barrier, log, mods, limits, punish FROM guilds"
    ) as cur:
        for gid, en, ar, bg, oo, bar, log, mods, lim, pun in await cur.fetchall():
            try:
                limits = {k: int(v) for k, v in json.loads(lim or "{}").items() if k in BIT}
            except Exception:
                limits = {}
            m = ALL_MASK if mods is None else int(mods) & ALL_MASK
            if m == OLD_ALL_MASK:                       # V40: servers with everything on get Anti Link Role on too
                m = ALL_MASK
            _cfg[gid] = GuildCfg(bool(en), bool(ar), bool(bg), bool(oo), bar or 0, log or 0, m, limits)
            _cfg[gid].punish = pun if pun in PUNISHMENTS else "ban"
    async with db.execute("SELECT guild_id, user_id, mask FROM wl") as cur:
        for gid, uid, mask in await cur.fetchall():
            m = int(mask) & ALL_MASK
            if m == OLD_ALL_MASK:                       # fully trusted before V40 -> still fully trusted
                m = ALL_MASK
            _mut(gid).wl[uid] = m
    async with db.execute("SELECT guild_id, role_id FROM mainroles") as cur:
        for gid, rid in await cur.fetchall():
            _mut(gid).mainroles.add(rid)


# old anti.db whitelist column -> new module keys
_LEGACY_WL = {
    "ban": ("ban", "unban"), "kick": ("kick",), "prune": ("prune",), "botadd": ("botadd",),
    "serverup": ("serverup",), "memup": ("memup",), "chcr": ("chcr",), "chdl": ("chdl",),
    "chup": ("chup",), "rlcr": ("rlcr",), "rlup": ("rlup",), "rldl": ("rldl",),
    "meneve": ("everyone",), "mngweb": ("webhook", "integration"), "mngstemo": ("emoji",),
}


async def _migrate_legacy() -> None:
    """One-time import of the previous antinuke (enabled servers, whitelist, mainroles,
    extraowners) so upgrading never leaves a protected server unprotected."""
    db = _db
    async with db.execute("SELECT v FROM meta WHERE k = 'legacy_done'") as cur:
        if await cur.fetchone():
            return
    if os.path.exists(LEGACY_DB):
        try:
            old = await aiosqlite.connect(LEGACY_DB)
            try:
                async def rows(sql):
                    try:
                        async with old.execute(sql) as c:
                            return await c.fetchall()
                    except Exception:
                        return []

                for gid, status in await rows("SELECT guild_id, status FROM antinuke"):
                    if status:
                        await db.execute(
                            "INSERT OR IGNORE INTO guilds (guild_id, enabled, mods, limits) VALUES (?, 1, ?, '{}')",
                            (gid, ALL_MASK))
                cols = list(_LEGACY_WL)
                for r in await rows(f"SELECT guild_id, user_id, {', '.join(cols)} FROM whitelisted_users"):
                    keys = [k for c, v in zip(cols, r[2:]) if v for k in _LEGACY_WL[c]]
                    if keys:
                        await db.execute("INSERT OR IGNORE INTO wl (guild_id, user_id, mask) VALUES (?, ?, ?)",
                                         (r[0], r[1], mask_of(keys)))
                for gid, rid in await rows("SELECT guild_id, role_id FROM mainroles"):
                    await db.execute("INSERT OR IGNORE INTO mainroles (guild_id, role_id) VALUES (?, ?)", (gid, rid))
                for gid, uid in await rows("SELECT guild_id, owner_id FROM extraowners"):
                    if uid:
                        await db.execute("INSERT OR IGNORE INTO wl (guild_id, user_id, mask) VALUES (?, ?, ?)",
                                         (gid, uid, ALL_MASK))
            finally:
                await old.close()
        except Exception:
            pass
    await db.execute("INSERT OR REPLACE INTO meta (k, v) VALUES ('legacy_done', '1')")
    await db.commit()


# ------------------------------------------------------------------ writes
async def save(guild_id: int) -> None:
    cfg = _mut(guild_id)
    await _db.execute(
        "INSERT OR REPLACE INTO guilds (guild_id, enabled, autorec, betrayal, owneronly, barrier, log, mods, limits, punish) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (guild_id, cfg.enabled, cfg.autorec, cfg.betrayal, cfg.owneronly, cfg.barrier, cfg.log,
         cfg.mods, json.dumps(cfg.limits), cfg.punish))
    await _db.commit()


async def update(guild_id: int, **fields) -> GuildCfg:
    cfg = _mut(guild_id)
    for k, v in fields.items():
        setattr(cfg, k, v)
    await save(guild_id)
    return cfg


async def set_limits(guild_id: int, keys, amount: int) -> None:
    cfg = _mut(guild_id)
    for k in keys:
        cfg.limits[k] = amount
    await save(guild_id)


async def set_wl(guild_id: int, user_id: int, mask: int) -> None:
    cfg = _mut(guild_id)
    mask &= ALL_MASK
    if mask:
        cfg.wl[user_id] = mask
        await _db.execute("INSERT OR REPLACE INTO wl (guild_id, user_id, mask) VALUES (?, ?, ?)",
                          (guild_id, user_id, mask))
    else:
        cfg.wl.pop(user_id, None)
        await _db.execute("DELETE FROM wl WHERE guild_id = ? AND user_id = ?", (guild_id, user_id))
    await _db.commit()


async def add_mainrole(guild_id: int, role_id: int) -> bool:
    cfg = _mut(guild_id)
    if role_id in cfg.mainroles:
        return False
    cfg.mainroles.add(role_id)
    await _db.execute("INSERT OR IGNORE INTO mainroles (guild_id, role_id) VALUES (?, ?)", (guild_id, role_id))
    await _db.commit()
    return True


async def remove_mainrole(guild_id: int, role_id: int) -> bool:
    cfg = _mut(guild_id)
    if role_id not in cfg.mainroles:
        return False
    cfg.mainroles.discard(role_id)
    await _db.execute("DELETE FROM mainroles WHERE guild_id = ? AND role_id = ?", (guild_id, role_id))
    await _db.commit()
    return True


async def reset_mainroles(guild_id: int) -> None:
    _mut(guild_id).mainroles.clear()
    await _db.execute("DELETE FROM mainroles WHERE guild_id = ?", (guild_id,))
    await _db.commit()


async def wipe(guild_id: int) -> None:
    """`antinuke disable`: remove every setting, whitelist entry and mainrole of the guild."""
    _cfg.pop(guild_id, None)
    for table in ("guilds", "wl", "mainroles"):
        await _db.execute(f"DELETE FROM {table} WHERE guild_id = ?", (guild_id,))
    await _db.commit()


# Used by the emergency command to pause protection temporarily and restore it.
async def pause(guild_id: int) -> bool:
    cfg = _cfg.get(guild_id)
    if cfg is None or not cfg.enabled:
        return False
    await update(guild_id, enabled=False)
    return True


async def resume(guild_id: int) -> None:
    await update(guild_id, enabled=True)
