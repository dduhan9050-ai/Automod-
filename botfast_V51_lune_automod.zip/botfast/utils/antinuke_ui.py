"""Components V2 builders for the antinuke module. Every container uses accent #ffffff."""
from __future__ import annotations

from typing import Optional

import discord
from discord.ext import commands

WHITE = discord.Colour(0xFFFFFF)
OK = "<:emoji_4:1566043104551768114>"        # <:emoji_4:1566043104551768114>
NO = "<a:emoji_38:1567096105299214336>"        # <a:cross:1567096105299214336>
ARROW = "\u276f"     # ❯
TICK = "<a:emoji_39:1567099222103294022>"      # ▶
CORNER = "\u2570"    # ╰
NO_PING = discord.AllowedMentions.none()
BS = discord.ButtonStyle
LEGEND = "```<..> <required> | [..] [optional]```"


# ---------------------------------------------------------------- primitives
def text(content: str) -> discord.ui.TextDisplay:
    return discord.ui.TextDisplay((content or "\u200b")[:3990])


def sep() -> discord.ui.Separator:
    return discord.ui.Separator()


def box(*children) -> discord.ui.Container:
    return discord.ui.Container(*children, accent_colour=WHITE)


def view_of(*children, timeout: float | None = None) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView(timeout=timeout)
    view.add_item(box(*children))
    return view


def with_thumb(body: str, url: Optional[str]):
    if url:
        return discord.ui.Section(text(body), accessory=discord.ui.Thumbnail(media=url))
    return text(body)


def button(label, style, callback, *, emoji=None, disabled=False) -> discord.ui.Button:
    b = discord.ui.Button(label=label, style=style, emoji=emoji, disabled=disabled)
    b.callback = callback
    return b


def row(*items) -> discord.ui.ActionRow:
    r = discord.ui.ActionRow()
    for item in items:
        r.add_item(item)
    return r


# ---------------------------------------------------------------- one-shot replies
def ok(title: str, body: str = "") -> discord.ui.LayoutView:
    return view_of(text(f"{OK} **{title}**" + (f"\n{CORNER} {body}" if body else "")))


def fail(title: str, body: str = "") -> discord.ui.LayoutView:
    return view_of(text(f"{NO} **{title}**" + (f"\n{CORNER} {body}" if body else "")))


def toggled(title: str, on: bool, body_on: str, body_off: str) -> discord.ui.LayoutView:
    return (ok if on else fail)(f"{title} {'Enabled' if on else 'Disabled'}", body_on if on else body_off)


def usage_line(prefix: str, command: commands.Command) -> str:
    sig = (command.signature or "").strip()
    return f"{prefix}{command.qualified_name}" + (f" {sig}" if sig else "")


# ---------------------------------------------------------------- help views
def command_help_view(prefix: str, command: commands.Command) -> discord.ui.LayoutView:
    desc = command.description or command.short_doc or command.help or "No description provided."
    lines = [LEGEND, f"> **`{usage_line(prefix, command)}`**\n"]
    if command.aliases:
        lines.append(f"{ARROW} **Aliases :** " + " ".join(f"`{a}`" for a in command.aliases))
    lines.append(f"{ARROW} {desc}")
    return view_of(text("\n".join(lines)))


def usage_notice(prefix: str, command: commands.Command) -> discord.ui.LayoutView:
    return command_help_view(prefix, command)


def not_found_view(prefix: str, matches: list) -> discord.ui.LayoutView:
    parts = [text(f"{NO} **Command Not Found**")]
    if matches:
        blocks = [f"`{usage_line(prefix, c)}`\n{ARROW} {c.short_doc or c.help or ''}" for c in matches]
        parts += [sep(), text("**Did you mean:**\n\n" + "\n\n".join(blocks))]
    else:
        parts.append(text("No similar commands were found."))
    return view_of(*parts)


class BaseView(discord.ui.LayoutView):
    """Owner-locked view that disables itself on timeout."""

    def __init__(self, ctx: commands.Context, timeout: float = 120):
        super().__init__(timeout=timeout)
        self.ctx = ctx
        self.author_id = ctx.author.id
        self.guild = ctx.guild
        self.message: Optional[discord.Message] = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == self.author_id:
            return True
        await interaction.response.send_message("Only the person who ran this command can use this.",
                                                ephemeral=True)
        return False

    async def on_timeout(self) -> None:
        if self.message is None:
            return
        try:
            for child in self.walk_children():
                if hasattr(child, "disabled"):
                    child.disabled = True
            await self.message.edit(view=self, allowed_mentions=NO_PING)
        except Exception:
            pass

    async def close(self, interaction: discord.Interaction) -> None:
        self.stop()
        try:
            await interaction.response.defer()
            await interaction.message.delete()
        except Exception:
            pass


class PagerView(BaseView):
    """« ‹ <:bin:1567102784552304640> › » pager. `pages` is a list of already-formatted markdown strings."""

    def __init__(self, ctx, head: str, pages: list[str], *, legend: bool = False):
        super().__init__(ctx)
        self.head, self.pages, self.legend = head, pages or ["\u200b"], legend
        self.page = 0
        self.build()

    def build(self) -> None:
        self.clear_items()
        last = len(self.pages) - 1
        parts = [text(self.head)]
        if self.legend:
            parts.append(text(LEGEND))
        parts += [text(self.pages[self.page]),
                  text(f"-# Page {self.page + 1}/{len(self.pages)} | Requested by {self.ctx.author.display_name}")]
        self.add_item(box(*parts))

        async def go(i, page):
            self.page = max(0, min(last, page))
            self.build()
            await i.response.edit_message(view=self)

        async def first(i): await go(i, 0)
        async def prev(i): await go(i, self.page - 1)
        async def nxt(i): await go(i, self.page + 1)
        async def end(i): await go(i, last)
        async def trash(i): await self.close(i)

        lo, hi = self.page <= 0, self.page >= last
        self.add_item(row(
            button(None, BS.secondary, first, emoji="<:icon_2:1567113746374197318>", disabled=lo),
            button(None, BS.secondary, prev, emoji="<:left:1567104063240146984>", disabled=lo),
            button(None, BS.secondary, trash, emoji="<:bin:1567102784552304640>"),
            button(None, BS.secondary, nxt, emoji="<:right:1567104038284034058>", disabled=hi),
            button(None, BS.secondary, end, emoji="<:icon_3:1567113772852838410>", disabled=hi),
        ))


def group_help_view(ctx: commands.Context, group: commands.Group, per_page: int = 7, extra_pages: list | None = None):
    subs = sorted((c for c in group.commands if not c.hidden), key=lambda c: c.name)
    prefix = ctx.clean_prefix
    entries = [f"> **`{usage_line(prefix, c).split(' <')[0].split(' [')[0]}`**\n"
               f"{ARROW} {c.short_doc or c.help or 'No description provided.'}" for c in subs]
    pages = ["\n\n".join(entries[i:i + per_page]) for i in range(0, len(entries), per_page)]
    pages += list(extra_pages or ())                 # module sections (e.g. Anti Bot Nuker) live in the same menu
    head = f"## {ctx.bot.user.name} {group.qualified_name} [{len(subs)}]"
    return PagerView(ctx, head, pages, legend=True)
