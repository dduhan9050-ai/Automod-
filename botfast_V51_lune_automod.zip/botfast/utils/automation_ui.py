"""Shared Components V2 builders (panels + « ‹ <:bin:1567102784552304640> › » pager) used by several help pages."""
from __future__ import annotations

import discord

OK = "<:emoji_4:1566043104551768114>"        # <:emoji_4:1566043104551768114>
FAIL = "❎"      # ❎
WARN = "<a:emoji_250:1567101252712530020>"  # <a:warn:1567101252712530020>
GEAR = "<a:emoji_9:1566444878303461566>"  # <a:gear:1566444878303461566>
ARROW = "❯"     # ❯
DOT = "<a:whitearrow:1567140354833129472>"   # <a:whitearrow:1567140354833129472>

from utils.config import OWNER_IDS  # bot owners may use any panel


def _text(content: str) -> discord.ui.TextDisplay:
    return discord.ui.TextDisplay((content or "​")[:3990])


def _container(*children) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView(timeout=None)
    box = discord.ui.Container()
    for child in children:
        box.add_item(child)
    view.add_item(box)
    return view


# --------------------------------------------------------------------------
# Small result panels (Autorole Added / Removed / Permission Error ...)
# --------------------------------------------------------------------------
def panel(icon: str, title: str, *blocks: str) -> discord.ui.LayoutView:
    body = "\n\n".join(b for b in blocks if b)
    return _container(_text(f"### {icon} {title}\n\n{body}" if body else f"### {icon} {title}"))


def success(title: str, *blocks: str) -> discord.ui.LayoutView:
    return panel(OK, title, *blocks)


def error(title: str, *blocks: str) -> discord.ui.LayoutView:
    return panel(FAIL, title, *blocks)


def warning(title: str, *blocks: str) -> discord.ui.LayoutView:
    return panel(WARN, title, *blocks)


def note(text: str) -> str:
    return f"{ARROW} {text}"


def label(name: str, value: str, icon: str = GEAR) -> str:
    return f"{icon} __**{name}:**__ {value}"


# --------------------------------------------------------------------------
# Group help (BOTNAME AUTOROLE GROUP) with the « ‹ <:bin:1567102784552304640> › » pager
# --------------------------------------------------------------------------
def _usage(prefix: str, command) -> str:
    sig = (command.signature or "").strip()
    return f"{prefix}{command.qualified_name}" + (f" {sig}" if sig else "")


def _entry(prefix: str, command) -> str:
    desc = command.short_doc or command.help or "No description provided."
    return f"> `{_usage(prefix, command)}`\n> {ARROW} {desc}"


def _ordered(group) -> list:
    order = (getattr(group, "extras", None) or {}).get("help_order")
    subs = [c for c in group.commands if not c.hidden]
    if order:
        rank = {name: i for i, name in enumerate(order)}
        return sorted(subs, key=lambda c: (rank.get(c.name, len(rank)), c.name))
    return sorted(subs, key=lambda c: c.name)


class _PagerButton(discord.ui.Button):
    def __init__(self, action: str, **kwargs):
        super().__init__(style=discord.ButtonStyle.secondary, **kwargs)
        self.action = action

    async def callback(self, interaction: discord.Interaction):
        await self.view.handle(interaction, self.action)


class GroupHelpView(discord.ui.LayoutView):
    def __init__(self, ctx, title: str, entries: list[str], per_page: int = 4, accent: int | None = None):
        super().__init__(timeout=120)
        self.ctx = ctx
        self.accent = accent
        self.owner_id = ctx.author.id
        self.heading = title
        self.pages = [entries[i:i + per_page] for i in range(0, len(entries), per_page)] or [[]]
        self.index = 0
        self.expired = False
        self.message: discord.Message | None = None
        self._build()

    def _build(self) -> None:
        self.clear_items()
        last = len(self.pages) - 1
        off = self.expired
        row = discord.ui.ActionRow()
        row.add_item(_PagerButton("first", emoji="<:icon_2:1567113746374197318>", disabled=off or self.index == 0))
        row.add_item(_PagerButton("prev", emoji="<:left:1567104063240146984>", disabled=off or self.index == 0))
        row.add_item(_PagerButton("stop", emoji="<:bin:1567102784552304640>", disabled=off))
        row.add_item(_PagerButton("next", emoji="<:right:1567104038284034058>", disabled=off or self.index == last))
        row.add_item(_PagerButton("last", emoji="<:icon_3:1567113772852838410>", disabled=off or self.index == last))
        box = discord.ui.Container(accent_colour=discord.Colour(self.accent)) if self.accent else discord.ui.Container()
        box.add_item(_text(f"## {self.heading}"))
        box.add_item(discord.ui.Separator())
        box.add_item(_text("\n\n".join(self.pages[self.index])))
        box.add_item(discord.ui.Separator())
        box.add_item(_text(f"-# Requested by {self.ctx.author.name} | Page {self.index + 1}/{len(self.pages)}"))
        box.add_item(discord.ui.Separator())
        box.add_item(row)
        self.add_item(box)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user and (interaction.user.id == self.owner_id or interaction.user.id in OWNER_IDS):
            return True
        await interaction.response.send_message(
            "Uh oh! That message doesn't belong to you.\nYou must run this command to interact with it.",
            ephemeral=True)
        return False

    async def handle(self, interaction: discord.Interaction, action: str) -> None:
        if action == "stop":
            self.stop()
            try:
                await interaction.response.defer()
                await interaction.message.delete()
            except discord.HTTPException:
                pass
            return
        last = len(self.pages) - 1
        self.index = {"first": 0, "prev": max(0, self.index - 1),
                      "next": min(last, self.index + 1), "last": last}[action]
        self._build()
        await interaction.response.edit_message(view=self)

    async def on_timeout(self) -> None:
        self.expired = True
        if self.message is None:
            return
        try:
            self._build()
            await self.message.edit(view=self)
        except Exception:
            pass


async def send_group_help(ctx, group, accent: int | None = None) -> None:
    prefix = ctx.clean_prefix
    entries = [_entry(prefix, c) for c in _ordered(group)]
    title = f"{ctx.bot.user.name} {group.qualified_name} Group".upper()
    view = GroupHelpView(ctx, title, entries, accent=accent)
    view.message = await ctx.send(view=view)


async def send_command_help(ctx, command) -> None:
    prefix = ctx.clean_prefix
    desc = command.short_doc or command.help or "No description provided."
    await ctx.reply(view=_container(_text(
        f"### {WARN} Invalid Usage\n\n"
        f"> `{_usage(prefix, command)}`\n> {ARROW} {desc}\n\n"
        f"-# `<>` required • `[]` optional")), mention_author=False)
