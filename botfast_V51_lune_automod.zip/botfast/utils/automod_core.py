"""Automod core constants (port of Lune's ``src/automod/AutoModManager.js`` definitions).

Lune's automod does NOT scan messages itself: it creates and manages *native Discord AutoMod rules*
and reacts to the ``AUTO_MODERATION_ACTION_EXECUTION`` gateway event.  Four rule types exist.
"""
from __future__ import annotations

import discord

# type id -> (label, description, trigger type).  Order = order everywhere in the UI.
RULE_TYPES = {
    "keyword": {
        "label": "Keyword",
        "desc": "Flags messages containing blocked words",
        "trigger": discord.AutoModRuleTriggerType.keyword,
    },
    "spam": {
        "label": "Spam",
        "desc": "Detects and blocks spam / message flooding",
        "trigger": discord.AutoModRuleTriggerType.spam,
    },
    "mention": {
        "label": "Mention Spam",
        "desc": "Blocks messages that mass-mention users",
        "trigger": discord.AutoModRuleTriggerType.mention_spam,
    },
    "preset": {
        "label": "Profanity",
        "desc": "Flags profanity, sexual content and slurs",
        "trigger": discord.AutoModRuleTriggerType.keyword_preset,
    },
}
TYPES = tuple(RULE_TYPES)

MODULE_STATES = {
    "disabled": "Disabled",
    "pending": "Pending",
    "loading": "Loading",
    "error": "Error",
    "ready": "Ready",
}

MODES = ("block", "timeout", "alert")
MODE_LABEL = {"block": "Block message", "timeout": "Timeout", "alert": "Alert only"}

# Discord only allows the TIMEOUT action on keyword + mention-spam rules.
TIMEOUT_TYPES = frozenset({"keyword", "mention"})

DEFAULT_KEYWORDS = ["discord.gg/*"]          # Lune default when no keyword was configured
DEFAULT_TIMEOUT_SECONDS = 600
MAX_TIMEOUT_SECONDS = 2_419_200              # Discord limit: 4 weeks
DEFAULT_MENTION_LIMIT = 5
MAX_EXEMPT_ROLES = 20                        # Discord limits
MAX_EXEMPT_CHANNELS = 25                     # Discord allows 50; UI select menus cap at 25

ESCALATION_COUNT = 5                         # Lune: 5 violations ...
ESCALATION_WINDOW = 10 * 60                  # ... within 10 minutes ...
ESCALATION_TIMEOUT = 60 * 60                 # ... = 1 hour timeout
DEDUPE_SECONDS = 3.0                         # alert + block of the same message count once
VIOLATION_KEEP_DAYS = 30

TRIGGER_TO_TYPE = {d["trigger"]: k for k, d in RULE_TYPES.items()}


def default_action_config(bot_name: str = "Luna") -> dict:
    return {
        "mode": "block",
        "customMessage": f"Your message was removed by {bot_name} AutoMod.",
        "timeoutSeconds": DEFAULT_TIMEOUT_SECONDS,
    }


def clamp_timeout(seconds) -> int:
    try:
        value = int(seconds)
    except (TypeError, ValueError):
        return DEFAULT_TIMEOUT_SECONDS
    return max(60, min(value, MAX_TIMEOUT_SECONDS))


def fmt_duration(seconds: int) -> str:
    seconds = int(seconds)
    for unit, size in (("d", 86400), ("h", 3600), ("m", 60)):
        if seconds >= size and seconds % size == 0:
            return f"{seconds // size}{unit}"
    return f"{seconds}s"


def split_list(text: str, *, limit: int = 1000, item_max: int = 60) -> list:
    """Comma / newline separated text -> unique, trimmed items."""
    out, seen = [], set()
    for raw in (text or "").replace(",", "\n").split("\n"):
        item = raw.strip()[:item_max]
        if item and item.lower() not in seen:
            seen.add(item.lower())
            out.append(item)
        if len(out) >= limit:
            break
    return out
