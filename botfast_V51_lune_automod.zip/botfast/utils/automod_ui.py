"""Automod dashboard (port of Lune's ``src/automod/dashboard.js`` + ``handler.js``).

One Components V2 container (#ffffff, like every botfast reply) with 8 pages and a 2-row navigation:
Overview, Modules, Configure, Rules, Exclusions, Stats, Settings, Logs.  Only the person who ran the
command can press the controls.  ``send_group_help`` / ``send_command_help`` are used by ``help.py``.
"""
from __future__ import annotations

import math
from typing import Optional

import discord

from utils.automod_core import (
    DEFAULT_MENTION_LIMIT, DEFAULT_TIMEOUT_SECONDS, MAX_EXEMPT_CHANNELS, MAX_EXEMPT_ROLES, MODE_LABEL,
    MODULE_STATES, RULE_TYPES, TIMEOUT_TYPES, TYPES, clamp_timeout, fmt_duration, split_list,
)

WHITE = discord.Colour(0xFFFFFF)
ARROW = "❯"
TICK, CROSS = "<:emoji_4:1566043104551768114>", "<a:emoji_38:1567096105299214336>"
WARN = "<a:emoji_250:1567101252712530020>"
NO_PING = discord.AllowedMentions.none()
LEGEND = "`<..> <required> | [..] [optional]`"
PER_PAGE = 7

PAGES = (
    ("overview", "Overview"), ("modules", "Modules"), ("configure", "Configure"), ("rules", "Rules"),
    ("exclusions", "Exclusions"), ("stats", "Stats"), ("settings", "Settings"), ("logs", "Logs"),
)


# ------------------------------------------------------------------ building blocks
def _t(text: str) -> discord.ui.TextDisplay:
    return discord.ui.TextDisplay((text or "​")[:3990])


def box(*children, timeout: Optional[float] = None) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView(timeout=timeout)
    container = discord.ui.Container(accent_colour=WHITE)
    for child in children:
        container.add_item(child)
    view.add_item(container)
    return view


def card(title: str, body: str = "") -> discord.ui.LayoutView:
    return box(_t(f"## {title}" + (f"\n{body}" if body else "")))


def ok(title: str, body: str = "") -> discord.ui.LayoutView:
    return card(f"{TICK} {title}", body)


def fail(title: str, body: str = "") -> discord.ui.LayoutView:
    return card(f"{CROSS} {title}", body)


def _row(*items) -> discord.ui.ActionRow:
    row = discord.ui.ActionRow()
    for item in items:
        row.add_item(item)
    return row


def _button(label: str, style: discord.ButtonStyle, handler, *, emoji=None, disabled=False) -> discord.ui.Button:
    btn = discord.ui.Button(label=label or None, style=style, emoji=emoji, disabled=disabled)
    btn.callback = handler
    return btn


def state_emoji(state: str) -> str:
    return {"ready": TICK, "disabled": "⛔", "loading": "⏳", "error": CROSS}.get(state, "🔄")


def _defaults(ids, getter, kind):
    out = []
    for i in sorted(ids):
        if getter(i) is not None:
            out.append(discord.SelectDefaultValue(id=i, type=kind))
    return out[:25]


class _View(discord.ui.LayoutView):
    """Base: only the command author may press things; controls are disabled on timeout."""

    def __init__(self, ctx, timeout: float = 300):
        super().__init__(timeout=timeout)
        self.ctx = ctx
        self.message: Optional[discord.Message] = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.ctx.author.id:
            await interaction.response.send_message(
                view=fail("Not Your Menu", "You must run this command to interact with it."), ephemeral=True)
            return False
        return True

    async def on_timeout(self) -> None:
        if self.message is None:
            return
        try:
            for item in self.walk_children():
                if hasattr(item, "disabled"):
                    item.disabled = True
            await self.message.edit(view=self)
        except Exception:
            pass


# ------------------------------------------------------------------ Advanced modal (per rule)
class AdvancedModal(discord.ui.Modal):
    """Lune's "Advanced" button: message / timeout length and the rule specific lists."""

    def __init__(self, dash: "Dashboard", typ: str):
        super().__init__(title=f"Advanced · {RULE_TYPES[typ]['label']}"[:45], timeout=300)
        self.dash, self.typ = dash, typ
        cfg = dash.rule(typ).action
        self.message = discord.ui.TextInput(
            label="Custom block message", default=str(cfg.get("customMessage") or "")[:150], max_length=150,
            required=False, placeholder="Shown to the user when a message is blocked")
        self.add_item(self.message)
        self.timeout_s = None
        if typ in TIMEOUT_TYPES:
            self.timeout_s = discord.ui.TextInput(
                label="Timeout length (seconds, 60 - 2419200)",
                default=str(cfg.get("timeoutSeconds") or DEFAULT_TIMEOUT_SECONDS), max_length=8, required=False)
            self.add_item(self.timeout_s)
        self.limit = self.keywords = self.allow = self.regex = None
        if typ == "mention":
            self.limit = discord.ui.TextInput(
                label="Mention limit per message (1 - 50)",
                default=str(cfg.get("mentionLimit") or DEFAULT_MENTION_LIMIT), max_length=2, required=False)
            self.add_item(self.limit)
        if typ == "keyword":
            self.keywords = discord.ui.TextInput(
                label="Blocked keywords (comma / new line, * wildcard)", style=discord.TextStyle.paragraph,
                default=", ".join(cfg.get("keywords") or [])[:1500], max_length=1500, required=False,
                placeholder="empty = discord.gg/*")
            self.allow = discord.ui.TextInput(
                label="Allowed words (never blocked)", style=discord.TextStyle.paragraph,
                default=", ".join(cfg.get("allowlist") or [])[:1000], max_length=1000, required=False)
            self.regex = discord.ui.TextInput(
                label="Regex patterns (one per line, max 10)", style=discord.TextStyle.paragraph,
                default=str(cfg.get("regex") or "")[:1000], max_length=1000, required=False)
            for item in (self.keywords, self.allow, self.regex):
                self.add_item(item)
        if typ == "preset":
            self.allow = discord.ui.TextInput(
                label="Allowed words (never blocked)", style=discord.TextStyle.paragraph,
                default=", ".join(cfg.get("allowlist") or [])[:1000], max_length=1000, required=False)
            self.add_item(self.allow)

    async def on_submit(self, interaction: discord.Interaction):
        update = {}
        text = self.message.value.strip()
        if text:
            update["customMessage"] = text[:150]
        if self.timeout_s is not None and self.timeout_s.value.strip():
            update["timeoutSeconds"] = clamp_timeout(self.timeout_s.value.strip())
        if self.limit is not None and self.limit.value.strip():
            try:
                update["mentionLimit"] = max(1, min(int(self.limit.value.strip()), 50))
            except ValueError:
                pass
        if self.keywords is not None:
            update["keywords"] = split_list(self.keywords.value, limit=1000)
            update["regex"] = "\n".join(
                line.strip()[:260] for line in self.regex.value.splitlines() if line.strip())
        if self.allow is not None:
            update["allowlist"] = split_list(self.allow.value, limit=100 if self.typ == "keyword" else 1000)
        await interaction.response.defer()
        await self.dash.store.update_rule_config(self.dash.ctx.guild, self.typ, **update)
        self.dash.page, self.dash.type = "configure", self.typ
        await self.dash.refresh(interaction)


# ------------------------------------------------------------------ the dashboard
class Dashboard(_View):
    def __init__(self, ctx, store, page: str = "overview", typ: str = "keyword"):
        super().__init__(ctx)
        self.store = store
        self.page = page if page in dict(PAGES) else "overview"
        self.type = typ if typ in RULE_TYPES else "keyword"

    # ---- helpers
    @property
    def guild(self) -> discord.Guild:
        return self.ctx.guild

    @property
    def bot_name(self) -> str:
        return self.ctx.bot.user.name

    def rule(self, typ: Optional[str] = None):
        return self.store.get_rules(self.guild.id)[typ or self.type]

    async def start(self):
        await self.store.ensure_rules(self.guild.id)
        await self.render()
        self.message = await self.ctx.reply(view=self, mention_author=False, allowed_mentions=NO_PING)
        return self.message

    async def refresh(self, interaction: discord.Interaction) -> None:
        await self.render()
        if interaction.response.is_done():
            await interaction.edit_original_response(view=self)
        else:
            await interaction.response.edit_message(view=self)

    def _header(self) -> list:
        return [_t(f"# {self.bot_name} AutoMod\nPolicy-based content filtering"), discord.ui.Separator()]

    # ---- navigation row
    def _nav(self) -> list:
        def make(slice_):
            buttons = []
            for key, label in slice_:
                style = discord.ButtonStyle.primary if key == self.page else discord.ButtonStyle.secondary
                buttons.append(_button(label, style, self._go(key)))
            return _row(*buttons)
        return [make(PAGES[:4]), make(PAGES[4:])]

    def _go(self, key: str):
        async def handler(interaction: discord.Interaction):
            self.page = key
            await self.refresh(interaction)
        return handler

    def _module_select(self, handler) -> discord.ui.ActionRow:
        sel = discord.ui.Select(
            placeholder="Select a module to manage...", min_values=1, max_values=1,
            options=[discord.SelectOption(label=d["label"], description=d["desc"][:100], value=t,
                                          default=(t == self.type and self.page in ("configure", "exclusions")))
                     for t, d in RULE_TYPES.items()])
        sel.callback = handler
        return _row(sel)

    # ---- render
    async def render(self) -> None:
        self.clear_items()
        container = discord.ui.Container(accent_colour=WHITE)
        for item in self._header():
            container.add_item(item)
        builder = getattr(self, f"_page_{self.page}")
        for item in await builder():
            container.add_item(item)
        for row in self._nav():
            container.add_item(row)
        self.add_item(container)

    # ---- pages
    async def _page_overview(self) -> list:
        cfg = self.store.guild(self.guild.id)
        rules = self.store.get_rules(self.guild.id)
        stats = await self.store.get_stats(self.guild.id, 7)
        status = "**ENABLED**" if cfg.enabled else "**PAUSED**"
        intro = (f"**Status:** {status}\n**Rules:** {len(rules)} configured\n\n"
                 "Protect your server with native Discord AutoMod rules — keyword, spam, mention and profanity "
                 "filtering. Configure, preview and manage rules from one dashboard.")
        items: list = []
        try:
            items.append(discord.ui.Section(
                _t(intro), accessory=discord.ui.Thumbnail(self.ctx.bot.user.display_avatar.url)))
        except Exception:
            items.append(_t(intro))
        lines = []
        for typ, definition in RULE_TYPES.items():
            rule = rules.get(typ)
            label = "Disabled" if (rule is not None and not rule.enabled) else "Active"
            lines.append(f"> {state_emoji(rule.state if rule else 'disabled')} **{definition['label']}** — {label}")
        items += [_t("**Modules**\n" + "\n".join(lines)), discord.ui.Separator(), _t(
            f"**7-day totals** — Blocked: **{stats['blocked']}** · Timeouts: **{stats['timeouts']}** · "
            f"Alerts: **{stats['alerts']}**\nUse the navigation below to manage modules and settings.")]
        items.append(_row(_button("Pause All" if cfg.enabled else "Resume All",
                                  discord.ButtonStyle.danger if cfg.enabled else discord.ButtonStyle.success,
                                  self._toggle_all)))
        return items

    async def _toggle_all(self, interaction: discord.Interaction):
        cfg = self.store.guild(self.guild.id)
        cfg.enabled = not cfg.enabled
        await self.store.save_guild(self.guild.id)
        await self.refresh(interaction)

    async def _page_modules(self) -> list:
        rules = self.store.get_rules(self.guild.id)
        blocks = []
        for typ, definition in RULE_TYPES.items():
            state = rules[typ].state if typ in rules else "pending"
            blocks.append(f"> {state_emoji(state)} **{definition['label']}** — "
                          f"{MODULE_STATES.get(state, 'Pending')}\n{definition['desc']}")
        return [_t("**Protection Modules**\nUse the buttons to enable, disable or configure each module."),
                discord.ui.Separator(), _t("\n\n".join(blocks)), discord.ui.Separator(),
                self._module_select(self._on_module_pick)]

    async def _on_module_pick(self, interaction: discord.Interaction):
        self.type = interaction.data["values"][0]
        self.page = "configure"
        await self.refresh(interaction)

    async def _on_type_pick(self, interaction: discord.Interaction):
        self.type = interaction.data["values"][0]
        await self.refresh(interaction)

    async def _page_configure(self) -> list:
        typ = self.type
        definition, rule = RULE_TYPES[typ], self.rule()
        cfg = rule.action
        mode = rule.mode
        if mode == "block":
            action = "Block message"
        elif mode == "timeout":
            action = f"Timeout ({fmt_duration(cfg.get('timeoutSeconds') or DEFAULT_TIMEOUT_SECONDS)})"
            if typ not in TIMEOUT_TYPES:
                action += " — not supported by Discord for this module, **block** is used"
        else:
            action = "Alert only"
        lines = [f"**Module:** {state_emoji(rule.state)} {MODULE_STATES.get(rule.state, 'Pending')} · "
                 f"{'Enabled' if rule.enabled else 'Disabled'}", f"**Action:** {action}"]
        if cfg.get("customMessage"):
            lines.append(f"**Custom message:** {cfg['customMessage']}")
        if typ == "keyword":
            kws = cfg.get("keywords") or []
            lines.append("**Keywords:** " + (", ".join(f"`{k}`" for k in kws[:15]) + (" …" if len(kws) > 15 else "")
                                             if kws else "`discord.gg/*` (default)"))
        if typ == "mention":
            lines.append(f"**Mention limit:** {cfg.get('mentionLimit') or DEFAULT_MENTION_LIMIT}")
        if rule.error:
            lines.append(f"{WARN} {rule.error}")
        sec = discord.ButtonStyle.secondary
        ok_ = discord.ButtonStyle.success

        def mode_btn(key: str, label: str):
            return _button(label, ok_ if mode == key else sec, self._set_mode(key))

        return [
            _t(f"## Configure · {definition['label']}\n{definition['desc']}\n\n"
               "Select what this module should do with offending messages."),
            discord.ui.Separator(), _t("\n".join(lines)),
            self._module_select(self._on_type_pick),
            _row(mode_btn("block", "Block"), mode_btn("timeout", "Timeout"), mode_btn("alert", "Alert Only")),
            _row(_button("Disable" if rule.enabled else "Enable",
                         discord.ButtonStyle.danger if rule.enabled else ok_, self._toggle_rule),
                 _button("Advanced", sec, self._advanced),
                 _button("Back", discord.ButtonStyle.primary, self._back)),
        ]

    def _set_mode(self, mode: str):
        async def handler(interaction: discord.Interaction):
            await interaction.response.defer()
            await self.store.update_rule_config(self.guild, self.type, mode=mode)
            await self.refresh(interaction)
        return handler

    async def _toggle_rule(self, interaction: discord.Interaction):
        await interaction.response.defer()
        await self.store.toggle_rule(self.guild, self.type, not self.rule().enabled)
        await self.refresh(interaction)

    async def _advanced(self, interaction: discord.Interaction):
        await interaction.response.send_modal(AdvancedModal(self, self.type))

    async def _back(self, interaction: discord.Interaction):
        self.page = "overview"
        await self.refresh(interaction)

    async def _page_rules(self) -> list:
        rules = self.store.get_rules(self.guild.id)
        blocks = []
        for typ, definition in RULE_TYPES.items():
            rule = rules.get(typ)
            if rule is None:
                blocks.append(f"> {CROSS} **{definition['label']}** — not created")
                continue
            disc = f"`{rule.discord_id}`" if rule.discord_id else "not provisioned"
            block = (f"> {state_emoji(rule.state)} **{definition['label']}**\n"
                     f"Enabled: {'yes' if rule.enabled else 'no'} · State: **{rule.state}** · ID: {disc}")
            if rule.error:
                block += f"\n{WARN} {rule.error}"
            blocks.append(block)
        return [_t("**Created Rules**\nThese are the native Discord AutoMod rules "
                   f"{self.bot_name} manages for this server."),
                discord.ui.Separator(), _t("\n\n".join(blocks)), discord.ui.Separator(),
                _row(_button("Sync Rules to Discord", discord.ButtonStyle.primary, self._sync))]

    async def _sync(self, interaction: discord.Interaction):
        await interaction.response.defer()
        await self.store.provision(self.guild)
        await self.refresh(interaction)

    async def _page_exclusions(self) -> list:
        rule = self.rule()
        guild = self.guild
        roles = discord.ui.RoleSelect(
            placeholder="↳ Exempt roles", min_values=0, max_values=MAX_EXEMPT_ROLES,
            default_values=_defaults(rule.exempt_roles, guild.get_role, discord.SelectDefaultValueType.role))
        roles.callback = self._save_exempt("roles", roles)
        channels = discord.ui.ChannelSelect(
            placeholder="↳ Exempt channels / categories", min_values=0, max_values=MAX_EXEMPT_CHANNELS,
            channel_types=[discord.ChannelType.text, discord.ChannelType.news, discord.ChannelType.forum,
                           discord.ChannelType.voice, discord.ChannelType.stage_voice,
                           discord.ChannelType.category],
            default_values=_defaults(rule.exempt_channels, guild.get_channel,
                                     discord.SelectDefaultValueType.channel))
        channels.callback = self._save_exempt("channels", channels)
        roles_txt = ", ".join(f"<@&{i}>" for i in rule.exempt_roles) or "None"
        chans_txt = ", ".join(f"<#{i}>" for i in rule.exempt_channels) or "None"
        return [
            _t(f"## Exclusions · {RULE_TYPES[self.type]['label']}\n"
               "Roles and channels that are **not** affected by this rule.\n"
               "-# Your selection replaces the current list."),
            discord.ui.Separator(), _t(f"**Exempt Roles**\n{roles_txt}"),
            discord.ui.Separator(), _t(f"**Exempt Channels**\n{chans_txt}"),
            discord.ui.Separator(),
            self._module_select(self._on_type_pick), _row(roles), _row(channels),
        ]

    def _save_exempt(self, kind: str, select):
        async def handler(interaction: discord.Interaction):
            await interaction.response.defer()
            ids = [v.id for v in select.values]
            if kind == "roles":
                await self.store.set_exempt(self.guild, self.type, roles=ids)
            else:
                await self.store.set_exempt(self.guild, self.type, channels=ids)
            await self.refresh(interaction)
        return handler

    async def _page_stats(self) -> list:
        s7 = await self.store.get_stats(self.guild.id, 7)
        s30 = await self.store.get_stats(self.guild.id, 30)
        violations = await self.store.get_violations(self.guild.id, 8)
        recent = ("\n".join(f"> • <@{v['user_id']}> — {v['rule']} ({v['action']})" for v in violations)
                  if violations else "> No recent violations")

        def line(s):
            return (f"Blocked: **{s['blocked']}** · Warnings: **{s['warnings']}** · "
                    f"Timeouts: **{s['timeouts']}** · Alerts: **{s['alerts']}**")
        return [_t(f"**AutoMod Statistics**\nEnforcement counters tracked by {self.bot_name}."),
                discord.ui.Separator(),
                _t(f"**Last 7 days**\n{line(s7)}\n\n**Last 30 days**\n{line(s30)}"),
                discord.ui.Separator(), _t(f"**Recent Violations**\n{recent}")]

    async def _page_settings(self) -> list:
        cfg = self.store.guild(self.guild.id)
        guild = self.guild
        log = discord.ui.ChannelSelect(
            placeholder="↳ Log channel (leave empty to clear)", min_values=0, max_values=1,
            channel_types=[discord.ChannelType.text, discord.ChannelType.news],
            default_values=_defaults([cfg.log_channel] if cfg.log_channel else [], guild.get_channel,
                                     discord.SelectDefaultValueType.channel))
        log.callback = self._set_log(log)

        def toggle(label: str, attr: str):
            value = getattr(cfg, attr)
            return _button(f"{label}: {'ON' if value else 'OFF'}",
                           discord.ButtonStyle.success if value else discord.ButtonStyle.danger, self._flip(attr))

        text = (f"**Server Settings**\nLog channel: {f'<#{cfg.log_channel}>' if cfg.log_channel else 'not set'}\n"
                f"Notifications: {'on' if cfg.notifications else 'off'} · "
                f"DM offenders: {'on' if cfg.dm else 'off'}\nEscalation: {'on' if cfg.escalation else 'off'}\n"
                "-# Escalation = 5 violations within 10 minutes → 1 hour timeout.")
        return [_t(text), discord.ui.Separator(), _row(log),
                _row(toggle("Notifications", "notifications"), toggle("DM Offenders", "dm"),
                     toggle("Escalation", "escalation"))]

    def _set_log(self, select):
        async def handler(interaction: discord.Interaction):
            await interaction.response.defer()
            cfg = self.store.guild(self.guild.id)
            cfg.log_channel = select.values[0].id if select.values else None
            await self.store.save_guild(self.guild.id)
            await self.store.resync_provisioned(self.guild)      # alert channel is part of the Discord rules
            await self.refresh(interaction)
        return handler

    def _flip(self, attr: str):
        async def handler(interaction: discord.Interaction):
            cfg = self.store.guild(self.guild.id)
            setattr(cfg, attr, not getattr(cfg, attr))
            await self.store.save_guild(self.guild.id)
            await self.refresh(interaction)
        return handler

    async def _page_logs(self) -> list:
        violations = await self.store.get_violations(self.guild.id, 20)
        text = ("\n".join(f"• <@{v['user_id']}> · **{v['rule']}** · `{v['action']}` · <t:{v['ts']}:R>"
                          for v in violations) if violations else "> No logged violations yet.")
        return [_t("**Recent AutoMod Logs**\nThe latest enforcement events in this server."),
                discord.ui.Separator(), _t(text)]


# ------------------------------------------------------------------ help panels (command replies)
def _usage(prefix: str, command) -> str:
    sig = (command.signature or "").strip()
    return f"{prefix}{command.qualified_name}" + (f" {sig}" if sig else "")


def _entry(prefix: str, command) -> str:
    desc = command.short_doc or command.help or "No description provided."
    return f"> `{prefix}{command.qualified_name}`\n> {ARROW} {desc}"


class HelpPager(_View):
    """Group help: 7 commands per page with «  ‹  <:bin:1567102784552304640>  ›  » buttons."""

    def __init__(self, ctx, group):
        super().__init__(ctx)
        self.group = group
        self.subs = sorted((c for c in group.commands if not c.hidden), key=lambda c: c.name)
        self.pages = max(1, math.ceil(len(self.subs) / PER_PAGE))
        self.page = 0
        self.render()

    def render(self) -> None:
        self.clear_items()
        prefix = self.ctx.clean_prefix
        start = self.page * PER_PAGE
        entries = "\n\n".join(_entry(prefix, c) for c in self.subs[start:start + PER_PAGE])
        container = discord.ui.Container(accent_colour=WHITE)
        container.add_item(_t(f"## {self.ctx.bot.user.name} {self.group.qualified_name} [{len(self.subs)}]\n"
                              f"{LEGEND}\n\n{entries}"))
        container.add_item(discord.ui.Separator())
        container.add_item(_t(f"-# Page {self.page + 1}/{self.pages} | Requested by {self.ctx.author.name}"))
        self.add_item(container)
        first, last = self.page == 0, self.page >= self.pages - 1
        sec = discord.ButtonStyle.secondary
        self.add_item(_row(
            _button("", sec, self._go(0), emoji="<:icon_2:1567113746374197318>", disabled=first),
            _button("", sec, self._go(self.page - 1), emoji="<:left:1567104063240146984>", disabled=first),
            _button("", sec, self._delete, emoji="<:bin:1567102784552304640>"),
            _button("", sec, self._go(self.page + 1), emoji="<:right:1567104038284034058>", disabled=last),
            _button("", sec, self._go(self.pages - 1), emoji="<:icon_3:1567113772852838410>", disabled=last),
        ))

    def _go(self, page: int):
        async def handler(interaction: discord.Interaction):
            self.page = max(0, min(page, self.pages - 1))
            self.render()
            await interaction.response.edit_message(view=self)
        return handler

    async def _delete(self, interaction: discord.Interaction):
        self.stop()
        try:
            await interaction.message.delete()
        except discord.HTTPException:
            await interaction.response.defer()


def command_help_view(ctx, command) -> discord.ui.LayoutView:
    desc = command.short_doc or command.help or "No description provided."
    aliases = f"\n> **Aliases :** {', '.join(f'`{a}`' for a in command.aliases)}" if command.aliases else ""
    body = f"{LEGEND}\n\n> `{_usage(ctx.clean_prefix, command)}`\n> {ARROW} {desc}{aliases}"
    return card(command.qualified_name, body)


async def send_group_help(ctx, group) -> None:
    view = HelpPager(ctx, group)
    view.message = await ctx.reply(view=view, mention_author=False, allowed_mentions=NO_PING)


async def send_command_help(ctx, command) -> None:
    await ctx.reply(view=command_help_view(ctx, command), mention_author=False, allowed_mentions=NO_PING)
