"""Fast storage for the Autoresponder category (autoresponder + autoreact).

* Everything lives in memory, so the ``on_message`` listeners are a plain dict
  lookup: no disk access and no SQL for normal chat messages.
* Writes go to SQLite in a worker thread (one persistent connection, WAL).
* Uses the old tables (``db/autoresponder.db`` / ``db/autoreact.db``) as they
  are, so existing data keeps working.
* DB paths are resolved from this file, not from the working directory.
* A corrupt database file is moved aside instead of crashing the bot.
"""
from __future__ import annotations

import asyncio
import logging
import re
import sqlite3
import threading
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

log = logging.getLogger("autoresponder")

DB_DIR = Path(__file__).resolve().parent.parent / "db"

MAX_RESPONDERS = 20
MAX_TRIGGERS = 10
MAX_EMOJIS = 10

# --------------------------------------------------------------------------
# Emoji parsing (custom emojis + every common unicode emoji form)
# --------------------------------------------------------------------------
_BASE = (
    "[©®‼⁉™ℹ↔-↪⌚-⏿Ⓜ▪-◾"
    "☀-➿⤴⤵⬅-⭕〰〽㊗㊙\U0001F000-\U0001FAFF]"
)
_MOD = "(?:️|[\U0001F3FB-\U0001F3FF])?"
EMOJI_RE = re.compile(
    r"<a?:\w+:\d+>"                              # custom emoji
    r"|[0-9#*]️?⃣"                     # keycaps 1️⃣ #️⃣
    r"|[\U0001F1E6-\U0001F1FF]{2}"               # flags
    f"|{_BASE}{_MOD}(?:‍{_BASE}{_MOD})*"    # pictographs, skin tones, ZWJ sequences
)
CUSTOM_RE = re.compile(r"<a?:\w+:(\d+)>")


def parse_emojis(text: str) -> List[str]:
    """All emojis found in ``text`` (in order, no duplicates)."""
    return list(dict.fromkeys(EMOJI_RE.findall(text or "")))


# --------------------------------------------------------------------------
# SQLite helper
# --------------------------------------------------------------------------
class _Table:
    def __init__(self, filename: str, create_sql: str, probe_sql: str) -> None:
        self._path = DB_DIR / filename
        self._create_sql = create_sql
        self._probe_sql = probe_sql
        self._conn: sqlite3.Connection | None = None
        self._lock = threading.Lock()
        self._load_lock: asyncio.Lock | None = None
        self.loaded = False

    def _open(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._path), timeout=10, check_same_thread=False)
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
        except sqlite3.DatabaseError:
            pass
        conn.execute(self._create_sql)
        conn.commit()
        conn.execute(self._probe_sql).fetchall()
        return conn

    def _connect(self) -> sqlite3.Connection:  # call with self._lock held
        if self._conn is not None:
            return self._conn
        self._path.parent.mkdir(parents=True, exist_ok=True)
        try:
            conn = self._open()
        except sqlite3.DatabaseError:
            bad = self._path.with_suffix(".db.corrupt")
            try:
                self._path.replace(bad)
            except OSError:
                self._path.unlink(missing_ok=True)
            log.error("%s was unreadable; moved to %s and recreated", self._path.name, bad.name)
            conn = self._open()
        self._conn = conn
        return conn

    def _fetch(self, sql: str) -> list:
        with self._lock:
            return self._connect().execute(sql).fetchall()

    def _write(self, statements: Sequence[Tuple[str, tuple]]) -> None:
        with self._lock:
            conn = self._connect()
            try:
                for sql, params in statements:
                    conn.execute(sql, params)
                conn.commit()
            except Exception:
                conn.rollback()
                raise

    async def _persist(self, *statements: Tuple[str, tuple]) -> None:
        try:
            await asyncio.to_thread(self._write, statements)
        except Exception:  # never show storage hiccups to users
            log.exception("Could not save to %s", self._path.name)

    async def _load_rows(self, sql: str) -> list:
        try:
            return await asyncio.to_thread(self._fetch, sql)
        except Exception:
            log.exception("Could not load %s; starting empty", self._path.name)
            return []

    def close(self) -> None:
        with self._lock:
            if self._conn is not None:
                try:
                    self._conn.close()
                finally:
                    self._conn = None


# --------------------------------------------------------------------------
# Autoresponder
# --------------------------------------------------------------------------
class ResponderStore(_Table):
    def __init__(self) -> None:
        super().__init__(
            "autoresponder.db",
            "CREATE TABLE IF NOT EXISTS autoresponses ("
            "guild_id INTEGER, name TEXT, message TEXT, PRIMARY KEY (guild_id, name))",
            "SELECT guild_id, name, message FROM autoresponses LIMIT 1",
        )
        self._cache: Dict[int, Dict[str, str]] = {}

    async def load(self) -> None:
        if self.loaded:
            return
        if self._load_lock is None:
            self._load_lock = asyncio.Lock()
        async with self._load_lock:
            if self.loaded:
                return
            cache: Dict[int, Dict[str, str]] = {}
            for gid, name, message in await self._load_rows("SELECT guild_id, name, message FROM autoresponses"):
                if gid is None or not name or message is None:
                    continue
                cache.setdefault(int(gid), {})[str(name).strip().lower()] = str(message)
            self._cache = cache
            self.loaded = True

    # reads (no disk) -------------------------------------------------------
    def reply(self, gid: int, content: str) -> str | None:
        table = self._cache.get(gid)
        return table.get(content.strip().lower()) if table else None

    def items(self, gid: int) -> List[Tuple[str, str]]:
        return list(self._cache.get(gid, {}).items())

    def count(self, gid: int) -> int:
        return len(self._cache.get(gid, {}))

    # writes ------------------------------------------------------------------
    async def add(self, gid: int, name: str, message: str) -> str:
        """'added', 'exists' or 'full' (check + update has no await in between)."""
        key = name.strip().lower()
        table = self._cache.setdefault(gid, {})
        if key in table:
            return "exists"
        if len(table) >= MAX_RESPONDERS:
            return "full"
        table[key] = message
        await self._persist(("INSERT OR REPLACE INTO autoresponses (guild_id, name, message) VALUES (?, ?, ?)",
                             (gid, key, message)))
        return "added"

    async def edit(self, gid: int, name: str, message: str) -> bool:
        key = name.strip().lower()
        table = self._cache.get(gid)
        if not table or key not in table:
            return False
        table[key] = message
        await self._persist(("UPDATE autoresponses SET message = ? WHERE guild_id = ? AND LOWER(name) = ?",
                             (message, gid, key)))
        return True

    async def delete(self, gid: int, name: str) -> bool:
        key = name.strip().lower()
        table = self._cache.get(gid)
        if not table or key not in table:
            return False
        del table[key]
        if not table:
            self._cache.pop(gid, None)
        await self._persist(("DELETE FROM autoresponses WHERE guild_id = ? AND LOWER(name) = ?", (gid, key)))
        return True


# --------------------------------------------------------------------------
# Autoreact
# --------------------------------------------------------------------------
class ReactStore(_Table):
    def __init__(self) -> None:
        super().__init__(
            "autoreact.db",
            "CREATE TABLE IF NOT EXISTS autoreact (guild_id INTEGER, trigger TEXT, emojis TEXT)",
            "SELECT guild_id, trigger, emojis FROM autoreact LIMIT 1",
        )
        self._cache: Dict[int, Dict[str, Tuple[str, ...]]] = {}

    async def load(self) -> None:
        if self.loaded:
            return
        if self._load_lock is None:
            self._load_lock = asyncio.Lock()
        async with self._load_lock:
            if self.loaded:
                return
            cache: Dict[int, Dict[str, Tuple[str, ...]]] = {}
            for gid, trigger, emojis in await self._load_rows("SELECT guild_id, trigger, emojis FROM autoreact"):
                if gid is None or not trigger:
                    continue
                found = tuple(parse_emojis(str(emojis or "")))
                if found:
                    cache.setdefault(int(gid), {})[str(trigger).strip().lower()] = found
            self._cache = cache
            self.loaded = True

    # reads (no disk) -------------------------------------------------------
    def emojis(self, gid: int, content: str) -> Tuple[str, ...] | None:
        table = self._cache.get(gid)
        return table.get(content.strip().lower()) if table else None

    def items(self, gid: int) -> List[Tuple[str, Tuple[str, ...]]]:
        return list(self._cache.get(gid, {}).items())

    def count(self, gid: int) -> int:
        return len(self._cache.get(gid, {}))

    # writes ------------------------------------------------------------------
    async def add(self, gid: int, trigger: str, emojis: Sequence[str]) -> str:
        """'added', 'exists' or 'full'."""
        key = trigger.strip().lower()
        table = self._cache.setdefault(gid, {})
        if key in table:
            return "exists"
        if len(table) >= MAX_TRIGGERS:
            return "full"
        table[key] = tuple(emojis)
        await self._persist(
            ("DELETE FROM autoreact WHERE guild_id = ? AND LOWER(trigger) = ?", (gid, key)),
            ("INSERT INTO autoreact (guild_id, trigger, emojis) VALUES (?, ?, ?)", (gid, key, " ".join(emojis))),
        )
        return "added"

    async def remove(self, gid: int, trigger: str) -> bool:
        key = trigger.strip().lower()
        table = self._cache.get(gid)
        if not table or key not in table:
            return False
        del table[key]
        if not table:
            self._cache.pop(gid, None)
        await self._persist(("DELETE FROM autoreact WHERE guild_id = ? AND LOWER(trigger) = ?", (gid, key)))
        return True

    async def clear(self, gid: int) -> int:
        removed = len(self._cache.pop(gid, {}))
        if removed:
            await self._persist(("DELETE FROM autoreact WHERE guild_id = ?", (gid,)))
        return removed


responders = ResponderStore()
reactions = ReactStore()
