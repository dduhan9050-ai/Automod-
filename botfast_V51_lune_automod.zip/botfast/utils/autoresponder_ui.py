"""Components V2 panels for the Autoresponder category (autoresponder + autoreact).

Result panels look like the reference bot: a pale-pink side bar, a white
tick / cross, a bold title and a short bold message. Group / command help is
shared with the Automation category (« ‹ <:bin:1567102784552304640> › » pager).
"""
from __future__ import annotations

import discord

from utils import automation_ui as _base

TICK = "✔"    # ✔
CROSS = "✖"   # ✖
WARN = "<a:emoji_250:1567101252712530020>"  # <a:warn:1567101252712530020>

PINK = 0xF2B3C8
GRAY = 0x4F545C


async def send_group_help(ctx, group) -> None:
    await _base.send_group_help(ctx, group, accent=GRAY)


send_command_help = _base.send_command_help


def _view(*texts: str, accent: int = PINK, thumb: str | None = None) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView(timeout=None)
    box = discord.ui.Container(accent_colour=discord.Colour(accent))
    body = _base._text("\n".join(texts))
    if thumb:
        box.add_item(discord.ui.Section(body, accessory=discord.ui.Thumbnail(media=thumb)))
    else:
        box.add_item(body)
    view.add_item(box)
    return view


def panel(icon: str, title: str, message: str) -> discord.ui.LayoutView:
    return _view(f"### {icon} {title}", f"**{message}**")


def success(title: str, message: str) -> discord.ui.LayoutView:
    return panel(TICK, title, message)


def error(title: str, message: str) -> discord.ui.LayoutView:
    return panel(CROSS, title, message)


def warning(title: str, message: str) -> discord.ui.LayoutView:
    return panel(WARN, title, message)


def listing(title: str, lines: list[str], thumb: str | None = None) -> discord.ui.LayoutView:
    return _view(f"### {title}", "", "\n".join(lines), thumb=thumb)
