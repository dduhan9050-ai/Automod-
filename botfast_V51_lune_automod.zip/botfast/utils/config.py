import os

NAME = "DEATH DEVELOPMENT"
server = "https://discord.gg/cfYmz4634n"
ch = "https://discord.com/channels/1419194672017965098/1419194674135957589"
OWNER_IDS = [937212899380834314]
BotName = "DEATH DEVELOPMENT"
serverLink = "https://discord.gg/cfYmz4634n"

# Log channels (bot owner's log server)
NP_LOG_CHANNEL_ID = 1566551349892616324      # no-prefix added / removed / expired + team changes
GUILD_LOG_CHANNEL_ID = 1566771590174343239   # bot joined / left a server

# Extra Owners trusted BOT-WIDE by Bot Add Authorization (user IDs). Keep EMPTY in source control; the Server Owner is
# always trusted automatically. Per-server extra owners are managed with `antinuke extraowner add/remove/list`.
# You can also set EXTRA_OWNER_IDS=1,2,3 in .env. Invalid / duplicate IDs are ignored with a warning.
EXTRA_OWNER_IDS = []
