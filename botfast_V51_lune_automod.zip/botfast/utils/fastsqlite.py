"""Drop-in speed-up for ``async with aiosqlite.connect(path) as db`` (200+ call sites).

Stock aiosqlite starts a new thread and opens the file on EVERY call - including
every incoming message for AFK / media / word-filter / mention checks.  This shim:

* keeps a few warm connections per database file and leases one exclusively for the
  duration of each ``async with`` block (same isolation as before, no shared state);
* on release it rolls back anything left uncommitted and resets ``row_factory`` -
  exactly what closing the connection used to do;
* turns on WAL + ``synchronous=NORMAL`` (readers no longer block writers, far fewer
  fsyncs per commit).  Set ``SQLITE_WAL=0`` to disable WAL.

``await aiosqlite.connect(...)`` (non-context use) is left untouched.
"""
from __future__ import annotations

import asyncio
import os
import sqlite3

import aiosqlite

_orig_connect = aiosqlite.connect
_installed = False
_MAX_IDLE = 4
_USE_WAL = os.getenv("SQLITE_WAL", "1") != "0"

_idle: dict[tuple, list] = {}
_wal_done: set[str] = set()
_open: set = set()


async def _new_conn(args, kwargs, path: str):
    kwargs = dict(kwargs)
    kwargs.setdefault("timeout", 10)
    conn = await _orig_connect(*args, **kwargs)
    try:
        if path != ":memory:":
            if _USE_WAL and path not in _wal_done:
                await conn.execute("PRAGMA journal_mode=WAL")
                _wal_done.add(path)
            await conn.execute("PRAGMA synchronous=NORMAL")
            await conn.execute("PRAGMA temp_store=MEMORY")
            await conn.execute("PRAGMA cache_size=-4000")
    except sqlite3.Error:
        pass
    _open.add(conn)
    return conn


class _Lease:
    def __init__(self, args, kwargs):
        self._args, self._kwargs = args, kwargs
        target = args[0] if args else kwargs.get("database", "")
        self._path = str(target)
        extra = tuple(sorted((k, repr(v)) for k, v in kwargs.items() if k != "database"))
        self._key = (self._path, extra)
        self._conn = None

    def __await__(self):  # plain ``await connect()`` keeps stock behaviour
        return _orig_connect(*self._args, **self._kwargs).__await__()

    async def __aenter__(self):
        pool = _idle.setdefault(self._key, [])
        while pool:
            conn = pool.pop()
            if getattr(conn, "_running", True) and getattr(conn, "_connection", True) is not None:
                self._conn = conn
                return conn
            _open.discard(conn)
        self._conn = await _new_conn(self._args, self._kwargs, self._path)
        return self._conn

    async def __aexit__(self, exc_type, exc, tb):
        conn, self._conn = self._conn, None
        if conn is None:
            return False
        pool = _idle.setdefault(self._key, [])
        try:
            if conn.in_transaction:
                await conn.rollback()
            conn.row_factory = None
            if len(pool) < _MAX_IDLE:
                pool.append(conn)
                return False
        except Exception:
            pass
        _open.discard(conn)
        try:
            await conn.close()
        except Exception:
            pass
        return False


def _connect(*args, **kwargs):
    return _Lease(args, kwargs)


def install() -> None:
    global _installed
    if not _installed:
        aiosqlite.connect = _connect
        _installed = True


async def close_all() -> None:
    """Close every warm connection (call on shutdown so the process can exit)."""
    conns = list(_open)
    _idle.clear()
    _open.clear()
    await asyncio.gather(*(c.close() for c in conns), return_exceptions=True)
