"""White (#ffffff) Components V2 helpers + paginated list view for the General module."""
from __future__ import annotations

import math
from typing import List, Sequence

import discord

from components_v2 import media_gallery
WHITE = discord.Colour(0xFFFFFF)
MAX_TEXT = 3800  # a V2 message allows 4000 characters of text in total


def clip(text: str, limit: int) -> str:
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def kv(label: str, value) -> str:
    return f"**{label} :** {value}"


def section(title: str, lines: Sequence[str]) -> str:
    """`__Title__` heading followed by a quoted block (the left bar seen in the screenshots)."""
    return f"__**{title}**__\n" + "\n".join(f"> {l}" for l in lines)


def text_card(*texts: str, thumbnail: str | None = None, footer: str | None = None,
              buttons: Sequence[discord.ui.Button] = ()) -> discord.ui.LayoutView:
    """One #ffffff container. First text goes beside the thumbnail (if any)."""
    view = discord.ui.LayoutView(timeout=None)
    container = discord.ui.Container(accent_colour=WHITE)
    texts = [t for t in texts if t]
    if thumbnail and texts:
        container.add_item(discord.ui.Section(discord.ui.TextDisplay(texts[0]),
                                              accessory=discord.ui.Thumbnail(media=thumbnail)))
        rest = texts[1:]
    else:
        rest = texts
    for t in rest:
        container.add_item(discord.ui.TextDisplay(t))
    if footer:
        container.add_item(discord.ui.Separator())
        container.add_item(discord.ui.TextDisplay(f"-# {footer}"))
    if buttons:
        container.add_item(discord.ui.Separator())
        row = discord.ui.ActionRow()
        for b in buttons[:5]:
            row.add_item(b)
        container.add_item(row)
    view.add_item(container)
    return view


def note(text: str, *, ok: bool = False) -> discord.ui.LayoutView:
    return text_card(f"{'<:emoji_4:1566043104551768114>' if ok else '<a:emoji_38:1567096105299214336>'} {text}")


def link_button(label: str, url: str) -> discord.ui.Button:
    return discord.ui.Button(label=label, url=url, style=discord.ButtonStyle.link)


def media_card(title: str, url: str, buttons: Sequence[discord.ui.Button] = ()) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView(timeout=None)
    container = discord.ui.Container(accent_colour=WHITE)
    container.add_item(discord.ui.TextDisplay(f"## {title}"))
    container.add_item(media_gallery(url))
    if buttons:
        row = discord.ui.ActionRow()
        for b in buttons[:5]:
            row.add_item(b)
        container.add_item(row)
    view.add_item(container)
    return view


# ----------------------------------------------------------------- paginator
class _Btn(discord.ui.Button):
    def __init__(self, pview: "PagedView", action: str, *, style, label=None, emoji=None, disabled=False):
        super().__init__(style=style, label=label, emoji=emoji, disabled=disabled)
        self.pview, self.action = pview, action

    async def callback(self, interaction: discord.Interaction):
        await self.pview.handle(self.action, interaction)


class PagedView(discord.ui.LayoutView):
    """White container list + nav row below it.

    nav="sort" : ‹  <:bin:1567102784552304640>  ›  ↕  [page/total]      (data lists)
    nav="long" : «  ‹  <:bin:1567102784552304640>  ›  »                 (command help lists)
    """

    def __init__(self, ctx, title: str, entries: List[str], *, per_page: int = 10, numbered: bool = True,
                 header: str = "", nav: str = "sort", show_count: bool = True):
        super().__init__(timeout=180)
        self.ctx, self.title, self.entries = ctx, title, list(entries)
        self.per_page, self.numbered, self.header, self.nav = per_page, numbered, header, nav
        self.show_count = show_count
        self.page, self.descending = 0, False
        self.message = None
        self._buttons: list = []
        self.total = max(1, math.ceil(len(self.entries) / per_page))
        self.render()

    def render(self):
        self.clear_items()
        self._buttons = []
        order = list(reversed(self.entries)) if self.descending else self.entries
        start = self.page * self.per_page
        chunk = order[start:start + self.per_page]
        if self.numbered:
            chunk = [f"`[{start + i + 1:02d}]` {e}" for i, e in enumerate(chunk)]
        count = f" [{len(self.entries)}]" if self.show_count else ""
        body = f"## {self.title}{count}\n"
        if self.header:
            body += self.header + "\n\n"
        body += "\n".join(chunk)
        container = discord.ui.Container(accent_colour=WHITE)
        container.add_item(discord.ui.TextDisplay(clip(body, MAX_TEXT)))
        container.add_item(discord.ui.Separator())
        container.add_item(discord.ui.TextDisplay(
            f"-# Page {self.page + 1}/{self.total} | Requested by {self.ctx.author.display_name}"))
        self.add_item(container)

        last, first = self.page >= self.total - 1, self.page <= 0
        row = discord.ui.ActionRow()
        if self.nav == "long":
            specs = [("first", "<:icon_2:1567113746374197318>", first), ("prev", "<:left:1567104063240146984>", first), ("del", "<:bin:1567102784552304640>", False),
                     ("next", "<:right:1567104038284034058>", last), ("last", "<:icon_3:1567113772852838410>", last)]
        else:
            specs = [("prev", "<:left:1567104063240146984>", first), ("del", "<:bin:1567102784552304640>", False), ("next", "<:right:1567104038284034058>", last), ("sort", "↕", self.total < 1)]
        for action, label, disabled in specs:
            if action == "del":
                b = _Btn(self, action, style=discord.ButtonStyle.danger, emoji="<:bin:1567102784552304640>", disabled=disabled)
            elif action in ("first", "prev", "next", "last"):
                b = _Btn(self, action, style=discord.ButtonStyle.secondary, emoji=label, disabled=disabled)
            else:
                b = _Btn(self, action, style=discord.ButtonStyle.secondary, label=label, disabled=disabled)
            self._buttons.append(b)
            row.add_item(b)
        if self.nav != "long":
            ind = discord.ui.Button(label=f"{self.page + 1}/{self.total}", disabled=True,
                                    style=discord.ButtonStyle.secondary)
            self._buttons.append(ind)
            row.add_item(ind)
        self.add_item(row)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.ctx.author.id:
            await interaction.response.send_message("You must run this command to interact with it.", ephemeral=True)
            return False
        return True

    async def handle(self, action: str, interaction: discord.Interaction):
        if action == "del":
            await interaction.response.defer()
            try:
                await interaction.message.delete()
            except discord.HTTPException:
                pass
            self.stop()
            return
        if action == "first":
            self.page = 0
        elif action == "prev":
            self.page = max(0, self.page - 1)
        elif action == "next":
            self.page = min(self.total - 1, self.page + 1)
        elif action == "last":
            self.page = self.total - 1
        elif action == "sort":
            self.descending = not self.descending
            self.page = 0
        self.render()
        await interaction.response.edit_message(view=self)

    async def on_timeout(self):
        for b in self._buttons:
            b.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except Exception:
                pass

    async def start(self):
        self.message = await self.ctx.reply(view=self, mention_author=False)
        return self.message


async def send_list(ctx, title: str, entries: List[str], empty: str, **kw):
    if not entries:
        return await ctx.reply(view=note(empty), mention_author=False)
    return await PagedView(ctx, title, entries, **kw).start()
