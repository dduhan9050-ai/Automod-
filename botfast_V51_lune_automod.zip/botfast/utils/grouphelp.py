"""Group help card:   BOT NAME + GROUP  ->  `usage` / ❯ description  ->  Requested by | Page n/m  ->  « ‹ <:bin:1567102784552304640> › »

    GroupHelpView(ctx, group, order=["list", "add", ...], per_page=5)
"""
from __future__ import annotations

import discord
from discord.ext import commands

ARROW = "\u276f"          # ❯
INDENT = "\u00a0" * 6     # non-breaking spaces survive markdown


def usage_of(prefix: str, command: commands.Command) -> str:
    """`premium add <user> [duration=30d] [guild_limit=1] [reason=No reason provided]`"""
    parts = [f"{prefix}{command.qualified_name}"]
    for name, param in command.clean_params.items():
        if param.required:
            parts.append(f"<{name}>")
        elif param.default in (None, param.empty, ""):
            parts.append(f"[{name}]")
        else:
            parts.append(f"[{name}={param.default}]")
    return " ".join(parts)


def entry_text(prefix: str, command: commands.Command) -> str:
    desc = command.short_doc or command.help or "No description provided."
    return f"`{usage_of(prefix, command)}`\n{INDENT}{ARROW} {desc}"


def ordered(group: commands.Group, order: list[str] | None = None, *, hidden: bool = False) -> list[commands.Command]:
    subs = [c for c in group.commands if hidden or not c.hidden]
    rank = {name: i for i, name in enumerate(order or [])}
    return sorted(subs, key=lambda c: (rank.get(c.name, len(rank)), c.name))


class _Nav(discord.ui.Button):
    def __init__(self, view: "GroupHelpView", action: str, **kw):
        super().__init__(style=discord.ButtonStyle.danger if action == "del" else discord.ButtonStyle.secondary, **kw)
        self.pview, self.action = view, action

    async def callback(self, interaction: discord.Interaction):
        await self.pview.handle(self.action, interaction)


class GroupHelpView(discord.ui.LayoutView):
    def __init__(self, ctx: commands.Context, group: commands.Group, *, title: str | None = None,
                 order: list[str] | None = None, per_page: int = 5):
        super().__init__(timeout=180)
        self.ctx = ctx
        self.title = title or f"{ctx.bot.user.name} {group.qualified_name} group".upper()
        prefix = ctx.clean_prefix
        entries = [entry_text(prefix, c) for c in ordered(group, order)]
        self.pages = [entries[i:i + per_page] for i in range(0, len(entries), per_page)] or [["No commands."]]
        self.page = 0
        self.message: discord.Message | None = None
        self._nav: list[_Nav] = []
        self.render()

    def render(self) -> None:
        self.clear_items()
        self._nav = []
        box = discord.ui.Container()
        box.add_item(discord.ui.TextDisplay(f"## {self.title}"))
        box.add_item(discord.ui.Separator())
        for item in self.pages[self.page]:
            box.add_item(discord.ui.TextDisplay(item))
        box.add_item(discord.ui.Separator())
        box.add_item(discord.ui.TextDisplay(
            f"-# Requested by {self.ctx.author.display_name} | Page {self.page + 1}/{len(self.pages)}"))
        box.add_item(discord.ui.Separator())
        first, last = self.page <= 0, self.page >= len(self.pages) - 1
        row = discord.ui.ActionRow()
        for action, label, emoji, off in (("first", None, "<:icon_2:1567113746374197318>", first), ("prev", None, "<:left:1567104063240146984>", first),
                                          ("del", None, "<:bin:1567102784552304640>", False),
                                          ("next", None, "<:right:1567104038284034058>", last), ("last", None, "<:icon_3:1567113772852838410>", last)):
            button = _Nav(self, action, label=label, emoji=emoji, disabled=off)
            self._nav.append(button)
            row.add_item(button)
        box.add_item(row)
        self.add_item(box)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.ctx.author.id:
            await interaction.response.send_message("You must run this command to interact with it.", ephemeral=True)
            return False
        return True

    async def handle(self, action: str, interaction: discord.Interaction) -> None:
        if action == "del":
            self.stop()
            try:
                await interaction.response.defer()
                await interaction.message.delete()
            except discord.HTTPException:
                pass
            return
        last = len(self.pages) - 1
        self.page = {"first": 0, "prev": max(0, self.page - 1),
                     "next": min(last, self.page + 1), "last": last}[action]
        self.render()
        await interaction.response.edit_message(view=self)

    async def on_timeout(self) -> None:
        for button in self._nav:
            button.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass

    async def start(self) -> discord.Message:
        self.message = await self.ctx.reply(view=self, mention_author=False)
        return self.message
