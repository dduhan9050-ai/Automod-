from __future__ import annotations

from pathlib import Path

import discord
from discord.ext import commands

import io
from components_v2 import NO_ACCENT, media_gallery

ASSET_DIR = Path(__file__).resolve().parent.parent / "assets"
_ASSET_BYTES: dict[str, bytes] = {}
LOGO_FILE = "help_logo.jpg"
BANNER_FILE = "help_banner.jpg"


def module_banner(label: str) -> str:
    """Per-module banner file name (optional asset), e.g. 'Security' -> help_banner_security.png.
    .png / .jpg / .jpeg / .webp are all accepted; returns "" when the module has no banner."""
    slug = "".join(ch for ch in label.lower() if ch.isalnum())
    for ext in ("jpg", "png", "jpeg", "webp"):
        name = f"help_banner_{slug}.{ext}"
        if (ASSET_DIR / name).is_file():
            return name
    return ""


SUPPORT_URL = "https://discord.gg/cfYmz4634n"
LINKS_EMOJI = "<:emoji_37:1566470776851529769>"

# Help-menu order + display name + emoji.  (original label from help_custom(), shown label, emoji)
# Modules that are not listed here are added after these, in their old order.
HELP_LAYOUT = (
    ("Security", "Security", "<:emoji_22:1566460208086122536>"),
    ("Permit", "Permits", "<:emoji_36:1566461967751979118>"),
    ("Automod", "Automod", "<:emoji_21:1566460153782468739>"),
    ("Moderation", "Moderation", "<:emoji_38:1566462673636434052>"),
    ("General", "General", "<:emoji_35:1566466178409300089>"),
    ("Utility", "Utility", "<:emoji_23:1566460237769089145>"),
    ("Autoresponder", "Autoresponder", "<:emoji_37:1566462001729896488>"),
    ("Vanityroles", "Vanity & Tags", "<:emoji_20:1566460066444349652>"),
    ("Greetings", "Greetings", "<:emoji_25:1566460309726826506>"),
    ("Music Commands", "Music", "<:emoji_26:1566460336305864796>"),
    ("CustomRole", "Custom Roles", "<:emoji_28:1566460391125422110>"),
    ("Voice Commands", "Voice Commands", "<:emoji_27:1566460362466001018>"),
    ("Ticket", "Tickets", "<:emoji_29:1566460425795666010>"),
    ("Logging", "Logging", "<:emoji_34:1566460582658576566>"),
    ("Leaderboard", "Leaderboard", "<:emoji_39:1566465411245940868>"),
    ("Customize", "Customize", "<:emoji_36:1566469004065775716>"),
)
_LAYOUT = {orig: (i, label, emoji) for i, (orig, label, emoji) in enumerate(HELP_LAYOUT)}


class HelpSelect(discord.ui.Select):
    def __init__(self, owner_id: int, options: list[discord.SelectOption]):
        super().__init__(placeholder="Select a Module", min_values=1, max_values=1,
                         options=options[:25], custom_id="death_help:module_select")
        self.owner_id = owner_id

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("You must run this command to interact with it.", ephemeral=True)
            return
        await self.view.show_module(self.values[0], interaction)


class HelpView(discord.ui.LayoutView):
    """Native Components V2 help menu with bot avatar thumbnail and module selector."""

    def __init__(self, mapping: dict, ctx: commands.Context):
        super().__init__(timeout=180)
        self.ctx = ctx
        self.owner_id = ctx.author.id
        self.bot = ctx.bot
        self.modules: dict[str, tuple[str, str, list[str]]] = {}
        self.options: list[discord.SelectOption] = []
        self.plain: set[str] = set()  # modules rendered without an accent colour
        entries = []

        for cog in mapping:
            custom = getattr(cog, "help_custom", None)
            if not callable(custom):
                continue
            if getattr(cog, "help_owner_only", False) and ctx.author.id not in (ctx.bot.owner_ids or ()):
                continue                      # Bot Owner category is invisible to normal users
            try:
                emoji, label, description = custom()
            except Exception:
                continue
            label = str(label)
            position, label, emoji = _LAYOUT.get(label, (len(_LAYOUT) + len(entries), label, emoji))
            if getattr(cog, "help_plain", False):
                self.plain.add(label)
            command_lines = []
            body = getattr(cog, "help_body", None)
            if callable(body):
                try:
                    command_lines.append(str(body(ctx.clean_prefix)))
                except Exception:
                    pass
            for command in ([] if command_lines else cog.get_commands()):
                if command.hidden:
                    continue
                params = " ".join(f"<{name}>" for name in command.clean_params)
                usage = f"{ctx.clean_prefix}{command.qualified_name}"
                if params:
                    usage += f" {params}"
                detail = command.short_doc or command.help or "No description provided."
                command_lines.append(f"• `{usage}`\n  {detail}")
            entries.append((position, label, emoji, description, command_lines))
        for _, label, emoji, description, command_lines in sorted(entries, key=lambda e: e[0]):
            self.modules[label] = (str(emoji or "<:emoji_16:1566453033771077732>"), str(description or ""), command_lines)
            self.options.append(discord.SelectOption(
                label=label[:100], value=label[:100],
                description=str(description or f"{len(command_lines)} commands")[:100],
                emoji=emoji if emoji else None))
        self._render_home()

    def files(self) -> list[discord.File]:
        """Fresh attachment objects for the help message (logo + banner). Missing files are skipped."""
        return self._files_for([LOGO_FILE, BANNER_FILE])

    @staticmethod
    def _files_for(names: list[str]) -> list[discord.File]:
        # Discord allows max 10 attachments per message, so only the images the current
        # screen actually shows are attached (home: logo + banner, module: logo + its banner)
        out = []
        for name in names:
            if not name:
                continue
            data = _ASSET_BYTES.get(name)
            if data is None:
                path = ASSET_DIR / name
                if not path.is_file():
                    continue
                data = _ASSET_BYTES[name] = path.read_bytes()      # read once, then served from RAM
            out.append(discord.File(io.BytesIO(data), filename=name))
        return out

    def _avatar_url(self) -> str | None:
        if (ASSET_DIR / LOGO_FILE).is_file():
            return f"attachment://{LOGO_FILE}"
        avatar = getattr(self.bot.user, "display_avatar", None)
        return str(avatar.url) if avatar else None

    def _base_container(self, heading: str, body: str, plain: bool = False) -> discord.ui.Container:
        container = discord.ui.Container(accent_colour=NO_ACCENT)  # help menu: never an accent colour
        avatar = self._avatar_url()
        text = discord.ui.TextDisplay(f"# {heading}\n{body}")
        if avatar:
            container.add_item(discord.ui.Section(text, accessory=discord.ui.Thumbnail(media=avatar)))
        else:
            container.add_item(text)
        return container

    def _add_selector(self, container: discord.ui.Container):
        if self.options:
            row = discord.ui.ActionRow()
            row.add_item(HelpSelect(self.owner_id, self.options))
            container.add_item(row)

    def _render_home(self):
        self.clear_items()
        container = discord.ui.Container(accent_colour=NO_ACCENT)
        header = discord.ui.TextDisplay(
            "-# I   A M   D E A T H\n"
            "# Help Menu\n"
            "Select a module to view its commands.")
        logo = self._avatar_url()
        if logo:
            container.add_item(discord.ui.Section(header, accessory=discord.ui.Thumbnail(media=logo)))
        else:
            container.add_item(header)
        container.add_item(discord.ui.Separator())
        self._add_selector(container)
        if (ASSET_DIR / BANNER_FILE).is_file():
            container.add_item(media_gallery(f"attachment://{BANNER_FILE}"))
        self.add_item(container)

    async def show_module(self, label: str, interaction: discord.Interaction):
        if label not in self.modules:
            await interaction.response.send_message("This module is no longer available.", ephemeral=True)
            return
        emoji, description, lines = self.modules[label]
        self.clear_items()
        banner = module_banner(label)
        if banner:
            # modules with their own banner: banner image replaces the heading + logo
            container = discord.ui.Container(accent_colour=NO_ACCENT)
            container.add_item(media_gallery(f"attachment://{banner}"))
        else:
            container = self._base_container(f"{emoji} {label}", description or f"Commands available in {label}.",
                                             plain=label in self.plain)
        container.add_item(discord.ui.Separator())
        if lines:
            text = "\n\n".join(lines)
            chunks = [text[i:i + 3900] for i in range(0, len(text), 3900)]
            for chunk in chunks[:8]:
                container.add_item(discord.ui.TextDisplay(chunk))
        else:
            container.add_item(discord.ui.TextDisplay("No visible commands are available in this module."))
        container.add_item(discord.ui.Separator())
        self._add_selector(container)
        container.add_item(discord.ui.TextDisplay("-# Select another module to view its commands."))
        self.add_item(container)
        # swap the message attachments to exactly what this module screen needs
        await interaction.response.edit_message(
            view=self, attachments=self._files_for([LOGO_FILE, banner]))
