"""Storage layer for the Leaderboard category (voice / messages / invites / live boards).

Speed design
------------
* Settings, blacklists and reward roles live in memory -> the message listener never touches the disk.
* Message / voice counters are batched in memory and written with ONE transaction (``flush``).
* One shared aiosqlite connection in WAL mode (no connect-per-command).
"""
from __future__ import annotations

import os
import time
from typing import Iterable

import aiosqlite

DB_PATH = "db/leaderboard.db"
PERIODS = ("daily", "weekly", "alltime")

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;

CREATE TABLE IF NOT EXISTS settings (
    guild_id INTEGER PRIMARY KEY,
    voice    INTEGER NOT NULL DEFAULT 0,
    msg      INTEGER NOT NULL DEFAULT 0,
    invite   INTEGER NOT NULL DEFAULT 0,
    alt_days INTEGER NOT NULL DEFAULT 7
);
CREATE TABLE IF NOT EXISTS msg_daily (
    guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, day TEXT NOT NULL, n INTEGER NOT NULL,
    PRIMARY KEY (guild_id, user_id, day)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS msg_daily_day ON msg_daily (guild_id, day);
CREATE TABLE IF NOT EXISTS voice_daily (
    guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, day TEXT NOT NULL, secs INTEGER NOT NULL,
    PRIMARY KEY (guild_id, user_id, day)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS voice_daily_day ON voice_daily (guild_id, day);
CREATE TABLE IF NOT EXISTS msg_blacklist (
    guild_id INTEGER NOT NULL, target_id INTEGER NOT NULL, kind TEXT NOT NULL,
    PRIMARY KEY (guild_id, target_id)
) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS reward_roles (
    guild_id INTEGER NOT NULL, kind TEXT NOT NULL, threshold INTEGER NOT NULL, role_id INTEGER NOT NULL,
    PRIMARY KEY (guild_id, kind, role_id)
) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS invite_stats (
    guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
    joins INTEGER NOT NULL DEFAULT 0, left INTEGER NOT NULL DEFAULT 0, fake INTEGER NOT NULL DEFAULT 0,
    rejoins INTEGER NOT NULL DEFAULT 0, bonus INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (guild_id, user_id)
) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS invite_members (
    guild_id INTEGER NOT NULL, member_id INTEGER NOT NULL, inviter_id INTEGER NOT NULL,
    code TEXT, joined_at INTEGER NOT NULL, status TEXT NOT NULL,
    PRIMARY KEY (guild_id, member_id)
) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS invite_members_inviter ON invite_members (guild_id, inviter_id);
CREATE TABLE IF NOT EXISTS live_lb (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL, channel_id INTEGER NOT NULL, message_id INTEGER NOT NULL,
    kind TEXT NOT NULL, period TEXT NOT NULL DEFAULT 'alltime'
);
CREATE INDEX IF NOT EXISTS live_lb_guild ON live_lb (guild_id);
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
"""

# fixed SQL fragments (never built from user input)
_TABLES = {"messages": ("msg_daily", "n"), "voice": ("voice_daily", "secs")}
_INVITE_EXPR = {
    "total": "joins + bonus",
    "regular": "joins - left + bonus",
    "fake": "fake",
    "left": "left",
}
_FLAGS = ("voice", "msg", "invite")
_INV_FIELDS = ("joins", "left", "fake", "rejoins", "bonus")


def today_str() -> str:
    t = time.gmtime()
    return f"{t.tm_year:04d}-{t.tm_mon:02d}-{t.tm_mday:02d}"


def since_for(period: str) -> str | None:
    """First day (UTC, inclusive) that belongs to the period. None = all time."""
    if period == "daily":
        return today_str()
    if period == "weekly":
        t = time.gmtime(time.time() - 6 * 86400)
        return f"{t.tm_year:04d}-{t.tm_mon:02d}-{t.tm_mday:02d}"
    return None


class Settings:
    __slots__ = ("voice", "msg", "invite", "alt_days")

    def __init__(self, voice=0, msg=0, invite=0, alt_days=7):
        self.voice = bool(voice)
        self.msg = bool(msg)
        self.invite = bool(invite)
        self.alt_days = int(alt_days)


class Store:
    def __init__(self, path: str = DB_PATH):
        self.path = path
        self.db: aiosqlite.Connection | None = None
        self.settings: dict[int, Settings] = {}
        self.blacklist: dict[int, dict[int, str]] = {}          # guild -> {channel/category id: kind}
        self.rewards: dict[tuple[int, str], list[tuple[int, int]]] = {}   # (guild, kind) -> [(threshold, role)]
        self._msgs: dict[tuple[int, int, str], int] = {}
        self._voice: dict[tuple[int, int, str], int] = {}

    # ------------------------------------------------------------------ lifecycle
    async def open(self) -> None:
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        self.db = await aiosqlite.connect(self.path, timeout=30)
        await self.db.executescript(SCHEMA)
        await self.db.commit()
        await self._load()
        await self._migrate_old_messages()

    async def close(self) -> None:
        if self.db is not None:
            try:
                await self.flush()
            finally:
                await self.db.close()
                self.db = None

    async def _load(self) -> None:
        async with self.db.execute("SELECT guild_id, voice, msg, invite, alt_days FROM settings") as cur:
            async for g, v, m, i, a in cur:
                self.settings[g] = Settings(v, m, i, a)
        async with self.db.execute("SELECT guild_id, target_id, kind FROM msg_blacklist") as cur:
            async for g, t, k in cur:
                self.blacklist.setdefault(g, {})[t] = k
        async with self.db.execute("SELECT guild_id, kind, threshold, role_id FROM reward_roles") as cur:
            async for g, k, th, r in cur:
                self.rewards.setdefault((g, k), []).append((th, r))
        for rules in self.rewards.values():
            rules.sort()

    async def _migrate_old_messages(self) -> None:
        """Import the counts of the old `messages` cog (db/messages.db) once."""
        async with self.db.execute("SELECT 1 FROM meta WHERE key='messages_migrated'") as cur:
            if await cur.fetchone():
                return
        if os.path.exists("db/messages.db"):
            try:
                await self.db.execute("ATTACH DATABASE ? AS old", ("db/messages.db",))
                await self.db.execute(
                    "INSERT OR IGNORE INTO msg_daily SELECT guild_id, user_id, date, SUM(count) "
                    "FROM old.messages GROUP BY guild_id, user_id, date")
                await self.db.commit()
            except Exception:
                pass
            finally:
                try:
                    await self.db.commit()
                    await self.db.execute("DETACH DATABASE old")
                except Exception:
                    pass
        await self.db.execute("INSERT OR REPLACE INTO meta VALUES ('messages_migrated', '1')")
        await self.db.commit()

    # ------------------------------------------------------------------ settings
    def cfg(self, guild_id: int) -> Settings:
        s = self.settings.get(guild_id)
        if s is None:
            s = self.settings[guild_id] = Settings()
        return s

    async def set_flag(self, guild_id: int, field: str, value: bool) -> None:
        if field not in _FLAGS:
            raise ValueError(field)
        await self.db.execute("INSERT INTO settings (guild_id) VALUES (?) ON CONFLICT DO NOTHING", (guild_id,))
        await self.db.execute(f"UPDATE settings SET {field}=? WHERE guild_id=?", (int(value), guild_id))
        await self.db.commit()
        setattr(self.cfg(guild_id), field, bool(value))

    async def set_alt_days(self, guild_id: int, days: int) -> None:
        await self.db.execute("INSERT INTO settings (guild_id) VALUES (?) ON CONFLICT DO NOTHING", (guild_id,))
        await self.db.execute("UPDATE settings SET alt_days=? WHERE guild_id=?", (days, guild_id))
        await self.db.commit()
        self.cfg(guild_id).alt_days = days

    # ------------------------------------------------------------------ blacklist (messages)
    async def add_blacklist(self, guild_id: int, target_id: int, kind: str) -> bool:
        bl = self.blacklist.setdefault(guild_id, {})
        if target_id in bl:
            return False
        await self.db.execute("INSERT OR REPLACE INTO msg_blacklist VALUES (?, ?, ?)", (guild_id, target_id, kind))
        await self.db.commit()
        bl[target_id] = kind
        return True

    async def remove_blacklist(self, guild_id: int, target_id: int) -> bool:
        bl = self.blacklist.get(guild_id, {})
        if target_id not in bl:
            return False
        await self.db.execute("DELETE FROM msg_blacklist WHERE guild_id=? AND target_id=?", (guild_id, target_id))
        await self.db.commit()
        del bl[target_id]
        return True

    def blacklisted(self, guild_id: int, kind: str) -> list[int]:
        return [t for t, k in self.blacklist.get(guild_id, {}).items() if k == kind]

    # ------------------------------------------------------------------ reward roles
    async def set_reward(self, guild_id: int, kind: str, threshold: int, role_id: int) -> None:
        await self.db.execute("INSERT OR REPLACE INTO reward_roles VALUES (?, ?, ?, ?)",
                              (guild_id, kind, threshold, role_id))
        await self.db.commit()
        rules = [r for r in self.rewards.get((guild_id, kind), []) if r[1] != role_id]
        rules.append((threshold, role_id))
        rules.sort()
        self.rewards[(guild_id, kind)] = rules

    async def remove_reward(self, guild_id: int, kind: str, role_id: int) -> bool:
        rules = self.rewards.get((guild_id, kind), [])
        if not any(r[1] == role_id for r in rules):
            return False
        await self.db.execute("DELETE FROM reward_roles WHERE guild_id=? AND kind=? AND role_id=?",
                              (guild_id, kind, role_id))
        await self.db.commit()
        self.rewards[(guild_id, kind)] = [r for r in rules if r[1] != role_id]
        return True

    # ------------------------------------------------------------------ counters (hot path = memory only)
    def count_message(self, guild_id: int, user_id: int) -> None:
        k = (guild_id, user_id, today_str())
        self._msgs[k] = self._msgs.get(k, 0) + 1

    def count_voice(self, guild_id: int, user_id: int, secs: int) -> None:
        if secs <= 0:
            return
        k = (guild_id, user_id, today_str())
        self._voice[k] = self._voice.get(k, 0) + secs

    def count_message_amount(self, guild_id: int, user_id: int, amount: int) -> None:
        k = (guild_id, user_id, today_str())
        self._msgs[k] = self._msgs.get(k, 0) + amount

    async def flush(self) -> set[tuple[int, int]]:
        """Write all pending counters in one transaction. Returns the (guild, user) pairs that sent messages."""
        if not self._msgs and not self._voice:
            return set()
        msgs, voice = self._msgs, self._voice
        self._msgs, self._voice = {}, {}
        try:
            if msgs:
                await self.db.executemany(
                    "INSERT INTO msg_daily (guild_id, user_id, day, n) VALUES (?, ?, ?, ?) "
                    "ON CONFLICT (guild_id, user_id, day) DO UPDATE SET n = n + excluded.n",
                    [(g, u, d, n) for (g, u, d), n in msgs.items()])
            if voice:
                await self.db.executemany(
                    "INSERT INTO voice_daily (guild_id, user_id, day, secs) VALUES (?, ?, ?, ?) "
                    "ON CONFLICT (guild_id, user_id, day) DO UPDATE SET secs = secs + excluded.secs",
                    [(g, u, d, n) for (g, u, d), n in voice.items()])
            await self.db.commit()
        except Exception:
            for k, v in msgs.items():
                self._msgs[k] = self._msgs.get(k, 0) + v
            for k, v in voice.items():
                self._voice[k] = self._voice.get(k, 0) + v
            raise
        return {(g, u) for (g, u, _d) in msgs}

    # ------------------------------------------------------------------ reads (messages / voice)
    async def top(self, kind: str, guild_id: int, period: str) -> list[tuple[int, int]]:
        table, col = _TABLES[kind]
        since = since_for(period)
        sql = f"SELECT user_id, SUM({col}) AS s FROM {table} WHERE guild_id = ?"
        args: list = [guild_id]
        if since:
            sql += " AND day >= ?"
            args.append(since)
        sql += " GROUP BY user_id HAVING s > 0 ORDER BY s DESC"
        async with self.db.execute(sql, args) as cur:
            return [(u, s) for u, s in await cur.fetchall()]

    async def totals(self, kind: str, guild_id: int, user_id: int) -> tuple[int, int, int]:
        """(all time, last 7 days, today)"""
        table, col = _TABLES[kind]
        async with self.db.execute(
                f"SELECT COALESCE(SUM({col}), 0), "
                f"COALESCE(SUM(CASE WHEN day >= ? THEN {col} END), 0), "
                f"COALESCE(SUM(CASE WHEN day = ? THEN {col} END), 0) "
                f"FROM {table} WHERE guild_id = ? AND user_id = ?",
                (since_for("weekly"), today_str(), guild_id, user_id)) as cur:
            row = await cur.fetchone()
        return int(row[0]), int(row[1]), int(row[2])

    async def total(self, kind: str, guild_id: int, user_id: int) -> int:
        return (await self.totals(kind, guild_id, user_id))[0]

    async def deduct(self, kind: str, guild_id: int, user_id: int, amount: int) -> int:
        """Remove `amount` (newest days first). Returns how much was really removed."""
        table, col = _TABLES[kind]
        removed = 0
        async with self.db.execute(
                f"SELECT day, {col} FROM {table} WHERE guild_id=? AND user_id=? AND {col} > 0 ORDER BY day DESC",
                (guild_id, user_id)) as cur:
            rows = await cur.fetchall()
        for day, val in rows:
            if amount <= 0:
                break
            take = min(val, amount)
            await self.db.execute(
                f"UPDATE {table} SET {col} = {col} - ? WHERE guild_id=? AND user_id=? AND day=?",
                (take, guild_id, user_id, day))
            amount -= take
            removed += take
        await self.db.commit()
        return removed

    async def clear(self, kind: str, guild_id: int, user_id: int | None = None) -> None:
        table, _ = _TABLES[kind]
        if user_id is None:
            await self.db.execute(f"DELETE FROM {table} WHERE guild_id=?", (guild_id,))
        else:
            await self.db.execute(f"DELETE FROM {table} WHERE guild_id=? AND user_id=?", (guild_id, user_id))
        await self.db.commit()

    # ------------------------------------------------------------------ invites
    async def inv_stats(self, guild_id: int, user_id: int) -> dict:
        async with self.db.execute(
                "SELECT joins, left, fake, rejoins, bonus FROM invite_stats WHERE guild_id=? AND user_id=?",
                (guild_id, user_id)) as cur:
            row = await cur.fetchone()
        j, l, f, r, b = row or (0, 0, 0, 0, 0)
        return {"joins": j, "left": l, "fake": f, "rejoins": r, "bonus": b, "invites": j - l + b}

    async def inv_bump(self, guild_id: int, user_id: int, **deltas: int) -> None:
        sets = []
        args: list = []
        for key, value in deltas.items():
            if key not in _INV_FIELDS:
                raise ValueError(key)
            sets.append(f"{key} = {key} + ?")
            args.append(value)
        if not sets:
            return
        await self.db.execute("INSERT OR IGNORE INTO invite_stats (guild_id, user_id) VALUES (?, ?)",
                              (guild_id, user_id))
        await self.db.execute(
            f"UPDATE invite_stats SET {', '.join(sets)} WHERE guild_id=? AND user_id=?", (*args, guild_id, user_id))
        await self.db.commit()

    async def inv_board(self, guild_id: int, mode: str) -> list[tuple[int, int]]:
        expr = _INVITE_EXPR[mode]
        async with self.db.execute(
                f"SELECT user_id, v FROM (SELECT user_id, {expr} AS v FROM invite_stats WHERE guild_id=?) "
                f"WHERE v > 0 ORDER BY v DESC", (guild_id,)) as cur:
            return [(u, v) for u, v in await cur.fetchall()]

    async def inv_board_since(self, guild_id: int, since_ts: int) -> list[tuple[int, int]]:
        async with self.db.execute(
                "SELECT inviter_id, COUNT(*) AS c FROM invite_members "
                "WHERE guild_id=? AND status='in' AND joined_at >= ? GROUP BY inviter_id ORDER BY c DESC",
                (guild_id, since_ts)) as cur:
            return [(u, c) for u, c in await cur.fetchall()]

    async def inv_member(self, guild_id: int, member_id: int) -> dict | None:
        async with self.db.execute(
                "SELECT inviter_id, code, joined_at, status FROM invite_members WHERE guild_id=? AND member_id=?",
                (guild_id, member_id)) as cur:
            row = await cur.fetchone()
        if not row:
            return None
        return {"inviter_id": row[0], "code": row[1], "joined_at": row[2], "status": row[3]}

    async def inv_add_member(self, guild_id: int, member_id: int, inviter_id: int, code: str, status: str) -> None:
        await self.db.execute(
            "INSERT OR REPLACE INTO invite_members VALUES (?, ?, ?, ?, ?, ?)",
            (guild_id, member_id, inviter_id, code, int(time.time()), status))
        await self.db.commit()

    async def inv_set_status(self, guild_id: int, member_id: int, status: str) -> None:
        await self.db.execute("UPDATE invite_members SET status=? WHERE guild_id=? AND member_id=?",
                              (status, guild_id, member_id))
        await self.db.commit()

    async def inv_invited(self, guild_id: int, inviter_id: int) -> list[tuple[int, str, int]]:
        async with self.db.execute(
                "SELECT member_id, status, joined_at FROM invite_members WHERE guild_id=? AND inviter_id=? "
                "ORDER BY joined_at DESC", (guild_id, inviter_id)) as cur:
            return [(m, s, t) for m, s, t in await cur.fetchall()]

    async def inv_clear_user(self, guild_id: int, user_id: int) -> None:
        await self.db.execute("DELETE FROM invite_stats WHERE guild_id=? AND user_id=?", (guild_id, user_id))
        await self.db.execute("DELETE FROM invite_members WHERE guild_id=? AND inviter_id=?", (guild_id, user_id))
        await self.db.commit()

    async def inv_clear_guild(self, guild_id: int) -> None:
        await self.db.execute("DELETE FROM invite_stats WHERE guild_id=?", (guild_id,))
        await self.db.execute("DELETE FROM invite_members WHERE guild_id=?", (guild_id,))
        await self.db.commit()

    # ------------------------------------------------------------------ live boards
    async def live_add(self, guild_id: int, channel_id: int, message_id: int, kind: str, period: str) -> int:
        cur = await self.db.execute(
            "INSERT INTO live_lb (guild_id, channel_id, message_id, kind, period) VALUES (?, ?, ?, ?, ?)",
            (guild_id, channel_id, message_id, kind, period))
        await self.db.commit()
        return cur.lastrowid

    async def live_all(self, guild_id: int | None = None) -> list[dict]:
        sql = "SELECT id, guild_id, channel_id, message_id, kind, period FROM live_lb"
        args: Iterable = ()
        if guild_id is not None:
            sql += " WHERE guild_id=?"
            args = (guild_id,)
        async with self.db.execute(sql + " ORDER BY id", args) as cur:
            return [dict(id=i, guild_id=g, channel_id=c, message_id=m, kind=k, period=p)
                    for i, g, c, m, k, p in await cur.fetchall()]

    async def live_get(self, guild_id: int, live_id: int) -> dict | None:
        for row in await self.live_all(guild_id):
            if row["id"] == live_id:
                return row
        return None

    async def live_delete(self, live_id: int) -> None:
        await self.db.execute("DELETE FROM live_lb WHERE id=?", (live_id,))
        await self.db.commit()
