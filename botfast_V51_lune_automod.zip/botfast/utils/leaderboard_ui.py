"""Components V2 builders for the Leaderboard category (stat cards, boards, help panels)."""
from __future__ import annotations

import time
from typing import Awaitable, Callable

import discord

from utils import automation_ui as _base

OK = "<:emoji_4:1566043104551768114>"
BAD = "<a:emoji_38:1567096105299214336>"
ARROW = "<a:emoji_39:1567099222103294022>"          # bullet used in the invite stats card (change to your custom emoji if you like)
GRAY = 0x4F545C
MEDALS = {1: "<a:1_:1567105143365832734>", 2: "<a:3_:1567105212357812286>", 3: "<a:2_:1567105189431869531>"}   # <a:1_:1567105143365832734> <a:3_:1567105212357812286> <a:2_:1567105189431869531>

_text = _base._text
_PagerButton = _base._PagerButton


def _view(*children) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView(timeout=None)
    box = discord.ui.Container()
    for child in children:
        box.add_item(child)
    view.add_item(box)
    return view


# --------------------------------------------------------------------------
# Small result panels
# --------------------------------------------------------------------------
def notice(icon: str, message: str) -> discord.ui.LayoutView:
    return _view(_text(f"{icon} **{message}**"))


def success(message: str) -> discord.ui.LayoutView:
    return notice(OK, message)


def error(message: str) -> discord.ui.LayoutView:
    return notice(BAD, message)


def text_panel(title: str, body: str) -> discord.ui.LayoutView:
    return _view(_text(f"### {title}"), discord.ui.Separator(), _text(body))


def footer_for(ctx) -> str:
    return f"Requested by {ctx.author.name} • <t:{int(time.time())}:t>"


def card(author: str, icon: str | None, body: str, footer: str | None = None) -> discord.ui.LayoutView:
    """Stat card: author line + text, avatar on the right, small footer."""
    view = discord.ui.LayoutView(timeout=None)
    box = discord.ui.Container()
    content = _text(f"**{author}**\n\n{body}")
    if icon:
        box.add_item(discord.ui.Section(content, accessory=discord.ui.Thumbnail(media=icon)))
    else:
        box.add_item(content)
    if footer:
        box.add_item(discord.ui.Separator())
        box.add_item(_text(f"-# {footer}"))
    view.add_item(box)
    return view


# --------------------------------------------------------------------------
# Paged board  « ‹ <:bin:1567102784552304640> › »
# --------------------------------------------------------------------------
class BoardView(discord.ui.LayoutView):
    def __init__(self, ctx, title: str, subtitle: str, rows: list[str], per_page: int = 10):
        super().__init__(timeout=120)
        self.ctx = ctx
        self.owner_id = ctx.author.id
        self.title = title
        self.subtitle = subtitle
        self.pages = [rows[i:i + per_page] for i in range(0, len(rows), per_page)] or [[]]
        self.index = 0
        self.expired = False
        self.message: discord.Message | None = None
        self._build()

    def _build(self) -> None:
        self.clear_items()
        last = len(self.pages) - 1
        off = self.expired
        buttons = discord.ui.ActionRow()
        buttons.add_item(_PagerButton("first", emoji="<:icon_2:1567113746374197318>", disabled=off or self.index == 0))
        buttons.add_item(_PagerButton("prev", emoji="<:left:1567104063240146984>", disabled=off or self.index == 0))
        buttons.add_item(_PagerButton("stop", emoji="<:bin:1567102784552304640>", disabled=off))
        buttons.add_item(_PagerButton("next", emoji="<:right:1567104038284034058>", disabled=off or self.index == last))
        buttons.add_item(_PagerButton("last", emoji="<:icon_3:1567113772852838410>", disabled=off or self.index == last))
        footer = f"Requested by {self.ctx.author.name}"
        if len(self.pages) > 1:
            footer += f" | Page {self.index + 1}/{len(self.pages)}"
        box = discord.ui.Container()
        box.add_item(_text(f"## {self.title}"))
        box.add_item(discord.ui.Separator())
        box.add_item(_text(f"{self.subtitle}\n\n" + "\n".join(self.pages[self.index])))
        box.add_item(discord.ui.Separator())
        box.add_item(_text(f"-# {footer}"))
        box.add_item(discord.ui.Separator())
        box.add_item(buttons)
        self.add_item(box)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user and (interaction.user.id == self.owner_id or interaction.user.id in _base.OWNER_IDS):
            return True
        await interaction.response.send_message(
            "Uh oh! That message doesn't belong to you.\nYou must run this command to interact with it.",
            ephemeral=True)
        return False

    async def handle(self, interaction: discord.Interaction, action: str) -> None:
        if action == "stop":
            self.stop()
            try:
                await interaction.response.defer()
                await interaction.message.delete()
            except discord.HTTPException:
                pass
            return
        last = len(self.pages) - 1
        self.index = {"first": 0, "prev": max(0, self.index - 1),
                      "next": min(last, self.index + 1), "last": last}[action]
        self._build()
        await interaction.response.edit_message(view=self)

    async def on_timeout(self) -> None:
        self.expired = True
        if self.message is None:
            return
        try:
            self._build()
            await self.message.edit(view=self)
        except Exception:
            pass


async def send_board(ctx, title: str, subtitle: str, rows: list[str]) -> None:
    view = BoardView(ctx, title, subtitle, rows)
    view.message = await ctx.reply(view=view, mention_author=False)


def live_view(title: str, subtitle: str, rows: list[str]) -> discord.ui.LayoutView:
    body = "\n".join(rows) if rows else "No stats recorded yet."
    return _view(
        _text(f"## {title}"), discord.ui.Separator(),
        _text(f"{subtitle}\n\n{body}"), discord.ui.Separator(),
        _text(f"-# Live leaderboard • updated <t:{int(time.time())}:R>"))


# --------------------------------------------------------------------------
# Yes / No confirmation
# --------------------------------------------------------------------------
class _ConfirmButton(discord.ui.Button):
    def __init__(self, yes: bool):
        super().__init__(style=discord.ButtonStyle.danger if yes else discord.ButtonStyle.secondary,
                         label="Yes, continue" if yes else "Cancel")
        self.yes = yes

    async def callback(self, interaction: discord.Interaction):
        await self.view.answer(interaction, self.yes)


class ConfirmView(discord.ui.LayoutView):
    def __init__(self, ctx, prompt: str, on_confirm: Callable[[], Awaitable[str]]):
        super().__init__(timeout=30)
        self.owner_id = ctx.author.id
        self.on_confirm = on_confirm
        self.message: discord.Message | None = None
        row = discord.ui.ActionRow()
        row.add_item(_ConfirmButton(True))
        row.add_item(_ConfirmButton(False))
        box = discord.ui.Container()
        box.add_item(_text(f"<a:emoji_250:1567101252712530020> **{prompt}**"))
        box.add_item(row)
        self.add_item(box)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == self.owner_id:
            return True
        await interaction.response.send_message("This confirmation is not for you.", ephemeral=True)
        return False

    async def answer(self, interaction: discord.Interaction, yes: bool) -> None:
        self.stop()
        if yes:
            message = await self.on_confirm()
            await interaction.response.edit_message(view=success(message))
        else:
            await interaction.response.edit_message(view=error("Cancelled."))

    async def on_timeout(self) -> None:
        if self.message is not None:
            try:
                await self.message.edit(view=error("Timed out. Nothing was changed."))
            except Exception:
                pass


async def confirm(ctx, prompt: str, on_confirm: Callable[[], Awaitable[str]]) -> None:
    view = ConfirmView(ctx, prompt, on_confirm)
    view.message = await ctx.reply(view=view, mention_author=False)


# --------------------------------------------------------------------------
# Help (same look as the reference:  `?help top messages`)
# --------------------------------------------------------------------------
async def send_command_help(ctx, command) -> None:
    prefix = ctx.clean_prefix
    title = command.qualified_name.title()
    desc = command.help or command.short_doc or "No description provided."
    sig = (command.signature or "").strip()
    usage = f"{prefix}{command.qualified_name}" + (f" {sig}" if sig else "")
    aliases = ", ".join(f"`{a}`" for a in command.aliases) if command.aliases else "`None`"
    view = _view(
        _text(f"> __**{title}**__"),
        discord.ui.Separator(),
        _text(f"> *{desc}*\n\n__**Command Usage**__\n`{usage}`"),
        discord.ui.Separator(),
        _text(f"**Aliases**\n{aliases}"),
    )
    await ctx.reply(view=view, mention_author=False)


async def send_group_help(ctx, group) -> None:
    await _base.send_group_help(ctx, group, accent=GRAY)
