"""Find a log channel even when it isn't in the cache yet (falls back to an API fetch)."""
from __future__ import annotations

import logging
from typing import Optional

import discord


async def get_log_channel(bot, channel_id: int) -> Optional[discord.abc.Messageable]:
    channel = bot.get_channel(channel_id)
    if channel is not None:
        return channel
    try:
        return await bot.fetch_channel(channel_id)
    except discord.HTTPException as exc:
        logging.error(f"Log channel {channel_id} unavailable: {exc}")
        return None
