"""Creates / repairs log channels and the webhooks that deliver the logs."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field

import discord

from utils.logging_store import CATEGORY_NAME, TYPE_CHANNEL, TYPE_LABEL, store


class SetupError(Exception):
    """User-facing setup problem (missing permission, ...)."""


@dataclass
class SetupResult:
    created: list[str] = field(default_factory=list)
    reused: list[str] = field(default_factory=list)
    failed: list[tuple[str, str]] = field(default_factory=list)
    category: discord.abc.GuildChannel | None = None


def webhook_name(bot_user: discord.abc.User) -> str:
    name = f"{bot_user.name} Logs"
    for banned in ("discord", "clyde"):
        name = name.replace(banned, "").replace(banned.title(), "")
    return (name.strip() or "Server Logs")[:80]


def need_perms(guild: discord.Guild, *names: str) -> None:
    me = guild.me
    missing = [n.replace("_", " ").title() for n in names if not getattr(me.guild_permissions, n)]
    if missing:
        raise SetupError("I need these permissions: " + ", ".join(f"`{m}`" for m in missing) + ".")


async def ensure_webhook(channel: discord.TextChannel, bot_user, *, reason: str) -> discord.Webhook:
    """Reuse the bot's own logging webhook in ``channel`` or create one."""
    name = webhook_name(bot_user)
    for hook in await channel.webhooks():
        if hook.user is not None and hook.user.id == bot_user.id and hook.token and hook.name == name:
            return hook
    return await channel.create_webhook(name=name, reason=reason)


async def bind(channel: discord.TextChannel, bot_user, log_type: str, *, reason: str) -> None:
    """Make ``channel`` the destination of ``log_type`` (creates its webhook)."""
    hook = await ensure_webhook(channel, bot_user, reason=reason)
    await store.set_target(channel.guild.id, log_type, channel.id, hook.id, hook.token or "")


def _overwrites(guild: discord.Guild, invoker: discord.abc.User | None):
    ow = {
        guild.default_role: discord.PermissionOverwrite(view_channel=False),
        guild.me: discord.PermissionOverwrite(
            view_channel=True, send_messages=True, embed_links=True, read_message_history=True,
            manage_webhooks=True, manage_channels=True),
    }
    member = guild.get_member(invoker.id) if invoker else None
    if member is not None and member != guild.me:
        ow[member] = discord.PermissionOverwrite(view_channel=True, read_message_history=True)
    return ow


async def setup_logs(guild: discord.Guild, bot_user, types: list[str], *,
                     category: discord.CategoryChannel | None = None,
                     invoker: discord.abc.User | None = None) -> SetupResult:
    """Create (or reuse) a category + one private channel/webhook per log type."""
    need_perms(guild, "manage_channels", "manage_webhooks")
    reason = f"Logging setup by {invoker}" if invoker else "Logging setup"
    cfg = store.ensure(guild.id)
    result = SetupResult()

    if category is None and cfg.category_id:
        found = guild.get_channel(cfg.category_id)
        category = found if isinstance(found, discord.CategoryChannel) else None
    if category is None:
        category = discord.utils.get(guild.categories, name=CATEGORY_NAME)
    if category is None:
        category = await guild.create_category(CATEGORY_NAME, overwrites=_overwrites(guild, invoker), reason=reason)
    result.category = category
    await store.set_category(guild.id, category.id)

    # 1) channels - sequential so Discord keeps them in order
    channels: dict[str, discord.TextChannel] = {}
    for key in types:
        label = TYPE_LABEL[key]
        existing = cfg.targets.get(key)
        channel = guild.get_channel(existing.channel_id) if existing else None
        if not isinstance(channel, discord.TextChannel):
            channel = discord.utils.get(category.text_channels, name=TYPE_CHANNEL[key])
            created = False
            if channel is None:
                try:
                    channel = await guild.create_text_channel(
                        TYPE_CHANNEL[key], category=category, overwrites=_overwrites(guild, invoker), reason=reason)
                    created = True
                except discord.HTTPException as exc:
                    result.failed.append((label, f"channel: {exc.text or exc}"))
                    continue
            (result.created if created else result.reused).append(label)
        else:
            result.reused.append(label)
        channels[key] = channel

    # 2) webhooks - parallel (each channel has its own rate-limit bucket)
    async def _bind(key: str, channel: discord.TextChannel):
        try:
            await bind(channel, bot_user, key, reason=reason)
        except (discord.HTTPException, SetupError) as exc:
            result.failed.append((TYPE_LABEL[key], f"webhook: {getattr(exc, 'text', None) or exc}"))

    await asyncio.gather(*(_bind(k, c) for k, c in channels.items()))
    await store.set_enabled(guild.id, True)
    return result


async def drop_webhooks(bot, targets) -> None:
    """Best-effort delete of the webhooks the bot created for ``targets``."""
    async def _one(t):
        if not t.webhook_id:
            return
        try:
            hook = await bot.fetch_webhook(t.webhook_id)
            await hook.delete(reason="Logging cleared")
        except discord.HTTPException:
            pass
    await asyncio.gather(*(_one(t) for t in targets))
