"""Logging storage: per-guild config, log channels + their webhooks, ignore lists.

Speed notes
-----------
* Everything is loaded into memory once (``load_all``).  The event engine only
  ever reads plain dicts/sets, so a log event never touches SQLite.
* Every write updates the in-memory copy first and then persists it on one
  long-lived WAL connection (write-through).
"""
from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass, field
from typing import Dict, Optional, Set

import aiosqlite

LOGGING_DB = "db/logging.db"

# (key, label, channel name) - ORDER is the order shown in `logging config`.
LOG_TYPES: tuple[tuple[str, str, str], ...] = (
    ("system", "System Logs", "system-logs"),
    ("join", "Join Logs", "join-logs"),
    ("leave", "Leave Logs", "leave-logs"),
    ("member", "Member Logs", "member-logs"),
    ("message", "Message Logs", "message-logs"),
    ("thread", "Thread Logs", "thread-logs"),
    ("voice", "Voice Logs", "voice-logs"),
    ("stage", "Stage Logs", "stage-logs"),
    ("moderation", "Moderation Logs", "moderation-logs"),
    ("channel", "Channel Logs", "channel-logs"),
    ("server", "Server Logs", "server-logs"),
    ("event", "Event Logs", "event-logs"),
    ("webhook", "Webhook Logs", "webhook-logs"),
    ("role", "Role Logs", "role-logs"),
    ("application", "Application Logs", "application-logs"),
    ("alert", "Alert Logs", "alert-logs"),
)
TYPE_KEYS: tuple[str, ...] = tuple(t[0] for t in LOG_TYPES)
TYPE_LABEL: Dict[str, str] = {k: label for k, label, _ in LOG_TYPES}
TYPE_CHANNEL: Dict[str, str] = {k: name for k, _, name in LOG_TYPES}

CATEGORY_NAME = "Death Logs"
IGNORE_LIMIT = 50


def resolve_type(text: str) -> Optional[str]:
    """'system', 'System Logs', 'system-logs', 'systemlogs' -> 'system'."""
    t = text.strip().lower().replace("_", " ").replace("-", " ")
    for suffix in (" logs", " log"):
        if t.endswith(suffix):
            t = t[: -len(suffix)]
    t = t.replace(" ", "")
    aliases = {"mod": "moderation", "msg": "message", "messages": "message", "vc": "voice",
               "channels": "channel", "roles": "role", "members": "member", "threads": "thread",
               "events": "event", "webhooks": "webhook", "apps": "application", "app": "application",
               "applications": "application", "alerts": "alert", "joins": "join", "leaves": "leave"}
    t = aliases.get(t, t)
    return t if t in TYPE_LABEL else None


@dataclass
class Target:
    channel_id: int
    webhook_id: int = 0
    webhook_token: str = ""


@dataclass
class GuildLog:
    guild_id: int
    enabled: bool = True
    category_id: int = 0
    ignore_embeds: bool = True
    ignore_voice: bool = False
    targets: Dict[str, Target] = field(default_factory=dict)
    ignored_users: Set[int] = field(default_factory=set)
    ignored_roles: Set[int] = field(default_factory=set)

    def target(self, log_type: str) -> Optional[Target]:
        """Hot path: ``None`` when logging is off or this type has no channel."""
        if not self.enabled:
            return None
        return self.targets.get(log_type)


class LoggingStore:
    def __init__(self) -> None:
        self._db: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()
        self._guilds: Dict[int, GuildLog] = {}
        self._loaded = False

    # ------------------------------------------------------------------ setup
    async def _open(self) -> aiosqlite.Connection:
        if self._db is not None:
            return self._db
        async with self._lock:
            if self._db is None:
                os.makedirs("db", exist_ok=True)
                conn = await aiosqlite.connect(LOGGING_DB)
                await conn.execute("PRAGMA journal_mode=WAL")
                await conn.execute("PRAGMA synchronous=NORMAL")
                await conn.executescript("""
                    CREATE TABLE IF NOT EXISTS log_config (
                        guild_id INTEGER PRIMARY KEY,
                        enabled INTEGER NOT NULL DEFAULT 1,
                        category_id INTEGER NOT NULL DEFAULT 0,
                        ignore_embeds INTEGER NOT NULL DEFAULT 1,
                        ignore_voice INTEGER NOT NULL DEFAULT 0);
                    CREATE TABLE IF NOT EXISTS log_targets (
                        guild_id INTEGER, log_type TEXT, channel_id INTEGER,
                        webhook_id INTEGER NOT NULL DEFAULT 0,
                        webhook_token TEXT NOT NULL DEFAULT '',
                        PRIMARY KEY (guild_id, log_type));
                    CREATE TABLE IF NOT EXISTS log_ignored (
                        guild_id INTEGER, kind TEXT, target_id INTEGER,
                        PRIMARY KEY (guild_id, kind, target_id));
                """)
                await conn.commit()
                self._db = conn
        return self._db

    async def load_all(self) -> None:
        if self._loaded:
            return
        db = await self._open()
        guilds: Dict[int, GuildLog] = {}
        async with db.execute("SELECT guild_id, enabled, category_id, ignore_embeds, ignore_voice FROM log_config") as cur:
            async for gid, en, cat, ie, iv in cur:
                guilds[gid] = GuildLog(gid, bool(en), cat, bool(ie), bool(iv))
        async with db.execute("SELECT guild_id, log_type, channel_id, webhook_id, webhook_token FROM log_targets") as cur:
            async for gid, lt, cid, wid, tok in cur:
                if lt in TYPE_LABEL:
                    guilds.setdefault(gid, GuildLog(gid)).targets[lt] = Target(cid, wid, tok)
        async with db.execute("SELECT guild_id, kind, target_id FROM log_ignored") as cur:
            async for gid, kind, tid in cur:
                g = guilds.setdefault(gid, GuildLog(gid))
                (g.ignored_users if kind == "user" else g.ignored_roles).add(tid)
        self._guilds = guilds
        self._loaded = True

    # ------------------------------------------------------------------ reads (memory only)
    def get(self, guild_id: int) -> Optional[GuildLog]:
        return self._guilds.get(guild_id)

    def ensure(self, guild_id: int) -> GuildLog:
        g = self._guilds.get(guild_id)
        if g is None:
            g = self._guilds[guild_id] = GuildLog(guild_id)
        return g

    def configured_guild_ids(self) -> list[int]:
        return [gid for gid, g in self._guilds.items() if g.enabled and g.targets]

    # ------------------------------------------------------------------ writes
    async def _save_config(self, g: GuildLog) -> None:
        db = await self._open()
        await db.execute(
            "INSERT OR REPLACE INTO log_config (guild_id, enabled, category_id, ignore_embeds, ignore_voice) "
            "VALUES (?,?,?,?,?)",
            (g.guild_id, int(g.enabled), g.category_id, int(g.ignore_embeds), int(g.ignore_voice)))
        await db.commit()

    async def set_enabled(self, guild_id: int, value: bool) -> None:
        g = self.ensure(guild_id)
        g.enabled = value
        await self._save_config(g)

    async def set_flag(self, guild_id: int, flag: str, value: bool) -> None:
        g = self.ensure(guild_id)
        setattr(g, flag, value)
        await self._save_config(g)

    async def set_category(self, guild_id: int, category_id: int) -> None:
        g = self.ensure(guild_id)
        g.category_id = category_id
        await self._save_config(g)

    async def set_target(self, guild_id: int, log_type: str, channel_id: int,
                         webhook_id: int = 0, webhook_token: str = "") -> None:
        g = self.ensure(guild_id)
        g.targets[log_type] = Target(channel_id, webhook_id, webhook_token)
        db = await self._open()
        await db.execute(
            "INSERT OR REPLACE INTO log_targets (guild_id, log_type, channel_id, webhook_id, webhook_token) "
            "VALUES (?,?,?,?,?)", (guild_id, log_type, channel_id, webhook_id, webhook_token))
        await db.commit()
        await self._save_config(g)  # makes sure a config row exists

    async def remove_target(self, guild_id: int, log_type: str) -> Optional[Target]:
        g = self._guilds.get(guild_id)
        if g is None:
            return None
        old = g.targets.pop(log_type, None)
        if old is not None:
            db = await self._open()
            await db.execute("DELETE FROM log_targets WHERE guild_id=? AND log_type=?", (guild_id, log_type))
            await db.commit()
        return old

    async def clear_targets(self, guild_id: int) -> Dict[str, Target]:
        g = self._guilds.get(guild_id)
        if g is None:
            return {}
        old, g.targets = g.targets, {}
        g.category_id = 0
        db = await self._open()
        await db.execute("DELETE FROM log_targets WHERE guild_id=?", (guild_id,))
        await self._save_config(g)
        return old

    async def ignore_add(self, guild_id: int, kind: str, target_id: int) -> bool:
        g = self.ensure(guild_id)
        bucket = g.ignored_users if kind == "user" else g.ignored_roles
        if target_id in bucket:
            return False
        bucket.add(target_id)
        db = await self._open()
        await db.execute("INSERT OR IGNORE INTO log_ignored (guild_id, kind, target_id) VALUES (?,?,?)",
                         (guild_id, kind, target_id))
        await db.commit()
        return True

    async def ignore_remove(self, guild_id: int, kind: str, target_id: int) -> bool:
        g = self._guilds.get(guild_id)
        if g is None:
            return False
        bucket = g.ignored_users if kind == "user" else g.ignored_roles
        if target_id not in bucket:
            return False
        bucket.discard(target_id)
        db = await self._open()
        await db.execute("DELETE FROM log_ignored WHERE guild_id=? AND kind=? AND target_id=?",
                         (guild_id, kind, target_id))
        await db.commit()
        return True

    async def delete_guild(self, guild_id: int) -> None:
        self._guilds.pop(guild_id, None)
        db = await self._open()
        for table in ("log_config", "log_targets", "log_ignored"):
            await db.execute(f"DELETE FROM {table} WHERE guild_id=?", (guild_id,))
        await db.commit()

    async def close(self) -> None:
        if self._db is not None:
            await self._db.close()
            self._db = None


store = LoggingStore()
