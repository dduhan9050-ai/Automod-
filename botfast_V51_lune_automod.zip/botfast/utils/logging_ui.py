"""White (#ffffff) Components V2 container replies for the Logging module."""
from __future__ import annotations

import discord

from utils.logging_store import LOG_TYPES, TYPE_LABEL, GuildLog

WHITE = discord.Colour(0xFFFFFF)
ARROW = "❯"  # ❯
TICK, CROSS = "<:emoji_4:1566043104551768114>", "<a:emoji_38:1567096105299214336>"
NO_PING = discord.AllowedMentions.none()


def _t(text: str) -> discord.ui.TextDisplay:
    return discord.ui.TextDisplay((text or "​")[:3990])


def box(*children, timeout: float | None = None) -> discord.ui.LayoutView:
    """One #ffffff container holding ``children``."""
    view = discord.ui.LayoutView(timeout=timeout)
    container = discord.ui.Container(accent_colour=WHITE)
    for child in children:
        container.add_item(child)
    view.add_item(container)
    return view


def card(title: str, body: str = "", *, footer: str | None = None,
         thumbnail: str | None = None) -> discord.ui.LayoutView:
    text = f"## {title}" + (f"\n{body}" if body else "")
    items: list = []
    if thumbnail:
        items.append(discord.ui.Section(_t(text), accessory=discord.ui.Thumbnail(media=thumbnail)))
    else:
        items.append(_t(text))
    if footer:
        items += [discord.ui.Separator(), _t(f"-# {footer}")]
    return box(*items)


def ok(title: str, body: str = "") -> discord.ui.LayoutView:
    return card(f"{TICK} {title}", body)


def fail(title: str, body: str = "") -> discord.ui.LayoutView:
    return card(f"{CROSS} {title}", body)


def warn(title: str, body: str = "") -> discord.ui.LayoutView:
    return card(f"<a:emoji_250:1567101252712530020> {title}", body)


def working(title: str, body: str = "") -> discord.ui.LayoutView:
    return card(f"<a:emoji_40:1567099263513526273> {title}", body)


def yn(value: bool) -> str:
    return TICK if value else CROSS


# ------------------------------------------------------------------ config panel
def _channel_text(guild: discord.Guild, channel_id: int) -> str:
    ch = guild.get_channel(channel_id) if guild else None
    return ch.mention if ch is not None else f"`#deleted-channel` (`{channel_id}`)"


def config_view(ctx, cfg: GuildLog | None, *, notes: list[str] | None = None) -> discord.ui.LayoutView:
    guild = ctx.guild
    cfg = cfg or GuildLog(guild.id)
    category = f"<#{cfg.category_id}>" if cfg.category_id and guild.get_channel(cfg.category_id) else "`Not set`"
    head = (f"## <:emoji_81:1567148256260005978> Logging Configuration\n"
            f"> **Logging :** {yn(cfg.enabled)}\n"
            f"> **Category :** {category}\n"
            f"> **Ignore Embeds :** {yn(cfg.ignore_embeds)}\n"
            f"> **Ignore Voice :** {yn(cfg.ignore_voice)}")
    lines = []
    for key, label, _ in LOG_TYPES:
        target = cfg.targets.get(key)
        where = _channel_text(guild, target.channel_id) if target else "`Not configured`"
        lines.append(f"<a:emoji_39:1567099222103294022> `{label}` → {where}")
    ignored = [f"<@{i}>" for i in sorted(cfg.ignored_users)][:10] + [f"<@&{i}>" for i in sorted(cfg.ignored_roles)][:10]
    body = "__**Logging Channels :**__\n\n" + "\n".join(lines)
    items: list = []
    avatar = getattr(getattr(ctx.bot.user, "display_avatar", None), "url", None)
    items.append(discord.ui.Section(_t(head), accessory=discord.ui.Thumbnail(media=str(avatar)))
                 if avatar else _t(head))
    items += [discord.ui.Separator(), _t(body)]
    if ignored:
        total = len(cfg.ignored_users) + len(cfg.ignored_roles)
        extra = f" (+{total - len(ignored)} more)" if total > len(ignored) else ""
        items += [discord.ui.Separator(), _t(f"__**Ignored :**__ {', '.join(ignored)}{extra}")]
    if notes:
        items += [discord.ui.Separator(), _t("\n".join(f"<a:emoji_250:1567101252712530020> {n}" for n in notes))]
    items += [discord.ui.Separator(),
              _t(f"-# Requested by {ctx.author.mention} (`{ctx.author.name}`)")]
    return box(*items)


# ------------------------------------------------------------------ help panels
LEGEND = "`<..> <required> | [..] [optional]`"


def _usage(prefix: str, command) -> str:
    sig = (command.signature or "").strip()
    return f"{prefix}{command.qualified_name}" + (f" {sig}" if sig else "")


def _entry(prefix: str, command) -> str:
    desc = command.short_doc or command.help or "No description provided."
    return f"> `{_usage(prefix, command)}`\n> {ARROW} {desc}"


def group_help_view(ctx, group) -> discord.ui.LayoutView:
    subs = [c for c in group.commands if not c.hidden]
    order = (getattr(group, "extras", None) or {}).get("help_order")
    if order:
        rank = {n: i for i, n in enumerate(order)}
        subs.sort(key=lambda c: (rank.get(c.name, len(rank)), c.name))
    else:
        subs.sort(key=lambda c: c.name)
    prefix = ctx.clean_prefix
    body = LEGEND + "\n\n" + "\n\n".join(_entry(prefix, c) for c in subs)
    return card(f"{ctx.bot.user.name} {group.qualified_name} [{len(subs)}]", body)


def command_help_view(ctx, command) -> discord.ui.LayoutView:
    desc = command.short_doc or command.help or "No description provided."
    aliases = f"\n> **Aliases :** {', '.join(f'`{a}`' for a in command.aliases)}" if command.aliases else ""
    body = f"{LEGEND}\n\n> `{_usage(ctx.clean_prefix, command)}`\n> {ARROW} {desc}{aliases}"
    return card(command.qualified_name, body)


async def send_group_help(ctx, group) -> None:
    await ctx.reply(view=group_help_view(ctx, group), mention_author=False, allowed_mentions=NO_PING)


async def send_command_help(ctx, command) -> None:
    await ctx.reply(view=command_help_view(ctx, command), mention_author=False, allowed_mentions=NO_PING)


# ------------------------------------------------------------------ wizard
class _TypeSelect(discord.ui.Select):
    def __init__(self):
        options = [discord.SelectOption(label=label, value=key, default=True) for key, label, _ in LOG_TYPES]
        super().__init__(placeholder="Select the logs you want", min_values=1,
                         max_values=len(options), options=options)

    async def callback(self, interaction: discord.Interaction):
        self.view.chosen = list(self.values)
        for opt in self.options:
            opt.default = opt.value in self.values
        await interaction.response.defer()


class _CategorySelect(discord.ui.ChannelSelect):
    def __init__(self):
        super().__init__(placeholder="Use an existing category (optional)",
                         channel_types=[discord.ChannelType.category], min_values=0, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        self.view.category = self.values[0] if self.values else None
        await interaction.response.defer()


class _StartButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Start Setup", style=discord.ButtonStyle.success, emoji="\U0001f680")

    async def callback(self, interaction: discord.Interaction):
        await self.view.start(interaction)


class _CancelButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Cancel", style=discord.ButtonStyle.danger)

    async def callback(self, interaction: discord.Interaction):
        self.view.stop()
        await interaction.response.edit_message(view=fail("Wizard Cancelled", "Nothing was changed."))


class WizardView(discord.ui.LayoutView):
    """Interactive `logging wizard`: pick logs (+ optional category), press Start."""

    def __init__(self, ctx, runner):
        super().__init__(timeout=180)
        self.ctx = ctx
        self.runner = runner  # async (types, category|None) -> discord.ui.LayoutView
        self.chosen: list[str] = [k for k, _, _ in LOG_TYPES]
        self.category: discord.abc.GuildChannel | None = None
        self.message: discord.Message | None = None
        self.running = False
        container = discord.ui.Container(accent_colour=WHITE)
        container.add_item(_t(
            "## \U0001f9d9 Logging Wizard\n"
            "Pick the logs to set up (all are selected), optionally choose an existing category, "
            "then press **Start Setup**. I will create the channels and a webhook for each one."))
        container.add_item(discord.ui.Separator())
        for item in (_TypeSelect(), _CategorySelect()):
            row = discord.ui.ActionRow()
            row.add_item(item)
            container.add_item(row)
        buttons = discord.ui.ActionRow()
        buttons.add_item(_StartButton())
        buttons.add_item(_CancelButton())
        container.add_item(buttons)
        container.add_item(_t(f"-# Requested by {ctx.author.name}"))
        self.add_item(container)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == self.ctx.author.id:
            return True
        await interaction.response.send_message("This wizard belongs to someone else. Run the command yourself.",
                                                ephemeral=True)
        return False

    async def start(self, interaction: discord.Interaction):
        if self.running:
            return await interaction.response.defer()
        self.running = True
        self.stop()
        await interaction.response.edit_message(view=working(
            "Setting up logging", f"Creating `{len(self.chosen)}` log channel(s) and webhooks. This takes a few seconds."))
        result = await self.runner(self.chosen, self.category)
        try:
            await interaction.edit_original_response(view=result)
        except discord.HTTPException:
            pass

    async def on_timeout(self) -> None:
        if self.running or self.message is None:
            return
        try:
            await self.message.edit(view=fail("Wizard Timed Out", "Run the command again to restart it."))
        except discord.HTTPException:
            pass
