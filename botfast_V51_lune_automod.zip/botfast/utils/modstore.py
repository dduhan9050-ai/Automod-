"""Tiny persistent store for the Moderation module.

Everything the commands need on the hot path lives in plain dicts (zero disk I/O).
Writes go to SQLite through ONE background thread, so a command never waits for disk.
"""
from __future__ import annotations

import json
import logging
import sqlite3
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

log = logging.getLogger("deathbot.modstore")

DB_PATH = Path(__file__).resolve().parent.parent / "db" / "zmod.db"

_SCHEMA = (
    "CREATE TABLE IF NOT EXISTS q_cfg (guild_id INTEGER PRIMARY KEY, role_id INTEGER, channel_id INTEGER,"
    " auto_role INTEGER DEFAULT 0, auto_channel INTEGER DEFAULT 0)",
    "CREATE TABLE IF NOT EXISTS q_members (guild_id INTEGER, user_id INTEGER, roles TEXT, reason TEXT,"
    " mod_id INTEGER, ts REAL, PRIMARY KEY (guild_id, user_id))",
    "CREATE TABLE IF NOT EXISTS delete_after (channel_id INTEGER PRIMARY KEY, guild_id INTEGER, due REAL)",
)


class ModStore:
    def __init__(self, path: Path = DB_PATH):
        self.path = Path(path)
        self.cfg: dict[int, dict] = {}
        self.members: dict[int, dict[int, dict]] = {}
        self.delete_after: dict[int, tuple[int, float]] = {}
        self.loaded = False
        self._pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="modstore")

    # ------------------------------------------------------------------ io
    def _connect(self) -> sqlite3.Connection:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(self.path, timeout=10)
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA synchronous=NORMAL")
        return con

    def load(self) -> None:
        if self.loaded:
            return
        con = self._connect()
        try:
            for stmt in _SCHEMA:
                con.execute(stmt)
            con.commit()
            for gid, rid, cid, ar, ac in con.execute("SELECT guild_id, role_id, channel_id, auto_role, auto_channel FROM q_cfg"):
                self.cfg[gid] = {"role": rid, "channel": cid, "auto_role": bool(ar), "auto_channel": bool(ac)}
            for gid, uid, roles, reason, mod, ts in con.execute("SELECT guild_id, user_id, roles, reason, mod_id, ts FROM q_members"):
                try:
                    ids = [int(x) for x in json.loads(roles or "[]")]
                except Exception:
                    ids = []
                self.members.setdefault(gid, {})[uid] = {"roles": ids, "reason": reason, "mod": mod, "ts": ts}
            for cid, gid, due in con.execute("SELECT channel_id, guild_id, due FROM delete_after"):
                self.delete_after[cid] = (gid, due)
        finally:
            con.close()
        self.loaded = True

    def _do(self, sql: str, params: tuple = ()) -> None:
        try:
            con = self._connect()
            try:
                con.execute(sql, params)
                con.commit()
            finally:
                con.close()
        except Exception:
            log.exception("modstore write failed: %s", sql)

    def _write(self, sql: str, params: tuple = ()) -> None:
        self._pool.submit(self._do, sql, params)

    # ---------------------------------------------------------- quarantine
    def get_cfg(self, gid: int) -> dict:
        return self.cfg.get(gid) or {"role": None, "channel": None, "auto_role": False, "auto_channel": False}

    def set_cfg(self, gid: int, **kw) -> dict:
        cfg = dict(self.get_cfg(gid))
        cfg.update(kw)
        self.cfg[gid] = cfg
        self._write(
            "INSERT OR REPLACE INTO q_cfg (guild_id, role_id, channel_id, auto_role, auto_channel) VALUES (?,?,?,?,?)",
            (gid, cfg["role"], cfg["channel"], int(cfg["auto_role"]), int(cfg["auto_channel"])),
        )
        return cfg

    def guild_members(self, gid: int) -> dict[int, dict]:
        return self.members.get(gid) or {}

    def add_member(self, gid: int, uid: int, roles: list[int], reason: str | None, mod_id: int) -> dict:
        rec = {"roles": list(roles), "reason": reason, "mod": mod_id, "ts": time.time()}
        self.members.setdefault(gid, {})[uid] = rec
        self._write(
            "INSERT OR REPLACE INTO q_members (guild_id, user_id, roles, reason, mod_id, ts) VALUES (?,?,?,?,?,?)",
            (gid, uid, json.dumps(rec["roles"]), reason, mod_id, rec["ts"]),
        )
        return rec

    def remove_member(self, gid: int, uid: int) -> dict | None:
        rec = self.members.get(gid, {}).pop(uid, None)
        if rec is not None:
            self._write("DELETE FROM q_members WHERE guild_id=? AND user_id=?", (gid, uid))
        return rec

    def clear_guild(self, gid: int) -> None:
        self.cfg.pop(gid, None)
        self.members.pop(gid, None)
        self._write("DELETE FROM q_cfg WHERE guild_id=?", (gid,))
        self._write("DELETE FROM q_members WHERE guild_id=?", (gid,))

    # --------------------------------------------------------- deleteafter
    def set_delete_after(self, cid: int, gid: int, due: float) -> None:
        self.delete_after[cid] = (gid, due)
        self._write("INSERT OR REPLACE INTO delete_after (channel_id, guild_id, due) VALUES (?,?,?)", (cid, gid, due))

    def del_delete_after(self, cid: int) -> None:
        if self.delete_after.pop(cid, None) is not None:
            self._write("DELETE FROM delete_after WHERE channel_id=?", (cid,))

    def close(self) -> None:
        self._pool.shutdown(wait=True)


store = ModStore()
