"""Shared helpers for the Moderation module.

* Every reply is a native Components V2 card with the accent colour #ffffff.
* Emoji: <:emoji_4:1566043104551768114> success, <a:cross:1567096105299214336> failure / denied, <a:warn:1567101252712530020> error.
* ``guard`` bundles guild-only + blacklist/ignore + permission checks in the right order.
* ``pool`` runs bulk jobs (lockall, role all, ...) with a few parallel workers.
"""
from __future__ import annotations

import asyncio
import logging
import re
import traceback
from typing import Any, Awaitable, Callable, Iterable, Optional

import discord
from discord.ext import commands

from utils.Tools import blacklist_check, ignore_check
from utils import automation_ui as _base

log = logging.getLogger("deathbot.mod")

WHITE = discord.Colour(0xFFFFFF)
TICK = "<:emoji_4:1566043104551768114>"
CROSS = "<a:emoji_38:1567096105299214336>"
WARN = "<a:emoji_250:1567101252712530020>"
WAIT = "<a:emoji_40:1567099263513526273>"
ARROW = "❯"

# cog names of the Utility module (embed / sticky / reactionrole) - same white cards, short group listing
UTILITY_COGS = ("UtilEmbed", "UtilSticky", "UtilReactionRole", "CustomRole", "Voice", "VcRole")

# cog names that get the shared white help cards + friendly error mapping
MOD_COGS = ("ModBasic", "ModChannels", "ModRoles", "ModPurge", "ModEmoji", "Quarantine") + UTILITY_COGS

NO_REASON = "No reason provided"
NO_PING = discord.AllowedMentions.none()
LEGEND = "```<..> <required> | [..] [optional]```"

_tasks: set[asyncio.Task] = set()


# ------------------------------------------------------------------ cards
def _td(text: str) -> discord.ui.TextDisplay:
    return discord.ui.TextDisplay((text or "​")[:3990])


def card(*children: Any, accent: discord.Colour = WHITE) -> discord.ui.LayoutView:
    """One white container; plain strings become text blocks."""
    view = discord.ui.LayoutView(timeout=None)
    box = discord.ui.Container(accent_colour=accent)
    for child in children:
        box.add_item(_td(child) if isinstance(child, str) else child)
    view.add_item(box)
    return view


def line(icon: str, text: str) -> discord.ui.LayoutView:
    return card(f"{icon} | {text}")


def panel(icon: str, title: str, *blocks: str) -> discord.ui.LayoutView:
    body = "\n".join(b for b in blocks if b)
    return card(f"### {icon} {title}" + (f"\n{body}" if body else ""))


def spawn(coro: Awaitable) -> asyncio.Task:
    """Fire-and-forget (keeps a reference so the task is not garbage collected)."""
    task = asyncio.ensure_future(coro)
    _tasks.add(task)
    task.add_done_callback(_tasks.discard)
    return task


# ---------------------------------------------------------------- sending
async def send(ctx: commands.Context, view: discord.ui.LayoutView, **kw) -> Optional[discord.Message]:
    ref = ctx.message.to_reference(fail_if_not_exists=False)
    kw.setdefault("allowed_mentions", NO_PING)
    return await ctx.send(view=view, reference=ref, mention_author=False, **kw)


async def ok(ctx, text: str, **kw):
    return await send(ctx, line(TICK, text), **kw)


async def fail(ctx, text: str, **kw):
    return await send(ctx, line(CROSS, text), **kw)


async def err(ctx, text: str, **kw):
    return await send(ctx, line(WARN, text), **kw)


async def edit(message: Optional[discord.Message], view: discord.ui.LayoutView) -> None:
    if message is None:
        return
    try:
        await message.edit(view=view, allowed_mentions=NO_PING)
    except discord.HTTPException:
        pass


def esc(text: Any) -> str:
    return discord.utils.escape_markdown(str(text))


def who(target: Any) -> str:
    """Safe display for a member / user (never pings)."""
    name = getattr(target, "display_name", None) or getattr(target, "name", None) or str(target)
    return f"**{esc(name)}**"


def reason_text(ctx, reason: Optional[str]) -> str:
    return f"{reason or NO_REASON} | {ctx.author} ({ctx.author.id})"[:512]


async def dm(user: discord.abc.Messageable, text: str) -> None:
    try:
        await user.send(view=line(CROSS, text))
    except Exception:
        pass


# ----------------------------------------------------------------- guards
def guard(user_perms: Optional[dict] = None, bot_perms: Optional[dict] = None):
    """guild_only -> blacklist -> ignore -> user permissions -> bot permissions."""

    def deco(func):
        if bot_perms:
            func = commands.bot_has_permissions(**bot_perms)(func)
        if user_perms:
            func = commands.has_permissions(**user_perms)(func)
        func = ignore_check()(func)
        func = blacklist_check()(func)
        func = commands.guild_only()(func)
        return func

    return deco


def hierarchy(ctx: commands.Context, target: Any, *, allow_self: bool = False) -> Optional[str]:
    """Return an error text if ``ctx.author`` / the bot may not act on ``target``."""
    guild = ctx.guild
    if target.id == ctx.author.id and not allow_self:
        return "You can't do that to yourself."
    if target.id == guild.me.id:
        return "I can't do that to myself."
    if target.id == guild.owner_id:
        return "I can't do that to the server owner."
    if isinstance(target, discord.Member):
        if ctx.author.id != guild.owner_id and target.id != ctx.author.id and target.top_role >= ctx.author.top_role:
            return f"Your top role must be higher than {who(target)}'s top role."
        if target.top_role >= guild.me.top_role:
            return f"My top role must be higher than {who(target)}'s top role."
    return None


def role_error(ctx: commands.Context, role: discord.Role) -> Optional[str]:
    guild = ctx.guild
    if role.is_default():
        return "The `@everyone` role can't be managed."
    if role.managed:
        return f"**{esc(role.name)}** is managed by an integration and can't be assigned."
    if role >= guild.me.top_role:
        return f"My top role must be higher than **{esc(role.name)}**."
    if ctx.author.id != guild.owner_id and role >= ctx.author.top_role:
        return f"Your top role must be higher than **{esc(role.name)}**."
    return None


# ---------------------------------------------------------------- parsing
_UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}
_DUR_FULL = re.compile(r"(?:\d+\s*[smhdw]?\s*)+", re.I)
_DUR_PART = re.compile(r"(\d+)\s*([smhdw])?", re.I)


def parse_duration(text: str, default_unit: str = "m") -> Optional[int]:
    """'10m', '1h30m', '2d', '45' -> seconds (None when invalid or zero)."""
    text = (text or "").strip().lower()
    if not text or not _DUR_FULL.fullmatch(text):
        return None
    total = 0
    for number, unit in _DUR_PART.findall(text):
        total += int(number) * _UNITS[(unit or default_unit).lower()]
    return total or None


def fmt_duration(seconds: int) -> str:
    seconds = int(seconds)
    parts = []
    for unit, size in (("d", 86400), ("h", 3600), ("m", 60), ("s", 1)):
        value, seconds = divmod(seconds, size)
        if value:
            parts.append(f"{value}{unit}")
    return " ".join(parts) or "0s"


async def fetch_bytes(bot, url: str, limit: int = 8 * 1024 * 1024) -> bytes:
    import aiohttp

    session = getattr(bot, "session", None)
    own = session is None or getattr(session, "closed", False)
    if own:
        session = aiohttp.ClientSession()
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
            if resp.status != 200:
                raise ValueError(f"download failed ({resp.status})")
            data = await resp.content.read(limit + 1)
            if len(data) > limit:
                raise ValueError("file is too large")
            return data
    finally:
        if own:
            await session.close()


# ------------------------------------------------------------ bulk workers
class Progress:
    __slots__ = ("ok", "bad", "total")

    def __init__(self, total: int = 0):
        self.ok = 0
        self.bad = 0
        self.total = total


async def pool(items: Iterable, fn: Callable[[Any], Awaitable], progress: Progress, workers: int = 8) -> None:
    """Run ``fn`` over ``items`` with N parallel workers; failures are counted, not raised."""
    it = iter(items)

    async def worker():
        for item in it:
            try:
                await fn(item)
                progress.ok += 1
            except asyncio.CancelledError:
                raise
            except Exception:
                progress.bad += 1

    await asyncio.gather(*(worker() for _ in range(max(1, workers))))


async def run_bulk(ctx, items: list, fn, *, start: str, done: Callable[[Progress], str], workers: int = 8,
                   ack_over: int = 12) -> Progress:
    """Bulk job with an optional "working" card that is edited into the result."""
    progress = Progress(len(items))
    ack = await send(ctx, line(WAIT, start)) if len(items) > ack_over else None
    await pool(items, fn, progress, workers)
    icon = TICK if progress.ok or not progress.bad else CROSS
    view = line(icon, done(progress))
    if ack is not None:
        await edit(ack, view)
    else:
        await send(ctx, view)
    return progress


# -------------------------------------------------------------- help panels
def params_text(command: commands.Command) -> str:
    out = []
    for name, param in command.clean_params.items():
        required = param.default is param.empty and param.kind != param.VAR_POSITIONAL
        out.append(f"<{name}>" if required else f"[{name}]")
    return " ".join(out)


def usage(prefix: str, command: commands.Command) -> str:
    params = params_text(command)
    return f"{prefix}{command.qualified_name}" + (f" {params}" if params else "")


def entry(prefix: str, command: commands.Command, aliases: bool = False, params: bool = True) -> str:
    desc = command.short_doc or command.help or "No description provided."
    head = usage(prefix, command) if params else f"{prefix}{command.qualified_name}"
    rows = [f"> `{head}`"]
    if aliases and command.aliases:
        rows.append(f"> {ARROW} **Aliases :** " + " ".join(f"`{a}`" for a in command.aliases))
    rows.append(f"> {ARROW} {desc}")
    return "\n".join(rows)


def ordered(group: commands.Group) -> list:
    return sorted((c for c in group.commands if not c.hidden), key=lambda c: c.name)


class ListPager(_base.GroupHelpView):
    """White pager (« ‹ <:bin:1567102784552304640> › ») below the card - used by group help and list outputs."""

    def __init__(self, ctx, heading: str, entries: list[str], per_page: int = 6, legend: bool = True, sep: str = "\n\n"):
        self._legend = legend
        self._sep = sep
        super().__init__(ctx, heading, entries, per_page=per_page, accent=0xFFFFFF)

    def _build(self) -> None:
        self.clear_items()
        last = len(self.pages) - 1
        off = self.expired
        row = discord.ui.ActionRow()
        row.add_item(_base._PagerButton("first", emoji="<:icon_2:1567113746374197318>", disabled=off or self.index == 0))
        row.add_item(_base._PagerButton("prev", emoji="<:left:1567104063240146984>", disabled=off or self.index == 0))
        row.add_item(_base._PagerButton("stop", emoji="<:bin:1567102784552304640>", disabled=off))
        row.add_item(_base._PagerButton("next", emoji="<:right:1567104038284034058>", disabled=off or self.index == last))
        row.add_item(_base._PagerButton("last", emoji="<:icon_3:1567113772852838410>", disabled=off or self.index == last))
        box = discord.ui.Container(accent_colour=WHITE)
        box.add_item(_td(f"## {self.heading}"))
        if self._legend:
            box.add_item(_td(LEGEND))
        box.add_item(_td(self._sep.join(self.pages[self.index])))
        box.add_item(discord.ui.Separator())
        box.add_item(_td(f"-# Page {self.index + 1}/{len(self.pages)} | Requested by {self.ctx.author.display_name}"))
        self.add_item(box)
        self.add_item(row)


async def send_pager(ctx, view: ListPager) -> None:
    view.message = await ctx.send(view=view, allowed_mentions=NO_PING)


async def send_group_help(ctx, group: commands.Group) -> None:
    prefix = ctx.clean_prefix
    short = group.cog_name in UTILITY_COGS  # Utility lists just `.group sub`, usage shows on the sub-command
    entries = [entry(prefix, c, params=not short) for c in ordered(group)]
    if (group.extras or {}).get("help_self"):
        entries.insert(0, entry(prefix, group, params=not short))
    title = f"{ctx.bot.user.name} {group.qualified_name} [{len(entries)}]"
    await send_pager(ctx, ListPager(ctx, title, entries, per_page=7 if short else 6))


async def send_command_help(ctx, command: commands.Command) -> None:
    await send(ctx, card(LEGEND, entry(ctx.clean_prefix, command, aliases=True)))


# ------------------------------------------------------------- error mapping
def _missing(perms: Iterable[str]) -> str:
    names = [p.replace("_", " ").replace("guild", "server").title() for p in perms]
    return ", ".join(f"**{n}**" for n in names)


async def handle_error(ctx: commands.Context, error: Exception) -> bool:
    """Friendly errors for every Moderation command. Returns True when handled."""
    if isinstance(error, commands.MissingRequiredArgument) or isinstance(error, commands.TooManyArguments):
        await ctx.send_help(ctx.command)
        return True
    if isinstance(error, commands.MemberNotFound):
        await fail(ctx, f"Member `{error.argument}` was not found.")
        return True
    if isinstance(error, commands.UserNotFound):
        await fail(ctx, f"User `{error.argument}` was not found.")
        return True
    if isinstance(error, commands.RoleNotFound):
        await fail(ctx, f"Role `{error.argument}` was not found.")
        return True
    if isinstance(error, commands.ChannelNotFound):
        await fail(ctx, f"Channel `{error.argument}` was not found.")
        return True
    if isinstance(error, commands.BadArgument) or isinstance(error, commands.BadUnionArgument):
        await ctx.send_help(ctx.command)
        return True
    if isinstance(error, commands.BotMissingPermissions):
        await fail(ctx, f"I need {_missing(error.missing_permissions)} permission to run this command.")
        return True
    if isinstance(error, commands.CommandInvokeError):
        inner = error.original
        if isinstance(inner, discord.Forbidden):
            await fail(ctx, "I'm missing permissions for that, or my role is too low.")
        elif isinstance(inner, discord.NotFound):
            await fail(ctx, "That target no longer exists.")
        elif isinstance(inner, discord.HTTPException):
            await err(ctx, f"Discord error: `{(inner.text or 'unknown')[:180]}`")
        elif isinstance(inner, (ValueError, asyncio.TimeoutError)):
            await err(ctx, f"{esc(inner) or 'Invalid input.'}")
        else:
            log.error("Unhandled error in %s", ctx.command, exc_info=inner)
            traceback.print_exception(type(inner), inner, inner.__traceback__)
            await err(ctx, "Something went wrong while running this command.")
        return True
    return False


async def missing_perms(ctx, error: commands.MissingPermissions) -> None:
    await fail(ctx, f"You need {_missing(error.missing_permissions)} permission to run this command.")
