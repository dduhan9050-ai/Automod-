"""Permit storage: extraowners, trusted users, fake permissions and ignore lists.

Speed notes
-----------
* One long-lived SQLite connection per database (WAL) instead of reconnecting per call.
* Per-guild in-memory caches; every write updates SQLite and the cache together,
  so reads on the command hot path never touch the disk after the first hit.
"""
from __future__ import annotations

import asyncio
import os
from typing import Dict, Iterable, Set

import aiosqlite

PERMIT_DB = "db/permit.db"
IGNORE_DB = "db/ignore.db"

# ignore kind -> (table, column, limit)
IGNORE_KINDS = {
    "command": ("ignored_commands", "command_name", 25),
    "channel": ("ignored_channels", "channel_id", 30),
    "role": ("ignored_roles", "role_id", 30),
    "user": ("ignored_users", "user_id", 30),
    "bypass": ("bypassed_users", "user_id", 30),
}


def valid_permission_names() -> Set[str]:
    import discord
    return set(discord.Permissions.VALID_FLAGS)


def normalize_permission(name: str) -> str:
    return name.strip().lower().replace(" ", "_").replace("-", "_")


class PermitStore:
    def __init__(self) -> None:
        self._permit: aiosqlite.Connection | None = None
        self._ignore: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()
        self._eo: Dict[int, Set[int]] = {}
        self._trusted: Dict[int, Set[int]] = {}
        self._fake: Dict[int, Dict[int, Set[str]]] = {}

    # ------------------------------------------------------------------ setup
    async def _open(self) -> None:
        if self._permit is not None and self._ignore is not None:
            return
        async with self._lock:
            if self._permit is None:
                os.makedirs("db", exist_ok=True)
                conn = await aiosqlite.connect(PERMIT_DB)
                await conn.execute("PRAGMA journal_mode=WAL")
                await conn.execute("PRAGMA synchronous=NORMAL")
                await conn.executescript("""
                    CREATE TABLE IF NOT EXISTS extraowners (
                        guild_id INTEGER, user_id INTEGER, PRIMARY KEY (guild_id, user_id));
                    CREATE TABLE IF NOT EXISTS trusted (
                        guild_id INTEGER, user_id INTEGER, PRIMARY KEY (guild_id, user_id));
                    CREATE TABLE IF NOT EXISTS fake_perms (
                        guild_id INTEGER, role_id INTEGER, perm TEXT,
                        PRIMARY KEY (guild_id, role_id, perm));
                """)
                # one-time import of the old single-extraowner table
                try:
                    async with aiosqlite.connect("db/anti.db") as old:
                        async with old.execute("SELECT guild_id, owner_id FROM extraowners") as cur:
                            rows = await cur.fetchall()
                    await conn.executemany(
                        "INSERT OR IGNORE INTO extraowners (guild_id, user_id) VALUES (?, ?)", rows)
                except Exception:
                    pass
                await conn.commit()
                self._permit = conn
            if self._ignore is None:
                conn = await aiosqlite.connect(IGNORE_DB)
                await conn.execute("PRAGMA journal_mode=WAL")
                await conn.execute("PRAGMA synchronous=NORMAL")
                await conn.executescript("""
                    CREATE TABLE IF NOT EXISTS ignored_commands (guild_id INTEGER, command_name TEXT);
                    CREATE TABLE IF NOT EXISTS ignored_channels (guild_id INTEGER, channel_id INTEGER);
                    CREATE TABLE IF NOT EXISTS ignored_users (guild_id INTEGER, user_id INTEGER);
                    CREATE TABLE IF NOT EXISTS ignored_roles (guild_id INTEGER, role_id INTEGER);
                    CREATE TABLE IF NOT EXISTS bypassed_users (guild_id INTEGER, user_id INTEGER);
                """)
                await conn.commit()
                self._ignore = conn

    async def close(self) -> None:
        for conn in (self._permit, self._ignore):
            if conn is not None:
                await conn.close()
        self._permit = self._ignore = None

    # ------------------------------------------------- extraowner / trusted
    async def _members(self, table: str, cache: Dict[int, Set[int]], gid: int) -> Set[int]:
        hit = cache.get(gid)
        if hit is not None:
            return hit
        await self._open()
        async with self._permit.execute(f"SELECT user_id FROM {table} WHERE guild_id = ?", (gid,)) as cur:
            cache[gid] = {r[0] for r in await cur.fetchall()}
        return cache[gid]

    async def _member_add(self, table, cache, gid, uid) -> bool:
        members = await self._members(table, cache, gid)
        if uid in members:
            return False
        await self._permit.execute(f"INSERT OR IGNORE INTO {table} (guild_id, user_id) VALUES (?, ?)", (gid, uid))
        await self._permit.commit()
        members.add(uid)
        return True

    async def _member_remove(self, table, cache, gid, uid) -> bool:
        members = await self._members(table, cache, gid)
        if uid not in members:
            return False
        await self._permit.execute(f"DELETE FROM {table} WHERE guild_id = ? AND user_id = ?", (gid, uid))
        await self._permit.commit()
        members.discard(uid)
        return True

    async def _member_reset(self, table, cache, gid) -> int:
        members = await self._members(table, cache, gid)
        count = len(members)
        await self._permit.execute(f"DELETE FROM {table} WHERE guild_id = ?", (gid,))
        await self._permit.commit()
        members.clear()
        return count

    async def extraowners(self, gid: int) -> Set[int]:
        return await self._members("extraowners", self._eo, gid)

    async def extraowner_add(self, gid, uid): return await self._member_add("extraowners", self._eo, gid, uid)
    async def extraowner_remove(self, gid, uid): return await self._member_remove("extraowners", self._eo, gid, uid)
    async def extraowner_reset(self, gid): return await self._member_reset("extraowners", self._eo, gid)

    async def is_extraowner(self, gid: int, uid: int) -> bool:
        return uid in await self.extraowners(gid)

    async def trusted(self, gid: int) -> Set[int]:
        return await self._members("trusted", self._trusted, gid)

    async def trusted_add(self, gid, uid): return await self._member_add("trusted", self._trusted, gid, uid)
    async def trusted_remove(self, gid, uid): return await self._member_remove("trusted", self._trusted, gid, uid)
    async def trusted_reset(self, gid): return await self._member_reset("trusted", self._trusted, gid)

    async def is_trusted(self, gid: int, uid: int) -> bool:
        return uid in await self.trusted(gid)

    # --------------------------------------------------------- fake perms
    async def fake_perms(self, gid: int) -> Dict[int, Set[str]]:
        hit = self._fake.get(gid)
        if hit is not None:
            return hit
        await self._open()
        data: Dict[int, Set[str]] = {}
        async with self._permit.execute("SELECT role_id, perm FROM fake_perms WHERE guild_id = ?", (gid,)) as cur:
            for role_id, perm in await cur.fetchall():
                data.setdefault(role_id, set()).add(perm)
        self._fake[gid] = data
        return data

    async def fake_grant(self, gid: int, role_id: int, perms: Iterable[str]) -> Set[str]:
        data = await self.fake_perms(gid)
        current = data.setdefault(role_id, set())
        new = {p for p in perms if p not in current}
        if new:
            await self._permit.executemany(
                "INSERT OR IGNORE INTO fake_perms (guild_id, role_id, perm) VALUES (?, ?, ?)",
                [(gid, role_id, p) for p in new])
            await self._permit.commit()
            current |= new
        return new

    async def fake_revoke(self, gid: int, role_id: int, perms: Iterable[str]) -> Set[str]:
        data = await self.fake_perms(gid)
        current = data.get(role_id, set())
        gone = {p for p in perms if p in current}
        if gone:
            await self._permit.executemany(
                "DELETE FROM fake_perms WHERE guild_id = ? AND role_id = ? AND perm = ?",
                [(gid, role_id, p) for p in gone])
            await self._permit.commit()
            current -= gone
            if not current:
                data.pop(role_id, None)
        return gone

    async def fake_set(self, gid: int, role_id: int, perms: Iterable[str]) -> None:
        perms = set(perms)
        data = await self.fake_perms(gid)
        await self._permit.execute("DELETE FROM fake_perms WHERE guild_id = ? AND role_id = ?", (gid, role_id))
        if perms:
            await self._permit.executemany(
                "INSERT OR IGNORE INTO fake_perms (guild_id, role_id, perm) VALUES (?, ?, ?)",
                [(gid, role_id, p) for p in perms])
            data[role_id] = perms
        else:
            data.pop(role_id, None)
        await self._permit.commit()

    async def fake_resetall(self, gid: int) -> int:
        data = await self.fake_perms(gid)
        count = len(data)
        await self._permit.execute("DELETE FROM fake_perms WHERE guild_id = ?", (gid,))
        await self._permit.commit()
        data.clear()
        return count

    async def member_fake_perms(self, member) -> Set[str]:
        data = await self.fake_perms(member.guild.id)
        if not data:
            return set()
        out: Set[str] = set()
        for role in member.roles:
            out |= data.get(role.id, set())
        return out

    async def fake_covers(self, member, missing: Iterable[str]) -> bool:
        """True when the member's roles carry fake permissions for everything missing."""
        have = await self.member_fake_perms(member)
        if not have:
            return False
        if "administrator" in have:
            return True
        return all(p in have for p in missing)

    # ------------------------------------------------------------- ignore
    @staticmethod
    def _invalidate() -> None:
        from utils.Tools import invalidate_check_caches
        invalidate_check_caches()

    async def ignore_list(self, gid: int, kind: str) -> list:
        await self._open()
        table, col, _ = IGNORE_KINDS[kind]
        async with self._ignore.execute(f"SELECT {col} FROM {table} WHERE guild_id = ?", (gid,)) as cur:
            return [r[0] for r in await cur.fetchall()]

    async def ignore_add(self, gid: int, kind: str, value) -> str:
        """Returns 'added', 'exists' or 'limit'."""
        await self._open()
        table, col, limit = IGNORE_KINDS[kind]
        items = await self.ignore_list(gid, kind)
        if value in items:
            return "exists"
        if len(items) >= limit:
            return "limit"
        await self._ignore.execute(f"INSERT INTO {table} (guild_id, {col}) VALUES (?, ?)", (gid, value))
        await self._ignore.commit()
        self._invalidate()
        return "added"

    async def ignore_remove(self, gid: int, kind: str, value) -> bool:
        await self._open()
        table, col, _ = IGNORE_KINDS[kind]
        cur = await self._ignore.execute(f"DELETE FROM {table} WHERE guild_id = ? AND {col} = ?", (gid, value))
        await self._ignore.commit()
        self._invalidate()
        return cur.rowcount > 0

    async def ignore_reset(self, gid: int, kind: str) -> int:
        await self._open()
        table, _, _ = IGNORE_KINDS[kind]
        cur = await self._ignore.execute(f"DELETE FROM {table} WHERE guild_id = ?", (gid,))
        await self._ignore.commit()
        self._invalidate()
        return cur.rowcount


store = PermitStore()
