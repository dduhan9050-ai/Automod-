"""White (#ffffff) Components V2 container replies for the Permit module."""
from __future__ import annotations

import discord

WHITE = discord.Colour(0xFFFFFF)


def card(title: str, body: str = "", *, footer: str | None = None, thumbnail: str | None = None) -> discord.ui.LayoutView:
    """A single #ffffff Container: title + body (+ optional thumbnail/footer)."""
    view = discord.ui.LayoutView(timeout=None)
    container = discord.ui.Container(accent_colour=WHITE)
    text = f"## {title}" + (f"\n{body}" if body else "")
    text = text[:3900]
    if thumbnail:
        container.add_item(discord.ui.Section(discord.ui.TextDisplay(text),
                                              accessory=discord.ui.Thumbnail(media=thumbnail)))
    else:
        container.add_item(discord.ui.TextDisplay(text))
    if footer:
        container.add_item(discord.ui.Separator())
        container.add_item(discord.ui.TextDisplay(f"-# {footer}"))
    view.add_item(container)
    return view


def ok(title: str, body: str = "") -> discord.ui.LayoutView:
    return card(f"<:emoji_4:1566043104551768114> {title}", body)


def fail(title: str, body: str = "") -> discord.ui.LayoutView:
    return card(f"<a:emoji_38:1567096105299214336> {title}", body)


def listing(title: str, lines: list[str], *, empty: str, footer: str | None = None) -> discord.ui.LayoutView:
    if not lines:
        return card(title, empty, footer=footer)
    body = "\n".join(lines)
    if len(body) > 3500:
        body = body[:3500].rsplit("\n", 1)[0] + "\n…"
    return card(title, body, footer=footer)
