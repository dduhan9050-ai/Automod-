"""Premium storage (fast, in-memory cache + SQLite in a worker thread).

Tables (db/premium.db)
* plans        user_id -> slots, expires_at (NULL = lifetime)
* activations  guild_id -> user_id (who activated premium for that server)
* servernp     guild_id, user_id (members with server no-prefix, max 10)
* aliases      guild_id, alias -> command (custom command aliases)

Everything is loaded once into memory so ``get_prefix`` / ``get_context`` never
touch the disk on the message hot path.
"""
from __future__ import annotations

import asyncio
import sqlite3
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from utils.config import OWNER_IDS
from utils.team_store import team as team_store

DB_PATH = Path(__file__).resolve().parent.parent / "db" / "premium.db"

MAX_SERVER_NP = 10
MAX_ALIASES = 50
DEFAULT_SLOTS = 1


class PremiumStore:
    def __init__(self, path: Path | str = DB_PATH) -> None:
        self._path = Path(path)
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = threading.Lock()
        self.plans: Dict[int, Tuple[int, Optional[float]]] = {}      # user -> (slots, expires_ts)
        self.activations: Dict[int, int] = {}                        # guild -> user
        self.server_np: Dict[int, Set[int]] = {}                     # guild -> {user ids}
        self.aliases: Dict[int, Dict[str, str]] = {}                 # guild -> {alias: command}
        self.loaded = False
        self._load_lock: Optional[asyncio.Lock] = None

    # ------------------------------------------------------------------ db
    def _connect(self) -> sqlite3.Connection:
        if self._conn is not None:
            return self._conn
        self._path.parent.mkdir(parents=True, exist_ok=True)
        try:
            conn = self._open()
        except sqlite3.DatabaseError:
            bad = self._path.with_suffix(".db.corrupt")
            try:
                self._path.replace(bad)
            except OSError:
                self._path.unlink(missing_ok=True)
            conn = self._open()
        self._conn = conn
        return conn

    def _open(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._path), timeout=10, check_same_thread=False)
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
        except sqlite3.DatabaseError:
            pass
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS plans (
                user_id INTEGER PRIMARY KEY, slots INTEGER NOT NULL, expires_at REAL);
            CREATE TABLE IF NOT EXISTS activations (
                guild_id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS servernp (
                guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
                PRIMARY KEY (guild_id, user_id));
            CREATE TABLE IF NOT EXISTS aliases (
                guild_id INTEGER NOT NULL, alias TEXT NOT NULL, command TEXT NOT NULL,
                PRIMARY KEY (guild_id, alias));
            """
        )
        conn.commit()
        return conn

    def _run(self, sql: str, params: tuple = ()) -> List[tuple]:
        with self._lock:
            conn = self._connect()
            cur = conn.execute(sql, params)
            rows = cur.fetchall()
            conn.commit()
            return rows

    async def _exec(self, sql: str, params: tuple = ()) -> List[tuple]:
        return await asyncio.to_thread(self._run, sql, params)

    # ---------------------------------------------------------------- load
    async def load(self) -> None:
        if self.loaded:
            return
        if self._load_lock is None:
            self._load_lock = asyncio.Lock()
        async with self._load_lock:
            if self.loaded:
                return
            for uid, slots, exp in await self._exec("SELECT user_id, slots, expires_at FROM plans"):
                self.plans[int(uid)] = (int(slots), exp)
            for gid, uid in await self._exec("SELECT guild_id, user_id FROM activations"):
                self.activations[int(gid)] = int(uid)
            for gid, uid in await self._exec("SELECT guild_id, user_id FROM servernp"):
                self.server_np.setdefault(int(gid), set()).add(int(uid))
            for gid, alias, cmd in await self._exec("SELECT guild_id, alias, command FROM aliases"):
                self.aliases.setdefault(int(gid), {})[alias] = cmd
            self.loaded = True

    # --------------------------------------------------------------- plans
    def plan_of(self, user_id: int) -> Optional[Tuple[int, Optional[float]]]:
        """Return (slots, expires_ts) if the user has a live plan, else None.

        Bot owners (utils/config.py OWNER_IDS) always have an unlimited lifetime plan."""
        if user_id in OWNER_IDS or team_store.has_perks(user_id):   # owners / developers / core team
            return (999, None)
        plan = self.plans.get(user_id)
        if not plan:
            return None
        slots, exp = plan
        if exp is not None and exp <= time.time():
            return None
        return plan

    def used_slots(self, user_id: int) -> List[int]:
        return [g for g, u in self.activations.items() if u == user_id]

    def is_active(self, guild_id: Optional[int]) -> bool:
        """A guild is premium when its activator still owns a live plan."""
        if not guild_id:
            return False
        owner = self.activations.get(guild_id)
        return owner is not None and self.plan_of(owner) is not None

    async def grant(self, user_id: int, slots: int, expires_at: Optional[float]) -> None:
        self.plans[user_id] = (slots, expires_at)
        await self._exec("INSERT OR REPLACE INTO plans (user_id, slots, expires_at) VALUES (?,?,?)",
                         (user_id, slots, expires_at))

    async def revoke(self, user_id: int) -> List[int]:
        self.plans.pop(user_id, None)
        freed = self.used_slots(user_id)
        for g in freed:
            self.activations.pop(g, None)
        await self._exec("DELETE FROM plans WHERE user_id = ?", (user_id,))
        await self._exec("DELETE FROM activations WHERE user_id = ?", (user_id,))
        return freed

    # --------------------------------------------------------- activations
    async def activate(self, guild_id: int, user_id: int) -> None:
        self.activations[guild_id] = user_id
        await self._exec("INSERT OR REPLACE INTO activations (guild_id, user_id) VALUES (?,?)",
                         (guild_id, user_id))

    async def deactivate(self, guild_id: int) -> None:
        self.activations.pop(guild_id, None)
        await self._exec("DELETE FROM activations WHERE guild_id = ?", (guild_id,))

    # ----------------------------------------------------------- server np
    def has_server_np(self, guild_id: int, user_id: int) -> bool:
        return user_id in self.server_np.get(guild_id, ()) and self.is_active(guild_id)

    async def add_server_np(self, guild_id: int, user_id: int) -> None:
        self.server_np.setdefault(guild_id, set()).add(user_id)
        await self._exec("INSERT OR IGNORE INTO servernp (guild_id, user_id) VALUES (?,?)", (guild_id, user_id))

    async def remove_server_np(self, guild_id: int, user_id: int) -> None:
        self.server_np.get(guild_id, set()).discard(user_id)
        await self._exec("DELETE FROM servernp WHERE guild_id = ? AND user_id = ?", (guild_id, user_id))

    async def clear_server_np(self, guild_id: int) -> None:
        self.server_np.pop(guild_id, None)
        await self._exec("DELETE FROM servernp WHERE guild_id = ?", (guild_id,))

    # -------------------------------------------------------------- aliases
    def resolve_alias(self, guild_id: Optional[int], word: str) -> Optional[str]:
        if not guild_id:
            return None
        table = self.aliases.get(guild_id)
        if not table:
            return None
        cmd = table.get(word.lower())
        if cmd and self.is_active(guild_id):
            return cmd
        return None

    async def add_alias(self, guild_id: int, alias: str, command: str) -> None:
        self.aliases.setdefault(guild_id, {})[alias] = command
        await self._exec("INSERT OR REPLACE INTO aliases (guild_id, alias, command) VALUES (?,?,?)",
                         (guild_id, alias, command))

    async def remove_alias(self, guild_id: int, alias: str) -> bool:
        existed = self.aliases.get(guild_id, {}).pop(alias, None) is not None
        await self._exec("DELETE FROM aliases WHERE guild_id = ? AND alias = ?", (guild_id, alias))
        return existed

    async def clear_aliases(self, guild_id: int) -> int:
        count = len(self.aliases.pop(guild_id, {}))
        await self._exec("DELETE FROM aliases WHERE guild_id = ?", (guild_id,))
        return count


store = PremiumStore()
