"""Command rate-limit protection with an escalating TEMPORARY blacklist.

A user who spams commands is blocked for 10 minutes.  Every further offence doubles the block:

    1st strike -> 10 min      4th strike -> 80 min
    2nd strike -> 20 min      5th strike -> 160 min   ... capped at MAX_BLOCK (7 days)
    3rd strike -> 40 min

Strikes are forgotten after STRIKE_RESET seconds of clean behaviour (default 7 days).
Everything the hot path needs lives in RAM (one dict lookup + one deque per user);
SQLite (db/ratelimit.db) is only written when somebody gets blocked / unblocked.
This is separate from the permanent owner blacklist (db/block.db) - the two never touch each other.
"""
from __future__ import annotations

import os
import time
from collections import deque
from dataclasses import dataclass

import aiosqlite
from discord.ext import commands

DB_PATH = "db/ratelimit.db"

BASE_BLOCK = int(os.getenv("RL_BASE_BLOCK", "600"))          # first block: 10 minutes
GROWTH = 2                                                    # every strike doubles the block
MAX_BLOCK = int(os.getenv("RL_MAX_BLOCK", str(7 * 86400)))   # never longer than 7 days
STRIKE_RESET = int(os.getenv("RL_STRIKE_RESET", str(7 * 86400)))

# (max commands, seconds): exceeding ANY window triggers a strike
WINDOWS: tuple[tuple[int, float], ...] = (
    (5, 3.0),     # more than 5 commands in 3 seconds
    (10, 20.0),   # more than 10 commands in 20 seconds
)
_MAX_WINDOW = max(w for _, w in WINDOWS)


@dataclass(slots=True)
class Block:
    until: float = 0.0       # epoch seconds, 0 = not blocked
    strikes: int = 0
    last: float = 0.0        # epoch of the last offence


class TempBlacklisted(commands.CheckFailure):
    """Raised by the global check; handled (quietly) in cogs/events/Errors.py."""

    def __init__(self, user_id: int, until: float, strikes: int, first: bool):
        self.user_id, self.until, self.strikes, self.first = user_id, until, strikes, first
        super().__init__(f"{user_id} is temporarily blacklisted until {until}")


_blocks: dict[int, Block] = {}
_hits: dict[int, deque] = {}
_notified: dict[int, float] = {}     # user -> last time we told them they are blocked
_loaded = False


# ------------------------------------------------------------------ helpers
def duration_for(strikes: int) -> int:
    """Block length in seconds for the n-th strike (1-based)."""
    return int(min(MAX_BLOCK, BASE_BLOCK * GROWTH ** max(0, strikes - 1)))


def human(seconds: float) -> str:
    seconds = max(0, int(round(seconds)))
    d, r = divmod(seconds, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    parts = [f"{d}d"] if d else []
    if h:
        parts.append(f"{h}h")
    if m:
        parts.append(f"{m}m")
    if not parts:
        parts.append(f"{s}s")
    return " ".join(parts)


# ------------------------------------------------------------------ storage
async def load() -> None:
    global _loaded
    if _loaded:
        return
    os.makedirs("db", exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("CREATE TABLE IF NOT EXISTS temp_block ("
                         "user_id INTEGER PRIMARY KEY, until REAL, strikes INTEGER, last REAL)")
        await db.commit()
        async with db.execute("SELECT user_id, until, strikes, last FROM temp_block") as cur:
            for uid, until, strikes, last in await cur.fetchall():
                _blocks[int(uid)] = Block(float(until or 0), int(strikes or 0), float(last or 0))
    _loaded = True


async def _persist(uid: int) -> None:
    b = _blocks.get(uid)
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            if b is None:
                await db.execute("DELETE FROM temp_block WHERE user_id = ?", (uid,))
            else:
                await db.execute("INSERT OR REPLACE INTO temp_block (user_id, until, strikes, last) VALUES (?, ?, ?, ?)",
                                 (uid, b.until, b.strikes, b.last))
            await db.commit()
    except Exception:       # a DB hiccup must never break command handling; RAM state still applies
        pass


# ------------------------------------------------------------------ hot path (sync, no awaits)
def blocked_until(uid: int) -> float:
    """Epoch when the block ends, or 0.0 if the user is free."""
    b = _blocks.get(uid)
    if b is None or b.until <= 0:
        return 0.0
    if b.until > time.time():
        return b.until
    b.until = 0.0            # expired (strikes are kept so the NEXT block is longer)
    return 0.0


def record(uid: int) -> Block | None:
    """Count one command run. Returns the new Block when this run crosses a limit, else None."""
    now = time.monotonic()
    dq = _hits.get(uid)
    if dq is None:
        dq = _hits[uid] = deque()
    dq.append(now)
    while dq and now - dq[0] > _MAX_WINDOW:
        dq.popleft()
    for limit, window in WINDOWS:
        if len(dq) > limit and sum(1 for t in dq if now - t <= window) > limit:
            dq.clear()
            return strike(uid)
    if len(_hits) > 20000:   # bound memory
        for k in [k for k, v in _hits.items() if not v or now - v[-1] > _MAX_WINDOW]:
            _hits.pop(k, None)
    return None


def strike(uid: int, *, minimum: int = 0) -> Block:
    """Add a strike and start the (longer) block. Sync; call `await save(uid)` afterwards."""
    wall = time.time()
    b = _blocks.get(uid)
    if b is None:
        b = _blocks[uid] = Block()
    if b.strikes and wall - b.last > STRIKE_RESET:
        b.strikes = 0        # a week of good behaviour wipes the slate
    b.strikes += 1
    b.last = wall
    b.until = wall + duration_for(max(b.strikes, minimum))
    return b


async def save(uid: int) -> None:
    await _persist(uid)


async def punish(uid: int) -> Block:
    """Strike + persist in one call (used by the other spam detectors)."""
    b = strike(uid)
    await _persist(uid)
    return b


async def clear(uid: int, *, forget_strikes: bool = True) -> bool:
    """Unblock a user (owner command). Returns False if there was nothing to clear."""
    b = _blocks.get(uid)
    if b is None:
        return False
    if forget_strikes:
        _blocks.pop(uid, None)
    else:
        b.until = 0.0
    _hits.pop(uid, None)
    await _persist(uid)
    return True


def active() -> list[tuple[int, Block]]:
    now = time.time()
    return sorted(((u, b) for u, b in _blocks.items() if b.until > now), key=lambda x: x[1].until)


def should_notify(uid: int, every: float = 60.0) -> bool:
    """True at most once per `every` seconds per user (so a blocked spammer is not answered every time)."""
    now = time.monotonic()
    if now - _notified.get(uid, -1e9) < every:
        return False
    _notified[uid] = now
    if len(_notified) > 20000:
        _notified.clear()
    return True


# ------------------------------------------------------------------ discord.py global check
async def global_check(ctx: commands.Context) -> bool:
    """Registered with bot.add_check(..., call_once=True): runs once per real command invocation."""
    uid = ctx.author.id
    if uid in (getattr(ctx.bot, "owner_ids", None) or ()):
        return True
    until = blocked_until(uid)
    if until:
        raise TempBlacklisted(uid, until, _blocks[uid].strikes, first=False)
    hit = record(uid)
    if hit is not None:
        await _persist(uid)
        raise TempBlacklisted(uid, hit.until, hit.strikes, first=True)
    return True
