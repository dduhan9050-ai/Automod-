"""Bot team storage (db/team.db) kept fully in memory for instant lookups.

Roles
* owner      - perks: lifetime premium + global no-prefix
* developer  - perks: lifetime premium + global no-prefix
* core       - perks: lifetime premium + global no-prefix
* bughunter  - listed in Team Info only (no perks)

Perks are *derived* from membership (premium_store.plan_of and the bot's
get_prefix both ask this store), so removing someone from the team removes
their premium / no-prefix automatically - nothing is left behind in
premium.db or np.db.
"""
from __future__ import annotations

import sqlite3
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional

from utils.config import OWNER_IDS

DB_PATH = Path(__file__).resolve().parent.parent / "db" / "team.db"

ROLES = ("owner", "developer", "core", "bughunter")
PERK_ROLES = ("owner", "developer", "core")

ROLE_TITLES = {
    "owner": "Owners",
    "developer": "Developers",
    "core": "Core Team",
    "bughunter": "Bug Hunters",
}

_ALIASES = {
    "owner": "owner", "owners": "owner", "own": "owner",
    "developer": "developer", "developers": "developer", "dev": "developer", "devs": "developer",
    "core": "core", "coreteam": "core", "core-team": "core", "core_team": "core", "team": "core",
    "bughunter": "bughunter", "bughunters": "bughunter", "bug": "bughunter", "bug-hunter": "bughunter",
    "bug_hunter": "bughunter", "hunter": "bughunter",
}


def normalize_role(text: str) -> Optional[str]:
    return _ALIASES.get(text.lower().strip().replace(" ", ""))


class TeamStore:
    def __init__(self, path: Path | str = DB_PATH) -> None:
        self._path = Path(path)
        self._lock = threading.Lock()
        self.members: Dict[int, str] = {}          # user_id -> role
        self._load()

    # ------------------------------------------------------------- sqlite
    def _connect(self) -> sqlite3.Connection:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self._path, timeout=10)
        conn.execute("CREATE TABLE IF NOT EXISTS team ("
                     "user_id INTEGER PRIMARY KEY, role TEXT NOT NULL, added_by INTEGER, added_at REAL)")
        return conn

    def _run(self, sql: str, params: tuple = ()) -> list:
        with self._lock:
            conn = self._connect()
            try:
                rows = conn.execute(sql, params).fetchall()
                conn.commit()
                return rows
            finally:
                conn.close()

    def _load(self) -> None:
        self.members = {int(uid): role for uid, role in self._run("SELECT user_id, role FROM team")
                        if role in ROLES}

    # ------------------------------------------------------------- queries
    def role_of(self, user_id: int) -> Optional[str]:
        role = self.members.get(user_id)
        if role is None and user_id in OWNER_IDS:
            return "owner"
        return role

    def has_perks(self, user_id: int) -> bool:
        """Premium + no-prefix access for owner / developer / core team."""
        return self.role_of(user_id) in PERK_ROLES

    def by_role(self, role: str) -> List[int]:
        ids = [uid for uid, r in self.members.items() if r == role]
        if role == "owner":
            ids = [uid for uid in OWNER_IDS if uid not in self.members] + ids
        return ids

    # ------------------------------------------------------------- changes
    def set_role(self, user_id: int, role: str, added_by: int) -> Optional[str]:
        """Add or change a member. Returns the previous role (None if new)."""
        previous = self.members.get(user_id)
        self._run("INSERT OR REPLACE INTO team (user_id, role, added_by, added_at) VALUES (?,?,?,?)",
                  (user_id, role, added_by, time.time()))
        self.members[user_id] = role
        return previous

    def remove(self, user_id: int) -> Optional[str]:
        previous = self.members.pop(user_id, None)
        if previous is not None:
            self._run("DELETE FROM team WHERE user_id = ?", (user_id,))
        return previous


team = TeamStore()
