"""Ticket setup dashboard (Components V2) + panel helpers.

`?ticket setup` / `?ticket edit` open :class:`SetupView`, where every part of the
ticket system can be customised from inside Discord: panel look, ticket message,
subcategories (with questions), staff / category / transcript channel and toggles.
"""
from __future__ import annotations

import logging
import re
import time
from typing import Awaitable, Callable, Optional

import discord

from utils import automation_ui as base
from utils import ticket_ui as ui
from utils.ticket_store import MAX_PANELS, MAX_QUESTIONS, MAX_SUBCATEGORIES, store
from utils.ticket_vars import inline_text

log = logging.getLogger("tickets")
_text = base._text


# --------------------------------------------------------------------------
# panel helpers (shared with the `ticket panel` command)
# --------------------------------------------------------------------------
def panel_problem(guild: discord.Guild, cfg: dict) -> Optional[str]:
    role = guild.get_role(cfg.get("staff_role_id") or 0)
    if role is None:
        return "Set a staff role first with `ticket staff <role>` (or from `ticket setup`)."
    return None


async def send_panel(guild: discord.Guild, channel: discord.TextChannel) -> discord.Message:
    cfg = store.get(guild.id)
    msg = await channel.send(view=ui.panel_view(guild, cfg), allowed_mentions=discord.AllowedMentions.none())
    refs = [r for r in cfg["panels"] if r[0] != channel.id]
    refs.append([channel.id, msg.id])
    cfg["panels"] = refs[-MAX_PANELS:]
    await store.save(guild.id)
    return msg


async def refresh_panels(guild: discord.Guild) -> int:
    """Edit every live panel to match the current config. Returns how many were updated."""
    cfg = store.get(guild.id)
    updated, keep = 0, []
    for channel_id, message_id in cfg["panels"]:
        channel = guild.get_channel(channel_id)
        if channel is None:
            continue
        try:
            message = await channel.fetch_message(message_id)
            await message.edit(view=ui.panel_view(guild, cfg))
            keep.append([channel_id, message_id])
            updated += 1
        except discord.NotFound:
            continue
        except discord.HTTPException:
            keep.append([channel_id, message_id])
    if keep != cfg["panels"]:
        cfg["panels"] = keep
        await store.save(guild.id)
    return updated


# --------------------------------------------------------------------------
# tiny item / modal helpers
# --------------------------------------------------------------------------
class _Btn(discord.ui.Button):
    def __init__(self, handler: Callable[[discord.Interaction], Awaitable], **kw):
        super().__init__(**kw)
        self._handler = handler

    async def callback(self, interaction: discord.Interaction):
        await self._handler(interaction)


class _Sel(discord.ui.Select):
    def __init__(self, handler, **kw):
        super().__init__(**kw)
        self._handler = handler

    async def callback(self, interaction: discord.Interaction):
        await self._handler(interaction, self.values)


class _ChSel(discord.ui.ChannelSelect):
    def __init__(self, handler, **kw):
        super().__init__(**kw)
        self._handler = handler

    async def callback(self, interaction: discord.Interaction):
        await self._handler(interaction, self.values)


class _RoleSel(discord.ui.RoleSelect):
    def __init__(self, handler, **kw):
        super().__init__(**kw)
        self._handler = handler

    async def callback(self, interaction: discord.Interaction):
        await self._handler(interaction, self.values)


def _row(*items) -> discord.ui.ActionRow:
    row = discord.ui.ActionRow()
    for item in items:
        row.add_item(item)
    return row


class FieldsModal(discord.ui.Modal):
    """Generic modal: fields = [{key,label,default,max,long,required,hint}]."""

    def __init__(self, title: str, fields: list[dict],
                 callback: Callable[[discord.Interaction, dict], Awaitable]):
        super().__init__(title=title[:45], timeout=600)
        self._cb = callback
        self._inputs: dict[str, discord.ui.TextInput] = {}
        for f in fields:
            limit = f.get("max", 100)
            item = discord.ui.TextInput(
                label=f["label"][:45], default=(f.get("default") or "")[:limit] or None,
                placeholder=(f.get("hint") or None), required=f.get("required", False),
                style=discord.TextStyle.paragraph if f.get("long") else discord.TextStyle.short,
                max_length=limit)
            self.add_item(item)
            self._inputs[f["key"]] = item

    async def on_submit(self, interaction: discord.Interaction):
        await self._cb(interaction, {k: (v.value or "").strip() for k, v in self._inputs.items()})

    async def on_error(self, interaction: discord.Interaction, error: Exception):
        log.exception("ticket modal error", exc_info=error)
        try:
            if interaction.response.is_done():
                await interaction.followup.send(view=ui.error("Something went wrong", ui.note(str(error)[:200])),
                                                ephemeral=True)
            else:
                await interaction.response.send_message(
                    view=ui.error("Something went wrong", ui.note(str(error)[:200])), ephemeral=True)
        except discord.HTTPException:
            pass


async def _reject(interaction: discord.Interaction, title: str, text: str) -> None:
    await interaction.response.send_message(view=ui.error(title, ui.note(text)), ephemeral=True)


# --------------------------------------------------------------------------
# the dashboard
# --------------------------------------------------------------------------
CUSTOMIZE = (
    ("general", "General", "Staff role, ticket category, transcript channel", "<a:emoji_9:1566444878303461566>"),
    ("design", "Panel Design", "Title, description, footer, banner, thumbnail", "<a:z_exo_mobile:1567139775721377792>"),
    ("style", "Panel Style", "Colour, select / buttons, placeholder, button", "🖌️"),
    ("message", "Ticket Message", "What members see inside a new ticket", "<:emoji_19:1566458847613419591>"),
    ("settings", "Ticket Settings", "Channel name, limits, close text, colour", "<a:emoji_74:1567132979967299726>"),
    ("subs", "Subcategories", "Add / edit / remove ticket types & questions", "🗂️"),
)


class SetupView(discord.ui.LayoutView):
    def __init__(self, guild: discord.Guild, owner_id: int, prefix: str = "?"):
        super().__init__(timeout=900)
        self.guild = guild
        self.owner_id = owner_id
        self.prefix = prefix
        self.page = "home"
        self.sel: Optional[str] = None
        self.message: Optional[discord.Message] = None
        self._build()

    @property
    def cfg(self) -> dict:
        return store.get(self.guild.id)

    # ------------------------------------------------------------ checks
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id == self.owner_id or interaction.user.id in base.OWNER_IDS:
            return True
        await interaction.response.send_message(
            "Uh oh! That message doesn't belong to you.\nYou must run this command to interact with it.",
            ephemeral=True)
        return False

    async def on_timeout(self) -> None:
        self.clear_items()
        box = discord.ui.Container()
        box.add_item(_text(f"{base.WARN} **Setup panel expired.** Run `{self.prefix}ticket setup` again."))
        self.add_item(box)
        if self.message is not None:
            try:
                await self.message.edit(view=self)
            except Exception:
                pass

    # ------------------------------------------------------------ render
    def _build(self) -> None:
        self.clear_items()
        {"home": self._home, "general": self._general, "subs": self._subs}[self.page]()

    async def _show(self, interaction: discord.Interaction) -> None:
        self._build()
        await interaction.response.edit_message(view=self)

    def _summary(self) -> str:
        cfg, g = self.cfg, self.guild
        cat = g.get_channel(cfg.get("category_id") or 0)
        log_ch = g.get_channel(cfg.get("transcript_id") or 0)
        role = g.get_role(cfg.get("staff_role_id") or 0)
        return (
            f"### Ticket Setup • {g.name}\n"
            "Customise every part of your ticket system from here.\n\n"
            f"{base.label('Staff Role', role.mention if role else '`Not set`')}\n"
            f"{base.label('Category', cat.mention if cat else '`Not set`')}\n"
            f"{base.label('Transcripts', log_ch.mention if log_ch else '`Not set`')}\n"
            f"{base.label('Subcategories', '`' + str(len(cfg['subcategories'])) + '/' + str(MAX_SUBCATEGORIES) + '`')}\n"
            f"{base.label('Panel Style', '`' + cfg['panel'].get('mode', 'select') + '`')}\n\n"
            f"-# Placeholders like {{user}} or {{ticket_number}} work everywhere. See `{self.prefix}ticketvariables`.")

    def _toggle(self, key: str, name: str) -> _Btn:
        on = self.cfg["settings"].get(key, False)
        return _Btn(self._make_toggle(key), label=name, emoji=("<:emoji_4:1566043104551768114>" if on else "<a:emoji_38:1567096105299214336>"),
                    style=discord.ButtonStyle.success if on else discord.ButtonStyle.secondary)

    def _make_toggle(self, key: str):
        async def handler(interaction: discord.Interaction):
            s = self.cfg["settings"]
            s[key] = not s.get(key, False)
            await store.save(self.guild.id)
            await self._show(interaction)
        return handler

    def _home(self) -> None:
        box = discord.ui.Container()
        box.add_item(_text(self._summary()))
        box.add_item(discord.ui.Separator())
        box.add_item(_row(_Sel(
            self._on_customize, placeholder="Customize your ticket system…", min_values=1, max_values=1,
            options=[discord.SelectOption(label=l, value=v, description=d, emoji=e) for v, l, d, e in CUSTOMIZE])))
        box.add_item(discord.ui.Separator())
        box.add_item(_row(self._toggle("claim", "Claim"), self._toggle("confirm_close", "Confirm Close"),
                          self._toggle("ask_reason", "Ask Reason"), self._toggle("dm_transcript", "DM Transcript"),
                          self._toggle("ping_staff", "Ping Staff")))
        box.add_item(discord.ui.Separator())
        box.add_item(_row(_ChSel(self._on_send_panel, placeholder="Send the ticket panel to a channel…",
                                 channel_types=[discord.ChannelType.text, discord.ChannelType.news],
                                 min_values=1, max_values=1)))
        box.add_item(_row(
            _Btn(self._preview_panel, label="Preview Panel", emoji="👁️", style=discord.ButtonStyle.secondary),
            _Btn(self._preview_ticket, label="Preview Ticket", emoji="<:emoji_15:1566452129894506606>", style=discord.ButtonStyle.secondary),
            _Btn(self._update_panels, label="Update Panels", emoji="<:loop:1567103059769958431>", style=discord.ButtonStyle.primary),
            _Btn(self._variables, label="Variables", emoji="<:server:1567099480602452078>", style=discord.ButtonStyle.secondary),
            _Btn(self._close, emoji="<:bin:1567102784552304640>", style=discord.ButtonStyle.danger)))
        self.add_item(box)

    def _general(self) -> None:
        box = discord.ui.Container()
        box.add_item(_text(self._summary().split("\n\n-#")[0]))
        box.add_item(discord.ui.Separator())
        box.add_item(_row(_RoleSel(self._set_staff, placeholder="Select the staff role", min_values=1, max_values=1)))
        box.add_item(_row(_ChSel(self._set_category, placeholder="Select the ticket category",
                                 channel_types=[discord.ChannelType.category], min_values=1, max_values=1)))
        box.add_item(_row(_ChSel(self._set_transcript, placeholder="Select the transcript channel",
                                 channel_types=[discord.ChannelType.text], min_values=1, max_values=1)))
        box.add_item(discord.ui.Separator())
        box.add_item(_row(_Btn(self._go_home, label="Back", emoji="<:left:1567104063240146984>", style=discord.ButtonStyle.secondary)))
        self.add_item(box)

    def _subs(self) -> None:
        subs = self.cfg["subcategories"]
        if self.sel and store.find_sub(self.cfg, self.sel) is None:
            self.sel = None
        lines = []
        for i, s in enumerate(subs, 1):
            extra = []
            if s.get("roles"):
                extra.append(f"{len(s['roles'])} role(s)")
            if s.get("questions"):
                extra.append(f"{len(s['questions'])} question(s)")
            if s.get("category_id"):
                extra.append("own category")
            mark = "<a:emoji_39:1567099222103294022> " if s["id"] == self.sel else ""
            lines.append(f"`{i}.` {mark}{s.get('emoji') or '<:emoji_15:1566452129894506606>'} **{s['label']}**"
                         + (f"  -# {', '.join(extra)}" if extra else ""))
        body = ("### Subcategories\n"
                "Each subcategory becomes an option on the panel. It can have its own extra staff roles, "
                "its own category and up to 5 questions asked before the ticket opens.\n\n"
                + ("\n".join(lines) if lines else "`No subcategories yet - the panel shows one Create Ticket button.`"))
        box = discord.ui.Container()
        box.add_item(_text(body[:3900]))
        box.add_item(discord.ui.Separator())
        if subs:
            box.add_item(_row(_Sel(
                self._pick_sub, placeholder="Select a subcategory to edit", min_values=1, max_values=1,
                options=[discord.SelectOption(label=s["label"][:100], value=s["id"], emoji=ui.make_emoji(s.get("emoji")),
                                              default=(s["id"] == self.sel)) for s in subs[:25]])))
        none = self.sel is None
        box.add_item(_row(
            _Btn(self._add_sub, label="Add", emoji="<:610985_add_symbol:1567111662316552292>", style=discord.ButtonStyle.success,
                 disabled=len(subs) >= MAX_SUBCATEGORIES),
            _Btn(self._edit_sub, label="Edit", emoji="✏️", style=discord.ButtonStyle.primary, disabled=none),
            _Btn(self._edit_questions, label="Questions", emoji="❓", style=discord.ButtonStyle.primary, disabled=none),
            _Btn(self._remove_sub, label="Remove", emoji="<:bin:1567102784552304640>", style=discord.ButtonStyle.danger, disabled=none),
            _Btn(self._go_home, label="Back", emoji="<:left:1567104063240146984>", style=discord.ButtonStyle.secondary)))
        self.add_item(box)

    # --------------------------------------------------------- navigation
    async def _go_home(self, interaction: discord.Interaction):
        self.page = "home"
        await self._show(interaction)

    async def _close(self, interaction: discord.Interaction):
        self.stop()
        try:
            await interaction.response.defer()
            await interaction.message.delete()
        except discord.HTTPException:
            pass

    async def _on_customize(self, interaction: discord.Interaction, values):
        choice = values[0]
        if choice == "general":
            self.page = "general"
            return await self._show(interaction)
        if choice == "subs":
            self.page = "subs"
            return await self._show(interaction)
        opener = {"design": self._modal_design, "style": self._modal_style,
                  "message": self._modal_message, "settings": self._modal_settings}[choice]
        await opener(interaction)

    # ------------------------------------------------------ general page
    async def _set_staff(self, interaction: discord.Interaction, values):
        role = values[0]
        if role.is_default() or getattr(role, "managed", False):
            return await _reject(interaction, "Invalid Role", "Choose a normal role (not @everyone or a bot role).")
        self.cfg["staff_role_id"] = role.id
        await store.save(self.guild.id)
        await self._show(interaction)

    async def _set_category(self, interaction: discord.Interaction, values):
        self.cfg["category_id"] = values[0].id
        await store.save(self.guild.id)
        await self._show(interaction)

    async def _set_transcript(self, interaction: discord.Interaction, values):
        self.cfg["transcript_id"] = values[0].id
        await store.save(self.guild.id)
        await self._show(interaction)

    # ------------------------------------------------------------ modals
    async def _modal_design(self, interaction: discord.Interaction):
        p = self.cfg["panel"]

        async def done(i: discord.Interaction, v: dict):
            if not ui.media_ok(v["banner"]) or not ui.media_ok(v["thumbnail"]):
                return await _reject(i, "Invalid Image", "Banner / thumbnail must be an image URL (https://…) or a {variable}.")
            p.update(title=v["title"], description=v["description"], footer=v["footer"],
                     banner=v["banner"], thumbnail=v["thumbnail"])
            await store.save(self.guild.id)
            await self._show(i)

        await interaction.response.send_modal(FieldsModal("Panel Design", [
            dict(key="title", label="Title", default=p.get("title"), max=100),
            dict(key="description", label="Description", default=p.get("description"), max=1500, long=True),
            dict(key="footer", label="Footer (small text)", default=p.get("footer"), max=200),
            dict(key="banner", label="Banner image URL", default=p.get("banner"), max=400, hint="https://… (empty = none)"),
            dict(key="thumbnail", label="Thumbnail URL", default=p.get("thumbnail"), max=400, hint="https://… or {server_icon}"),
        ], done))

    async def _modal_style(self, interaction: discord.Interaction):
        p = self.cfg["panel"]

        async def done(i: discord.Interaction, v: dict):
            mode = (v["mode"] or "select").lower()
            if mode not in ("select", "buttons"):
                return await _reject(i, "Invalid Mode", "Display mode must be `select` or `buttons`.")
            if v["color"] and ui.parse_color(v["color"]) is None:
                return await _reject(i, "Invalid Colour", "Use a hex colour like `#5865F2` (empty = no colour).")
            if v["button_emoji"] and ui.make_emoji(v["button_emoji"]) is None:
                return await _reject(i, "Invalid Emoji", "Use a normal emoji or a custom one like `<:name:id>`.")
            p.update(color=v["color"], mode=mode, placeholder=v["placeholder"] or "Select a ticket type",
                     button_label=v["button_label"] or "Create Ticket", button_emoji=v["button_emoji"])
            await store.save(self.guild.id)
            await self._show(i)

        await interaction.response.send_modal(FieldsModal("Panel Style", [
            dict(key="color", label="Accent colour (hex)", default=p.get("color"), max=7, hint="#5865F2 (empty = none)"),
            dict(key="mode", label="Display mode", default=p.get("mode"), max=7, hint="select  or  buttons", required=True),
            dict(key="placeholder", label="Select menu placeholder", default=p.get("placeholder"), max=100),
            dict(key="button_label", label="Create button label", default=p.get("button_label"), max=80),
            dict(key="button_emoji", label="Create button emoji", default=p.get("button_emoji"), max=60),
        ], done))

    async def _modal_message(self, interaction: discord.Interaction):
        t = self.cfg["ticket"]

        async def done(i: discord.Interaction, v: dict):
            if not ui.media_ok(v["banner"]) or not ui.media_ok(v["thumbnail"]):
                return await _reject(i, "Invalid Image", "Banner / thumbnail must be an image URL (https://…) or a {variable}.")
            t.update(title=v["title"], description=v["description"], footer=v["footer"],
                     banner=v["banner"], thumbnail=v["thumbnail"])
            await store.save(self.guild.id)
            await self._show(i)

        await interaction.response.send_modal(FieldsModal("Ticket Message", [
            dict(key="title", label="Title", default=t.get("title"), max=200),
            dict(key="description", label="Description", default=t.get("description"), max=1800, long=True),
            dict(key="footer", label="Footer (small text)", default=t.get("footer"), max=200),
            dict(key="banner", label="Banner image URL", default=t.get("banner"), max=400, hint="https://… (empty = none)"),
            dict(key="thumbnail", label="Thumbnail URL", default=t.get("thumbnail"), max=400, hint="https://… or {user_avatar}"),
        ], done))

    async def _modal_settings(self, interaction: discord.Interaction):
        s, t = self.cfg["settings"], self.cfg["ticket"]

        async def done(i: discord.Interaction, v: dict):
            if not v["name_format"]:
                return await _reject(i, "Invalid Name", "The channel name format can't be empty.")
            try:
                max_open = int(v["max_open"] or 1)
                delay = int(v["delete_delay"] or 0)
            except ValueError:
                return await _reject(i, "Invalid Number", "Max tickets and delete delay must be numbers.")
            if not 1 <= max_open <= 10 or not 0 <= delay <= 60:
                return await _reject(i, "Out of Range", "Max tickets: `1-10`. Delete delay: `0-60` seconds.")
            if v["color"] and ui.parse_color(v["color"]) is None:
                return await _reject(i, "Invalid Colour", "Use a hex colour like `#5865F2` (empty = no colour).")
            s.update(name_format=v["name_format"], max_open=max_open, delete_delay=delay)
            t.update(close_text=v["close_text"], color=v["color"])
            await store.save(self.guild.id)
            await self._show(i)

        await interaction.response.send_modal(FieldsModal("Ticket Settings", [
            dict(key="name_format", label="Channel name format", default=s.get("name_format"), max=80,
                 hint="ticket-{ticket_number}  /  {ticket_subcategory}-{user_name}", required=True),
            dict(key="max_open", label="Max open tickets per member", default=str(s.get("max_open", 1)), max=2),
            dict(key="delete_delay", label="Delete delay (seconds, 0-60)", default=str(s.get("delete_delay", 5)), max=2),
            dict(key="close_text", label="Close message", default=t.get("close_text"), max=800, long=True),
            dict(key="color", label="Ticket message colour (hex)", default=t.get("color"), max=7, hint="#5865F2 (empty = none)"),
        ], done))

    # ------------------------------------------------------ subcategories
    async def _pick_sub(self, interaction: discord.Interaction, values):
        self.sel = values[0]
        await self._show(interaction)

    def _parse_roles(self, raw: str) -> list[int]:
        found = dict.fromkeys(int(n) for n in re.findall(r"\d{15,20}", raw or ""))
        return [rid for rid in found if self.guild.get_role(rid) is not None][:10]

    def _sub_modal(self, existing: Optional[dict]) -> FieldsModal:
        async def done(i: discord.Interaction, v: dict):
            if not v["label"]:
                return await _reject(i, "Missing Name", "A subcategory needs a name.")
            if v["emoji"] and ui.make_emoji(v["emoji"]) is None:
                return await _reject(i, "Invalid Emoji", "Use a normal emoji or a custom one like `<:name:id>`.")
            category_id = None
            if v["category"]:
                digits = re.sub(r"\D", "", v["category"])
                channel = self.guild.get_channel(int(digits)) if digits else None
                if not isinstance(channel, discord.CategoryChannel):
                    return await _reject(i, "Invalid Category", "That ID is not a category in this server.")
                category_id = channel.id
            lowered = v["label"].lower()
            for other in self.cfg["subcategories"]:
                if other["label"].lower() == lowered and (existing is None or other["id"] != existing["id"]):
                    return await _reject(i, "Duplicate Name", "A subcategory with that name already exists.")
            data = dict(label=v["label"], emoji=v["emoji"], description=v["description"],
                        roles=self._parse_roles(v["roles"]), category_id=category_id)
            if existing is None:
                if len(self.cfg["subcategories"]) >= MAX_SUBCATEGORIES:
                    return await _reject(i, "Limit Reached", f"You can only add up to `{MAX_SUBCATEGORIES}` subcategories.")
                data.update(id=store.new_sub_id(self.cfg), questions=[])
                self.cfg["subcategories"].append(data)
                self.sel = data["id"]
            else:
                existing.update(data)
            await store.save(self.guild.id)
            await self._show(i)
            await refresh_panels(self.guild)

        e = existing or {}
        return FieldsModal("Edit Subcategory" if existing else "Add Subcategory", [
            dict(key="label", label="Name", default=e.get("label"), max=80, required=True, hint="Billing, Report a user, Partnership…"),
            dict(key="emoji", label="Emoji", default=e.get("emoji"), max=60, hint="🎫 or <:name:id>"),
            dict(key="description", label="Description (shown in the menu)", default=e.get("description"), max=100),
            dict(key="roles", label="Extra staff roles (IDs / mentions)", default=" ".join(str(r) for r in e.get("roles", [])),
                 max=250, hint="Optional, separated by spaces"),
            dict(key="category", label="Own category ID (optional)", default=str(e.get("category_id") or ""), max=25,
                 hint="Tickets of this type are created here"),
        ], done)

    async def _add_sub(self, interaction: discord.Interaction):
        await interaction.response.send_modal(self._sub_modal(None))

    async def _edit_sub(self, interaction: discord.Interaction):
        sub = store.find_sub(self.cfg, self.sel)
        if sub is None:
            return await self._show(interaction)
        await interaction.response.send_modal(self._sub_modal(sub))

    async def _edit_questions(self, interaction: discord.Interaction):
        sub = store.find_sub(self.cfg, self.sel)
        if sub is None:
            return await self._show(interaction)

        async def done(i: discord.Interaction, v: dict):
            lines = [ui.cut(line.strip(), 45) for line in v["questions"].splitlines() if line.strip()]
            sub["questions"] = lines[:MAX_QUESTIONS]
            await store.save(self.guild.id)
            await self._show(i)

        await interaction.response.send_modal(FieldsModal(f"Questions • {sub['label']}"[:45], [
            dict(key="questions", label=f"One question per line (max {MAX_QUESTIONS})",
                 default="\n".join(sub.get("questions", [])), max=400, long=True,
                 hint="What do you need help with?\nOrder ID (if any)")], done))

    async def _remove_sub(self, interaction: discord.Interaction):
        self.cfg["subcategories"] = [s for s in self.cfg["subcategories"] if s["id"] != self.sel]
        self.sel = None
        await store.save(self.guild.id)
        await self._show(interaction)
        await refresh_panels(self.guild)

    # ---------------------------------------------------- panel actions
    async def _on_send_panel(self, interaction: discord.Interaction, values):
        problem = panel_problem(self.guild, self.cfg)
        if problem:
            await self._show(interaction)
            return await interaction.followup.send(view=ui.error("Can't Send Panel", ui.note(problem)), ephemeral=True)
        channel = self.guild.get_channel(values[0].id)
        me = self.guild.me
        if channel is None or not channel.permissions_for(me).send_messages:
            await self._show(interaction)
            return await interaction.followup.send(
                view=ui.error("Missing Permissions", ui.note("I can't send messages in that channel.")), ephemeral=True)
        await self._show(interaction)
        try:
            await send_panel(self.guild, channel)
        except discord.HTTPException as exc:
            return await interaction.followup.send(
                view=ui.error("Couldn't Send Panel", ui.note(str(exc)[:200])), ephemeral=True)
        await interaction.followup.send(
            view=ui.success("Panel Sent", ui.note(f"The ticket panel was sent to {channel.mention}.")), ephemeral=True)

    async def _preview_panel(self, interaction: discord.Interaction):
        await interaction.response.send_message(view=ui.panel_view(self.guild, self.cfg, preview=True), ephemeral=True)

    async def _preview_ticket(self, interaction: discord.Interaction):
        cfg = self.cfg
        sub = cfg["subcategories"][0] if cfg["subcategories"] else None
        questions = (sub or {}).get("questions") or ["Why are you opening this ticket?"]
        fake = dict(number=cfg.get("counter", 0) + 1, channel_id=interaction.channel_id, status="open",
                    created_at=int(time.time()), claimed_by=None,
                    answers=[[q, "Example answer"] for q in questions])
        view = ui.ticket_view(self.guild, cfg, fake, owner=interaction.user, sub=sub,
                              channel=interaction.channel, disabled=True)
        await interaction.response.send_message(view=view, ephemeral=True)

    async def _update_panels(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        count = await refresh_panels(self.guild)
        text = (f"Updated `{count}` live panel(s)." if count
                else "No live panels found. Use the channel menu to send one.")
        await interaction.followup.send(view=ui.success("Panels Updated", ui.note(text)), ephemeral=True)

    async def _variables(self, interaction: discord.Interaction):
        view = discord.ui.LayoutView(timeout=None)
        box = discord.ui.Container()
        box.add_item(_text("### Ticket Variables"))
        box.add_item(discord.ui.Separator())
        box.add_item(_text(inline_text()[:3800]))
        view.add_item(box)
        await interaction.response.send_message(view=view, ephemeral=True)
