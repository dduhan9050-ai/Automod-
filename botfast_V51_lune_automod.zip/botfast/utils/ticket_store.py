"""Ticket storage.

* Guild configuration lives in memory (loaded once) and is written to SQLite
  as one JSON row per guild, so ticket opens never wait on disk reads.
* Individual tickets are rows in ``tickets`` (looked up by channel id), so
  every button keeps working after a restart.
* Uses the standard ``sqlite3`` module inside worker threads (no extra deps).
"""
from __future__ import annotations

import asyncio
import copy
import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Optional

DB_PATH = Path(__file__).resolve().parent.parent / "db" / "ticket.db"

MAX_SUBCATEGORIES = 25
MAX_QUESTIONS = 5
MAX_PANELS = 10

DEFAULT_CONFIG: dict[str, Any] = {
    "category_id": None,        # where tickets are created
    "transcript_id": None,      # where transcripts are logged
    "staff_role_id": None,      # default staff role
    "counter": 0,               # tickets created so far
    "panel": {
        "title": "Support Tickets",
        "description": "Need help? Open a ticket and our team will get back to you shortly.",
        "footer": "{server_name} • Support",
        "banner": "",
        "thumbnail": "{server_icon}",
        "color": "",
        "mode": "select",       # select | buttons
        "placeholder": "Select a ticket type",
        "button_label": "Create Ticket",
        "button_emoji": "<:emoji_15:1566452129894506606>",
    },
    "ticket": {
        "title": "{ticket_subcategory_emoji} {ticket_subcategory} • Ticket #{ticket_number}",
        "description": (
            "Hello {user}, thanks for contacting support!\n"
            "A member of {staff_role} will be with you shortly.\n\n"
            "{ticket_answers}"
        ),
        "footer": "{server_name} • Ticket #{ticket_number}",
        "banner": "",
        "thumbnail": "{user_avatar}",
        "color": "",
        "close_text": "This ticket was closed by {closer}.\n**Reason:** {close_reason}",
    },
    "settings": {
        "name_format": "ticket-{ticket_number}",
        "max_open": 1,
        "claim": True,
        "confirm_close": True,
        "ask_reason": False,
        "dm_transcript": True,
        "ping_staff": True,
        "delete_delay": 5,
    },
    "subcategories": [],        # [{id,label,emoji,description,roles,category_id,questions}]
    "panels": [],               # [[channel_id, message_id], ...]
}


def _merge(base: dict, saved: dict) -> dict:
    """Defaults first, saved values override (recursively for dicts)."""
    out = copy.deepcopy(base)
    for key, value in (saved or {}).items():
        if isinstance(out.get(key), dict) and isinstance(value, dict):
            out[key] = _merge(out[key], value)
        else:
            out[key] = value
    return out


class TicketStore:
    def __init__(self, path: Path = DB_PATH) -> None:
        self.path = path
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = threading.Lock()
        self._cache: dict[int, dict] = {}
        self._ready = False

    # ------------------------------------------------------------ plumbing
    def _connect(self) -> sqlite3.Connection:
        if self._conn is None:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(self.path), check_same_thread=False, timeout=30)
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS ticket_guild (
                    guild_id INTEGER PRIMARY KEY,
                    data     TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS tickets (
                    channel_id   INTEGER PRIMARY KEY,
                    guild_id     INTEGER NOT NULL,
                    owner_id     INTEGER NOT NULL,
                    number       INTEGER NOT NULL,
                    subcategory  TEXT,
                    status       TEXT NOT NULL DEFAULT 'open',
                    claimed_by   INTEGER,
                    message_id   INTEGER,
                    answers      TEXT,
                    created_at   INTEGER NOT NULL,
                    closed_at    INTEGER,
                    closed_by    INTEGER,
                    close_reason TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_tickets_owner
                    ON tickets (guild_id, owner_id, status);
                """
            )
            self._conn.commit()
        return self._conn

    def _run(self, sql: str, params: tuple = (), *, fetch: str = "none"):
        with self._lock:
            conn = self._connect()
            cur = conn.execute(sql, params)
            if fetch == "one":
                row = cur.fetchone()
                return dict(row) if row else None
            if fetch == "all":
                return [dict(r) for r in cur.fetchall()]
            conn.commit()
            return cur.rowcount

    async def _a(self, *args, **kwargs):
        return await asyncio.to_thread(self._run, *args, **kwargs)

    async def load(self) -> None:
        if self._ready:
            return
        rows = await self._a("SELECT guild_id, data FROM ticket_guild", fetch="all")
        for row in rows:
            try:
                self._cache[row["guild_id"]] = _merge(DEFAULT_CONFIG, json.loads(row["data"]))
            except ValueError:
                continue
        self._ready = True

    # --------------------------------------------------------------- config
    def get(self, guild_id: int) -> dict:
        """Live config dict for the guild (mutate it, then call ``save``)."""
        cfg = self._cache.get(guild_id)
        if cfg is None:
            cfg = self._cache[guild_id] = copy.deepcopy(DEFAULT_CONFIG)
        return cfg

    async def save(self, guild_id: int) -> None:
        data = json.dumps(self.get(guild_id), ensure_ascii=False)
        await self._a(
            "INSERT INTO ticket_guild (guild_id, data) VALUES (?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET data = excluded.data",
            (guild_id, data),
        )

    async def reset(self, guild_id: int) -> None:
        self._cache[guild_id] = copy.deepcopy(DEFAULT_CONFIG)
        await self._a("DELETE FROM ticket_guild WHERE guild_id = ?", (guild_id,))

    async def next_number(self, guild_id: int) -> int:
        cfg = self.get(guild_id)
        cfg["counter"] = int(cfg.get("counter", 0)) + 1
        await self.save(guild_id)
        return cfg["counter"]

    # -------------------------------------------------------- subcategories
    @staticmethod
    def find_sub(cfg: dict, sub_id: Optional[str]) -> Optional[dict]:
        for sub in cfg.get("subcategories", []):
            if sub["id"] == sub_id:
                return sub
        return None

    @staticmethod
    def new_sub_id(cfg: dict) -> str:
        used = {s["id"] for s in cfg.get("subcategories", [])}
        n = 1
        while f"s{n}" in used:
            n += 1
        return f"s{n}"

    # -------------------------------------------------------------- tickets
    async def add_ticket(self, *, channel_id: int, guild_id: int, owner_id: int, number: int,
                         subcategory: Optional[str], answers: list) -> None:
        await self._a(
            "INSERT OR REPLACE INTO tickets (channel_id, guild_id, owner_id, number, subcategory, "
            "status, answers, created_at) VALUES (?, ?, ?, ?, ?, 'open', ?, ?)",
            (channel_id, guild_id, owner_id, number, subcategory,
             json.dumps(answers, ensure_ascii=False), int(time.time())),
        )

    async def get_ticket(self, channel_id: int) -> Optional[dict]:
        return await self._a("SELECT * FROM tickets WHERE channel_id = ?", (channel_id,), fetch="one")

    async def open_tickets_of(self, guild_id: int, owner_id: int) -> list[dict]:
        return await self._a(
            "SELECT * FROM tickets WHERE guild_id = ? AND owner_id = ? AND status != 'closed'",
            (guild_id, owner_id), fetch="all")

    async def open_count(self, guild_id: int) -> int:
        row = await self._a(
            "SELECT COUNT(*) AS n FROM tickets WHERE guild_id = ? AND status != 'closed'",
            (guild_id,), fetch="one")
        return int(row["n"]) if row else 0

    async def set_message(self, channel_id: int, message_id: int) -> None:
        await self._a("UPDATE tickets SET message_id = ? WHERE channel_id = ?", (message_id, channel_id))

    async def set_claim(self, channel_id: int, user_id: Optional[int]) -> None:
        await self._a("UPDATE tickets SET claimed_by = ? WHERE channel_id = ?", (user_id, channel_id))

    async def close_ticket(self, channel_id: int, closer_id: int, reason: Optional[str]) -> None:
        await self._a(
            "UPDATE tickets SET status = 'closed', closed_at = ?, closed_by = ?, close_reason = ? "
            "WHERE channel_id = ?", (int(time.time()), closer_id, reason, channel_id))

    async def reopen_ticket(self, channel_id: int) -> None:
        await self._a(
            "UPDATE tickets SET status = 'open', closed_at = NULL, closed_by = NULL, close_reason = NULL "
            "WHERE channel_id = ?", (channel_id,))

    async def delete_ticket(self, channel_id: int) -> None:
        await self._a("DELETE FROM tickets WHERE channel_id = ?", (channel_id,))


store = TicketStore()
