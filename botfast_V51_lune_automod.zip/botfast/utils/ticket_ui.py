"""Components V2 builders for the Ticket system (panel, ticket message, closed card, help)."""
from __future__ import annotations

import html
import io
import re
from datetime import timezone
from typing import Optional

import discord

from utils import automation_ui as base
from utils.ticket_vars import SCOPE_NOTE, build_values, help_pages, render

OK, BAD, WARN = base.OK, base.FAIL, base.WARN
_text = base._text

# custom_id namespace handled by the Tickets cog (works after restarts, no stored views needed)
CID_SELECT = "zticket:select"
CID_CREATE = "zticket:create"        # + ":<subcategory id | _>"
CID_CLAIM = "zticket:claim"
CID_UNCLAIM = "zticket:unclaim"
CID_CLOSE = "zticket:close"
CID_CLOSE_YES = "zticket:close_yes"
CID_CLOSE_NO = "zticket:close_no"
CID_REOPEN = "zticket:reopen"
CID_DELETE = "zticket:delete"
CID_TRANSCRIPT = "zticket:transcript"


# --------------------------------------------------------------------------
# small helpers
# --------------------------------------------------------------------------
def cut(text: Optional[str], limit: int) -> str:
    text = text or ""
    return text if len(text) <= limit else text[: limit - 1] + "…"


def parse_color(raw: Optional[str]) -> Optional[int]:
    raw = (raw or "").strip().lstrip("#")
    if len(raw) == 3:
        raw = "".join(c * 2 for c in raw)
    if len(raw) != 6:
        return None
    try:
        return int(raw, 16)
    except ValueError:
        return None


def make_emoji(raw: Optional[str]) -> Optional[discord.PartialEmoji]:
    """Accept a unicode emoji or <:name:id> / <a:name:id>; anything else is ignored."""
    raw = (raw or "").strip()
    if not raw:
        return None
    if re.fullmatch(r"<a?:\w+:\d+>", raw) or any(ord(c) > 127 for c in raw):
        try:
            return discord.PartialEmoji.from_str(raw)
        except Exception:
            return None
    return None


def is_url(value: str) -> bool:
    return value.startswith(("http://", "https://"))


def media_ok(value: str) -> bool:
    """Image fields accept: empty, a URL, or a single {variable}."""
    value = (value or "").strip()
    return not value or is_url(value) or bool(re.fullmatch(r"\{\w+\}", value))


def resolve_media(value: str, values: dict) -> Optional[str]:
    rendered = render(value, values).strip()
    return rendered if is_url(rendered) else None


def _gallery(url: str) -> discord.ui.MediaGallery:
    from components_v2 import media_gallery
    return media_gallery(url)


def _box(accent: Optional[int]) -> discord.ui.Container:
    return discord.ui.Container(accent_colour=discord.Colour(accent)) if accent else discord.ui.Container()


def _head(box: discord.ui.Container, title: str, description: str, thumb: Optional[str]) -> None:
    body = f"## {cut(title, 250) or '​'}" + (f"\n{description}" if description else "")
    body = cut(body, 3000)
    if thumb:
        box.add_item(discord.ui.Section(_text(body), accessory=discord.ui.Thumbnail(media=thumb)))
    else:
        box.add_item(_text(body))


def staff_role_ids(cfg: dict, sub: Optional[dict] = None) -> set[int]:
    ids: set[int] = set()
    if cfg.get("staff_role_id"):
        ids.add(int(cfg["staff_role_id"]))
    if sub:
        ids.update(int(r) for r in sub.get("roles", []))
    return ids


def is_staff(member: discord.Member, cfg: dict, sub: Optional[dict] = None) -> bool:
    if member.guild_permissions.administrator or member.id == member.guild.owner_id:
        return True
    ids = staff_role_ids(cfg, sub)
    return any(role.id in ids for role in member.roles)


def channel_name(fmt: str, values: dict) -> str:
    name = render(fmt, values).lower()
    name = re.sub(r"[^a-z0-9\-_ ]+", "", name)
    name = re.sub(r"[\s_]+", "-", name).strip("-")
    return name[:90] or "ticket"


# --------------------------------------------------------------------------
# result panels (re-use the bot's existing look)
# --------------------------------------------------------------------------
success = base.success
error = base.error
warning = base.warning
note = base.note


# --------------------------------------------------------------------------
# Panel (the message members click to open a ticket)
# --------------------------------------------------------------------------
def panel_view(guild: discord.Guild, cfg: dict, *, preview: bool = False) -> discord.ui.LayoutView:
    p = cfg["panel"]
    vals = build_values(guild=guild, cfg=cfg)
    view = discord.ui.LayoutView(timeout=None)
    box = _box(parse_color(p.get("color")))
    _head(box, render(p.get("title"), vals) or "Support Tickets", render(p.get("description"), vals),
          resolve_media(p.get("thumbnail", ""), vals))
    banner = resolve_media(p.get("banner", ""), vals)
    if banner:
        box.add_item(_gallery(banner))
    box.add_item(discord.ui.Separator())

    subs = cfg.get("subcategories", [])
    if not subs:
        row = discord.ui.ActionRow()
        row.add_item(discord.ui.Button(
            style=discord.ButtonStyle.primary, label=cut(p.get("button_label") or "Create Ticket", 80),
            emoji=make_emoji(p.get("button_emoji")), custom_id=f"{CID_CREATE}:_", disabled=preview))
        box.add_item(row)
    elif p.get("mode") == "buttons":
        for start in range(0, len(subs), 5):
            row = discord.ui.ActionRow()
            for sub in subs[start:start + 5]:
                row.add_item(discord.ui.Button(
                    style=discord.ButtonStyle.secondary, label=cut(sub["label"], 80),
                    emoji=make_emoji(sub.get("emoji")), custom_id=f"{CID_CREATE}:{sub['id']}", disabled=preview))
            box.add_item(row)
    else:
        row = discord.ui.ActionRow()
        row.add_item(discord.ui.Select(
            custom_id=CID_SELECT, placeholder=cut(p.get("placeholder") or "Select a ticket type", 150),
            disabled=preview, min_values=1, max_values=1,
            options=[discord.SelectOption(label=cut(s["label"], 100), value=s["id"],
                                          description=cut(s.get("description"), 100) or None,
                                          emoji=make_emoji(s.get("emoji"))) for s in subs[:25]]))
        box.add_item(row)

    footer = render(p.get("footer"), vals)
    if footer:
        box.add_item(_text(f"-# {cut(footer, 300)}"))
    view.add_item(box)
    return view


# --------------------------------------------------------------------------
# Message posted inside a fresh ticket
# --------------------------------------------------------------------------
def ticket_view(guild: discord.Guild, cfg: dict, ticket: dict, *, owner, sub: Optional[dict],
                channel, claimer=None, mention_line: Optional[str] = None,
                disabled: bool = False) -> discord.ui.LayoutView:
    t = cfg["ticket"]
    vals = build_values(guild, owner, cfg, ticket, sub, channel, claimer=claimer)
    view = discord.ui.LayoutView(timeout=None)
    if mention_line:
        view.add_item(_text(mention_line))
    box = _box(parse_color(t.get("color")))
    _head(box, render(t.get("title"), vals), render(t.get("description"), vals),
          resolve_media(t.get("thumbnail", ""), vals))
    banner = resolve_media(t.get("banner", ""), vals)
    if banner:
        box.add_item(_gallery(banner))
    if claimer is not None:
        box.add_item(_text(f"-# 🙋 Claimed by {claimer.mention}"))
    box.add_item(discord.ui.Separator())

    row = discord.ui.ActionRow()
    row.add_item(discord.ui.Button(style=discord.ButtonStyle.danger, label="Close", emoji="<:emoji_18:1566457796973826100>",
                                   custom_id=CID_CLOSE, disabled=disabled))
    if cfg["settings"].get("claim", True):
        if claimer is None:
            row.add_item(discord.ui.Button(style=discord.ButtonStyle.primary, label="Claim", emoji="🙋",
                                           custom_id=CID_CLAIM, disabled=disabled))
        else:
            row.add_item(discord.ui.Button(style=discord.ButtonStyle.secondary, label="Unclaim", emoji="↩️",
                                           custom_id=CID_UNCLAIM, disabled=disabled))
    row.add_item(discord.ui.Button(style=discord.ButtonStyle.secondary, label="Transcript", emoji="📄",
                                   custom_id=CID_TRANSCRIPT, disabled=disabled))
    box.add_item(row)

    footer = render(t.get("footer"), vals)
    if footer:
        box.add_item(_text(f"-# {cut(footer, 300)}"))
    view.add_item(box)
    return view


def closed_view(guild: discord.Guild, cfg: dict, ticket: dict, *, owner, sub, channel, closer,
                reason: Optional[str]) -> discord.ui.LayoutView:
    vals = build_values(guild, owner, cfg, ticket, sub, channel, closer=closer, close_reason=reason)
    view = discord.ui.LayoutView(timeout=None)
    box = _box(parse_color(cfg["ticket"].get("color")))
    box.add_item(_text("### <:emoji_18:1566457796973826100> Ticket Closed"))
    box.add_item(_text(cut(render(cfg["ticket"].get("close_text"), vals), 2000)))
    box.add_item(discord.ui.Separator())
    row = discord.ui.ActionRow()
    row.add_item(discord.ui.Button(style=discord.ButtonStyle.success, label="Reopen", emoji="🔓", custom_id=CID_REOPEN))
    row.add_item(discord.ui.Button(style=discord.ButtonStyle.danger, label="Delete", emoji="<:bin:1567102784552304640>", custom_id=CID_DELETE))
    row.add_item(discord.ui.Button(style=discord.ButtonStyle.secondary, label="Transcript", emoji="📄",
                                   custom_id=CID_TRANSCRIPT))
    box.add_item(row)
    view.add_item(box)
    return view


def confirm_close_view() -> discord.ui.LayoutView:
    view = discord.ui.LayoutView(timeout=None)
    box = discord.ui.Container()
    box.add_item(_text(f"{WARN} **Are you sure you want to close this ticket?**"))
    row = discord.ui.ActionRow()
    row.add_item(discord.ui.Button(style=discord.ButtonStyle.danger, label="Yes, close it", custom_id=CID_CLOSE_YES))
    row.add_item(discord.ui.Button(style=discord.ButtonStyle.secondary, label="Cancel", custom_id=CID_CLOSE_NO))
    box.add_item(row)
    view.add_item(box)
    return view


def created_view(channel: discord.abc.GuildChannel) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView(timeout=None)
    box = discord.ui.Container()
    box.add_item(_text(f"### {OK} Ticket Created\n\n{note(f'Your ticket is ready: {channel.mention}')}"))
    row = discord.ui.ActionRow()
    row.add_item(discord.ui.Button(style=discord.ButtonStyle.link, label="Open Ticket", url=channel.jump_url))
    box.add_item(row)
    view.add_item(box)
    return view


def log_view(title: str, lines: list[str], filename: Optional[str] = None) -> discord.ui.LayoutView:
    """Card sent to the transcript channel (the HTML file is attached via a File component)."""
    view = discord.ui.LayoutView(timeout=None)
    box = discord.ui.Container()
    box.add_item(_text(f"### {title}\n\n" + "\n".join(lines)))
    if filename:
        box.add_item(discord.ui.Separator())
        box.add_item(discord.ui.File(f"attachment://{filename}"))
    view.add_item(box)
    return view


# --------------------------------------------------------------------------
# ticket config
# --------------------------------------------------------------------------
def _onoff(flag: bool) -> str:
    return "`Enabled`" if flag else "`Disabled`"


def config_view(bot_user, guild: discord.Guild, cfg: dict, open_count: int) -> discord.ui.LayoutView:
    s = cfg["settings"]
    cat = guild.get_channel(cfg.get("category_id") or 0)
    log = guild.get_channel(cfg.get("transcript_id") or 0)
    role = guild.get_role(cfg.get("staff_role_id") or 0)
    subs = cfg.get("subcategories", [])
    sub_lines = "\n".join(f"{base.DOT} {(s_.get('emoji') or '')} {s_['label']}" for s_ in subs[:10]) or "`None`"
    body = (
        f"### Ticket Configuration • {guild.name}\n\n"
        f"{base.label('Category', cat.mention if cat else '`Not set`')}\n"
        f"{base.label('Transcript Channel', log.mention if log else '`Not set`')}\n"
        f"{base.label('Staff Role', role.mention if role else '`Not set`')}\n"
        f"{base.label('Panel Style', '`' + cfg['panel'].get('mode', 'select') + '`')}\n"
        f"{base.label('Channel Name', '`' + s.get('name_format', '') + '`')}\n"
        f"{base.label('Max Open / User', '`' + str(s.get('max_open', 1)) + '`')}\n\n"
        f"{base.label('Claim Button', _onoff(s.get('claim', True)))}\n"
        f"{base.label('Close Confirmation', _onoff(s.get('confirm_close', True)))}\n"
        f"{base.label('Ask Reason', _onoff(s.get('ask_reason', False)))}\n"
        f"{base.label('DM Transcript', _onoff(s.get('dm_transcript', True)))}\n"
        f"{base.label('Ping Staff', _onoff(s.get('ping_staff', True)))}\n\n"
        f"__**Subcategories ({len(subs)}/25)**__\n{sub_lines}\n\n"
        f"{base.label('Tickets Created', '`' + str(cfg.get('counter', 0)) + '`')}\n"
        f"{base.label('Open Tickets', '`' + str(open_count) + '`')}"
    )
    avatar = getattr(getattr(bot_user, "display_avatar", None), "url", None)
    box = discord.ui.Container()
    if avatar:
        box.add_item(discord.ui.Section(_text(cut(body, 3900)), accessory=discord.ui.Thumbnail(media=str(avatar))))
    else:
        box.add_item(_text(cut(body, 3900)))
    view = discord.ui.LayoutView(timeout=None)
    view.add_item(box)
    return view


# --------------------------------------------------------------------------
# help screens
# --------------------------------------------------------------------------
async def send_group_help(ctx, group) -> None:
    """`?ticket` -> "<BOT> TICKET GROUP" with 5 commands per page and the « ‹ <:bin:1567102784552304640> › » pager."""
    prefix = ctx.clean_prefix
    entries = [base._entry(prefix, c) for c in base._ordered(group)]
    title = f"{ctx.bot.user.name} {group.qualified_name} Group".upper()
    view = base.GroupHelpView(ctx, title, entries, per_page=5)
    view.message = await ctx.send(view=view)


async def send_variables(ctx) -> None:
    intro = (
        "Use these placeholders in the panel, ticket message, close text and channel name.\n\n"
        f"{SCOPE_NOTE}\n\n"
        f"__**Example**__\n> `Hello {{user}}, your ticket #{{ticket_number}} for {{ticket_subcategory}} is open!`"
    )
    pages = [intro] + help_pages()
    title = f"{ctx.bot.user.name} Ticket Variables".upper()
    view = base.GroupHelpView(ctx, title, pages, per_page=1)
    view.message = await ctx.send(view=view)


# --------------------------------------------------------------------------
# transcript (self-contained dark HTML page)
# --------------------------------------------------------------------------
_CSS = (
    "body{background:#1e1f22;color:#dbdee1;font-family:Arial,Helvetica,sans-serif;margin:0;padding:24px}"
    "h1{font-size:20px;margin:0 0 4px}.meta{color:#949ba4;font-size:13px;margin-bottom:20px}"
    ".m{display:flex;gap:12px;padding:8px 0;border-top:1px solid #2b2d31}.m img{width:40px;height:40px;border-radius:50%}"
    ".n{font-weight:700;color:#fff}.t{color:#949ba4;font-size:12px;margin-left:6px}"
    ".c{white-space:pre-wrap;word-break:break-word;margin-top:2px}.a a{color:#00a8fc}"
    ".e{border-left:4px solid #4e5058;background:#2b2d31;padding:6px 10px;margin-top:4px;border-radius:4px}"
)


async def build_transcript(channel: discord.TextChannel, header: str, limit: int = 10000):
    """Return (html_bytes, filename, message_count). Use :func:`make_file` once per upload."""
    rows: list[str] = []
    count = 0
    async for msg in channel.history(limit=limit, oldest_first=True):
        count += 1
        stamp = msg.created_at.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        body = html.escape(msg.content or "")
        extra = ""
        for att in msg.attachments:
            extra += f'<div class="a"><a href="{html.escape(att.url)}">📎 {html.escape(att.filename)}</a></div>'
        for emb in msg.embeds:
            bits = [x for x in (emb.title, emb.description) if x]
            if bits:
                extra += f'<div class="e">{html.escape(" — ".join(bits))}</div>'
        if not body and not extra:
            body = "<i>(components / no text)</i>"
        rows.append(
            f'<div class="m"><img src="{html.escape(str(msg.author.display_avatar.url))}">'
            f'<div><span class="n">{html.escape(msg.author.display_name)}</span>'
            f'<span class="t">{stamp}</span><div class="c">{body}</div>{extra}</div></div>')
    page = (f"<!doctype html><html><head><meta charset='utf-8'><title>{html.escape(channel.name)}</title>"
            f"<style>{_CSS}</style></head><body><h1>#{html.escape(channel.name)}</h1>"
            f"<div class='meta'>{html.escape(header)} • {count} messages</div>{''.join(rows)}</body></html>")
    return page.encode("utf-8"), f"transcript-{channel.name}.html", count


def make_file(data: bytes, filename: str) -> discord.File:
    return discord.File(io.BytesIO(data), filename=filename)
