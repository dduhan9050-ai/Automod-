"""Ticket variables: one registry used by the `ticketvariables` command and by the renderer.

Style matches the welcome system:  {user}, {user_name}, {server_name} ...
Unknown variables are left untouched, matching is case-insensitive.
"""
from __future__ import annotations

import json
import re
from typing import Any, Optional

import discord

# (group, variable, description)
VARIABLES: tuple[tuple[str, str, str], ...] = (
    # ---------------------------------------------------------------- user
    ("User", "user", "Mentions the ticket owner (e.g. @UserName)."),
    ("User", "user_name", "The ticket owner's username."),
    ("User", "user_id", "The ticket owner's ID number."),
    ("User", "user_nick", "The ticket owner's display name in the server."),
    ("User", "user_avatar", "The ticket owner's avatar URL."),
    ("User", "user_joindate", "Date the owner joined the server."),
    ("User", "user_createdate", "Date the owner's account was created."),
    # -------------------------------------------------------------- server
    ("Server", "server_name", "The server's name."),
    ("Server", "server_id", "The server's ID number."),
    ("Server", "server_membercount", "The server's total member count."),
    ("Server", "server_icon", "The server's icon URL."),
    # -------------------------------------------------------------- ticket
    ("Ticket", "ticket_number", "This ticket's number (1, 2, 3 ...)."),
    ("Ticket", "ticket_total", "Total tickets created in the server so far."),
    ("Ticket", "ticket_id", "The ticket channel's ID."),
    ("Ticket", "ticket_channel", "Mentions the ticket channel."),
    ("Ticket", "ticket_name", "The ticket channel's name."),
    ("Ticket", "ticket_status", "Open, Claimed or Closed."),
    ("Ticket", "ticket_opened", "Full date/time the ticket was opened."),
    ("Ticket", "ticket_opened_relative", "Relative time, e.g. `5 minutes ago`."),
    # --------------------------------------------------------- subcategory
    ("Subcategory", "ticket_subcategory", "Name of the chosen subcategory."),
    ("Subcategory", "ticket_subcategory_emoji", "Emoji of the chosen subcategory."),
    ("Subcategory", "ticket_subcategory_description", "Description of the chosen subcategory."),
    # ----------------------------------------------------------- questions
    ("Questions", "ticket_reason", "Answer to the first question / reason field."),
    ("Questions", "ticket_answers", "All questions with their answers, formatted."),
    ("Questions", "ticket_answer_1", "Answer to question 1 (up to `ticket_answer_5`)."),
    # --------------------------------------------------------------- staff
    ("Staff & Claim", "staff_role", "Mentions the staff role."),
    ("Staff & Claim", "staff_role_name", "Name of the staff role."),
    ("Staff & Claim", "ticket_claimer", "Mentions the staff member who claimed it."),
    ("Staff & Claim", "ticket_claimer_name", "Username of the staff member who claimed it."),
    # --------------------------------------------------------------- close
    ("Close", "closer", "Mentions whoever closed the ticket."),
    ("Close", "closer_name", "Username of whoever closed the ticket."),
    ("Close", "close_reason", "Reason given when closing the ticket."),
    ("Close", "closed_at", "Full date/time the ticket was closed."),
)

GROUP_ORDER = ("User", "Server", "Ticket", "Subcategory", "Questions", "Staff & Claim", "Close")

# Where each part of the system understands which variables.
SCOPE_NOTE = (
    "**Panel** text supports `Server` variables.\n"
    "**Ticket message**, naming format and close text support every variable."
)

_VAR = re.compile(r"\{(\w+)\}")


def _ts(value: Any, style: str) -> str:
    try:
        return f"<t:{int(value)}:{style}>"
    except (TypeError, ValueError):
        return "N/A"


def _date(dt) -> str:
    return dt.strftime("%A, %B %d, %Y") if dt else "N/A"


def build_values(
    guild: Optional[discord.Guild] = None,
    user: Optional[discord.abc.User] = None,
    cfg: Optional[dict] = None,
    ticket: Optional[dict] = None,
    subcategory: Optional[dict] = None,
    channel: Optional[discord.abc.GuildChannel] = None,
    closer: Optional[discord.abc.User] = None,
    close_reason: Optional[str] = None,
    claimer: Optional[discord.abc.User] = None,
) -> dict[str, str]:
    """Collect every variable value available in the current context."""
    v: dict[str, str] = {}
    cfg = cfg or {}

    if guild is not None:
        icon = getattr(guild.icon, "url", "") if guild.icon else ""
        v.update(server_name=guild.name, server_id=str(guild.id),
                 server_membercount=str(guild.member_count or len(guild.members)),
                 server_icon=str(icon))
        role = guild.get_role(cfg.get("staff_role_id") or 0)
        v["staff_role"] = role.mention if role else "`staff`"
        v["staff_role_name"] = role.name if role else "staff"

    if user is not None:
        v.update(user=user.mention, user_name=user.name, user_id=str(user.id),
                 user_nick=getattr(user, "display_name", user.name),
                 user_avatar=str(user.display_avatar.url),
                 user_createdate=_date(user.created_at),
                 user_joindate=_date(getattr(user, "joined_at", None)))

    sub = subcategory or {}
    v["ticket_subcategory"] = sub.get("label") or "General"
    v["ticket_subcategory_emoji"] = sub.get("emoji") or "<:emoji_15:1566452129894506606>"
    v["ticket_subcategory_description"] = sub.get("description") or "No description"

    answers: list = []
    if ticket:
        raw = ticket.get("answers")
        if isinstance(raw, str):
            try:
                answers = json.loads(raw) or []
            except ValueError:
                answers = []
        elif isinstance(raw, list):
            answers = raw
        status = ticket.get("status", "open")
        if status == "open" and ticket.get("claimed_by"):
            status = "claimed"
        v.update(ticket_number=str(ticket.get("number", 0)),
                 ticket_id=str(ticket.get("channel_id", "")),
                 ticket_status=status.title(),
                 ticket_opened=_ts(ticket.get("created_at"), "F"),
                 ticket_opened_relative=_ts(ticket.get("created_at"), "R"),
                 closed_at=_ts(ticket.get("closed_at"), "F") if ticket.get("closed_at") else "N/A")
    v.setdefault("ticket_total", str(cfg.get("counter", 0)))

    if channel is not None:
        v.update(ticket_channel=channel.mention, ticket_name=channel.name,
                 ticket_id=str(channel.id))

    if claimer is not None:
        v.update(ticket_claimer=claimer.mention, ticket_claimer_name=claimer.name)
    else:
        v.update(ticket_claimer="Unclaimed", ticket_claimer_name="Unclaimed")

    if closer is not None:
        v.update(closer=closer.mention, closer_name=closer.name)
    v["close_reason"] = close_reason or (ticket or {}).get("close_reason") or "No reason provided"

    v["ticket_reason"] = (answers[0][1] if answers else "") or "No reason provided"
    v["ticket_answers"] = "\n".join(f"**{q}**\n{a or '-'}" for q, a in answers) if answers else "No answers provided"
    for i in range(1, 6):
        v[f"ticket_answer_{i}"] = answers[i - 1][1] if len(answers) >= i and answers[i - 1][1] else "N/A"
    return v


def render(text: Optional[str], values: dict[str, str]) -> str:
    """Replace every known `{variable}`; unknown ones are left as typed."""
    lowered = {k.lower(): str(val) for k, val in values.items()}

    def swap(match: re.Match) -> str:
        name = match.group(1).lower()
        return lowered.get(name, match.group(0))

    return _VAR.sub(swap, text or "")


def help_pages(per_page: int = 7) -> list[str]:
    """Pre-formatted text blocks (one per page) for the `ticketvariables` command."""
    pages: list[str] = []
    for group in GROUP_ORDER:
        rows = [(n, d) for g, n, d in VARIABLES if g == group]
        for i in range(0, len(rows), per_page):
            chunk = rows[i:i + per_page]
            head = f"__**{group} Variables**__" + (f" (part {i // per_page + 1})" if len(rows) > per_page else "")
            body = "\n".join(f"> `{{{n}}}`\n> ❯ {d}" for n, d in chunk)
            pages.append(f"{head}\n{body}")
    return pages


def inline_text() -> str:
    """Compact one-block list (every variable, grouped) for the setup dashboard."""
    lines = []
    for group in GROUP_ORDER:
        names = " ".join(f"`{{{n}}}`" for g, n, _ in VARIABLES if g == group)
        lines.append(f"__**{group}**__\n{names}")
    return "\n\n".join(lines)
