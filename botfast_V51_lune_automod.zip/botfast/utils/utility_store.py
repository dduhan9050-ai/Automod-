"""Storage for the Utility module (embeds, sticky messages, reaction roles).

Speed model
-----------
* Everything is loaded into memory once; every read (reaction listener, sticky
  listener, command lookups) is a plain dict access - zero database round trips.
* Writes update memory first and are queued to a single background writer that
  batches many statements into one commit, so a command never waits on SQLite.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sqlite3
from dataclasses import dataclass, field
from typing import Optional

import aiosqlite
import discord

log = logging.getLogger("deathbot.utility")

DB_PATH = "db/utility.db"
OLD_RR_DB = "rr.db"

MAX_EMBEDS = 50
MAX_STICKY = 25
MAX_RR_PER_MESSAGE = 20

# claiming formats for a reaction role panel
FORMATS = {
    "normal": "React to get the role, un-react to lose it.",
    "unique": "Only one role of the panel at a time (picking a new one swaps the old).",
    "verify": "React to get the role. Un-reacting does not remove it.",
    "reverse": "React to lose the role, un-react to get it back.",
}

_SCHEMA = (
    "CREATE TABLE IF NOT EXISTS embeds (guild_id INTEGER, name TEXT, data TEXT, PRIMARY KEY (guild_id, name))",
    "CREATE TABLE IF NOT EXISTS sticky (channel_id INTEGER PRIMARY KEY, guild_id INTEGER, content TEXT, message_id INTEGER DEFAULT 0)",
    "CREATE TABLE IF NOT EXISTS rr_panels (message_id INTEGER PRIMARY KEY, guild_id INTEGER, channel_id INTEGER DEFAULT 0, "
    "format TEXT DEFAULT 'normal', maxroles INTEGER DEFAULT 0)",
    "CREATE TABLE IF NOT EXISTS rr_items (message_id INTEGER, ekey TEXT, display TEXT, role_id INTEGER, PRIMARY KEY (message_id, ekey))",
    "CREATE INDEX IF NOT EXISTS rr_panels_guild ON rr_panels (guild_id)",
)


# ------------------------------------------------------------------ helpers
def emoji_key(emoji) -> str:
    """Stable key for an emoji: the id for custom emoji, the bare unicode otherwise."""
    if isinstance(emoji, str):
        emoji = discord.PartialEmoji.from_str(emoji.strip())
    if emoji.id:
        return str(emoji.id)
    return (emoji.name or "").replace("️", "")


@dataclass
class Panel:
    message_id: int
    guild_id: int
    channel_id: int = 0
    format: str = "normal"
    maxroles: int = 0
    roles: dict = field(default_factory=dict)  # ekey -> (display, role_id)

    def role_ids(self) -> set:
        return {rid for _, rid in self.roles.values()}

    def jump(self) -> Optional[str]:
        if not self.channel_id:
            return None
        return f"https://discord.com/channels/{self.guild_id}/{self.channel_id}/{self.message_id}"


@dataclass
class Sticky:
    channel_id: int
    guild_id: int
    content: str
    message_id: int = 0

    def jump(self) -> Optional[str]:
        if not self.message_id:
            return None
        return f"https://discord.com/channels/{self.guild_id}/{self.channel_id}/{self.message_id}"


class UtilityStore:
    def __init__(self) -> None:
        self.embeds: dict[int, dict[str, dict]] = {}
        self.sticky: dict[int, Sticky] = {}
        self.panels: dict[int, Panel] = {}
        self._loaded = False
        self._lock: Optional[asyncio.Lock] = None
        self._queue: Optional[asyncio.Queue] = None
        self._writer: Optional[asyncio.Task] = None

    # ----------------------------------------------------------------- load
    async def load(self) -> None:
        if self._loaded:
            return
        if self._lock is None:
            self._lock = asyncio.Lock()
        async with self._lock:
            if self._loaded:
                return
            os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
            async with aiosqlite.connect(DB_PATH) as db:
                for stmt in _SCHEMA:
                    await db.execute(stmt)
                await db.commit()
                async with db.execute("SELECT guild_id, name, data FROM embeds") as cur:
                    for gid, name, data in await cur.fetchall():
                        try:
                            self.embeds.setdefault(gid, {})[name] = json.loads(data)
                        except ValueError:
                            continue
                async with db.execute("SELECT channel_id, guild_id, content, message_id FROM sticky") as cur:
                    for cid, gid, content, mid in await cur.fetchall():
                        self.sticky[cid] = Sticky(cid, gid, content or "", mid or 0)
                async with db.execute("SELECT message_id, guild_id, channel_id, format, maxroles FROM rr_panels") as cur:
                    for mid, gid, cid, fmt, mx in await cur.fetchall():
                        self.panels[mid] = Panel(mid, gid, cid or 0, fmt or "normal", mx or 0)
                async with db.execute("SELECT message_id, ekey, display, role_id FROM rr_items") as cur:
                    for mid, key, display, rid in await cur.fetchall():
                        panel = self.panels.get(mid)
                        if panel:
                            panel.roles[key] = (display, rid)
            self._queue = asyncio.Queue()
            self._writer = asyncio.ensure_future(self._write_loop())
            self._migrate_old_reaction_roles()
            self._loaded = True

    def _migrate_old_reaction_roles(self) -> None:
        """Import the reaction roles of the removed `createrr` system once."""
        if not os.path.exists(OLD_RR_DB):
            return
        try:
            con = sqlite3.connect(OLD_RR_DB)
            rows = con.execute("SELECT guild_id, message_id, emoji, role_id FROM reaction_roles").fetchall()
            con.close()
        except sqlite3.Error:
            return
        for gid, mid, emoji, rid in rows:
            try:
                key = emoji_key(emoji)
            except Exception:
                continue
            if not key:
                continue
            panel = self.panels.get(mid)
            if panel is None:
                panel = self.panel_create(gid, mid, 0)
            if key not in panel.roles:
                self.item_set(panel, key, emoji, rid)
        try:
            os.replace(OLD_RR_DB, OLD_RR_DB + ".migrated")
        except OSError:
            pass

    # --------------------------------------------------------------- writer
    def write(self, sql: str, params: tuple = ()) -> None:
        if self._queue is not None:
            self._queue.put_nowait((sql, params))

    async def _write_loop(self) -> None:
        queue = self._queue
        while True:
            batch = [await queue.get()]
            while not queue.empty() and len(batch) < 200:
                batch.append(queue.get_nowait())
            try:
                async with aiosqlite.connect(DB_PATH) as db:
                    for sql, params in batch:
                        await db.execute(sql, params)
                    await db.commit()
            except Exception:
                log.exception("utility store: write batch failed")
            finally:
                for _ in batch:
                    queue.task_done()

    async def flush(self) -> None:
        if self._queue is not None:
            await self._queue.join()

    # --------------------------------------------------------------- embeds
    def embeds_of(self, guild_id: int) -> dict[str, dict]:
        return self.embeds.get(guild_id) or {}

    def get_embed(self, guild_id: int, name: str) -> Optional[dict]:
        return self.embeds.get(guild_id, {}).get(name.lower())

    def save_embed(self, guild_id: int, name: str, data: dict) -> None:
        name = name.lower()
        self.embeds.setdefault(guild_id, {})[name] = data
        self.write("INSERT OR REPLACE INTO embeds (guild_id, name, data) VALUES (?, ?, ?)",
                   (guild_id, name, json.dumps(data, separators=(",", ":"))))

    def delete_embed(self, guild_id: int, name: str) -> bool:
        name = name.lower()
        if self.embeds.get(guild_id, {}).pop(name, None) is None:
            return False
        self.write("DELETE FROM embeds WHERE guild_id = ? AND name = ?", (guild_id, name))
        return True

    def rename_embed(self, guild_id: int, old: str, new: str) -> None:
        old, new = old.lower(), new.lower()
        data = self.embeds[guild_id].pop(old)
        self.embeds[guild_id][new] = data
        self.write("DELETE FROM embeds WHERE guild_id = ? AND name = ?", (guild_id, old))
        self.write("INSERT OR REPLACE INTO embeds (guild_id, name, data) VALUES (?, ?, ?)",
                   (guild_id, new, json.dumps(data, separators=(",", ":"))))

    # --------------------------------------------------------------- sticky
    def guild_sticky(self, guild_id: int) -> list[Sticky]:
        return [s for s in self.sticky.values() if s.guild_id == guild_id]

    def sticky_save(self, rec: Sticky) -> None:
        self.sticky[rec.channel_id] = rec
        self.write("INSERT OR REPLACE INTO sticky (channel_id, guild_id, content, message_id) VALUES (?, ?, ?, ?)",
                   (rec.channel_id, rec.guild_id, rec.content, rec.message_id))

    def sticky_message(self, rec: Sticky, message_id: int) -> None:
        rec.message_id = message_id
        self.write("UPDATE sticky SET message_id = ? WHERE channel_id = ?", (message_id, rec.channel_id))

    def sticky_delete(self, channel_id: int) -> Optional[Sticky]:
        rec = self.sticky.pop(channel_id, None)
        if rec:
            self.write("DELETE FROM sticky WHERE channel_id = ?", (channel_id,))
        return rec

    # ------------------------------------------------------- reaction roles
    def guild_panels(self, guild_id: int) -> list[Panel]:
        return [p for p in self.panels.values() if p.guild_id == guild_id]

    def panel_create(self, guild_id: int, message_id: int, channel_id: int) -> Panel:
        panel = Panel(message_id, guild_id, channel_id)
        self.panels[message_id] = panel
        self.panel_save(panel)
        return panel

    def panel_save(self, panel: Panel) -> None:
        self.write("INSERT OR REPLACE INTO rr_panels (message_id, guild_id, channel_id, format, maxroles) VALUES (?, ?, ?, ?, ?)",
                   (panel.message_id, panel.guild_id, panel.channel_id, panel.format, panel.maxroles))

    def panel_delete(self, message_id: int) -> Optional[Panel]:
        panel = self.panels.pop(message_id, None)
        if panel:
            self.write("DELETE FROM rr_items WHERE message_id = ?", (message_id,))
            self.write("DELETE FROM rr_panels WHERE message_id = ?", (message_id,))
        return panel

    def item_set(self, panel: Panel, key: str, display: str, role_id: int) -> None:
        panel.roles[key] = (display, role_id)
        self.write("INSERT OR REPLACE INTO rr_items (message_id, ekey, display, role_id) VALUES (?, ?, ?, ?)",
                   (panel.message_id, key, display, role_id))

    def item_delete(self, panel: Panel, key: str) -> None:
        panel.roles.pop(key, None)
        self.write("DELETE FROM rr_items WHERE message_id = ? AND ekey = ?", (panel.message_id, key))


store = UtilityStore()
