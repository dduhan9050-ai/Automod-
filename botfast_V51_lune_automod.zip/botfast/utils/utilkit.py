"""Shared helpers for the Utility module: embed data, variables and white (#ffffff) V2 rendering."""
from __future__ import annotations

import copy
import json
import re
import time
from typing import Any, Optional

import discord

from components_v2 import media_gallery
WHITE = discord.Colour(0xFFFFFF)
TICK = "<:emoji_4:1566043104551768114>"
CROSS = "<a:emoji_38:1567096105299214336>"
CORNER = "╰"

EMBED_TOTAL_LIMIT = 6000
MAX_FIELDS = 25
_URL = re.compile(r"^https?://\S+$", re.I)
_NAME = re.compile(r"^[\w-]{1,32}$")
_VAR = re.compile(r"\{([A-Za-z_]+)\}")

# (variable, description) - the names used by the welcome / greet systems
VARIABLES: tuple[tuple[str, str], ...] = (
    ("user", "Mentions the user."),
    ("user_name", "The user's username."),
    ("user_id", "The user's ID."),
    ("user_nick", "The user's display name in the server."),
    ("user_avatar", "The user's avatar URL."),
    ("user_joindate", "Date the user joined the server."),
    ("user_createdate", "Date the user's account was created."),
    ("server_name", "The server's name."),
    ("server_id", "The server's ID."),
    ("server_membercount", "Total members in the server."),
    ("server_icon", "The server's icon URL."),
)


# ------------------------------------------------------------------ cards
def td(text: str) -> discord.ui.TextDisplay:
    return discord.ui.TextDisplay((text or "​")[:3990])


def card(*children: Any) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView(timeout=None)
    box = discord.ui.Container(accent_colour=WHITE)
    for child in children:
        box.add_item(td(child) if isinstance(child, str) else child)
    view.add_item(box)
    return view


def result(title: str, text: str, icon: str = TICK) -> discord.ui.LayoutView:
    """`<:emoji_4:1566043104551768114> **Title**` + `╰ text` - the success / failure card used by every command."""
    return card(f"{icon} **{title}**\n{CORNER} {text}")


# --------------------------------------------------------------- variables
def apply_vars(text: Optional[str], member: Optional[discord.abc.User] = None,
               guild: Optional[discord.Guild] = None) -> Optional[str]:
    if not text or "{" not in text:
        return text
    guild = guild or getattr(member, "guild", None)

    def value(key: str) -> Optional[str]:
        if member is not None:
            if key == "user":
                return member.mention
            if key == "user_name":
                return member.name
            if key == "user_id":
                return str(member.id)
            if key == "user_nick":
                return member.display_name
            if key == "user_avatar":
                return member.display_avatar.url
            if key == "user_joindate":
                joined = getattr(member, "joined_at", None)
                return joined.strftime("%d %b %Y") if joined else None
            if key == "user_createdate":
                return member.created_at.strftime("%d %b %Y")
        if guild is not None:
            if key == "server_name":
                return guild.name
            if key == "server_id":
                return str(guild.id)
            if key == "server_membercount":
                return str(guild.member_count or len(guild.members))
            if key == "server_icon":
                return guild.icon.url if guild.icon else None
        return None

    return _VAR.sub(lambda m: value(m.group(1).lower()) or m.group(0), text)


# ----------------------------------------------------------- embed data
def new_embed() -> dict:
    return {"fields": [], "timestamp": False}


def valid_name(name: str) -> bool:
    return bool(_NAME.match(name or ""))


def valid_url(url: str) -> bool:
    return bool(_URL.match(url or ""))


def parse_color(text: str) -> Optional[int]:
    text = (text or "").strip().lstrip("#")
    if text.lower().startswith("0x"):
        text = text[2:]
    if not text:
        return None
    if not re.fullmatch(r"[0-9a-fA-F]{6}", text):
        raise ValueError("Color must be a 6 digit hex value like `#ffffff`.")
    return int(text, 16)


def check_url(url: str, what: str) -> str:
    url = (url or "").strip()
    if url and not valid_url(url):
        raise ValueError(f"{what} must be a valid `http(s)://` link.")
    return url


def embed_size(d: dict) -> int:
    total = len(d.get("title") or "") + len(d.get("description") or "")
    total += len((d.get("footer") or {}).get("text") or "") + len((d.get("author") or {}).get("name") or "")
    for f in d.get("fields") or ():
        total += len(f.get("name") or "") + len(f.get("value") or "")
    return total


def is_blank(d: dict) -> bool:
    return not (d.get("title") or d.get("description") or d.get("fields") or d.get("image")
                or d.get("thumbnail") or (d.get("author") or {}).get("name") or (d.get("footer") or {}).get("text"))


def validate(d: dict) -> dict:
    """Raise ValueError if ``d`` would be rejected by Discord."""
    if len(d.get("title") or "") > 256:
        raise ValueError("Title can be at most 256 characters.")
    if len(d.get("description") or "") > 4000:
        raise ValueError("Description can be at most 4000 characters.")
    if len(d.get("fields") or ()) > MAX_FIELDS:
        raise ValueError(f"An embed can have at most {MAX_FIELDS} fields.")
    if embed_size(d) > EMBED_TOTAL_LIMIT:
        raise ValueError(f"The embed is too large ({embed_size(d)}/{EMBED_TOTAL_LIMIT} characters).")
    return d


def normalize(raw: Any) -> dict:
    """Turn a Discord-style embed dict / JSON (``embeds`` list allowed) into the stored shape."""
    if isinstance(raw, list):
        raw = raw[0] if raw else {}
    if isinstance(raw, dict) and isinstance(raw.get("embeds"), list) and raw["embeds"]:
        raw = raw["embeds"][0]
    if not isinstance(raw, dict):
        raise ValueError("The JSON must be an embed object.")

    def url_of(value: Any) -> str:
        if isinstance(value, dict):
            value = value.get("url")
        return check_url(value if isinstance(value, str) else "", "URL")

    out = new_embed()
    for key, limit in (("title", 256), ("description", 4000)):
        value = raw.get(key)
        if isinstance(value, str) and value.strip():
            out[key] = value[:limit]
    out["url"] = url_of(raw.get("url")) or None
    color = raw.get("color", raw.get("colour"))
    if isinstance(color, int) and 0 <= color <= 0xFFFFFF:
        out["color"] = color
    elif isinstance(color, str) and color.strip():
        out["color"] = parse_color(color)
    for key in ("thumbnail", "image"):
        if (u := url_of(raw.get(key))):
            out[key] = u
    footer = raw.get("footer")
    if isinstance(footer, str):
        footer = {"text": footer}
    if isinstance(footer, dict) and (footer.get("text") or "").strip():
        out["footer"] = {"text": footer["text"][:2048], "icon_url": check_url(footer.get("icon_url") or "", "Footer icon") or None}
    author = raw.get("author")
    if isinstance(author, str):
        author = {"name": author}
    if isinstance(author, dict) and (author.get("name") or "").strip():
        out["author"] = {"name": author["name"][:256], "icon_url": check_url(author.get("icon_url") or "", "Author icon") or None,
                         "url": check_url(author.get("url") or "", "Author URL") or None}
    ts = raw.get("timestamp")
    out["timestamp"] = bool(ts) and ts not in ("false", "False", "0")
    fields = raw.get("fields")
    if isinstance(fields, list):
        for f in fields[:MAX_FIELDS]:
            if isinstance(f, dict) and str(f.get("name") or "").strip() and str(f.get("value") or "").strip():
                out["fields"].append({"name": str(f["name"])[:256], "value": str(f["value"])[:1024],
                                      "inline": bool(f.get("inline", False))})
    out = {k: v for k, v in out.items() if v not in (None, "")} | {"fields": out["fields"], "timestamp": out["timestamp"]}
    return validate(out)


def from_message_embed(embed: discord.Embed) -> dict:
    return normalize(embed.to_dict())


def to_json(d: dict) -> str:
    out = copy.deepcopy(d)
    return json.dumps(out, indent=2, ensure_ascii=False)


def parse_json_text(text: str) -> dict:
    text = (text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\n?|```$", "", text).strip()
    try:
        return normalize(json.loads(text))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON: {exc.msg} (line {exc.lineno}).") from None


# ----------------------------------------------------------------- render
def _chunks(text: str, limit: int = 3900) -> list[str]:
    text = text or "​"
    return [text[i:i + limit] for i in range(0, len(text), limit)] or ["​"]


def embed_container(d: dict, member: Optional[discord.abc.User] = None, guild: Optional[discord.Guild] = None,
                    *, preview: bool = False) -> discord.ui.Container:
    """Render a stored embed as one white (#ffffff) Components V2 container."""
    sub = lambda t: apply_vars(t, member, guild) if not preview else t  # noqa: E731
    parts: list[str] = []
    author = d.get("author") or {}
    if author.get("name"):
        name = sub(author["name"])
        parts.append(f"**[{name}]({author['url']})**" if author.get("url") else f"**{name}**")
    if d.get("title"):
        title = sub(d["title"])
        parts.append(f"# [{title}]({d['url']})" if d.get("url") else f"# {title}")
    if d.get("description"):
        parts.append(sub(d["description"]))
    for f in d.get("fields") or ():
        parts.append(f"**{sub(f['name'])}**\n{sub(f['value'])}")
    foot = []
    if (d.get("footer") or {}).get("text"):
        foot.append(sub(d["footer"]["text"]))
    if d.get("timestamp"):
        foot.append(f"<t:{int(time.time())}:f>")
    if foot:
        parts.append("-# " + " • ".join(foot))

    box = discord.ui.Container(accent_colour=WHITE)
    chunks = _chunks("\n\n".join(parts) if parts else "*Empty embed - use the dropdown to edit it.*")
    thumb = d.get("thumbnail")
    if thumb:
        box.add_item(discord.ui.Section(*[discord.ui.TextDisplay(c) for c in chunks[:3]],
                                        accessory=discord.ui.Thumbnail(media=thumb)))
        chunks = chunks[3:]
    for c in chunks[:8]:
        box.add_item(discord.ui.TextDisplay(c))
    if d.get("image"):
        box.add_item(media_gallery(d["image"]))
    return box


def embed_view(d: dict, member: Optional[discord.abc.User] = None, guild: Optional[discord.Guild] = None,
               *, extra_text: Optional[str] = None) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView(timeout=None)
    if extra_text:
        view.add_item(discord.ui.TextDisplay(extra_text[:3990]))
    view.add_item(embed_container(d, member, guild))
    return view


_EMBED_TOKEN = re.compile(r"\{embed:([\w-]{1,32})\}", re.I)


def split_embed_token(text: str) -> tuple[str, Optional[str]]:
    """'hello {embed:rules}' -> ('hello', 'rules')."""
    m = _EMBED_TOKEN.search(text or "")
    if not m:
        return text, None
    return (_EMBED_TOKEN.sub("", text, count=1)).strip(), m.group(1).lower()
